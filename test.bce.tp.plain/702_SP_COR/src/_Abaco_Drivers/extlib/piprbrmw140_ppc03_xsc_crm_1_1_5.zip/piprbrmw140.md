Types=Bluetooth
Parameters.Bluetooth=Port,Peer,PeerType,KeepAlive,DiscoverTimeout
Bluetooth.PeerType=Name,Address
Bluetooth.KeepAlive=True,False
