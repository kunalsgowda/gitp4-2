Types=DriverParameters,Bluetooth
Parameters.DriverParameters=ScanBufferSize,SkipInvalidScan,OpenDelay
DriverParameters.ScanBufferSize=2048
DriverParameters.SkipInvalidScan=true
DriverParameters.OpenDelay=6000
Parameters.Bluetooth=BTScannerName
