package com.sap.ip.me.mdk.pios.docgen;

import java.net.*;
import org.eclipse.ui.*;
import org.eclipse.ui.plugin.*;
import org.eclipse.core.runtime.*;
import org.eclipse.jface.resource.*;
import org.eclipse.jface.viewers.*;
import org.eclipse.core.resources.*;

import com.sap.ip.me.mdk.pios.docgen.editors.*;

/**
 * The main Document Generator plugin class.
 * Provides general helper methods for the Document Generator.
 * @author Abaco
 */

public class DocumentGeneratorPlugin extends AbstractUIPlugin {

	public static final String ID = "com.sap.ip.me.mdk.pios.docgen";
	public static final String APP_ROOT = "app-root";
	public static final String DOCUMENT_NAME = "DriverRequirementDocument.xml";
	public static final String MDK_PLUGIN_ID = "com.sap.ip.me.mdk.developmentTools";

	//The shared instance.
	private static DocumentGeneratorPlugin plugin;

	/**
	 * Creates a new instance of this class.
	 * @param descriptor The plugin descriptor.
	 */
	public DocumentGeneratorPlugin(IPluginDescriptor descriptor) {
		super(descriptor);
		plugin = this;

		//Load the peripheral templates into memory
		PeripheralManager.getInstance();

	}

	/**
	 * Returns the shared instance of this class.
	 * @return the shared instance of this class.
	 */
	public static DocumentGeneratorPlugin getDefault() {
		return plugin;
	}

	/**
	 * Returns the ImageDescriptor object for the received image.
	 * @param imageName The image to process.
	 * @return The ImageDescriptor object for the received image.
	 */
	public ImageDescriptor getImageDescriptor(String imageName) {
		URL imageURL = find(new Path(imageName));
		if (imageURL == null) {
			return null;
		}
		return ImageDescriptor.createFromURL(imageURL);
	}

	/**
	 * Returns the project from the received selection. If no project
	 * is found then null is returned.
	 * @param selection The current selection.
	 * @return the project from the received selection. If no project
	 * is found then null is returned.
	 */
	public IProject getProject(IStructuredSelection selection) {

		IProject project = null;
		if (selection != null && selection.isEmpty() == false) {
			Object obj = selection.getFirstElement();
			if (obj instanceof IAdaptable) {

				IProject proj = (IProject) ((IAdaptable) obj).getAdapter(IProject.class);

				if (proj != null) {
					if (proj.isOpen()) {
						project = proj;
					}
				} else if (obj instanceof IFile) {
					IFile file = (IFile) ((IAdaptable) obj).getAdapter(IFile.class);
					project = file.getProject();
				} else if (obj instanceof IFolder) {
					IFolder folder = (IFolder) ((IAdaptable) obj).getAdapter(IFolder.class);
					project = folder.getProject();
				}

			}
		} else {
			//If there is nothing in the tree selected then check if a Driver Requirements Document editor is selected.
			IWorkbenchPart workbenchPart =
				PlatformUI
					.getWorkbench()
					.getActiveWorkbenchWindow()
					.getActivePage()
					.getActivePart();
			if (workbenchPart instanceof DRDEditor) {
				project = ((DRDEditor) workbenchPart).getDriverRequirementsDocument().getProject();
			}
		}

		return project;
	}

	/**
	 * Adds a the received information to the eclipse log.
	 * @param message The error message.
	 * @param exception The exception of the error.
	 */
	public void logError(String message, Throwable exception) {
		getLog().log(new Status(Status.ERROR, ID, Status.OK, message, exception));
	}

	/**
	 * Returns a reference to the DriverRequirements Document Editor opened.
	 * If this editor is not opened then null is returned.
	 * @param project The project for wich to get the DRD Editor.
	 * @return a reference to the DriverRequirements Document Editor opened.
	 */
	public DRDEditor getDRDEditor(IProject project) {

		DRDEditor drdEditor = null;

		IWorkbenchWindow[] workbenchWindows = PlatformUI.getWorkbench().getWorkbenchWindows();

		if (workbenchWindows != null) {

			//Check all the open workbench windows for the Driver Requirements Editor 			
			for (int i = 0; i < workbenchWindows.length; i++) {

				IWorkbenchPage[] workbenchPages = workbenchWindows[i].getPages();

				for (int n = 0; n < workbenchPages.length; n++) {

					IEditorReference[] editorReferences = workbenchPages[n].getEditorReferences();

					for (int j = 0; j < editorReferences.length; j++) {

						//If the current editor is a Driver Requirements Document editor
						if (editorReferences[j].getEditor(false) instanceof DRDEditor) {

							DRDEditor drdEditorTmp =
								(DRDEditor) editorReferences[j].getEditor(false);

							//If this editor is the editor of the file being edited.
							if (project
								== drdEditorTmp.getDriverRequirementsDocument().getProject()) {
								drdEditor = drdEditorTmp;
							}
						}
					}
				}
			}
		}
		return drdEditor;
	}

	/**
	 * Close the DRDEditor for the specified project. If there is no editor opened for 
	 * the project then nothing happens.
	 * @param project The project for which to close the project.
	 */
	public void closeDRDEditorForProject(IProject project) {
		try {

			//Close the editor.
			final DRDEditor drdEditor = getDRDEditor(project);
			if (drdEditor != null) {
				drdEditor.getEditorSite().getShell().getDisplay().asyncExec(new Runnable() {
					public void run() {
						IWorkbenchPage workbenchPage =
							PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
						workbenchPage.closeEditor(drdEditor, false);
					}
				});
			}

		} catch (Exception ex) {
			//If any error occured then log it and keep going.
			DocumentGeneratorPlugin.getDefault().logError(
				"Error closing the Driver Requirements Document",
				ex);
		}
	}
	
	/**
	 * Get the path of the Driver Requirements Document in this project.  If the 
	 * app-root folder does not exists then it is created.
	 * @param project The project
	 * @return The path of the Driver Requirements Document in this project.
	 * @throws DocumentGeneratorException
	 */
	public IFile getDRDFile(IProject project) throws DocumentGeneratorException {

		IFolder folder = project.getFolder(APP_ROOT);
		
		if (!folder.exists()) {
			try {
				folder.create(true, true, null);
			} catch (CoreException ex) {
				// $JL-EXC$
				logError("Error creating 'app-root' folder.", ex);
				throw new DocumentGeneratorException("Error creating 'app-root' folder");
			}
		}
		
		return folder.getFile(new Path(DocumentGeneratorPlugin.DOCUMENT_NAME));
	}
	
	/**
	 * Returns true if the Driver Requirements Document file exists in the specified project. 
	 * @param project The project to search
	 * @return true if the Driver Requirements Document file exists in the specified project.
	 */
	public boolean containsDRD(IProject project) {
		
		IFolder folder = project.getFolder(APP_ROOT);
		
		if (!folder.exists()) {
			return false;
		}
		
		IFile drdFile = folder.getFile(new Path(DocumentGeneratorPlugin.DOCUMENT_NAME));
		
		return drdFile.exists();

	}
}
