package com.sap.ip.me.mdk.pios.docgen.actions;

import java.io.*;

import org.eclipse.ui.*;
import org.eclipse.jface.action.*;
import org.eclipse.core.runtime.*;
import org.eclipse.jface.viewers.*;
import org.eclipse.jface.dialogs.*;

import com.sap.ip.me.mdk.pios.docgen.*;

/**
 * Represents the Document Generator Launch Emulator toolbar action.
 * @author Abaco
 */

public class LaunchEmulatorAction implements IWorkbenchWindowActionDelegate {

	private static boolean emulatorRunning = false;

	private IWorkbenchWindow window;
	private IStructuredSelection selection = null;
	private DocGenResources rb = DocGenResourcesManager.getInstance().getResourceBundle("actions");
	private EmulatorProcess emulatorProc = null;

	/**
	 * Creates a new instance of this class.
	 */
	public LaunchEmulatorAction() {}

	public void init(IWorkbenchWindow window) {
		this.window = window;
	}

	public void dispose() {}

	public void selectionChanged(IAction action, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
			this.selection = (IStructuredSelection) selection;
		}
	}

	public void run(IAction action) {

		//Validate that the emulator is not already running
		if (emulatorRunning) {
			MessageDialog.openError(
				null,
				rb.getString("launch_emulator.error_dialog.tittle"),
				rb.getString("launch_emulator.error_dialog.emulator_already_running"));
			return;
		}

		//Start the Peripheral I/O Emulator.
		String javaHome =
			System.getProperty("java.home") + File.separator + "bin" + File.separator + "javaw";
		emulatorProc =
			new EmulatorProcess(
				javaHome,
				DocumentGeneratorPlugin.getDefault().find(new Path("emulator")).getPath());
		emulatorProc.start();

	}

	/**
	 * This thread is used to start the emulator process and manage the
	 * lifetime of the emulator.
	 * @author Abaco
	 */
	class EmulatorProcess extends Thread {

		private String javaExec = null;
		private String emulatorHome = null;

		/**
		 * Creates a new instance of the emulator.
		 * @param javaExec The java executable path.
		 * @param emulatorHome The path of the emulator installation.
		 */
		public EmulatorProcess(String javaExec, String emulatorHome) {

			this.javaExec = javaExec;
			this.emulatorHome = emulatorHome;
		}

		public void run() {

			try {
				//Start the emulator
				Process proc =
					Runtime.getRuntime().exec(
						javaExec
							+ " -DPERIPHERAL_EMULATOR_HOME=. -cp .\\startup.jar pios.emulator.utils.StaticClassLoader .\\lib pios.emulator.PEmulator ",
						null,
						new File(emulatorHome));

				emulatorRunning = true;

				//Set the shutdown hook
				Runtime.getRuntime().addShutdownHook(new EmulatorShutdownProcess(proc));

				//Wait this thread until the emulator is closed.
				proc.waitFor();
				emulatorRunning = false;

			} catch (IOException ex) {
				// $JL-EXC$
				MessageDialog.openError(
					null,
					rb.getString("launch_emulator.error_dialog.tittle"),
					rb.getString(
						"launch_emulator.error_dialog.error_launching_emulator",
						new String[] { ex.getMessage()}));
			} catch (InterruptedException ex) {
				DocumentGeneratorPlugin.getDefault().logError("Thread interrupted by another tread. EmulatorRunning set a False.", ex);
				emulatorRunning = false;
			}
		}
	}

	/**
	 * Shutdown hook implementation to close the emulator when eclipse is closed.
	 * @author Abaco
	 */
	class EmulatorShutdownProcess extends Thread {

		private Process proc = null;

		/**
			 * Creates a new instnace of this class. 
			 * @param proc The emulator process.
			 */
		public EmulatorShutdownProcess(Process proc) {
			this.proc = proc;
		}

		public void run() {
			if (emulatorRunning) {

				//Send the close command to the emulator.
				BufferedOutputStream bos = new BufferedOutputStream(proc.getOutputStream());
				byte[] cmd = { 'c', 'l', 'o', 's', 'e' };
				try {
					bos.write(cmd);
					bos.flush();
					emulatorRunning = false;
				} catch (IOException e) {
					DocumentGeneratorPlugin.getDefault().logError( "Unable to send the close command to the emulator.", e);
				}
			}
		}
	}
}
