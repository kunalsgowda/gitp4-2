package com.sap.ip.me.mdk.pios.docgen.attributes;

import java.util.*;

import com.sap.ip.me.mdk.pios.docgen.*;

/**
 * Represents an Option node in the Driver Requirements Document.
 * An Option object is a child to the Property object. Options do not contain any child objects.
 * @author Abaco 
 */

public class Option extends Attribute {

	/**
	 * Creates a new instance of this class.
	 * @param optionName The name of this option.
	 * @param parent The Property parent for this option.
	 */
	public Option(String optionName, Property parent) {
		super();
		super.name = optionName;
		super.parent = parent;
	}

	protected ResourceBundle getResourceBundle() {
		//The resource bundle for this option is the same as the Peripheral one.
		return parent.getResourceBundle();
	}

	/**
	 * Returns the String representation of the xml node for this option.
	 * @return The String representation of the xml node for this option. 
	 */
	protected String ToXml() {
		StringBuffer sXml = new StringBuffer("<" + DriverRequirementsDocument.PERIPHERAL_OPTION + " ");
		sXml.append(DriverRequirementsDocument.PERIPHERAL_ATTRIB_NAME + "=\"" + getName() + "\" ");
		String sSupp = isRequired() ? "yes": "no" ;
		sXml.append(DriverRequirementsDocument.PERIPHERAL_ATTRIB_REQUIRED + "=\"" + sSupp + "\"" );

		sXml.append(">" );

		sXml.append( "</" + DriverRequirementsDocument.PERIPHERAL_OPTION + ">" );
	
		return sXml.toString();
	}


	public String toString() {
		return getDescription();
	}
}