package com.sap.ip.me.mdk.pios.docgen;

import java.io.*;
import java.util.*;
import org.xml.sax.*;
import org.eclipse.core.resources.*;
import org.eclipse.core.runtime.*;

import com.sap.ip.me.mdk.pios.docgen.attributes.*;

/**
 * Represents a Driver Requirements Document. 
 * @author Abaco
 */

public class DriverRequirementsDocument {

	public static final String PERIPHERALS = "peripherals";
	public static final String VERSION = "version";
	public static final String PERIPHERAL = "peripheral";
	public static final String PERIPHERAL_TYPE = "type";
	public static final String PERIPHERAL_PROP = "prop";
	public static final String PERIPHERAL_ATTRIB_REQUIRED = "required";
	public static final String PERIPHERAL_ATTRIB_NAME = "name";
	public static final String PERIPHERAL_OPTION = "option";

	private ArrayList peripheralList;
	private DocGenResources rb =
		DocGenResourcesManager.getInstance().getResourceBundle("document_generator");
	private IProject project = null;
	private boolean isDirty = false;
	private String version = null;

	/**
	 * Creates a new instance of this class.
	 * An empty Driver Requirements Document is created.
	 * @param project The eclipse project containing this Driver Requirements Document. 
	 */
	public DriverRequirementsDocument(IProject project) {
		peripheralList = new ArrayList();
		this.project = project;
	}

	/**
	 * Creates a new instance of this class. The peripherals for this document are
	 * read from the specified stream.
	 * @param drdInStream An input stream of an existing Driver Requirements Document.
	 * @param project The eclipse project containing this Driver Requirements Document.
	 * @throws DocumentGeneratorException
	 */
	public DriverRequirementsDocument(InputStream drdInStream, IProject project)
		throws DocumentGeneratorException {

		if (drdInStream == null) {
			throw new DocumentGeneratorException("Invalid Driver Requirements Document input stream.");
		}

		//Parse Xml and create Peripheral Req List
		DriverRequirementsDocumentParser parser = new DriverRequirementsDocumentParser(rb);
		peripheralList = parseDocument(parser, drdInStream);
		this.version = parser.getVersion();
		this.project = project;
		this.isDirty = parser.isDirty();

	}

	/**
	 * Adds the specified peripheral to this document. The peripheral is added from the
	 * peripheral type template.
	 * @param peripheralName The name of the peripheral to add.
	 * @throws DocumentGeneratorException
	 */
	public void addPeripheral(String peripheralName) throws DocumentGeneratorException {
		// Check if peripheral already exists
		if (getPeripheral(peripheralName) != null) {
			throw new DocumentGeneratorException(
				rb.getString("drd.peripheral_already_exists", new String[] { peripheralName }));
		}

		//Add peripheral from template
		peripheralList.add(getPeripheralFromTemplate(peripheralName));
	}

	/**
	 * Returns the project that contains this Driver Requirements Document.
	 * @return The project that contains this Driver Requirements Document.
	 */
	public IProject getProject() {
		return project;
	}

	/**
	 * Returns the version of this driver requirements document.
	 * @return the version of this driver requirements document.
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Returns a list the Peripheral objects in this document.
	 * @return A list the Peripheral objects in this document.
	 */
	public ArrayList getPeripheralList() {
		return peripheralList;
	}

	/**
	 * Returns true if the specified peripheral exists in this document.
	 * @param peripheralName The name of the peripheral to check.
	 * @return true if the specified peripheral exists in this document, otherwise false.
	 */
	public boolean containsPeripheral(String peripheralName) {
		return getPeripheral(peripheralName) != null;
	}

	/**
	 * Removes the specified peripheral from this document.
	 * @param peripheralName The name of the peripheral to remove.
	 */
	public void removePeripheral(String peripheralName) {
		Peripheral peripheral = getPeripheral(peripheralName);
		if (peripheral != null) {
			peripheralList.remove(peripheral);
		}
	}

	/**
	 * Saves this document into the specified file.
	 * @param file The file to save this document into.
	 * @param monitor The progress monitor for this operation.
	 * @throws DocumentGeneratorException
	 */
	public void save(IFile file, IProgressMonitor monitor) throws DocumentGeneratorException {

		if (file == null) {
			throw new DocumentGeneratorException(rb.getString("drd.save.invalid_file"));
		}

		monitor.subTask(rb.getString("drd.save.monitor.task"));

		// Buffer for the document		
		StringBuffer xmlDocument = new StringBuffer();
		xmlDocument.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		xmlDocument.append("<peripherals version=\"" + DocumentGeneratorPlugin.getDefault().getDescriptor().getVersionIdentifier().toString() + "\">");

		// Go through the Peripheral List
		for (int n = 0; n < peripheralList.size(); n++) {
			Peripheral perreq = (Peripheral) peripheralList.get(n);
			xmlDocument.append(perreq.ToXml());
			monitor.worked(1);
		}
		xmlDocument.append("</peripherals>");

		// Create Stream from Buffer
		ByteArrayInputStream bais = null;
		BufferedInputStream bis = null;
		try {

			// create stream
			bais = new ByteArrayInputStream((xmlDocument.toString().getBytes("UTF-8")));
			bis = new BufferedInputStream(bais);

			if (file.exists()) {
				file.setContents(bis, true, true, null);
			} else {
				file.create(bis, true, null);
			}

		} catch (Exception ex) {
			monitor.setCanceled(true);
			throw new DocumentGeneratorException(
				rb.getString("drd.save.cannot_save", new String[] { file.getName()}),
				ex);
		} finally {
			try {
				bis.close();
			} catch (Exception ex) {
				// $JL-EXC$
			}
			try {
				bais.close();
			} catch (Exception ex) {
				// $JL-EXC$
			}
		}
	}

	/**
	 * Sets the dirty property of this driver requirements document.
	 * @param dirty the new dirty value for this driver requirements document.
	 */
	public void setDirty(boolean dirty) {
		this.isDirty = dirty;
	}

	/**
	 * Returns true if this document has changed, otherwise false.
	 * @return true if this document has changed, otherwise false.
	 */
	public boolean isDirty() {
		return isDirty;
	}

	private Peripheral getPeripheral(String peripheralName) {
		for (int n = 0; n < peripheralList.size(); n++) {
			Peripheral perreq = (Peripheral) peripheralList.get(n);
			if (peripheralName.equalsIgnoreCase(perreq.getName()))
				return perreq;
		}
		return null;
	}

	private ArrayList parseDocument(
		DriverRequirementsDocumentParser parser,
		InputStream drdInStream)
		throws DocumentGeneratorException {

		BufferedInputStream bis = null;
		InputSource is = null;
		ArrayList peripherals = null;
		try {
			bis = new BufferedInputStream(drdInStream);
			is = new InputSource(bis);
			peripherals = parser.parseDoc(is);
		} catch (Exception ex) {
			throw new DocumentGeneratorException("Error parsing Driver Requirements Document", ex);
		} finally {
			try {
				bis.close();
			} catch (Exception ex) {
				// $JL-EXC$
			}
		}
		return peripherals;
	}

	private Peripheral getPeripheralFromTemplate(String peripheralName)
		throws DocumentGeneratorException {

		//Load the new peripheral template
		String templatePath =
			PeripheralManager.getInstance().getPeripheralTemplatePath(peripheralName);
		DriverRequirementsDocumentParser parser = new DriverRequirementsDocumentParser(rb);
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(templatePath);
			ArrayList peripherals = parseDocument(parser, fis);

			if (peripherals.size() > 0) {
				Peripheral peripheral = (Peripheral) peripherals.get(0);
				return peripheral;

			} else {
				throw new DocumentGeneratorException(
					rb.getString(
						"drd.unable_to_parse_peripheral",
						new String[] { peripheralName }));
			}
		} catch (FileNotFoundException ex) {
			throw new DocumentGeneratorException(
				rb.getString("drd.template_not_found", new String[] { peripheralName }),
				ex);
		} finally {
			try {
				fis.close();
			} catch (Exception ex) {
				// $JL-EXC$
			}
		}
	}
}
