package com.sap.ip.me.mdk.pios.docgen;

import java.io.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import org.apache.xerces.parsers.*;

/**
 * Document parser for the peripheral definition information of the 
 * peripheral type template file. 
 * @author Abaco
 */

public class PeripheralInfoHandler extends DefaultHandler {

	private static final String PERIPHERAL_IMAGE = "peripheralImage";	
	private static final String PERIPHERAL_VERSION = "peripheralVersion";	
	private static final String PERIPHERAL_RESOURCE_BUNDLE = "peripheralResourceBundle";	

	String peripheralName = null;
	String peripheralVersion = null;			
	String peripheralResourceBundle = null;
	String peripheralImage = null;

	/**
	 * Creates a new instance of this class.
	 */
	public PeripheralInfoHandler() {
		
	}

	/**
	 * Parses the received Peripheral Type template file.
	 * @param templateFile The Template file to parse. 
	 * @return The PeripheralInfo object for the parsed document. 
	 * @throws DocumentGeneratorException
	 */
	public PeripheralInfo parseDoc(File templateFile) throws DocumentGeneratorException {

		FileInputStream fis = null;
		BufferedInputStream bis = null;
		InputSource is = null;
		
		try {
			fis = new FileInputStream(templateFile);
			bis = new BufferedInputStream(fis);
			is = new InputSource(bis);

			SAXParser parser = new SAXParser();
			parser.setContentHandler(this);
			parser.setErrorHandler(this);
			parser.parse(is);

		} catch (Exception ex) {
			throw new DocumentGeneratorException("Error parsing Peripheral Type Template Document: " + templateFile, ex);
		} finally {
			try { bis.close(); } catch (Exception ex) {
				// $JL-EXC$
			}
			try { fis.close(); } catch (Exception ex) {
				// $JL-EXC$
			}
		}
		
		return new PeripheralInfo(peripheralName, templateFile.getName(), peripheralImage, peripheralVersion, peripheralResourceBundle);
	}

	public void startElement(String uri, String elementName, String qName, Attributes attributes)  {

		if (elementName.equalsIgnoreCase(DriverRequirementsDocument.PERIPHERAL)) {

			peripheralName = attributes.getValue(DriverRequirementsDocument.PERIPHERAL_TYPE);
			peripheralVersion = attributes.getValue(PERIPHERAL_VERSION);		
			peripheralResourceBundle = attributes.getValue(PERIPHERAL_RESOURCE_BUNDLE);
			peripheralImage = attributes.getValue(PERIPHERAL_IMAGE);
		}
	}

}
