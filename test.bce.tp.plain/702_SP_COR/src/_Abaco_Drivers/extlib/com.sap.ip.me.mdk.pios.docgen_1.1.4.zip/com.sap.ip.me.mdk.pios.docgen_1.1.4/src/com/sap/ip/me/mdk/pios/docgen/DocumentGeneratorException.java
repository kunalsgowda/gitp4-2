package com.sap.ip.me.mdk.pios.docgen;

/**
 * Base exception for the Document Generator. 
 * @author Abaco
 */

public class DocumentGeneratorException extends Exception {

	private Throwable cause;

	/**
	 * Creates a new instance of this class.
	 * @param message The exception message.
	 */
	public DocumentGeneratorException(String message) { 
		super(message);
	}
	
	/**
	 * Creates a new instance of this class.
	 * @param message The exception message.
	 * @param cause The cause of this exception.
	 */
	public DocumentGeneratorException(String message, Throwable cause) {
		super(message);
		this.cause = cause;
		
	}

}
