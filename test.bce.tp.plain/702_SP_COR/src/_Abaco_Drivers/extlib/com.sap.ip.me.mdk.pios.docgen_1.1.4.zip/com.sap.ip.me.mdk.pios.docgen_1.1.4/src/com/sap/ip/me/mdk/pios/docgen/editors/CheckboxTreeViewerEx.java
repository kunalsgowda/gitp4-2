package com.sap.ip.me.mdk.pios.docgen.editors;

import org.eclipse.swt.widgets.*;
import org.eclipse.jface.viewers.*;

import com.sap.ip.me.mdk.pios.docgen.attributes.*;

/**
 * Extends the CheckboxTreeViewer for adding gray and check functionality.
 */
public class CheckboxTreeViewerEx extends CheckboxTreeViewer {

	/**
	 * Constructor for CheckboxTreeViewerEx.
	 * @param parent
	 */
	public CheckboxTreeViewerEx(Composite parent) {
		super(parent);
	}

	/**
	 * Constructor for CheckboxTreeViewerEx.
	 * @param parent
	 * @param style
	 */
	public CheckboxTreeViewerEx(Composite parent, int style) {
		super(parent, style);
	}

	/**
	 * Constructor for CheckboxTreeViewerEx.
	 * @param tree
	 */
	public CheckboxTreeViewerEx(Tree tree) {
		super(tree);
	}

	/**
	 * Method declared in TreeViewer. Ask for Check and Grayed
	 */
	protected void doUpdateItem(Item item, Object element) {
		super.doUpdateItem(item, element);
		super.setChecked(element, ((Attribute) element).isRequired());

		if (element instanceof Property) {

			if (((Property) element).isPartiallyRequired()) {
				super.setGrayChecked(element, true);
			} else {
				super.setGrayChecked(element, false);
				super.setChecked(element, ((Property) element).isRequired());
			}				
		} else if (element instanceof Peripheral) {
			
			if (((Peripheral) element).isPartiallyRequired()) {
				super.setGrayChecked(element, true);
			} else {
				super.setGrayChecked(element, false);
				super.setChecked(element, ((Peripheral) element).isRequired());
			}				
		}
	}
}

