package com.sap.ip.me.mdk.pios.docgen.attributes;

import java.util.*;

/**
 * Base class for all the Peripheral Type Attribute classes.
 * @author Abaco 
 */

public abstract class Attribute {

	protected String name = null;
	protected boolean isRequired = false;
	protected Attribute parent = null;
	protected boolean isPartiallyRequired = false;

	/**
	 * Creates a new instance of this class.
	 */
	public Attribute() {
	}
	
	/**
	 * Returns the name of this attribute.
	 * @return The name of this attribute.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the description of this attribute.
	 * @return the description of this attribute.
	 */
	public String getDescription() {
		return getResourceBundle().getString(name);
	}

	/**
	 * Returns the long description of this attribute.
	 * @return The long description of this attribute.
	 */
	public String getLongDescription() {
		return getResourceBundle().getString(name + "_LONG_DESC");
	}
	
	/**
	 * Returns the parent of this attribute. If this attribute does not have any
	 * parent then null is returned.
	 * @return The parent of this attribute. 
	 */
	public Attribute getParent() {
		return parent;
	}

	/**
	 * Returns true if this attribute is mark as required.
	 * @return true if this attribute is mark as required, otherwise false.
	 */
	public boolean isRequired() {
		return isRequired;
	}

	/**
	 * Sets the required status of this attribute.
	 * @param isRequired true to set this attribute as required, otherwise false.
	 */
	public void setRequired(boolean isRequired) {
		this.isRequired = isRequired;
	}

	/**
	 * Returns true is this attribute is partially required.
	 * @return true is this attribute is partially required, otherwise false
	 */
	public boolean isPartiallyRequired() {
		return this.isPartiallyRequired;
	}

	/**
	 * Sets the partially required status of this attribute.
	 * @param isRequired true to set this attribute as partially required, otherwise false.
	 */
	public void setPartiallyRequired(boolean isPartiallyRequired) {
		this.isPartiallyRequired = isPartiallyRequired;
	}

	/**
	 * Returns the String representation of the xml node for this attribute.
	 * @return The String representation of the xml node for this attribute.
	 */
	protected abstract String ToXml();

	/**
	 * Returns the resource bundle for this attribute.
	 * @return The resource bundle for this attribute.
	 */
	protected abstract ResourceBundle getResourceBundle();
		
	public String toString() {
		return name;
	}
}
