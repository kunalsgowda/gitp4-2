package com.sap.ip.me.mdk.pios.docgen.actions;

import java.io.*;
import java.lang.reflect.*;

import org.eclipse.ui.*;
import org.eclipse.jface.action.*;
import org.eclipse.jface.viewers.*;
import org.eclipse.core.runtime.*;
import org.eclipse.jface.dialogs.*;
import com.sap.ip.me.mdk.pios.docgen.*;

/**
 * Manages the Document Generator Set Emulation Mode toolbar action.
 * @author Abaco
 */

public class SetEmulationMode implements IWorkbenchWindowActionDelegate {

	private static final String EMULATION_MODE = DocumentGeneratorPlugin.ID + ".emulation_mode";  
	private static final String ADDITIONAL_CLASSPATH = DocumentGeneratorPlugin.ID + ".additional_classpath";
	private static final String EMULATOR_HOME = DocumentGeneratorPlugin.ID + ".emulator_home";
	private static final String EMULATOR_CONNECTOR = DocumentGeneratorPlugin.ID + ".emulator_connector";

	private IWorkbenchWindow window;
	private IStructuredSelection selection = null;
	private DocGenResources rb = DocGenResourcesManager.getInstance().getResourceBundle("actions");

	/**
	 * Creates a new instance of this class.
	 */
	public SetEmulationMode() {}

	public void init(IWorkbenchWindow window) {
		this.window = window;
	}

	public void dispose() {}

	public void selectionChanged(IAction action, ISelection selection) {
		if (selection instanceof IStructuredSelection) {
			this.selection = (IStructuredSelection) selection;
		}
	}

	public void run(IAction action) {

		Plugin mdkPlugin = Platform.getPlugin(DocumentGeneratorPlugin.MDK_PLUGIN_ID);

		if (mdkPlugin == null) {

			MessageDialog.openError(
				null,
				rb.getString("set_emulation_mode.dialog.tittle"),
				rb.getString("set_emulation_mode.dialog.mdk_not_installed"));
			return;

		}

		//Check the emulation mode
 		Preferences pref = mdkPlugin.getPluginPreferences();
 		boolean emulationMode = !action.isChecked();
		
		//If the emulation mode is on the turn it off
 		if (emulationMode) {

 			pref.setValue(EMULATION_MODE, false);
			pref.setValue(ADDITIONAL_CLASSPATH, "");
			pref.setValue(EMULATOR_HOME, "");
			pref.setValue(EMULATOR_CONNECTOR, ""); 			

 		} else {
 			//If the emulation mode is off then turn it on
			String emulatorHome = DocumentGeneratorPlugin.getDefault().find(new Path("emulator")).getPath();

			pref.setValue(EMULATION_MODE, true);
			pref.setValue(ADDITIONAL_CLASSPATH, emulatorHome + File.separator + "connector_emulator.jar");
			pref.setValue(EMULATOR_HOME, emulatorHome);
			pref.setValue(EMULATOR_CONNECTOR, "com.sap.ip.me.api.pios.impl.emulator.ConnectorImpl"); 			
 		}


		//Save the changes
		mdkPlugin.savePluginPreferences();

		//Notify the MDK plugin of the change
		try {
			Method method = mdkPlugin.getClass().getMethod("setPios_Emulation_Mode", new Class[] {boolean.class});
			method.invoke(mdkPlugin, new Object[] {new Boolean(emulationMode)});
		} catch (Exception e) {
			DocumentGeneratorPlugin.getDefault().logError("Error while trying to notify MDK plugin of change.",e);
		} 


	}
}
