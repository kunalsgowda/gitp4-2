package com.sap.ip.me.mdk.pios.docgen.editors;

import org.eclipse.core.resources.*;

import com.sap.ip.me.mdk.pios.docgen.*;

/**
 * This is the change listener implementation for the Driver Requirements 
 * Document editor.
 * @author Abaco
 */

public class WorspaceListener implements IResourceChangeListener {

	/**
	 * Creates a new instance of this class.
	 */
	public WorspaceListener() {	}

	/**
	 * Automatically called by eclipse when a change to the workbench occurs. 
	 * Checks the change type and closes any DRD editor opened relevant to the
	 * change.
	 */
	public void resourceChanged(IResourceChangeEvent event) {

		closeRelevantDRDEditor(event.getDelta());

	}

	private void closeRelevantDRDEditor(IResourceDelta delta) {

		if (delta != null) {
		
			IResourceDelta[] deltas = delta.getAffectedChildren();
			for (int i = 0; i < deltas.length; i++) {

				if (deltas[i].getResource().getName().equals(DocumentGeneratorPlugin.DOCUMENT_NAME)) {
					if (deltas[i].getKind() == IResourceDelta.REMOVED) {
						DocumentGeneratorPlugin.getDefault().closeDRDEditorForProject(deltas[i].getResource().getProject());
					} 
				}
				closeRelevantDRDEditor(deltas[i]);
			}
		}
	}
}
