package com.sap.ip.me.mdk.pios.docgen.wizards;

import org.eclipse.core.resources.*;
import org.eclipse.core.runtime.*;
import org.eclipse.jface.dialogs.*;
import org.eclipse.ui.*;

import com.sap.ip.me.mdk.pios.docgen.*;
import com.sap.ip.me.mdk.pios.docgen.editors.*;

/**
 * This Wizard enables the user to create a new Driver Requirements Document or 
 * modify an existing one. Once the document is created the DRDEditor is automatically opened. 
 */

public class CreateModifyDRDWizard extends DocGenWizard implements INewWizard {

	private SelectPeripheralsWizardPage wizardPage;

	/**
	 * Creates a new instance of this class.
	 */
	public CreateModifyDRDWizard() {
		super("");
	}

	public void addPages() {
		//Validate that a project is selected
		IProject project = DocumentGeneratorPlugin.getDefault().getProject(selection);
		if (project == null) {

			wizardPage = new NewDRDWizardPage(selection, project);
			super.setWindowTitle(rb.getString("new_drd.tittle"));
			wizardPage.setPageComplete(false);
			wizardPage.setErrorMessage(rb.getString("select_peripheral.error.no_project_selected"));
		} else if(!DocumentGeneratorPlugin.getDefault().containsDRD(project)) {
			wizardPage = new NewDRDWizardPage(selection, project);
			super.setWindowTitle(rb.getString("new_drd.tittle"));
		} else {
			wizardPage = new ConfigureDRDWizardPage(selection, project);
			super.setWindowTitle(rb.getString("config_drd.tittle"));
		}

		addPage(wizardPage);
	}

	public boolean doFinish(IProgressMonitor monitor) throws DocumentGeneratorException {

		if (wizardPage instanceof NewDRDWizardPage) {
			return createNewDRD(monitor);
		} else {
			return configureDRD(monitor); 
		}
	}

	private boolean createNewDRD(IProgressMonitor monitor) throws DocumentGeneratorException {

		String projectName = wizardPage.getProjectName();
		String[] peripherals = wizardPage.getAddedPeripherals();

		// create a sample file
		IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject(projectName);
		if( project == null ) {
			throw new DocumentGeneratorException(rb.getString("new_drd.error.project_not_found", new String[] {projectName}));
		}
		
		final IFile file = DocumentGeneratorPlugin.getDefault().getDRDFile(project);

		//Create and save the Driver Requirements Document
		//The amount of work units y twice the number of peripherals because first they are created and then saved.
		monitor.beginTask(rb.getString("new_drd.monitor.task_name"), peripherals.length * 2);

		DriverRequirementsDocument driverRequirementsDocument = new DriverRequirementsDocument(project);		
	
		//Add peripherals
		for (int i = 0; i < peripherals.length; i++) {
			monitor.subTask(rb.getString("new_drd.monitor.subtask.adding_peripheral", new String[] {peripherals[i]}));
			driverRequirementsDocument.addPeripheral(peripherals[i]);
			monitor.worked(1);
		}
		driverRequirementsDocument.save(file, monitor);


		//Open the created Driver Requirements Document.
		getShell().getDisplay().asyncExec(new Runnable() {
			public void run() {
				IWorkbenchPage page =
					PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
				try {
					page.openEditor(file);

					
					
				} catch (PartInitException e) {
					DocumentGeneratorPlugin.getDefault().logError("Unable to initiale editor.", e);
					MessageDialog.openWarning(null, rb.getString("new_drd.messagedialog.error_initializing_editor.tittle"), rb.getString("new_drd.messagedialog.error_initializing_editor.message", new String[] {e.getMessage()}));
				}
			}
		});
		return true;
	}
	
	private boolean configureDRD(IProgressMonitor monitor) throws DocumentGeneratorException {

		String projectName = wizardPage.getProjectName();
		String[] addedPeripherals = wizardPage.getAddedPeripherals();
		String[] removedPeripherals = wizardPage.getRemovedPeripherals();
		DriverRequirementsDocument driverRequirementsDocument = ((ConfigureDRDWizardPage) wizardPage).getDriverRequirementsDocument();

		// create a sample file
		final IProject project = ResourcesPlugin.getWorkspace().getRoot().getProject(projectName);
		if (project == null) {
			throw new DocumentGeneratorException(rb.getString("config_drd.error.project_not_found", new String[] {projectName}));
		}

		final IFile file = DocumentGeneratorPlugin.getDefault().getDRDFile(project);

		//The amount of work units y twice the number of peripherals because first they are created and then saved.
		monitor.beginTask(
			rb.getString("config_drd.monitor.task_name"),
			(addedPeripherals.length * 2) + removedPeripherals.length + 1);

		//Remove peripherals
		monitor.subTask(rb.getString("config_drd.monitor.subtask.removing_peripherals"));
		for (int i = 0; i < removedPeripherals.length; i++) {

			if (driverRequirementsDocument.containsPeripheral(removedPeripherals[i])) {
				driverRequirementsDocument.removePeripheral(removedPeripherals[i]);
			}
			monitor.worked(1);
		}

		monitor.subTask(rb.getString("config_drd.monitor.subtask.adding_peripherals"));
		for (int i = 0; i < addedPeripherals.length; i++) {

			if (!driverRequirementsDocument.containsPeripheral(addedPeripherals[i])) {
				driverRequirementsDocument.addPeripheral(addedPeripherals[i]);
			}
			monitor.worked(1);
		}
		driverRequirementsDocument.save(file, monitor);

		monitor.subTask(rb.getString("config_drd.monitor.subtask.update_editor"));
		getShell().getDisplay().asyncExec(new Runnable() {
			public void run() {

				IWorkbenchPage page = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
				try {
					DRDEditor drdEditor = DocumentGeneratorPlugin.getDefault().getDRDEditor(project); 

					//If the Driver Requirements Document Editor is opened then refresh its contents.
					if (drdEditor != null) {
						page.closeEditor(drdEditor, false);
						page.openEditor(file);

					}
				} catch (PartInitException e) {
					DocumentGeneratorPlugin.getDefault().logError("Unable to update editor.", e);
					MessageDialog.openWarning(getShell(), rb.getString("config_drd.messagedialog.error_updating_editor.tittle"), 
						rb.getString("config_drd.messagedialog.error_updating_editor.message", new String[] {e.getMessage()}));
				}
			}
		});
		monitor.worked(1);
		return true;
	}
}
