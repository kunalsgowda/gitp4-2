package com.sap.ip.me.mdk.pios.docgen.wizards;

import java.util.ArrayList;
import org.eclipse.core.resources.*;
import org.eclipse.jface.viewers.*;

import com.sap.ip.me.mdk.pios.docgen.*;

/**
 * Main wizard page for the NewDRDWizard.
 * @author Abaco
 */

public class NewDRDWizardPage extends SelectPeripheralsWizardPage {

	private static DocGenResources rb = CreateModifyDRDWizard.rb;

	/**
	 * Creates a new instance of this class.
	 * @param selection The selected node in the workspace.
	 * @param project The current project.
	 */
	public NewDRDWizardPage(IStructuredSelection selection, IProject project) {
		super(rb.getString("new_drd.page.name"), project, selection);
		super.setTitle(rb.getString("new_drd.page.tittle"));
		super.setDescription(rb.getString("new_drd.page.description"));
		super.setImageDescriptor(DocumentGeneratorPlugin.getDefault().getImageDescriptor(rb.getString("image.new_drd_header")));
	}

	protected void fillPeripheralLists(IProject project) {

		// Add Peripherals
		ArrayList installedPeripherals = PeripheralManager.getInstance().getInstalled();
		for( int i = 0; i < installedPeripherals.size(); i++ ) {
			listPeripheralsAvailable.add((String) installedPeripherals.get(i));
		}

		//Validate that there are peripherals available 
		if(listPeripheralsAvailable.getItemCount() == 0 ){
			setErrorMessage(rb.getString("new_drd.page.error.no_peripherals_available"));
			setPageComplete(false);
			return;
		}
	}
}
