package com.sap.ip.me.mdk.pios.docgen;

import java.util.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import org.apache.xerces.parsers.*;
import org.eclipse.jface.dialogs.*;

import com.sap.ip.me.mdk.pios.docgen.attributes.*;

/**
 * Document parser for the Driver Requirements Document.
 * @author Abaco
 */

public class DriverRequirementsDocumentParser extends DefaultHandler {

	private String version = null;
	private ArrayList peripheralList;
	private Peripheral currentPeripheral;
	private Property currentProperty;
	private Option currentOption;
	private DocGenResources rb = null;
	private boolean isDirty = false; //Driver Requirements Document changed from the input file. 

	/**
	 * Creates a new instance of this class.
	 */
	public DriverRequirementsDocumentParser(DocGenResources rb) {
		super();
		this.rb = rb;
	}
	
	/**
	 * Parses the received Driver Requirements Document.
	 * @param in The Driver Requirements Document to parse. 
	 * @return An ArrayList containing the Peripheral objects from the Driver Requirements Document. 
	 * @throws Exception
	 */
	public ArrayList parseDoc(InputSource in) throws Exception {
	
		peripheralList = new ArrayList();

		SAXParser parser = new SAXParser();
		parser.setContentHandler(this);
		parser.setErrorHandler(this);
		parser.parse(in);
		return peripheralList;
	}
	
	/**
	 * Returns the version of the parsed driver requirements document.
	 * @return the version of the parsed driver requirements document.
	 */
	public String getVersion() {
		return this.version;
	}

	/**
	 * Returns true if this document has changed, otherwise false.
	 * @return true if this document has changed, otherwise false.
	 */
	public boolean isDirty() {
		return isDirty; 
	}
	
	

	public void startElement(String uri, String elementName, String qName, Attributes attributes)  {

		if (elementName.equalsIgnoreCase(DriverRequirementsDocument.PERIPHERALS)) {
			version = attributes.getValue(DriverRequirementsDocument.VERSION);

		} else if (elementName.equalsIgnoreCase(DriverRequirementsDocument.PERIPHERAL)) {

			String peripheralName = attributes.getValue(DriverRequirementsDocument.PERIPHERAL_TYPE);
			
			try {
				currentPeripheral = new Peripheral(peripheralName);
			} catch (DocumentGeneratorException ex) {
				MessageDialog.openInformation(null, rb.getString("drd.header"), rb.getString("drd.peripheral_not_found", new String[] {peripheralName}));				
				DocumentGeneratorPlugin.getDefault().logError("Unable to load peripheral: " + peripheralName, ex);
				currentPeripheral = null;
				isDirty = true;
			}
		} else if (elementName.equalsIgnoreCase(DriverRequirementsDocument.PERIPHERAL_PROP)) {

			if (currentPeripheral != null) {
				currentProperty =
					new Property(
						attributes.getValue(DriverRequirementsDocument.PERIPHERAL_ATTRIB_NAME),
						currentPeripheral);
				setRequired(currentProperty, attributes);
			} else {
				currentProperty = null;
			}
		} else if (elementName.equalsIgnoreCase(DriverRequirementsDocument.PERIPHERAL_OPTION)) {

			if (currentProperty != null) {
				currentOption =
					new Option(
						attributes.getValue(DriverRequirementsDocument.PERIPHERAL_ATTRIB_NAME),
						currentProperty);
				setRequired(currentOption, attributes);

			} else {
				currentOption = null;
			}
		}
	}

	public void endElement(String uri, String elementName, String qName) {

		if (elementName.equalsIgnoreCase(DriverRequirementsDocument.PERIPHERAL)) {
			if (currentPeripheral != null) {
				peripheralList.add(currentPeripheral);
				currentPeripheral = null;
			} 
		} else if (elementName.equalsIgnoreCase(DriverRequirementsDocument.PERIPHERAL_PROP)) {
			if (currentProperty != null) {
				currentPeripheral.getProperties().add(currentProperty);
				currentProperty = null;
			}
		} else if (elementName.equalsIgnoreCase(DriverRequirementsDocument.PERIPHERAL_OPTION)) {
			if (currentOption != null) {
				currentProperty.getOptions().add(currentOption);
				currentOption = null;
			}
		}
	}

	public void characters(char[] ch, int start, int length) {}

	public void endDocument() {}

	private void setRequired(Attribute req, Attributes attributes) {
		String required =
			attributes.getValue(DriverRequirementsDocument.PERIPHERAL_ATTRIB_REQUIRED);
		boolean bRequired = false;
		if (required != null && required.equalsIgnoreCase("yes"))
			bRequired = true;
		req.setRequired(bRequired);
	}
}
