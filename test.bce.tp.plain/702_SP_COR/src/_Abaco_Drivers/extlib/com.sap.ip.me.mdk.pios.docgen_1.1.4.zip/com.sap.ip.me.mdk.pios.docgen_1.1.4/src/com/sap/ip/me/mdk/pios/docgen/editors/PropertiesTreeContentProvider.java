package com.sap.ip.me.mdk.pios.docgen.editors;

import java.util.*;
import org.eclipse.core.resources.*;
import org.eclipse.jface.viewers.*;

import com.sap.ip.me.mdk.pios.docgen.attributes.*;

/**
 * TreeContentProvider implementation of the attributes tree in the Driver Requirements
 * editor.
 * @author Abaco 
 */

public class PropertiesTreeContentProvider implements ITreeContentProvider {

	private ArrayList propertiesList = null;

	private PropertiesTreeContentProvider() {
	}

	/**
	 * Creates a new instance of this class.
	 * @param propertiesList An ArrayList containing the properties of the peripheral.
	 */
	public PropertiesTreeContentProvider(ArrayList propertiesList) {
		this.propertiesList = propertiesList;
	}

	public void inputChanged(Viewer v, Object oldInput, Object newInput) {	}

	public void dispose() {}

	public Object[] getElements(Object parent) {
		if (parent.equals(ResourcesPlugin.getWorkspace())) {
			return new Object[] {((Property) propertiesList.get(0)).getParent()};
		} 
		return new Object[0];
	}

	public Object getParent(Object child) {
		return ((Attribute) child).getParent();
	}

	public Object[] getChildren(Object parent) {
		if (parent instanceof Property) {
			ArrayList options = ((Property) parent).getOptions();
			Object[] result = new Object[options.size()];
			for (int i = 0; i < result.length; i++) {
				result[i] = options.get(i);
			}
			return result;
		} else if (parent instanceof Peripheral) {
			ArrayList properties = ((Peripheral) parent).getProperties();
			Object[] result = new Object[properties.size()];
			for (int i = 0; i < result.length; i++) {
				result[i] = properties.get(i);
			}
			return result;
		}
		
		return new Object[0];
	}

	public boolean hasChildren(Object parent) {

		if (parent instanceof Property) {
			return ((Property) parent).getOptions().size() > 0; 
		} else {
			return false;
		}
	}
}