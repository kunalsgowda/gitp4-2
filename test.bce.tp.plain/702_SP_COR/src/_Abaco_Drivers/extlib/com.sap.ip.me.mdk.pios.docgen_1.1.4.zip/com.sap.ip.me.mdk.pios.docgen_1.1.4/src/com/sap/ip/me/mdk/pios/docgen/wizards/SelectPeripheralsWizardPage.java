package com.sap.ip.me.mdk.pios.docgen.wizards;

import org.eclipse.core.resources.*;
import org.eclipse.jface.wizard.*;
import org.eclipse.jface.viewers.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.*;

import com.sap.ip.me.mdk.pios.docgen.*;

/**
 * Base class for the wizard pages that require the user to select the
 * peripheral types to include in the Driver Requirements Document. 
 * @author Abaco
 */

public abstract class SelectPeripheralsWizardPage extends WizardPage {

	private static DocGenResources rb = DocGenWizard.rb;

	private Text textProjectName = null;
	protected List listPeripheralsAvailable = null;
	protected List listPeripheralsAdded = null;
	private Button buttonAdd = null;
	private Button buttonRemove = null;	
	private IStructuredSelection selection;	
	private IProject project = null;

	/**
	 * Creates a new instance of this class.
	 * @param pageName The name of this wizard page.
	 * @param project The current project.
	 * @param selection The selected node in the workspace.
	 */
	public SelectPeripheralsWizardPage(String pageName, IProject project, IStructuredSelection selection) {
		super(pageName);
		this.selection = selection;
		this.project = project;
	}

	public void createControl(Composite parent) {

		Composite compositeMain = new Composite(parent, SWT.NULL);

		GridLayout layout = new GridLayout();
		layout.numColumns = 1;
		layout.verticalSpacing = 1;

		compositeMain.setLayout(layout);
		compositeMain.setLayoutData(new GridData(GridData.FILL_BOTH));

		createProjectNameGroup(compositeMain);		
		createPeripheralsGroup(compositeMain);

		//Register Listeners		
		buttonAdd.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event event) {
				addPeripheral();
			}
		});

		buttonRemove.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event event) {
				removePeripheral();
			}
		});

		listPeripheralsAvailable.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event event) {
				enableDisableComponents();
			}
		});

		listPeripheralsAdded.addListener(SWT.Selection, new Listener() {
			public void handleEvent(Event event) {
				enableDisableComponents();
			}
		});

		initialize();
		enableDisableComponents();
		setControl(compositeMain);
		listPeripheralsAvailable.setFocus();
		
		parent.pack();
		//Make both buttons the same size
		if (buttonRemove.getSize().x > buttonAdd.getSize().x) {
			buttonAdd.setSize(buttonRemove.getSize());
		} else {
			buttonRemove.setSize(buttonAdd.getSize());
		}

		
	}
	
	/**
	 * Returns the name of the project used in this wizard page.
	 * @return The name of the project used in this wizard page.
	 */
	public String getProjectName() {
		return textProjectName.getText();
	}
	
	/**
	 * Returns a list with the names of the peripheral types in the added UI list.
	 * @return A list with the names of the peripheral types in the added UI list.
	 */
	public String[] getAddedPeripherals() {
		return listPeripheralsAdded.getItems();
	}

	/**
	 * Returns a list with the names of the peripheral types in the removed UI list.
	 * @return A list with the names of the peripheral types in the removed UI list.
	 */
	public String[] getRemovedPeripherals() {
		return listPeripheralsAvailable.getItems();
	}
		
	/**
	 * Creates the project name section of the page.
	 * @param parent The parent composite.
	 */
	private void createProjectNameGroup(Composite parent) {

		// project specification group
		Composite projectGroup = new Composite(parent, SWT.NONE);
		projectGroup.setLayout(new GridLayout(2, false));
		projectGroup.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
	
		// project label
		Label labelProjectHeader = new Label(projectGroup, SWT.NONE);
		labelProjectHeader.setText(rb.getString("select_peripheral.page.current_project")); 
	
		//Project Name
		textProjectName = new Text(projectGroup, SWT.READ_ONLY);
		textProjectName.setLayoutData(new GridData(GridData.FILL_HORIZONTAL)); 
	}
	
	/**
	 * Creates the peripherals section of the page.
	 * @param parent The parent composite.
	 */
	private void createPeripheralsGroup(Composite parent) {
		
		// peripherals specification group
		Composite compositeMain = new Composite(parent, SWT.NONE);
		compositeMain.setLayoutData(new GridData(GridData.FILL_BOTH));
		compositeMain.setLayout(new GridLayout(3, false));
	
		// project label
		Label separator = new Label(compositeMain, SWT.SEPARATOR | SWT.HORIZONTAL);
		separator.setLayoutData(getGridData(GridData.FILL_HORIZONTAL, 3));

		//Peripherals Available list
		Composite compositePeripheralsAvailable = new Composite(compositeMain, SWT.NONE);
		compositePeripheralsAvailable.setLayoutData(new GridData(GridData.FILL_BOTH));
		compositePeripheralsAvailable.setLayout(new GridLayout(1, false));

		Label labelPeripheralsAvailable = new Label(compositePeripheralsAvailable, SWT.NONE);
		labelPeripheralsAvailable.setText(rb.getString("select_peripheral.page.peripherals_available"));
		labelPeripheralsAvailable.setLayoutData(getGridData(SWT.NONE, 1));
		
		listPeripheralsAvailable = new List(compositePeripheralsAvailable, SWT.MULTI | SWT.BORDER );
		listPeripheralsAvailable.setLayoutData(getGridData(GridData.FILL_BOTH, 1));

		//Add/Remove Buttons
		Composite compositeButtons = new Composite(compositeMain, SWT.NONE);
		compositeButtons.setLayout(new GridLayout(1, false));

		buttonAdd = new Button(compositeButtons, SWT.NONE);
		buttonAdd.setLayoutData(getGridData(SWT.NONE, 1));
		buttonAdd.setText(rb.getString("select_peripheral.page.button.add")); 
		buttonAdd.setToolTipText(rb.getString("select_peripheral.page.button.tooltip.add"));

		buttonRemove = new Button(compositeButtons, SWT.NONE);
		buttonRemove.setLayoutData(getGridData(SWT.NONE, 1));
		buttonRemove.setText(rb.getString("select_peripheral.page.button.remove")); 
		buttonRemove.setToolTipText(rb.getString("select_peripheral.page.button.tooltip.remove"));

		//Peripherals Added list
		Composite compositePeripheralsAdded = new Composite(compositeMain, SWT.NONE);
		compositePeripheralsAdded.setLayoutData(new GridData(GridData.FILL_BOTH));
		compositePeripheralsAdded.setLayout(new GridLayout(1, false));

		Label labelPeripheralAdded = new Label(compositePeripheralsAdded, SWT.NONE);
		labelPeripheralAdded.setText(rb.getString("select_peripheral.page.peripherals_added"));
		labelPeripheralAdded.setLayoutData(getGridData(SWT.NONE, 1));
		
		listPeripheralsAdded = new List(compositePeripheralsAdded, SWT.MULTI | SWT.BORDER );
		listPeripheralsAdded.setLayoutData(getGridData(GridData.FILL_BOTH, 1));
		
	}	
	
	protected void initialize() {
		if (project != null) {
			textProjectName.setText(project.getName());
		
			fillPeripheralLists(project);
		}
	}
	
	/**
	 * This method adds the peripheral types to the peripheral UI lists.
	 * @param project The selected project.
	 */
	protected abstract void fillPeripheralLists(IProject project); 
	
	/**
	 * Moves the selected peripheral type in the available list to the
	 * added list. 
	 */
	private void addPeripheral() {
		String[] selectedPeripherals = listPeripheralsAvailable.getSelection();
		for (int i = 0; i < selectedPeripherals.length; i++) {
			listPeripheralsAdded.add(selectedPeripherals[i]);
			listPeripheralsAvailable.remove(selectedPeripherals[i]);  		
		}
		enableDisableComponents();
	}
	
	/**
	 * Moves the selected peripheral type in the added list to the
	 * available list. 
	 */
	private void removePeripheral() {
		String[] selectedPeripherals = listPeripheralsAdded.getSelection();
		for (int i = 0; i < selectedPeripherals.length; i++) {
			listPeripheralsAvailable.add(selectedPeripherals[i]);
			listPeripheralsAdded.remove(selectedPeripherals[i]);  		
		}
		enableDisableComponents();
	}

	/**
	 * Helper method to create a new GridData object. 
	 * @param style The style of the component.
	 * @param horizontalSpan The horizontal span of the component.
	 * @return The created GridData object.
	 */
	private GridData getGridData(int style, int horizontalSpan) {
		GridData gridData = new GridData(style);
		gridData.horizontalSpan = horizontalSpan;
		return gridData;
	}

	protected void enableDisableComponents() {

		//Enable or disable the add/remove buttons
		buttonAdd.setEnabled(listPeripheralsAvailable.getSelection().length > 0);
		buttonRemove.setEnabled(listPeripheralsAdded.getSelection().length > 0);

		//Enable or Disable the finish button
		super.setPageComplete(listPeripheralsAdded.getItemCount() > 0);
	}
}
