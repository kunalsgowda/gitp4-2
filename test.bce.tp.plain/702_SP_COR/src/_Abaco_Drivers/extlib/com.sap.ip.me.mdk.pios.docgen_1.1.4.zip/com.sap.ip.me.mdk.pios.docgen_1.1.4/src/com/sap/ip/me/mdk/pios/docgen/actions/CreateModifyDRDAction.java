package com.sap.ip.me.mdk.pios.docgen.actions;

import org.eclipse.jface.action.*;

import com.sap.ip.me.mdk.pios.docgen.wizards.*;

/**
 * Represents the new Driver Requirements Document toolbar action. 
 * This class launches the NewDRDWizard wizard. 
 * @author Abaco
 */

public class CreateModifyDRDAction extends ToolBarAction {

	/**
	 * Creates a new instance of this class.
	 */
	public CreateModifyDRDAction() {
		super();
	}

	public void run(IAction action) {
		//Display the New Driver Requirements Document wizard.
		super.showWizard(new CreateModifyDRDWizard());
	}
}
