package com.sap.ip.me.mdk.pios.docgen;

import java.util.*;

import org.eclipse.jface.dialogs.*;

/**
 * This class is a factory of DocGenResources. 
 * @author Abaco
 */

public class DocGenResourcesManager {

	private static DocGenResourcesManager instance = null;

	private Map resourceBundles = null;

	/**
	 * Creates a new instance of this class.
	 */
	private DocGenResourcesManager() {
		resourceBundles = new HashMap();
	}

	/**
	 * Returns the DocGenResources object for specified base name.
	 * @param baseName The base name of the resource bundle.
	 * @return The DocGenResources object for specified base name.
	 */
	public DocGenResources getResourceBundle(String baseName) {

		try {
			if (!resourceBundles.containsKey(baseName)) {
				DocGenResources resourceBundle =
					new DocGenResources("com.sap.ip.me.mdk.pios.docgen.language." + baseName);
				resourceBundles.put(baseName, resourceBundle);
			}
			return (DocGenResources) resourceBundles.get(baseName);
		} catch (Exception ex) {
			DocumentGeneratorPlugin.getDefault().logError(
				"Unable to load resource bundle: " + baseName,
				ex);
			MessageDialog.openError(
				null,
				"Document Generator",
				"Unable to load resource bundle: "
					+ baseName
					+ ". \nThe Document Generator may behave incorrectly. \nCheck log for more details.");
			return null;
		}
	}

	/**
	 * Returns an instance of this class.
	 * @return An instance of this class.
	 */
	public static DocGenResourcesManager getInstance() {
		if (instance == null) {
			instance = new DocGenResourcesManager();
		}
		return instance;
	}
}
