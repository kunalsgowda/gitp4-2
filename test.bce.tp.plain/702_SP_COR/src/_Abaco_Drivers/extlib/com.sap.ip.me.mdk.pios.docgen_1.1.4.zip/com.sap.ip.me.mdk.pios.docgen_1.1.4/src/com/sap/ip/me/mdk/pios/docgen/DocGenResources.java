package com.sap.ip.me.mdk.pios.docgen;

import java.util.*;

/**
 * This is a utility class to extend the basic java.util.ResourceBundle 
 * functionality.   
 * @author Abaco
 */

public class DocGenResources {

	private ResourceBundle resourceBundle = null;

	/**
	 * Creates a new instance of this class.
	 * @param baseName The base name of the resource bundle, a fully qualified class name. 
	 * @throws Exception
	 */
	public DocGenResources(String baseName) throws Exception {
		try {
			resourceBundle = ResourceBundle.getBundle(baseName);
		} catch (MissingResourceException ex) {
			//If the default language is not found then default to english.
			DocumentGeneratorPlugin.getDefault().logError("Default language resource file " + baseName +" not found, default language set to US English.", ex);
			resourceBundle = ResourceBundle.getBundle(baseName, Locale.US);
		}
	}

	/**
	 * Gets a string for the given key from this resource bundle or one of its parents. 
	 * @param key The key for the desired string. 
	 * @return The string for the given key.
	 */
	public String getString(String key) {
		try {
			return resourceBundle.getString(key);
		} catch (Exception ex) {
			DocumentGeneratorPlugin.getDefault().logError("Key " + key + " not found. Returning empty String.", ex);
			return "";
		}
	}

	/**
	 * Gets a string for the given key from this resource bundle or one of its parents. 
	 * The [n] entries in the string are replaced by the args values.  
	 * @param key The key for the desired string.
	 * @param args The strings to replace in the resource bundle string.
	 * @return The string for the given key and args.
	 */
	public String getString(String key, Object[] args) {
		try {
			String s = resourceBundle.getString(key);

			//replace the arguments in the string
			for (int i = 0; i < args.length; i++) {
				String token = "[" + i + "]";

				while (s.indexOf(token) != -1) {
					String tmp = s.substring(0, s.indexOf(token));
					tmp += args[i].toString();
					tmp += s.substring(s.indexOf(token) + token.length());
					s = tmp;
				}
			}
			return s;
		} catch (Exception ex) {
			DocumentGeneratorPlugin.getDefault().logError("Key " + key + " not found. Returning empty String.",ex);
			return "";
		}
	}

}
