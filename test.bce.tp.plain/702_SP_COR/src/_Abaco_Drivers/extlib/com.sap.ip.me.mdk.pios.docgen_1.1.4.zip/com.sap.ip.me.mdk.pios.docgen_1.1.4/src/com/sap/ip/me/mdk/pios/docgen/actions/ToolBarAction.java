package com.sap.ip.me.mdk.pios.docgen.actions;

import org.eclipse.ui.*;
import org.eclipse.jface.wizard.*;
import org.eclipse.jface.action.*;
import org.eclipse.jface.viewers.*;

/**
 * Base class for most of the Document Generator Toolbar Action. Manages the 
 * common logic to those actions. 
 * @author Abaco
 */

public abstract class ToolBarAction implements IWorkbenchWindowActionDelegate {

	private IWorkbenchWindow window;
	private IStructuredSelection selection = null;

	/**
	 * Creates a new instance of this class.
	 */
	public ToolBarAction () {
	}

	public void init(IWorkbenchWindow window) {
		this.window = window;
	}

	public void dispose() {}

	public void selectionChanged(IAction action, ISelection selection) {

		if (selection instanceof IStructuredSelection) {
			this.selection = (IStructuredSelection) selection;
		}
	}

	/**
	 * Displays the received wizard.
	 * @param wizard The wizard to display.
	 */
	protected void showWizard(IWorkbenchWizard wizard) {
		wizard.init(window.getWorkbench(), selection);
		WizardDialog wizardDialog = new WizardDialog(window.getShell(), wizard);
		wizardDialog.open();
	}
}
