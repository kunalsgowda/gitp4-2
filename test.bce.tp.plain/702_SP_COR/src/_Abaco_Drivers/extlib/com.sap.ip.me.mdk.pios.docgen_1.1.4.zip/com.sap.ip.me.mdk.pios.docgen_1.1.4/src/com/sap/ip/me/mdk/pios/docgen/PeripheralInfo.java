package com.sap.ip.me.mdk.pios.docgen;

import java.net.*;
import java.io.*;
import java.util.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.jface.resource.*;
import org.eclipse.core.runtime.*;

/**
 * Contains the information required to load Peripherla Type from its definition template. 
 * @author Abaco
 */

public class PeripheralInfo {

	private String name;
	private String templateFileName;
	private Image image;
	private String version;
	private ResourceBundle resourceBundle;

	/**
	 * Creates a new instance of this class.
	 * @param name The name of the peripheral.
	 * @param templateFileName The name of the template file for this peripheral. 
	 * @param imageName The name of the image for this peripheral. 
	 * @param version The version of this peripheral.
	 * @param resourceBundleFileName The name of the resource bundle file for this peripheral. 
	 * @throws DocumentGeneratorException
	 */
	public PeripheralInfo(
		String name,
		String templateFileName,
		String imageName,
		String version,
		String resourceBundleFileName)
		throws DocumentGeneratorException {

		this.name = name;
		this.templateFileName = templateFileName;
		this.image = createImage(imageName);
		this.version = version;

		try {
			resourceBundle =
				ResourceBundle.getBundle(
					"com.sap.ip.me.mdk.pios.docgen.language.peripherals." + name.toLowerCase(),
					Locale.getDefault());

		} catch (MissingResourceException ex) {
			DocumentGeneratorPlugin.getDefault().logError("Getting for: " + Locale.US, ex);
			resourceBundle =
				ResourceBundle.getBundle(
					"com.sap.ip.me.mdk.pios.docgen.language.peripherals." + name.toLowerCase(),
					Locale.US);
		}
	}

	/**
	 * Returns the name of this peripheral type.
	 * @return The name of this peripheral type.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Returns the template file name for this peripheral type.
	 * @return The template file name for this peripheral type.
	 */
	public String getTemplateFileName() {
		return templateFileName;
	}

	/**
	 * Returns the image for this peripheral type.
	 * @return The image for this peripheral type.
	 */
	public Image getImage() {
		return image;
	}

	/**
	 * Returns the version of this peripheral type.
	 * @return The version of this peripheral type.
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Returns the language ResourceBundle for this peripheral type and system default locale.
	 * @return The language ResourceBundle for this peripheral type and system default locale.
	 */
	public ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	private Image createImage(String imageName) {

		URL imageURL =
			DocumentGeneratorPlugin.getDefault().find(
				new Path("peripheral_types" + File.separator + imageName));
		if (imageURL == null) {
			return null;
		} else {
			return ImageDescriptor.createFromURL(imageURL).createImage();
		}
	}
}
