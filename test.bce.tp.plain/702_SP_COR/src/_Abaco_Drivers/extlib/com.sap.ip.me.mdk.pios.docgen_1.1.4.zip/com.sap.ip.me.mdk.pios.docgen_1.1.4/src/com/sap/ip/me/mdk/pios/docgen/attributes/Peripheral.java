package com.sap.ip.me.mdk.pios.docgen.attributes;

import java.util.*;
import org.eclipse.swt.graphics.*;

import com.sap.ip.me.mdk.pios.docgen.*;

/**
 * Represents a Peripheral Type node in the Driver Requirements Document.
 * @author Abaco 
 */

public class Peripheral extends Attribute {

	private ArrayList properties = null;
	private ResourceBundle resourceBundle = null;
	private Image peripheralIcon = null;

	/**
	 * Creates a new instance of this class.
	 * @param peripheralName The name of the peripheral type.
	 * @throws DocumentGeneratorException
	 */
	public Peripheral(String peripheralName) throws DocumentGeneratorException {
		super();
		super.name = peripheralName;
		properties = new ArrayList();
		resourceBundle = PeripheralManager.getInstance().getPeripheralResourceBundle(name);
		peripheralIcon = PeripheralManager.getInstance().getPeripheralIcon(name);
	}

	/**
	 * Returns the properties of this peripheral type.
	 * @return The properties of this peripheral type.
	 */
	public ArrayList getProperties() {
		return properties;
	}

	/**
	 * Returns the specified property. If the property is not found then null is returned. 
	 * @param propertyName The name of the property.
	 * @return The specified property.
	 */
	public Property getProperty(String propertyName) {
		for (int i = 0; i < properties.size(); i++) {
			Property property = (Property) properties.get(i);
			if (property.getName().equals(propertyName)) {
				return  property;
			}
		}
		return null;
	}

	/**
	 * Returns the icon for the peripheral type.
	 * @return the icon for the peripheral type.
	 */
	public Image getIcon() {
		return peripheralIcon;
	}

	/**
	 * Returns the String representation of the xml node for this peripheral type.
	 * @return The String representation of the xml node for this peripheral type. 
	 */
	public String ToXml() {

		StringBuffer sXml = new StringBuffer("<" + DriverRequirementsDocument.PERIPHERAL + " ");
		sXml.append(DriverRequirementsDocument.PERIPHERAL_TYPE + "=\"" + getName() + "\">"); 

		//Append options and properties
		appendAttributeNode(sXml, properties);		

		sXml.append("</" + DriverRequirementsDocument.PERIPHERAL + ">");

		return sXml.toString();
	}
	
	protected ResourceBundle getResourceBundle() {
		return resourceBundle;
	}

	private void appendAttributeNode(StringBuffer sXml, ArrayList attributes) {

		for(int i = 0; i < attributes.size(); i++ ) {
			Attribute req = (Attribute) attributes.get(i);
			sXml.append(req.ToXml());
		}
	}

	public String toString() {
		return getResourceBundle().getString(name);
	}
}
