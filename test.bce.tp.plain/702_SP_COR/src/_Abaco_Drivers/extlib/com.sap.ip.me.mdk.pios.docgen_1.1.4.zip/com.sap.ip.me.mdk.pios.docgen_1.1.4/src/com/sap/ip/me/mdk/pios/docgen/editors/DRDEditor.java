package com.sap.ip.me.mdk.pios.docgen.editors;

import java.util.*;

import org.eclipse.core.resources.*;
import org.eclipse.core.runtime.*;
import org.eclipse.jface.dialogs.*;
import org.eclipse.jface.viewers.*;
import org.eclipse.swt.*;
import org.eclipse.swt.layout.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.ui.*;
import org.eclipse.ui.part.*;
import org.eclipse.swt.custom.*;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;

import com.sap.ip.me.mdk.pios.docgen.*;
import com.sap.ip.me.mdk.pios.docgen.attributes.*;

/**
 * Implementation of the Plugin Editor.
 * 
 * This editor will be executed after the requirement document is
 * selected and opened or after it has been created with the Req.
 * Wizard.
 * 
 * It contains a tree view that represents all the requirements and
 * all the peripherals included in the document. Allows the user to 
 * select which requirements are needed for the application.
 */

public class DRDEditor extends EditorPart {

	private TabFolder tabFolder = null;
	private DriverRequirementsDocument driverRequirementsDocument;
	private Label listDescription = null;
	private boolean dirty = false;
	private IFile drdFile = null;
	private DocGenResources rb = DocGenResourcesManager.getInstance().getResourceBundle("editors");

	/**
	 * Creates a new instance of this class.
	 */
	public DRDEditor() {
		super();
	}

	public void createPartControl(Composite parent) {

		//Create the form components
		SashForm formProperties = new SashForm(parent, SWT.VERTICAL);
		formProperties.setLayout(new FillLayout(SWT.VERTICAL));
		formProperties.setFont(parent.getFont());
		tabFolder = new TabFolder(formProperties, SWT.NONE);

		listDescription = new Label(formProperties, SWT.WRAP);
		formProperties.setWeights(new int[] { 6, 1 });

		//Add data to the form
		ArrayList peripherals = driverRequirementsDocument.getPeripheralList();

		for (int i = 0; i < peripherals.size(); i++) {

			Peripheral peripheral = (Peripheral) peripherals.get(i);

			TabItem item = new TabItem(tabFolder, SWT.NONE);
			item.setText(peripheral.toString());
			item.setImage(peripheral.getIcon());

			//Create the tree that will contain the properties
			Composite composite = new Composite(tabFolder, SWT.NONE);
			composite.setLayout(new FillLayout());
			CheckboxTreeViewerEx treeProperties =
				new CheckboxTreeViewerEx(composite, SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL);

			treeProperties.setContentProvider(
				new PropertiesTreeContentProvider(peripheral.getProperties()));
			treeProperties.setInput(ResourcesPlugin.getWorkspace());

			composite.pack();
			item.setControl(composite);

			treeProperties.expandAll();

			treeProperties.addSelectionChangedListener(new ISelectionChangedListener() {
				public void selectionChanged(SelectionChangedEvent event) {
					treeNodeSelected(
						(Attribute) ((StructuredSelection) event.getSelection()).getFirstElement());
				}
			});

			treeProperties.addCheckStateListener(new ICheckStateListener() {
				public void checkStateChanged(CheckStateChangedEvent event) {
					attributeChecked(
						(Attribute) event.getElement(),
						event.getChecked(),
						(CheckboxTreeViewer) event.getSource());

				}
			});

			//Select the root node and set it as checked
			treeProperties.setSelection(new StructuredSelection(peripheral));
			
			//Manage the partially required fields
			ArrayList properties = ((Peripheral) peripherals.get(i)).getProperties();
			for (int j = 0; j < properties.size(); j++) {

				ArrayList options = ((Property) properties.get(i)).getOptions();
				if (options.size() > 0) {
					setParentState((Option) options.get(0), treeProperties);
				}
			}
			
			if (properties.size() > 0) {
				setParentState((Property) properties.get(0), treeProperties);
			}
		}
		listDescription.setText("");

		//Clear the description box when the peripheral tab selection is changed 
		tabFolder.addSelectionListener(new SelectionListener() {
			public void widgetSelected(SelectionEvent e) {
				listDescription.setText("");
			}

			public void widgetDefaultSelected(SelectionEvent e) {
				listDescription.setText("");
			}
		});

		//Add the workspace change listeners
		ResourcesPlugin.getWorkspace().addResourceChangeListener(new WorspaceListener());

	}

	public void doSave(IProgressMonitor monitor) {
		if (isDirty() == false)
			return;
		if (driverRequirementsDocument != null) {
			try {
				monitor.beginTask(
					rb.getString("drd_editor.monitor.task"),
					driverRequirementsDocument.getPeripheralList().size());
				driverRequirementsDocument.save(drdFile, monitor);
				monitor.done();
				dirty = false;
				driverRequirementsDocument.setDirty(false);
				firePropertyChange(PROP_DIRTY);
			} catch (DocumentGeneratorException ex) {
				MessageDialog.openError(
					null,
					rb.getString("drd_editor.messagedialog.error_saving_drd.tittle"),
					rb.getString(
						"drd_editor.messagedialog.error_saving_drd.message",
						new String[] { ex.getMessage()}));
				DocumentGeneratorPlugin.getDefault().logError(
					"Error Saving Driver Requirements Document",
					ex);
			}
		}
	}

	public void doSaveAs() {}

	public void gotoMarker(IMarker marker) {}

	/**
	 * @see org.eclipse.ui.IEditorPart#init(IEditorSite, IEditorInput)
	 */
	public void init(IEditorSite site, IEditorInput input) throws PartInitException {

		// Set Editor Site
		setSite(site);

		try {
			// Set Editor Input
			driverRequirementsDocument = doSetInput(input);
			dirty = driverRequirementsDocument.isDirty();
			
		} catch (CoreException coreex) {
			DocumentGeneratorPlugin.getDefault().logError(
				"Error Opening Driver Requirements Document",
				coreex);
			throw new PartInitException(rb.getString("drd_editor.error_opening_editor"), coreex);
		} catch (DocumentGeneratorException ioex) {
			DocumentGeneratorPlugin.getDefault().logError(
				"Error Opening Driver Requirements Document",
				ioex);
			throw new PartInitException(rb.getString("drd_editor.error_opening_editor"), ioex);
		}
	}

	/**
	 * @see org.eclipse.ui.IEditorPart#isDirty()
	 */
	public boolean isDirty() {
		return dirty;
	}

	/**
	 * Returns the Driver Requirements Document for this editor.
	 * @return The Driver Requirements Document for this editor.
	 */
	public DriverRequirementsDocument getDriverRequirementsDocument() {
		return driverRequirementsDocument;
	}

	/**
	 * Sets the dirty property of this editor.
	 * @param dirty The new value for the dirty property.
	 */
	public void setDirty(boolean dirty) {
		this.dirty = false;
		firePropertyChange(PROP_DIRTY);
	}

	private DriverRequirementsDocument doSetInput(IEditorInput input)
		throws CoreException, DocumentGeneratorException {

		IFileEditorInput fileInput = null;

		// Parse Xml and fill the list of peripherals
		if (input != null) {
			super.setInput(input);

			setTitle(rb.getString("drd_editor.tittle"));

			try {
				fileInput = (IFileEditorInput) input;
			} catch (Exception exc) {
				DocumentGeneratorPlugin.getDefault().logError("Invalid Editor Input.", exc);
				throw new PartInitException(rb.getString("drd_editor.invalid_editor_input"));
			}

			drdFile = fileInput.getFile();

			return new DriverRequirementsDocument(drdFile.getContents(), drdFile.getProject());
		}
		return null;
	}

	private void treeNodeSelected(Attribute selectedNode) {
		if (selectedNode != null) {
			listDescription.setText(selectedNode.getLongDescription());
		}
	}

	private void attributeChecked(Attribute requirement, boolean value, CheckboxTreeViewer tree) {

		if ((requirement instanceof Property)) {

			requirement.setRequired(value);
			enableProperty((Property) requirement, value, tree);
			setParentState(requirement, tree);
			
		} else if ((requirement instanceof Option)) {
		
			requirement.setRequired(value);
			
			setParentState(requirement, tree);
			setParentState(requirement.getParent(), tree);
			
		} else {  //Peripheral

			requirement.setRequired(value);
			requirement.setPartiallyRequired(false);
			
			//Check all the options of this property
			ArrayList properties = ((Peripheral) requirement).getProperties();
			for (int i = 0; i < properties.size(); i++) {
				enableProperty((Property) properties.get(i), value, tree);
			}

			//The checked node is the peripheral node
			tree.update(requirement, null);
		}
		dirty = true;
		driverRequirementsDocument.setDirty(true);
		firePropertyChange(PROP_DIRTY);
	}
	
	private void enableProperty(Property property, boolean value, CheckboxTreeViewer tree) {

		property.setRequired(value);
		
		//Check all the options of this property
		ArrayList options = (property).getOptions();
		for (int i = 0; i < options.size(); i++) {
			((Option) options.get(i)).setRequired(value);
			tree.update(options.get(i), null);
		}
		property.setPartiallyRequired(false);
		tree.update(property, null);
	}

	private void setParentState(Attribute attribute, CheckboxTreeViewer tree) {

		//If all childs are selected then select the parent
		ArrayList brothers = null;
		
		if (attribute instanceof Option) {
			
			brothers = ((Property) attribute.getParent()).getOptions();
		} else {
			brothers = ((Peripheral) attribute.getParent()).getProperties();
		}
		
		boolean allSelected = true;
		boolean nonSelected = true ;
		boolean onePartiallyRequired = false;
		for (int i = 0; i < brothers.size(); i++) {
			Attribute brother = (Attribute) brothers.get(i);
			if (!brother.isRequired() && !brother.isPartiallyRequired()) {
				allSelected = false;
			} else if (brother.isPartiallyRequired()) {
				nonSelected = false;
				onePartiallyRequired = true;
			} else {
				nonSelected = false;
			}
		}
		if (allSelected && !onePartiallyRequired) {
			attribute.getParent().setRequired(true);
			attribute.getParent().setPartiallyRequired(false);
		} else if (nonSelected) {
			attribute.getParent().setRequired(false);
			attribute.getParent().setPartiallyRequired(false);
		} else {
			attribute.getParent().setRequired(false);
			attribute.getParent().setPartiallyRequired(true);
		}
		tree.update(attribute.getParent(), null);


	}

	public boolean isSaveAsAllowed() {
		return false;
	}

	public void setFocus() {
		if (tabFolder != null) {
			tabFolder.setFocus();
		}
	}
}