package com.sap.ip.me.mdk.pios.docgen.wizards;

import java.lang.reflect.*;
import org.eclipse.core.runtime.*;
import org.eclipse.jface.dialogs.*;
import org.eclipse.jface.operation.*;
import org.eclipse.jface.viewers.*;
import org.eclipse.jface.wizard.*;
import org.eclipse.ui.*;

import com.sap.ip.me.mdk.pios.docgen.*;

/**
 * Base class for all the Document Generator wizards. Manages the progress
 * monitor logic.
 */

public abstract class DocGenWizard extends Wizard implements IWorkbenchWizard {

	protected IStructuredSelection selection;
	protected static DocGenResources rb = DocGenResourcesManager.getInstance().getResourceBundle("wizards");	

	/**
	 * Creates a new instance of this class. 
	 * @param windowTittle The tittle of this wizard.
	 */
	public DocGenWizard(String windowTittle) {
		super();
		super.setNeedsProgressMonitor(true);
		this.setWindowTitle(windowTittle);
	}

	public void init(IWorkbench workbench, IStructuredSelection selection) {
		this.selection = selection;
	}

	public boolean performFinish() {

		//This variable is final so that it can be used inside the run method.
		final ProcessingResult result = new ProcessingResult();

		IRunnableWithProgress op = new IRunnableWithProgress() {
			public void run(IProgressMonitor monitor) throws InvocationTargetException {
				try {
					//Set the boolean return value of the function to the result final variable.
					result.setResult(doFinish(monitor));
				} catch (DocumentGeneratorException e) {
					throw new InvocationTargetException(e);
				} finally {
					monitor.done();
				}
			}
		};

		try {
			getContainer().run(false, false, op);

			//Check the result of the doFinish method.
			if (!result.getResult()) {
				return false;
			}
		} catch (InterruptedException e) {
			DocumentGeneratorPlugin.getDefault().logError("Thread interrupted by another tread. Return False.", e);
			return false;
		} catch (InvocationTargetException e) {
			Throwable realException = e.getTargetException();
			MessageDialog.openError(getShell(), rb.getString("error"), realException.getMessage());
			return false;
		}
		return true;
	}

	/**
	 * Called when the user presses the Finish button. 
	 * @param monitor The progress monitor for the operation.
	 * @throws DocumentGeneratorException
	 */
	public abstract boolean doFinish(IProgressMonitor monitor) throws DocumentGeneratorException;

	/**
	 * Helper class for the performFinish method. In this method we need to store the
	 * boolean result of the doFinish() method in the specific wizard. The only way to
	 * get this into a variable global to the method is to make the variable final. But
	 * if we make a primitive (boolean) variable final then the value cannot be assign to 
	 * it after the declaration. For that reason this method was created, it wraps a primitive
	 * value but because only the instance is final then the boolean value of this class
	 * can be changed.
	 * @author Abaco
	 */
	class ProcessingResult {

		private boolean result = false;

		public ProcessingResult() {	}

		public void setResult(boolean b) {
			this.result = b;
		}
		
		public boolean getResult() {
			return result;
		}
	}
}
