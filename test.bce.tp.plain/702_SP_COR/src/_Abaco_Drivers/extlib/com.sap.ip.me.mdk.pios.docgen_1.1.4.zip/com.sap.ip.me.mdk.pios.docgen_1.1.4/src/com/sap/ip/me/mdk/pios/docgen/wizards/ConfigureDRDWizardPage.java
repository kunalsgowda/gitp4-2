package com.sap.ip.me.mdk.pios.docgen.wizards;

import java.util.ArrayList;
import org.eclipse.core.resources.*;
import org.eclipse.jface.viewers.*;
import org.eclipse.jface.dialogs.*;
import org.eclipse.ui.*;

import com.sap.ip.me.mdk.pios.docgen.*;
import com.sap.ip.me.mdk.pios.docgen.attributes.*;
import com.sap.ip.me.mdk.pios.docgen.editors.*;

/**
 * Main wizard page for the ConfigureDRDWizard. 
 * @author Abaco
 */

public class ConfigureDRDWizardPage extends SelectPeripheralsWizardPage {

	private DriverRequirementsDocument driverRequirementsDocument = null;
	private static DocGenResources rb = CreateModifyDRDWizard.rb;	

	/**
	 * Creates a new instance of this class.
	 * @param selection The selected node in the workspace.
	 * @param project The current project.
	 */
	public ConfigureDRDWizardPage(IStructuredSelection selection, IProject project) {
		super(rb.getString("config_drd.page.name"), project, selection);
		setTitle(rb.getString("config_drd.page.tittle"));
		setDescription(rb.getString("config_drd.page.description"));
		setImageDescriptor(DocumentGeneratorPlugin.getDefault().getImageDescriptor(rb.getString("image.configure_drd_header")));
	}

	/**
	 * Returns the Driver Requirements Document used in this document.
	 * @return The Driver Requirements Document used in this document.
	 */
	public DriverRequirementsDocument getDriverRequirementsDocument() {
		return driverRequirementsDocument;
	}
	
	protected void fillPeripheralLists(IProject project) {

		//Validate if the DRD Editor is opened that the changes are saved.
		DRDEditor drdEditor = DocumentGeneratorPlugin.getDefault().getDRDEditor(project);
		if(drdEditor != null) {
			addPeripherals(drdEditor.getDriverRequirementsDocument());			
		} else {
			final IFile file;
			try {
				file = DocumentGeneratorPlugin.getDefault().getDRDFile(project);
			} catch (DocumentGeneratorException e1) {
				DocumentGeneratorPlugin.getDefault().logError("No DRD found in project.", e1);
				setErrorMessage(rb.getString("config_drd.page.error.no_drd_in_project"));
				setPageComplete(false);
				return;
			}

			//Open the Driver Requirements Document editor for this project.
			getShell().getDisplay().asyncExec(new Runnable() {
				public void run() {
					IWorkbenchPage page =
						PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage();
					try {
						DRDEditor drdEditor = (DRDEditor) page.openEditor(file);
						
						addPeripherals(drdEditor.getDriverRequirementsDocument());					
					} catch (PartInitException e) {
						DocumentGeneratorPlugin.getDefault().logError("Unable to initialize the editor.",e);
						MessageDialog.openWarning(null, rb.getString("new_drd.messagedialog.error_initializing_editor.tittle"), rb.getString("new_drd.messagedialog.error_initializing_editor.message", new String[] {e.getMessage()}));
					}
				}
			});
		}
	}
	
	final private void addPeripherals(DriverRequirementsDocument driverRequirementsDocument) {

		this.driverRequirementsDocument = driverRequirementsDocument;

		if (driverRequirementsDocument.isDirty()) {
			setMessage(rb.getString("config_drd.page.warning.drd_not_saved"), WARNING);
		} 
		
		//Add the peripherals existing in the driver requirements document
		ArrayList drdPeripherals = driverRequirementsDocument.getPeripheralList();
		for (int i = 0; i < drdPeripherals.size(); i++) {
			listPeripheralsAdded.add(((Peripheral) drdPeripherals.get(i)).getName());
		} 

		//Add Peripherals
		ArrayList installedPeripherals = PeripheralManager.getInstance().getInstalled();
		for( int i = 0; i < installedPeripherals.size(); i++ ) {
			//Check if the peripheral is not already added
			boolean found = false;
			for (int j = 0; j < drdPeripherals.size(); j++) {
				if (installedPeripherals.get(i).equals(((Peripheral) drdPeripherals.get(j)).getName())) {
					found = true;	
					break;
				}
			}
			
			if (!found) {
				listPeripheralsAvailable.add((String) installedPeripherals.get(i));
			}
		}
	}
}