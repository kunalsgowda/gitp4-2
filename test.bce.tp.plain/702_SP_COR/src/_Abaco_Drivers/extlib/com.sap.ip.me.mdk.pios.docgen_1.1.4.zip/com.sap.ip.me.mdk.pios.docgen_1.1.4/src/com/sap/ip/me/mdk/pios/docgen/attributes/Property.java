package com.sap.ip.me.mdk.pios.docgen.attributes;

import java.util.*;

import com.sap.ip.me.mdk.pios.docgen.*;

/**
 * Represents a Property node in the Driver Requirements Document.
 * A Property object is a child to the Peripheral object. The properties 
 * contain Option object.
 * @author Abaco 
 */

public class Property extends Attribute  {

	private ArrayList options = null;

	/**
	 * Creates a new instance of this class.
	 * @param propertyName The name of this property.
	 * @param parent The Peripheral parent of this property.
	 */
	public Property(String propertyName, Peripheral parent) {
		super();
		super.name = propertyName;
		super.parent = parent;
		options = new ArrayList();
	}

	/**
	 * Returns the option of this property.
	 * @return The option of this property.
	 */
	public ArrayList getOptions() {
		return options;
	}

	/**
	 * Returns the specified option. If the option is not found then null is returned.
	 * @param optionName The name of the option.
	 * @return The specified option.
	 */
	public Option getOption(String optionName) {
		for (int i = 0; i < options.size(); i++) {
			Option option = (Option) options.get(i);
			if (option.getName().equals(optionName)) {
				return option;
			}
		}
		return null;
	}

	/**
	 * Returns the String representation of the xml node for this property.
	 * @return The String representation of the xml node for this property. 
	 */
	protected String ToXml() {
		
		StringBuffer sXml = new StringBuffer("<" + DriverRequirementsDocument.PERIPHERAL_PROP + " ");
		sXml.append(DriverRequirementsDocument.PERIPHERAL_ATTRIB_NAME + "=\"" + getName() + "\" ");
		String sSupp = isRequired() ? "yes": "no" ;
		sXml.append(DriverRequirementsDocument.PERIPHERAL_ATTRIB_REQUIRED + "=\"" + sSupp + "\">" );

		// Add options
		for (int i = 0; i < options.size(); i++) {
			sXml.append(((Attribute) options.get(i)).ToXml());		
		}
		sXml.append("</" + DriverRequirementsDocument.PERIPHERAL_PROP + ">");
		
		return sXml.toString();
	}
	
	protected ResourceBundle getResourceBundle() {
		//The resource bundle for this property is Peripheral one.
		return parent.getResourceBundle();
	}

	public String toString() {
		return getDescription();
	}
	
}