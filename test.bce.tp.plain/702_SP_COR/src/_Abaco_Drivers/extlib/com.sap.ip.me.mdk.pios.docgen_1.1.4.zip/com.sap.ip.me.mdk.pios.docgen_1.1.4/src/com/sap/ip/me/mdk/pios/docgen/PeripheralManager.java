package com.sap.ip.me.mdk.pios.docgen;

import java.io.*;
import java.util.*;
import java.net.*;

import org.eclipse.swt.graphics.*;
import org.eclipse.core.runtime.*;
import org.eclipse.jface.dialogs.*;

/**
 * Manager of all peripherals. Contains a list of peripherals and the 
 * templates each one defines. 
 */

public class PeripheralManager {

	private static PeripheralManager instance = null;

	private ArrayList peripherals = null;
	private DocGenResources rb = DocGenResourcesManager.getInstance().getResourceBundle("document_generator");

	/**
	 * Creates a new instance of this class. 
	 * Loads all the peripheral templates into memory.
	 */
	private PeripheralManager() {
		peripherals = new ArrayList();

		//Get the installed peripherals template files
		URL path = DocumentGeneratorPlugin.getDefault().find(new Path("peripheral_types"));
		File peripheralsPath = new File(path.getFile());

		//Filter the template files using their extension
		File[] templateFiles = peripheralsPath.listFiles(new java.io.FileFilter() {
			public boolean accept(File pathname) {
				String fileName = pathname.getAbsolutePath();
				String extension = fileName.substring(pathname.getAbsolutePath().lastIndexOf('.') + 1);

				if (extension.equals("xml")) {
					return true;
				} else {
					return false;
				}
			}
		});
		
		
		PeripheralInfoHandler peripheralInfoHandler = new PeripheralInfoHandler();
		for (int i = 0; i < templateFiles.length; i++) {
			// Add to list
			try {
				PeripheralInfo peripheralInfo = peripheralInfoHandler.parseDoc(templateFiles[i]);
				peripherals.add(peripheralInfo);
			} catch (DocumentGeneratorException ex) {
				//This exception only occurs if the peripheral info cannot be created and
				//in that case it is not added to the list.
				DocumentGeneratorPlugin.getDefault().logError("Unable to load peripheral: " + templateFiles[i].getName(), ex);
				MessageDialog.openError(null, rb.getString("pm.messagedialog.error_loading_peripheral.tittle"), rb.getString("pm.messagedialog.error_loading_peripheral.message", new String[] {templateFiles[i].getName()}));
			}
		}
	}

	/** 
	 * Returns an ArrayList containing the names of the installed peripherals.
	 * @return An ArrayList containing the names of the installed peripherals.
	 */
	public ArrayList getInstalled() {

		ArrayList result = new ArrayList();
		for (int i = 0; i < peripherals.size(); i++) {
			result.add(((PeripheralInfo) peripherals.get(i)).getName());
		}

		return result;
	}
	
	/**
	 * Returns the full path of the template for the specified peripheral.
	 * @param peripheralName The name of the peripheral to process.
	 * @return The full path of the template for the specified peripheral.
	 * @throws DocumentGeneratorException
	 */
	public String getPeripheralTemplatePath(String peripheralName) throws DocumentGeneratorException {

		PeripheralInfo peripheralInfo = getPeripheral(peripheralName); 
		if (peripheralInfo == null) {
			throw new DocumentGeneratorException(rb.getString("pm.peripheral_not_found", new String[] {peripheralName}));
		}

		// Read Template 
		URL path = DocumentGeneratorPlugin.getDefault().find(new Path("peripheral_types"));
		File peripheralFile = new File(path.getFile() + File.separator + peripheralInfo.getTemplateFileName());
		return peripheralFile.getAbsolutePath();
	}

	/**
	 * Returns the ResourceBundle object for the specified peripheral.
	 * @param peripheralName The name of the peripheral to process.
	 * @return The ResourceBundle object for the specified peripheral.
	 * @throws DocumentGeneratorException
	 */
	public ResourceBundle getPeripheralResourceBundle(String peripheralName) throws DocumentGeneratorException {

		PeripheralInfo peripheralInfo = getPeripheral(peripheralName); 
		if (peripheralInfo == null) {
			throw new DocumentGeneratorException(rb.getString("pm.peripheral_not_found", new String[] {peripheralName}));
		}
		
		return peripheralInfo.getResourceBundle();
	}
	
	/**
	 * Returns the Image object for the icon of the specified peripheral.
	 * @param peripheralName The name of the peripheral to process.
	 * @return The Image object for the icon of the specified peripheral.
	 * @throws DocumentGeneratorException
	 */
	public Image getPeripheralIcon(String peripheralName) throws DocumentGeneratorException {

		PeripheralInfo peripheralInfo = getPeripheral(peripheralName); 
		if (peripheralInfo == null) {
			throw new DocumentGeneratorException(rb.getString("pm.peripheral_not_found", new String[] {peripheralName}));
		}

		return peripheralInfo.getImage();
	} 
	
	/**
	 * Returns the instance of this class. 
	 * @return the instance of this class.
	 */
	public static PeripheralManager getInstance() {
		if (instance == null) {
			instance = new PeripheralManager();
		}
		return instance;
	}
	
	private PeripheralInfo getPeripheral(String peripheralName) {

		//Get the peripheral
		PeripheralInfo peripheralInfo = null;
		for (int i = 0; i < peripherals.size(); i++) {
			if (((PeripheralInfo) peripherals.get(i)).getName().equalsIgnoreCase(peripheralName)) {
				peripheralInfo = (PeripheralInfo) peripherals.get(i);
				break;
			}
		}
		//Returns null if the peripheral was not found
		return peripheralInfo;
	}

}
