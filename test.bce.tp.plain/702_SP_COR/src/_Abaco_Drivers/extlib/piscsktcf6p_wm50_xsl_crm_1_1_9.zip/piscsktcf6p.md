Types=DriverParameters,Integrated
Parameters.DriverParameters=ScanBufferSize,SkipInvalidScan
DriverParameters.ScanBufferSize=2048
DriverParameters.SkipInvalidScan=true
Parameters.Integrated
