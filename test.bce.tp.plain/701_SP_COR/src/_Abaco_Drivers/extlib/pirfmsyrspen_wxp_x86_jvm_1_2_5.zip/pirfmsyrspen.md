Types=DriverParameters,Serial
Parameters.DriverParameters=ReadTimeout,WriteTimeout,IdentifyTimeout
DriverParameters.ReadTimeout=2000
DriverParameters.WriteTimeout=2000
DriverParameters.IdentifyTimeout=3000
Parameters.Serial=Port
Serial.Port=COM1:,COM2:,COM3:,COM4:
