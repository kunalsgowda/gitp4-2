Types=Integrated
Parameters.Integrated
