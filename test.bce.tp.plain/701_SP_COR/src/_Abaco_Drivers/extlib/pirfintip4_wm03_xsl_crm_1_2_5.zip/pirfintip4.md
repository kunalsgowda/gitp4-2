Types=DriverParameters,Irda
Parameters.DriverParameters=ReaderName,IDTries,ReadTries,WriteTries
Parameters.Irda=Protocol,DiscoverTimeout,OpenRetries,OpenTimeout,DataBlockSize,ReadTimeout
Irda.Protocol=COMM,OBEX,LPT,LMP,TinyTP
