Types=DriverParameters,Integrated
Parameters.DriverParameters=ReadTimeout,WriteTimeout,IdentifyTimeout,PortType,CFPort
DriverParameters.ReadTimeout=2000
DriverParameters.WriteTimeout=2000
DriverParameters.IdentifyTimeout=3000
DriverParameters.PortType=0
DriverParameters.CFPort=COM4:
Parameters.Integrated
