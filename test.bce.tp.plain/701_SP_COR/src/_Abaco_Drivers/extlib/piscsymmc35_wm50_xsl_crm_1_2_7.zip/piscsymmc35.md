Types=DriverParameters,Integrated
Parameters.DriverParameters=Flashlight,TriggerHold,ScanTimeout
DriverParameters.Flashlight=false
DriverParameters.TriggerHold=false
DriverParameters.ScanTimeout=10000
Parameters.Integrated
