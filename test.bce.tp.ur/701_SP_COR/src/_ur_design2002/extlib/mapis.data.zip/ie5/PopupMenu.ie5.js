var oPopup;
var _ur_POMN = {all:new Array(),menus:new Array(),level:0};
var _ur_POMN_triggerId="";
var mnu = new Object();
mnu.intv = null;
mnu.active = false;
mnu.delay = 250;
mnu.cancel = false;
mnu.mnuWin = null;
mnu.mnuE = null;
var sapPopupMenuLevel = 0;
var menuFontSize;
var subMenus = new Array(null,null,null,null,null,null);
var subMenuItems = new Array(null,null,null,null,null,null);
var initMenus = new Array();
var me = window;
function sapUrMapi_PopupMenu_init(id,e) {
	if (me.menuObject) {
	  sapUrMapi_PopupMenu_exit(id,e);
	}
	if (!me.menuObject) {
	  var items =window.document.getElementById(id).childNodes.item(0).childNodes.item(0).childNodes.item(1).childNodes;
	  var menu = new sapUrMapi_PopupMenu(items);
	  me.menuObject = menu;
    me.menuObject.standalone=true;
  }
}
function sapUrMapi_PopupMenu_exit(id,e) {
	if (e.srcElement.id==id) {
		if (me.menuObject) {
			if (!me.menuObject.standalone) {
			  sapUrMapi_PopupMenu_hideAll();
			  sapUrMapi_PopupMenu_setItemActive(me,-1, id);
		    me.menuObject = null;
		  }
		}
	} else {
		if (me.menuObject) {
			if (me.menuObject.out) {
		    sapUrMapi_PopupMenu_setItemActive(me,-1, id);
		  }
		}

	}
}

function sapUrMapi_PopupMenu_hoverItem(mywindow,id,e) {
	//find the popup with the event
	var o=mywindow.event.srcElement;
  if(o.parentNode.className=="urMnuDvdr"){
      iIdx = "dvdr"
      sapUrMapi_PopupMenu_setItemActive(mywindow,iIdx, id);
      if (mywindow.mylevel<=sapPopupMenuLevel) {
                  for (var n=mywindow.mylevel+1;n<=sapPopupMenuLevel;n++) {
                       subMenus[n].hide();
                  }
      }
      return;
  }
  if (o.tagName=="IMG" || o.tagName=="NOBR" || o.tagName=="SPAN")o=o.parentNode;
	if (o.tagName=="TD") {
	  iIdx = parseInt(o.parentNode.getAttribute("Idx"));
	  if (mywindow.menuObject==null) {
	    sapUrMapi_PopupMenu_init(id,e);
	  }
	  if (mywindow.menuObject.activeItem==iIdx) return;

//GPR:  need to escape hover behavior for scrollers
if(o.getAttribute("isscroll")=="true") {
    mywindow.event.cancelBubble=true;
				iIdx=-1;
    return false;
}

	  sapUrMapi_PopupMenu_setItemActive(mywindow,iIdx, id);
	  if (mywindow.mylevel<=sapPopupMenuLevel) {
	  	for (var n=mywindow.mylevel+1;n<=sapPopupMenuLevel;n++) {
	      subMenus[n].hide();
      }
	  }
	  try {
	  if (ur_getAttD(mywindow.menuObject.items[mywindow.menuObject.activeItem],"st","").indexOf("d")==-1) {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"opensub", id);
	  }
		} catch (e) {
		}
	}
	mywindow.event.cancelBubble=true;

}

var oPopup;
function sapUrMapi_PopupMenu_hideAll() {
  window.document.detachEvent("ondeactivate",closeIfDeactivated);
  for (var n=0;n<sapPopupMenuLevel+1;n++) {
	 if (subMenus[n]!=null) {
    subMenus[n].hide();
    }
  }
  if (oPopup) {
    oPopup.hide();
    try {
	  //CSN: 340942 2010, If a td is focused here the browser scrolls
	  //Therefore focus the first child if any
	  var oSrc = oPopup.source.object;
	  if (oSrc && oSrc.tagName=="TD") {
	    if (oSrc.firstChild && oSrc.firstChild.nodeType == 1) 
	        ur_focus(oSrc.firstChild);
	  } else {
	    ur_focus(oSrc);
	  }
	} catch(e) 
	{}	
  }
  oPopup=null;
  window.document.onmousedown=null;
  document.detachEvent("onmousedown",sapUrMapi_PopupMenu_hideAll);

  sapPopupMenuLevel=0;
}

function 	sapUrMapi_PopupMenu_showMenu(idTrigger,idContent,enumAlignment,e) {
	var styles = document.getElementsByTagName("LINK");
	var arrUrls;
	_ur_POMN_triggerId=idTrigger;
	arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
  //close all open submenus
  for (var i=0;i<subMenus.length;i++) {
  	if (subMenus[i]!=null) {
  		subMenus[i].hide();
  	}
  }
	var menuDiv = ur_get(idContent);
	if (!menuDiv) return;
	if (menuDiv.hasChildNodes() && menuDiv.childNodes[0].tagName=="XMP") {
	  menuDiv.innerHTML=menuDiv.firstChild.innerHTML; 
	}
	sapUrMapi_PopupMenu_drawInit(idContent); //Jan

	oPopup = new sapPopup(window,arrUrls,ur_get(idContent),ur_get(idTrigger),e,0);
  oPopup.onblur=oPopup.hide;
  oPopup.idTrigger = idTrigger;
  
  if (ur_system.direction=="rtl") {
    if (!enumAlignment) enumAlignment= sapPopupPositionBehavior.MENURIGHT
  } else {
    if (!enumAlignment) enumAlignment= sapPopupPositionBehavior.MENULEFT
  }
  oPopup.positionbehavior = enumAlignment;
  oPopup.show();
  document.attachEvent("onmousedown",sapUrMapi_PopupMenu_hideAll);
  window.document.attachEvent("ondeactivate",closeIfDeactivated);


  
	var items = oPopup.frame.window.document.body.childNodes.item(0).childNodes.item(0).childNodes.item(0).childNodes.item(1).childNodes;
  var menu = new sapUrMapi_PopupMenu(items);
  oPopup.frame.window.menuObject = menu;
  oPopup.frame.window.document.body.onkeydown = menuDiv.childNodes.item(0).onkeydown;
  try {
  if (e.type=="keydown") {
  	sapUrMapi_PopupMenu_setItemActive(oPopup.frame.window,"first", idContent);
  }
  } catch (exc) {}
	if (ur_system.is508) {
  sapUrMapi_setTabIndex(oPopup.frame.window.document.body.childNodes.item(0).childNodes.item(0),0);
  oPopup.frame.window.document.body.childNodes.item(0).focus();
  } else {
		oPopup.frame.window.document.body.focus();
	}
try {
  oPopup.frame.window.document.body.childNodes.item(0).childNodes.item(0).fireEvent("onkeypress");
} catch(e) {
}
}

function sapUrMapi_PopupMenu_setItemActive(win,newActive, sId) {
	var remActive = newActive;
	var menuObj=win.menuObject;
	menuObj.out=false;
	if ((newActive=="opensubkey")||(newActive=="opensub")) {
		if (!menuObj.items[menuObj.activeItem]) return;
		if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) return;
		var sSubMenuId = ur_getAttD(menuObj.items[menuObj.activeItem],"smnu","");
		if (sSubMenuId!="") {
		  if (!oPopup) {
		  	var iStartLevel=-1;
		  } else {
		  	var iStartLevel=win.mylevel;
		  }
		  if (iStartLevel<sapPopupMenuLevel) {
				for (var n=iStartLevel+1;n<sapPopupMenuLevel+1;n++) {
				  if (subMenus[n]!=null) {
  				  subMenus[n].hide();
  		      //subMenuItems[n].className = 'urMnuRowOff';
  				}
				}
			  sapPopupMenuLevel=iStartLevel;
			}

			var arrUrls;
			arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");

			if (!oPopup) {
			   subwindow = window;
  			 sapPopupMenuLevel = 0;
			} else {
			  subwindow = win;
			  sapPopupMenuLevel = win.mylevel+1;
			}
			var src = menuObj.items[menuObj.activeItem];

			var o = ur_get(sSubMenuId);
			if (o.hasChildNodes() && o.firstChild.tagName=="XMP") {
				o.innerHTML=o.firstChild.innerHTML; 
			}
			sapUrMapi_PopupMenu_drawInit(sSubMenuId, window); //GPR HERE

		  sapUrMapi_PopupMenu_drawInit(sSubMenuId);
			subMenu = new sapPopup(window,arrUrls,o,src,subwindow.event,sapPopupMenuLevel);
		  subMenu.onblur=subMenu.hide;
		  subMenu.positionbehavior = sapPopupPositionBehavior.SUBMENU;
		  subMenu.show();
		  subMenus[sapPopupMenuLevel] = subMenu;
			subMenuItems[sapPopupMenuLevel] = menuObj.items[menuObj.activeItem];
			var items = subMenus[sapPopupMenuLevel].frame.window.document.body.childNodes.item(0).childNodes.item(0).childNodes.item(0).childNodes.item(1).childNodes;
			var menu = new sapUrMapi_PopupMenu(items);
		  subMenus[sapPopupMenuLevel].frame.window.menuObject = menu;
		  subMenus[sapPopupMenuLevel].frame.window.document.body.onkeydown = o.childNodes.item(0).onkeydown;

			//sapUrMapi_PopupMenu_drawInit(sSubMenuId, subMenu.frame.window); //GPR HERE

			if (!oPopup) {
				oPopup= subMenus[sapPopupMenuLevel];
			}
			if (win.mylevel>1) {
				sapUrMapi_PopupMenu_setItemActive(subMenus[win.mylevel-1].frame.window,subMenus[win.mylevel-1].frame.window.menuObject.activeItem, sId)
			} else {
				if (!oPopup) {
					sapUrMapi_PopupMenu_setItemActive(subMenus[sapPopupMenuLevel].frame.window,subMenus[sapPopupMenuLevel].frame.window.menuObject.activeItem, sId)
				} else {
					sapUrMapi_PopupMenu_setItemActive(oPopup.frame.window,oPopup.frame.window.menuObject.activeItem, sId)
				}
			}
			if (newActive=="opensubkey") {
				sapUrMapi_PopupMenu_setItemActive(subMenus[sapPopupMenuLevel].frame.window,"first", sId);
		  }
			if (ur_system.is508) {
		  sapUrMapi_setTabIndex(subMenus[sapPopupMenuLevel].frame.window.document.body.childNodes.item(0),0);
		  subMenus[sapPopupMenuLevel].frame.window.document.body.childNodes.item(0).focus();
			}
try {
		  subMenus[sapPopupMenuLevel].frame.window.document.body.childNodes.item(0).fireEvent("onkeypress");
} catch(e) {
}
		}
	  return;
	}
	if (newActive=="closesub") {
		if (win.mylevel) {
			subMenus[win.mylevel].hide();
			if (win.mylevel>1) {
				subMenus[win.mylevel-1].frame.window.document.body.focus();
				sapUrMapi_PopupMenu_setItemActive(subMenus[win.mylevel-1].frame.window,subMenus[win.mylevel-1].frame.window.menuObject.activeItem, sId)
			} else {
				oPopup.frame.window.document.body.focus();
				sapUrMapi_PopupMenu_setItemActive(oPopup.frame.window,oPopup.frame.window.menuObject.activeItem, sId)
			}
		}
	  return;
	}

	if (newActive=="first") {
	  newActive=menuObj.activeItem+1;
	  if (newActive>menuObj.items.length-1) newActive=0;
	}

	var bDown = "true";
	if (newActive=="next") {
	  newActive=menuObj.activeItem+1;
		if (newActive>menuObj.items.length-1){
			if (menuObj.items[0].style.display != "none"){
				newActive=0;
			}
			else{
			   newActive = menuObj.items.length-1;
			   return;
			}

		}
	}
	if (newActive=="prev") {
		newActive=menuObj.activeItem-1;
		if (newActive<0){
			if (menuObj.items[menuObj.items.length-1].style.display != "none"){
				newActive=menuObj.items.length-1;
			}
			else{
			   newActive = 0;
			   return;
			}
		}
		bDown = "false";
	}
  if (newActive=="dvdr") {
             if (menuObj.activeItem>-1) {
                  if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) {
                    menuObj.items[menuObj.activeItem].className="urMnuRowDsbl";
                  } else {
                    menuObj.items[menuObj.activeItem].className="urMnuRowOff";
                  }
             }
             menuObj.activeItem=newActive;
  }
	if ((newActive>-1) || isNaN(newActive)) {
		if (menuObj.activeItem>-1) {
			if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) {
			  menuObj.items[menuObj.activeItem].className="urMnuRowDsbl";
		  } else {
			  menuObj.items[menuObj.activeItem].className="urMnuRowOff";
		  }
		  if (ur_system.is508) {
		  	with(menuObj.items[menuObj.activeItem]) {
		  	  for (var i=0;i<childNodes.length;i++) {
		  	    if (childNodes.item(i).className=="urMnuTxt") {
		  	    	sapUrMapi_setTabIndex(childNodes.item(i),-1);
		  	    	break;
		  	    }
		  	  }
		  	}
		  }
		}
		menuObj.activeItem =  newActive;
		if (menuObj.activeItem>-1) {
		  while (menuObj.items[menuObj.activeItem].style.display == "none"){
			sapUrMapi_PopupMenu_manualScroll(win, sId, bDown, true);
		  }
		  //if (ur_system.is508) {
		  	with(menuObj.items[menuObj.activeItem]) {
		  	  for (var i=0;i<childNodes.length;i++) {
		  	    if (childNodes.item(i).className=="urMnuTxt") {
		  	    	if (ur_system.is508) {
		  	    	sapUrMapi_setTabIndex(childNodes.item(i),0);
					childNodes.item(i).hideFocus=true;
		  	    	childNodes.item(i).focus();
		  				}
		  	    	break;
		  	    }
		  	  }
		  	}
		  //}
			if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) {
			  menuObj.items[menuObj.activeItem].className="urMnuRowDsblOn";
		  } else {
			  menuObj.items[menuObj.activeItem].className="urMnuRowOn";
		  }
		}
	} else {
		if (newActive==-1) {
			if (ur_system.is508) {
				if (menuObj) {
					if (menuObj.items) {
				  	for (var j=0;j<menuObj.items.length;j++) {
				 			if (menuObj.items[j]) {
					  		with(menuObj.items[j]) {
						  	  for (var i=0;i<childNodes.length;i++) {
						  	    if (childNodes.item(i).className=="urMnuTxt") {
						  	    	sapUrMapi_setTabIndex(childNodes.item(i),-1);
						  	    	break;
						  	    }
						  	  }
						  	}
					  	}
					  }
					}
				}
		  }
		  if (menuObj) {
			  if (menuObj.items.length>0) {
			  	if (menuObj.items[menuObj.activeItem]) {
						if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) {
						  menuObj.items[menuObj.activeItem].className="urMnuRowDsbl";
					  } else {
						  menuObj.items[menuObj.activeItem].className="urMnuRow";
					  }
					}
				}
			}
		}
	}
}



function sapUrMapi_PopupMenu(items) {
	this.activeItem = -1;
	this.items = new Array();
	for (var i=0;i<items.length;i++) {
		if (items.item(i).childNodes.item(0).className!="urMnuDvdr") {
			this.items[this.items.length]=items.item(i);
			this.items[this.items.length-1].setAttribute("Idx",this.items.length-1);
		}
	}
	return this;
}
function sapUrMapi_PopupMenu_keyDown(mywindow,id,e) {
  	
	if (!oPopup || oPopup.frame.object.style.posTop < 0) return;
	
	if (e.keyCode==27 || e.keyCode==115 ) {
		if (mywindow.menuObject) {
			if (mywindow.mylevel>0) {
				sapUrMapi_PopupMenu_setItemActive(mywindow,"closesub", id);
			} else {
				if (oPopup.source.object) oPopup.source.object.focus();
				hidePopupMenu();
			}
		}
		ur_EVT_cancel(e);
		return false;
	}
	if (e.keyCode==40) { //down
	  sapUrMapi_PopupMenu_setItemActive(mywindow,"next", id);
	}
	if (e.keyCode==38) { //up
	  sapUrMapi_PopupMenu_setItemActive(mywindow,"prev", id);
	}
	if (e.keyCode==39) { //right
	  if (ur_system.direction == "rtl") {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"closesub", id);
	  } else {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"opensubkey", id);
	  }
    }
	if (e.keyCode==37) { //left
	  if (ur_system.direction == "rtl") {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"opensubkey", id);
	  } else {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"closesub", id);
	  }
	}
	if (e.keyCode==13) { //
	  ur_PopupMenu_click(mywindow,id,e);
	}
	if (e.keyCode!=9) {
	  e.cancelBubble=true;
	  e.returnValue=false;
	} else {
		if (mywindow.menuObject) {
			mywindow.menuObject.out=true;
		}
		if(oPopup.source.object!=null) oPopup.source.object.focus();
		hidePopupMenu();
	  e.cancelBubble=false;
	  e.returnValue=true;
	}
	return false;
}

function sapUrMapi_PopupMenu_ExecuteLink(id) {
  oItem = window.document.getElementById(id);
  sTarget = oItem.target;
  sHref   = oItem.href;
  oTarget = top.frames[sTarget];
  if (oTarget) {
  	oTarget.location.href=sHref;
  } else {
    window.open(sHref,sTarget,"");
  }
}



//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupMenu_drawInit
//* parameter   : sId - string - Id of the PopupMenu
//*               oSubWindow - Window in which the menu is to appear
//* description : builds up the menu in max possible height
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_PopupMenu_drawInit( sId, oSubWindow ){

	if (typeof(initMenus[sId])!="undefined" && initMenus[sId] != null && initMenus[sId].windowHeight==window.document.body.clientHeight) {
	  return;
	}

	var tbl = null;
	if (!oSubWindow) {
	  tbl = window.document.getElementById(sId+"-r");
	}
	else {
	  tbl = oSubWindow.document.getElementById(sId+"-r");
	}
	if (typeof(tbl)=="undefined" || tbl==null)  {
 		tbl=oSubWindow.document.getElementById(sId).childNodes.item(0).childNodes.item(0);
 		if (tbl.tagName=="TABLE") {
 		  	tbl.setAttribute("id",sId+"-r");
 		} else {
 			tbl=null;
 		}

 	}

	//escape the function if we can't draw it correctly
	if (typeof(tbl)=="undefined" || tbl==null)  {
	return;
	}
	tbl.style.width = tbl.offsetWidth;
	
	var rows = tbl.childNodes.item(1).rows;
	//escape the function if we can't draw it correctly
	if (tbl.offsetWidth == 0 || !rows(0)){
	  //tbl.style.display="none";
	return;
	}

	var visIdx = tbl.getAttribute("visidx") - 0;
    var visCnt = tbl.getAttribute("viscnt") - 0;
	if (visCnt==0){
	    visCnt = rows.length;
	    visIdx = visIdx = 0;
	}
	tbl.childNodes.item(0).style.display = "";
	tbl.childNodes.item(2).style.display = "";
  var actVisCnt = visCnt;
  var oldActVisCnt = tbl.getAttribute("actviscnt") - 0;
	var maxVisCnt = rows.length - visIdx;

	if (visCnt > maxVisCnt) {
	    //reset the visible count
		visCnt = maxVisCnt;
		//tbl.setAttribute("viscnt", visCnt);
	}

	//tbl.width = tbl.offsetWidth;
  //tbl.style.width = tbl.offsetWidth + "px";

	//get max height of window
	var maxHt = window.document.body.clientHeight;
	var mnuHt = tbl.offsetHeight;
	var btnHt = tbl.childNodes.item(0).rows(0).offsetHeight + tbl.childNodes.item(2).rows(0).offsetHeight;
	var visBtns = true;
	var menuProps = new Array();
	var firsttime = false;

	if (typeof(initMenus[sId])=="undefined" || initMenus[sId] == null) {
	  for (var i = 0; i < rows.length; i++){
        for (var z = 0; z < rows(i).cells.length; z++){
						var oCell = rows(i).cells(z);
						if (oCell.offsetWidth == 0) {
							var originalStyle = rows(i).style.display;
							rows(i).style.display="";
              				oCell.style.width = oCell.offsetWidth +"px";
							rows(i).style.display = originalStyle;                            
						}
						else {
							oCell.style.width = oCell.offsetWidth +"px";
						}
        }
      }
	  menuProps["windowHeight"] = maxHt;
	  menuProps["menuHeight"]= mnuHt;
	  menuProps["buttonHeight"] = btnHt;
	  menuProps["itemHeight"] = rows(0).offsetHeight;
	  initMenus[sId]=menuProps;
	  oldActVisCnt = visCnt;
	  firsttime=true;
	} else {
	  initMenus[sId].windowHeight=maxHt;
	}
	if (typeof(menuFontSize)=="undefined") {
	  menuFontSize = rows(0).cells(0).currentStyle.fontSize;
	}

	//see if we need buttons, if not, turn them off
	if ((visIdx == 0) && (visCnt >= rows.length)) {
	    if (maxHt > mnuHt){
	      mnuHt = 0;
	      tbl.setAttribute("actviscnt", actVisCnt);
		  for (var i = 0; i < rows.length; i++){
    		 if (rows(i).cells(0).className == "urMnuDvdr"){
			    rows(i).cells(0).style.fontSize="5px";
		     }
		     visBtns = false;
		  }
	      tbl.childNodes.item(0).style.display = "none";
    	  tbl.childNodes.item(2).style.display = "none";
    	  mnuHt = 0;
    	  actVisCnt = visCnt;
	    } else {
	      tbl.childNodes.item(0).style.display = "";
		  tbl.childNodes.item(2).style.display = "";
	      mnuHt = 0 + tbl.childNodes.item(0).rows(0).offsetHeight + tbl.childNodes.item(2).rows(0).offsetHeight;
          actVisCnt = Math.floor((maxHt-mnuHt)/initMenus[sId].itemHeight);
		}
	}
    var n;


	if (actVisCnt <= 0) actVisCnt=1;
	if (actVisCnt > visCnt) actVisCnt=visCnt;

	var upOn = false;
	var dnOn = false;

	if (firsttime) {
	  //turn off all rows before our active (first visible) row
	  for (n=0; n<visIdx; n++) rows(n).style.display = "none";
	  // turn off all rows after the last visible row
	  for (n=visIdx+actVisCnt; n<rows.length; n++) rows(n).style.display = "none";
	}
	if (visIdx>0) upOn = true;
	// turn on / off the items that changed their visibility since last time of rendering
	// remark: if (firsttime), then oldActVisCnt == visCnt
    if (actVisCnt < oldActVisCnt) {
      for (n= visIdx+actVisCnt; n<visIdx+oldActVisCnt; n++)
           rows(n).style.display = "none";
	} else {
	  for (n= visIdx+oldActVisCnt; n<visIdx+actVisCnt; n++)
           rows(n).style.display = "";
    }
    if (visIdx+actVisCnt < rows.length) dnOn = true;

    if ((actVisCnt!=oldActVisCnt) || (firsttime))
      tbl.setAttribute("actviscnt", actVisCnt);

	//and activate our buttons, if visible
	if (visBtns) {
	  if (!oSubWindow) {
	    sapUrMapi_PopupMenu_setButtons( sId, false, upOn );
	    sapUrMapi_PopupMenu_setButtons( sId, true, dnOn );
	  } else {
		sapUrMapi_PopupMenu_setButtons( sId, false, upOn, oSubWindow );
		sapUrMapi_PopupMenu_setButtons( sId, true, dnOn, oSubWindow );
	  }
    }
}

function sapUrMapi_PopupMenu_timeScroll(oWindow, sId, bDown, bCancel, e) {
    //assign our arguments to global variables
    mnu.mnuWin = oWindow;
    mnu.mnuWin.event.cancelBubble = true;

    if (bCancel & mnu.intv == null){
        mnu.active = false;
        return false;
    }
    else if (bCancel){
        mnu.cancel = true;
        mnu.mnuWin.parent.clearInterval(mnu.intv);
        mnu.intv = null;
        //now call to finish out our onclick event
        if (mnu.active == false){
            sapUrMapi_PopupMenu_scrollItem(sId, bDown);
        }
        mnu.active = false;
    }
    else{
        mnu.cancel = false;
		mnu.intv = mnu.mnuWin.parent.setInterval("sapUrMapi_PopupMenu_scrollItem('" + sId + "', '" + bDown + "')", mnu.delay);
    }
}

function sapUrMapi_PopupMenu_manualScroll(oWindow, sId, bDown, bCancel, e ){
    //assign our arguments to global variables
    mnu.mnuWin = oWindow;
    mnu.mnuWin.event.cancelBubble = true;
	if (bCancel){
        mnu.cancel = true;
        mnu.mnuWin.parent.clearInterval(mnu.intv);
        mnu.intv = null;
        //now call to finish out our onclick event
        if (mnu.active == false){
            sapUrMapi_PopupMenu_scrollItem(sId, bDown);
        }
        mnu.active = false;
	}
	else{
	   return false;
	}
}

function sapUrMapi_PopupMenu_scrollItem(sId, bDown) {
    mnu.active = true;
    //find the menu wrapper and other elements
	var tbl = mnu.mnuWin.document.getElementById(sId+"-r");
    var tbody = tbl.childNodes.item(1);

    //get indexes and scroll
    var rIdx = tbl.getAttribute("visidx") - 0;
    var visCnt = tbl.getAttribute("actviscnt") - 0;

    //change scroll direction
    if (bDown == "true"){
        if ((rIdx + visCnt) >= tbody.rows.length){
            mnu.cancel = true;
        }
        else{
            tbody.rows(rIdx).style.display = "none";
			tbody.rows(rIdx + visCnt).style.display = "";
            ++rIdx;
            tbl.setAttribute("visidx", rIdx);
            mnu.cancel = false;
        }
    }
    else{
       if (rIdx <= 0){
           mnu.cancel = true;
       }
       else{
           tbody.rows(rIdx + visCnt - 1).style.display = "none";
           --rIdx;
		   tbody.rows(rIdx).style.display = "";
           tbl.setAttribute("visidx", rIdx);
           mnu.cancel = false;
       }
    }
    //manage the timeout
    if(mnu.cancel){
        mnu.mnuWin.parent.clearInterval(mnu.intv);
        mnu.intv = null;
        return;
    }
    else{
       //toggle up menu
       if ((rIdx + visCnt - 0) >= tbody.rows.length){
           sapUrMapi_PopupMenu_setButtons(sId, true, false);
       }
       else{
           sapUrMapi_PopupMenu_setButtons(sId, true, true);
       }
       if (rIdx - 0 <= 0){
          sapUrMapi_PopupMenu_setButtons(sId, false, false);
       }
       else{
          sapUrMapi_PopupMenu_setButtons(sId, false, true);
       }
    }
}

function sapUrMapi_PopupMenu_setButtons( sId, bUp, bOn, oMenuWin ){
    var x;
    var node;
    (bUp)? x = 2 : x = 0;
		try {
			if (oMenuWin) {
			  node = oMenuWin.document.getElementById(sId+"-r").childNodes.item(x).childNodes.item(0).childNodes.item(0);
			} else {
	        if (mnu.mnuWin != null){
	         node = mnu.mnuWin.document.getElementById(sId+"-r").childNodes.item(x).childNodes.item(0).childNodes.item(0);
	        } else {
	         node = window.document.getElementById(sId+"-r").childNodes.item(x).childNodes.item(0).childNodes.item(0);
	        }
			}
			if (!bOn){
			  node.className = node.className.split("Dsbl")[0] + "Dsbl";
			} else {
		      node.className = node.className.split("Dsbl")[0];
			}
		}
		catch(e){
		}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupMenuItem_setDisabled
//* parameter   : sPopupMenuId - string Id of the PopupMenu
//*               iIdx - int Index of the MenuItem to disable
//* return      : none
//*	description	: Disables a PopupMenuItem in a PopupMenu
//* ------------------------------------------------------------------------
function sapUrMapi_PopupMenuItem_setDisabled( sPopupMenuId, iIdx){
  var tbl = window.document.getElementById(sPopupMenuId+"-r");
	if (isNaN(iIdx)) { return; }
	var rows = tbl.childNodes.item(1).rows;
	rows(iIdx).className="urMnuRowDsbl";
	rows(iIdx).setAttribute("dsbl","true");
	rows(iIdx).cells(1).oldTitle=rows(iIdx).cells(1).title;
  rows(iIdx).cells(1).title=getLanguageText("SAPUR_POPUP_ITEM_WHL_DISABLED",new Array(rows(iIdx).cells(1).innerText,"SAPUR_POPUP_ITEM_DISABLED"))
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupMenuItem_setEnabled
//* parameter   : sPopupMenuId - string Id of the PopupMenu
//*               iIdx - int Index of the MenuItem to disable
//* return      : none
//*	description	: Enables a PopupMenuItem in a PopupMenu
//* ------------------------------------------------------------------------
function sapUrMapi_PopupMenuItem_setEnabled( sPopupMenuId, iIdx){
  var tbl = window.document.getElementById(sPopupMenuId+"-r");
	if (isNaN(iIdx)) { return; }
	var rows = tbl.childNodes.item(1).rows;
	rows(iIdx).className="urMnuRowOff";
	rows(iIdx).setAttribute("dsbl","false");
	rows(iIdx).cells(1).title=rows(iIdx).cells(1).oldTitle;
}
var ur_replace_function=false;
var ur_replace_function_button_id="";

function sapUrMapi_PopupMenu_selectItem(oWnd,sItemId,bChecked,oEvt) {
	
   if(oEvt && oPopup && oPopup.idTrigger && document.getElementById(oPopup.idTrigger)) {
     if(!oEvt.ur_param) oEvt.ur_param = {};
   	 oEvt.ur_param.TriggerId = oPopup.idTrigger;
   }	
	
   oWnd.me.sapUrMapi_ToolbarButton_setFunctionFromMenuItem(sItemId);  
   oWnd.me.sapUrMapi_PopupMenu_hideAll();
   ur_EVT_cancel(oEvt);
}

// returns the popup menu js object 
function mf_PopupMenu_getObj(sId,hWnd) {
	//get the popupmenu on the page
	if (typeof(hWnd)=="undefined") hWnd=window;
	var o=hWnd.document.getElementById(sId);
	if (o.hasChildNodes() && o.childNodes[0].tagName=="XMP") {
	  o.innerHTML=o.firstChild.innerHTML; 
	}
	
	//not found or not an popup menu -> return
  if (o==null) return;
  if (hWnd._ur_POMN.all[sId]==null) {
    //create the object
		var oPMn={id:sId,
		          ref:o,
		          evtref:o.childNodes[0],
		          items:new Array(),
		          shown:false,
		          frame:null};
		var oRows=o.getElementsByTagName("TBODY")[0].getElementsByTagName("TR");
		var iIdx=0;
		for (var i=0;i<oRows.length;i++) {
			var bHasSep=false;
			var oSepRef=null;
			if (oRows[i].firstChild.className.indexOf("urMnuDvdr")>-1) {
				bHasSep=true; 
				oSepRef=oRows[i];
				i++;
			}
			var oRow=oRows[i];
			var sSt=ur_getAttD(oRow,"st","");
			var sAtt=ur_getAttD(oRow,"att","");
			var sTd=ur_getAttD(oRow,"td","");
			var sSmnu=ur_getAttD(oRow,"smnu","");
			oPMn.items.push({ref:oRow,
			                 sepref:oSepRef,
			                 idx:iIdx,
			                 Id:oRow.id,
			                 Enabled:sSt.indexOf("d")==-1,
			                 HasSubMenu:sSmnu!="",
											 SubMenuId:sSmnu,
			                 HasSeparator:sAtt.indexOf("s")>-1,
			                 Text:ur_getAttD(oRow,"t",""),
			                 CanCheck:(sSt.indexOf("n")>-1 || sSt.indexOf("s")>-1),
			                 GroupId:ur_getAttD(oRow,"gid",""),
			                 Checked:sSt.indexOf("s")>-1,
			                 HasIcon:sAtt.indexOf("i")>-1,
			                 IsLink:sAtt.indexOf("l")>-1,
			                 EnabledIconSrc:ur_getAttD(oRow,"eis",""),
			                 DisabledIconSrc:ur_getAttD(oRow,"dis",""),
			                 HasEllipsis:sAtt.indexOf("e")>-1,
			                 TextDirection:sTd,
			                 POPUPMENUITEMSELECT:ur_getAttD(oRow,"ocl",""),
			                 POPUPMENUITEMLINKCLICK:ur_getAttD(oRow,"olc",""),
			                 Hovered:false,
			                 Hidden:false,
			                 Menu:oPMn});
			iIdx++;
		}
		hWnd._ur_POMN.all[sId]=oPMn;
	}
	return hWnd._ur_POMN.all[sId];
}

//returns the id of the element that triggered the last opened popupmenu
function mf_PopupMenu_getTriggerId() {
	return _ur_POMN_triggerId.split("-")[0];
}

//Popupmenu Object

function ur_PopupMenu_render(oPMn) {
  var oTBdy=oPMn.ref.getElementsByTagName("TBODY")[0];
  var oTable=oPMn.ref.getElementsByTagName("TABLE")[0];
  while (oTBdy.childNodes.length>0) oTBdy.removeChild(oTBdy.lastChild);
  for (var i=0;i<oPMn.items.length;i++) {
    var oItm=oPMn.items[i];
    var oH=document.createElement("TR");
    var oHTxtTd=document.createElement("TD");
    var oHTxtSpan=document.createElement("SPAN");
 
    var oHIcoTd=document.createElement("TD");
    var oHChkTd=document.createElement("TD");
    var oHTd=document.createElement("TD");
    var oHSubTd=document.createElement("TD");
    
    
    if (oItm.Enabled) oH.className="urMnuRowOff";
    else oH.className="urMnuRowDsbl";
    
    //handle the checked cell
    if (oItm.CanCheck) {
      if(oItm.GroupId!='')
        if (oItm.Checked) oHChkTd.className="urMnuChkRbgOn";
        else oHChkTd.className="urMnuChkRbg";
      else if (oItm.Checked) oHChkTd.className="urMnuChkOn";
      else oHChkTd.className="urMnuChk";
    } else {
     oHTxtTd.className="urMnuTxt";
    } 
    if (oItm.CanCheck) oHChkTd.innerHTML="&nbsp;&nbsp;&nbsp;";
    else oHChkTd.innerHTML="&nbsp;";

    //handle the icon cell
    if (oItm.HasIcon) {
      oHIcoTd.className="urMnuTxt";
      if (ur_system.direction=="RTL") oHIcoTd.style.paddingLeft="3px";
      else oHIcoTd.style.paddingRight="3px";
      oImg=document.createElement("IMG");
      if (oItm.Enabled) oImg.src=oItm.EnabledIconSrc;
      else oImg.src=oItm.DisabledIconSrc;		
      oImg.border="0";
      oHIcoTd.appendChild(oImg);
    } else {
      oHIcoTd.innerHTML="&nbsp;";
    }
    
    //handle the text
    var sEll="";
    if (oItm.HasEllipsis) sEll="\u2026";
    var oHTxt=document.createTextNode(oItm.Text+sEll);
    oHTxtTd.className="urMnuTxt";
    oHTxtTd.appendChild(oHTxtSpan);
    oHTxtSpan.style.whiteSpace="nowrap";
    

    //handle the submenu
    if (oItm.HasSubMenu) { oHSubTd.className="urMnuSubOn";oHSubTd.innerHTML="&nbsp;&nbsp;&nbsp;";
    } else {oHSubTd.className="urMnuSub";oHSubTd.innerHTML="&nbsp;";}
    
	//handle attributes for 508	
     if (ur_system.is508){
	if (oItm.HasSubMenu)oHTxtTd.setAttribute("tp","ISMNU");
	else oHTxtTd.setAttribute("tp","I");
	oHTxtTd.setAttribute("t",oItm.Text);
	if(oItm.Enabled == false)oHTxtTd.setAttribute("st","d");
	if(oItm.CanCheck==true){
		var sSt=oHTxtTd.getAttribute("st");
		if(sSt==null)sSt="";
	 	if(oItm.Checked)oHTxtTd.setAttribute("st",sSt+"s");
	 	else oHTxtTd.setAttribute(sSt+"n");
	 }
	 oHTxtTd.setAttribute("idx",i+1);
	 oTable.ic=oPMn.items.length;
	}
	
    //build tree
    oH.appendChild(oHChkTd);
    oH.appendChild(oHIcoTd);
    oH.appendChild(oHTxtTd);
    oH.appendChild(oHSubTd);
    oHTxtSpan.appendChild(oHTxt);
    if (oItm.TextDirection=="ltr" && ur_system.direction=="RTL") {
      oHTxtSpan.style.direction="ltr";
    } else if (oItm.TextDirection=="rtl" && ur_system.direction=="LTR") {
      oHTxtSpan.style.direction="ltr";
    }
    if (oItm.HasSeparator) {
      var oHSep=document.createElement("TR");
      oHSep.setAttribute("class","urMnuRowOff");
      var oHSepTd=document.createElement("TD");
      oHSepTd.className="urMnuDvdr";
      oHSepTd.colSpan="4";
      var oHSepTmp=document.createElement("DIV")
      oHSepTmp.innerHTML="&nbsp;";
      oHSepTd.appendChild(oHSepTmp);
      oHSep.appendChild(oHSepTd);
	    oTBdy.appendChild(oHSep);
    }

    //set the id
    oH.setAttribute("id",oItm.Id);
    //set the custom attributes again
    var sAtt="";
    sAtt+=oItm.HasSeparator?"s":"";
    sAtt+=oItm.HasEllipsis?"e":"";
    sAtt+=oItm.HasIcon?"i":"";
    sAtt+=oItm.IsLink?"l":"";
    oH.setAttribute("att",sAtt);
    if (oItm.TextDirection!=ur_system.direction) {
	    oH.setAttribute("td",oItm.TextDirection);
    } else {
	    oH.setAttribute("td",ur_system.direction);
    }
    var sSt="";
    if (!oItm.Enabled) sSt+="d";
    if (oItm.CanCheck) {
      if (oItm.Checked) sSt+="s";
      else sSt+="n";
    } 
    oH.setAttribute("st",sSt);
    oH.setAttribute("ocl",oItm.POPUPMENUITEMSELECT);
    oH.setAttribute("olc",oItm.POPUPMENUITEMLINKCLICK);
    
    if (oItm.HasSubMenu && oItm.SubMenuId!='') oH.setAttribute("smnu",oItm.SubMenuId);
    oH.setAttribute("t",oItm.Text);
    if (oItm.HasIcon) {
      oH.setAttribute("eis",oItm.EnabledIconSrc);
      oH.setAttribute("dis",oItm.DisabledIconSrc);
    }
	  oTBdy.appendChild(oH);
  }
  //empty the object array and reinit
  var sId=oPMn.id;
  _ur_POMN.all[sId]=null;
  if (!initMenus)  initMenus=new Array();
  if (initMenus[sId]) initMenus[sId]=null;
  mf_PopupMenu_getObj(sId);
}

function mf_PopupMenu_addItem (oPMn,oItm) {
  oPMn.items[oPMn.items.length]=oItm;
}
function mf_PopupMenu_removeItem (oPMn,oItm) {
  var j=0;
  var items=new Array();
  for (var i=0;i<oPMn.items.length;i++) 
    if (oItm.Id!=oPMn.items[i].Id) items.push(oPMn.items[i]);
  oPMn.items=items
}

function mf_PopupMenu_replaceItem (oPMn,oOldItm,oNewItm) {
  var j=0;
  var oNewItems=new Array();
  for (var i=0;i<oPMn.items.length;i++) 
    if (oOldItm.Id==oPMn.items[i].Id) oPMn.items[i].Id=oNewItm;
}

function mf_PopupMenu_removeAllItems (oPMn) {
  oPMn.items=new Array();
  return oPMn;
}

function mf_PopupMenu_apply (oPMn) {
  ur_PopupMenu_render(oPMn);
}
function mf_PopupMenu_getItemById (oPMn,sItemId) {
  for (var i=0;i<oPMn.items.length;i++) 
    if (sItemId==oPMn.items[i].Id) return oPMn.items[i];
  return null;
}
function mf_PopupMenu_getItemByIdx (oPMn,iIdx) {
  return oPMn.items[iIdx];
}
function mf_PopupMenu_createItem (sId) {
  return {Id:sId,Enabled:true,HasSubMenu:false,SubMenuId:"",HasSeparator:false,Text:"",CanCheck:false,GroupId:"",Checked:false,HasIcon:false,EnabledIconSrc:"",DisabledIconSrc:"",HasEllipsis:false,TextDirection:"ltr",POPUPMENUITEMSELECT:"",POPUPMENUITEMLINKCLICK:"",Menu:null};
}

//default handler for all click events
function ur_PopupMenu_click(hWnd,sId,oEvt) {
  var oItm=ur_EVT_src(oEvt);
  if (oItm.tagName=="BODY") {
		var aItems = hWnd.document.getElementsByTagName("TR");
    for (var i=0;i<aItems.length;i++) {
			if (aItems[i].className.indexOf("urMnuRowOn")>-1) {
				oItm = aItems[i];
			}
    }
  } else {
		while (oItm && ur_getAttD(oItm,"ocl","")=="" && ur_getAttD(oItm,"olc","")=="") {
			if (oItm.className=="urMnuDvdr") return;
			if (ur_getAttD(oItm,"smnu","")!="") return;
			else oItm=oItm.parentNode;
		}
	}
  if (oItm == null || oItm.tagName=="BODY" || oItm.tagName=="DIV") return;
  if (ur_getAttD(oItm,"st","").indexOf("d")>-1) return
  if (ur_getAttD(oItm,"ocl","")!="")  ur_EVT_fire(oItm,"ocl",oEvt,hWnd);  //fire the item select event(oEvt) on oItm of the iframe
  if (ur_getAttD(oItm,"olc","")!="") ur_EVT_fire(oItm,"olc",oEvt,hWnd);	//fire the link click event(oEvt) on oItm of the iframe 
  ur_EVT_cancel(oEvt);
}

//default handler for keydown
function ur_PopupMenu_keydown(hWnd,sId,oEvt) {
	if (oEvt.keyCode==27) {
		if (hWnd.menuObject) {
			if (hWnd.mylevel>0) {
				for (var i=hWnd.mylevel+1;i<subMenus.length;i++) {
				  if (subMenus[i]!=null) subMenus[i].hide();
				}
				sapUrMapi_PopupMenu_setItemActive(hWnd,"closesub", sId);
			} else {
				oPopup.source.object.focus();
				hidePopupMenu();
			}
		}
		return;
	}
	if (oEvt.keyCode==40) { //down
	  var iIdx=hWnd.menu.activeItem.idx;
	  if (iIdx==hWnd.menu.items.length-1) iIdx=0;
	  else iIdx++;
	  var oItm=mf_PopupMenu_getItemByIdx(hWnd.menu,iIdx);
	  mf_PopupMenu_setItemDisplay(hWnd,oItm,"overkey",oEvt);
	  ur_EVT_cancel(oEvt);

	} else if (oEvt.keyCode==38) { //up
	  var iIdx=hWnd.menu.activeItem.idx;
	  if (iIdx==0) iIdx=hWnd.menu.items.length-1;
	  else iIdx--;
	  var oItm=mf_PopupMenu_getItemByIdx(hWnd.menu,iIdx);
	  mf_PopupMenu_setItemDisplay(hWnd,oItm,"overkey",oEvt);
	  ur_EVT_cancel(oEvt);

	} else if (oEvt.keyCode==39) { //right
	  if (ur_system.direction == "rtl") {
		  mf_PopupMenu_setItemDisplay(hWnd,hWnd.menu.activeItem,"closekey",oEvt);
	  } else {
		  mf_PopupMenu_setItemDisplay(hWnd,hWnd.menu.activeItem,"openkey",oEvt);
	  }

  } else if (oEvt.keyCode==37) { //left
	  if (ur_system.direction == "rtl") {
		  mf_PopupMenu_setItemDisplay(hWnd,hWnd.menu.activeItem,"closekey");
	  } else {
		  mf_PopupMenu_setItemDisplay(hWnd,hWnd.menu.activeItem,"closekey");
	  }
	} else if (oEvt.keyCode==13) { //return
		var item=hWnd.menuObject.items[hWnd.menuObject.activeItem];
    if (item.getAttribute("ocl")!=null && item.getAttribute("ocl")!="") ur_EVT_fire(item,"ocl",oEvt,hWnd);
    if (item.getAttribute("olc")!=null && item.getAttribute("olc")!="") ur_EVT_fire(item,"olc",oEvt,hWnd);
	} else if (oEvt.keyCode!=9) {
	  oEvt.cancelBubble=true;
	  oEvt.returnValue=false;
	} else {
		if (hWnd.menuObject) {
			hWnd.menuObject.out=true;
		}
		if(oPopup.source.object!=null) oPopup.source.object.focus();
		hidePopupMenu();
	  oEvt.cancelBubble=false;
	  oEvt.returnValue=true;
	}
	return false;
}

function mf_PopupMenu_setScrollSettings(iFirstVisibleItem,iMaxVisibleItems) {
  var o=ur_get(sId+"-r");
  o.setAttribute("viscnt",iMaxVisibleItems);
  o.setAttribute("visidx",iFirstVisibleItem);
  
  
}

//Returns the UserData given to a PopupTrigger element if the control that opened the menu was a PopupTrigger. Otherwise the functin will return the id of the element that triggered the PopupMenu
function mf_PopupMenu_getTriggeredUserData() {
  var o=ur_get(_ur_POMN_triggerId);
  if (o && o.getAttribute && o.getAttribute("ud")) {
	  return ur_getAttD(o,"ud","");
  }
  return _ur_POMN_triggerId;
}
