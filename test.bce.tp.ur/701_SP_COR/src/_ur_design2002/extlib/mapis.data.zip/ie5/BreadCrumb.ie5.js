//* ************************************************************************
//* BreadCrumb
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_BreadCrumb_keydown
//* parameter   : sId  - id	of the breadcrumb
//*             : oEvt - event object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function sapUrMapi_BreadCrumb_keydown(sId,oEvt){
	var o=ur_get(sId);
	var oCur=ur_EVT_src(oEvt);
	var oNext=null;

	var _ur_K_Next=ur_system.direction=="rtl"?37:39;
	var _ur_K_Prev=ur_system.direction=="rtl"?39:37;	
	
	/* left and right navigation with arrow keys */
	if(oEvt.keyCode=="39" || oEvt.keyCode=="37"){
		if(oEvt.keyCode==_ur_K_Next && oCur.nextSibling!=null){
			oNext=oCur.nextSibling;
			if(oNext.className.indexOf("urBrcDiv")>=0)
				oNext=oNext.nextSibling;
			sapUrMapi_setTabIndex(oCur,-1);
		}
		else if(oEvt.keyCode==_ur_K_Prev && oCur.previousSibling!=null){	
			oNext=oCur.previousSibling;	
			if(oNext.className.indexOf("urBrcDiv")>=0)
				oNext=oNext.previousSibling;	
			sapUrMapi_setTabIndex(oCur,-1);
		}
		o.setAttribute("nav","true");		
		if(oNext!=null){
			sapUrMapi_setTabIndex(oNext,0);
			sapUrMapi_focusElement(oNext);
		}
	}else if(oEvt.keyCode==32 && oCur.onclick!=null){
		 oCur.click();
	}else if(oEvt.keyCode==13){
		ur_EVT_cancel(oEvt);
	}
	
	if(oEvt.keyCode=="9"&&oCur.className.indexOf("Whl")<0)
		sapUrMapi_setTabIndex(oCur,-1);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_BreadCrumb_activate
//* parameter   : sId  - id	of the breadcrumb
//*             : oEvt - event object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function sapUrMapi_BreadCrumb_activate(sId,oEvt){
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_BreadCrumb_deactivate
//* parameter   : sId  - id	of the breadcrumb
//*             : oEvt - event object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function sapUrMapi_BreadCrumb_deactivate(sId,oEvt){
	if(oEvt.toElement!=null&&oEvt.toElement.parentNode.className.indexOf("Brc")>=0) return;
	var o=ur_get(sId);
	var oSel=o.lastChild;
	
	sapUrMapi_setTabIndex(oSel,0);
	o.setAttribute("nav","false");
}
