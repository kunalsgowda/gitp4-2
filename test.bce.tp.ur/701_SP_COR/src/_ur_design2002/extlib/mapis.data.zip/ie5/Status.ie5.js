//* ------------------------------------------------------------------------
//* Status functions
//* ------------------------------------------------------------------------
//* ------------------------------------------------------------------------
//* function:			ur_setSt
//* parameter:		sId - control id
//*								aSt - array of status
//*								bOn - if true set status, if false reamove status
//* return:				-
//* description:	set status read only, disabled, ... for a control
//* ------------------------------------------------------------------------
function ur_setSt(sId,aSt,bOn){
	var o=null;
	if(typeof(sId)=="string") o=ur_get(sId);
	else o=sId;
	if (!o) return //MS:Problem in LegendItems. This is safer anyway.
	var sSt=o.getAttribute("st");
	
	if(sSt==null) sSt="";

	if(typeof(aSt)=="string")
		aSt=new Array(aSt);
	
	for(var i=0; i<aSt.length;i++){
		if(sSt=="" || sSt.indexOf(aSt[i])==-1){
			if(bOn) sSt+=aSt[i];
		}
		else{
			if(!bOn) sSt=sSt.replace(aSt[i],"");
		}
	}
	
	o.setAttribute("st",sSt);
}

//* ------------------------------------------------------------------------
//* function:			ur_setSt
//* parameter:		sId - control id
//*								aSt - array of status
//* return:				true/false
//* description:	check if the control has the status
//* ------------------------------------------------------------------------
function ur_isSt(sId,aSt){
	var o=null;
	if(typeof(sId)=="string") o=ur_get(sId);
	else o=sId;
	if (!o) return false; //MS:Problem in LegendItems. This is safer anyway.

	var sSt=o.getAttribute("st");
	var bRet=true;

	if(sSt==null) return false;
	
	if(typeof(aSt)=="string")
		aSt=new Array(aSt);
	
	for(var i=0; i<aSt.length;i++)
		if(sSt.indexOf(aSt[i])==-1)
			bRet=false;
	return bRet;
}

function ur_getRootObj(o) {
  while(o.getAttribute!=null && (o.getAttribute("ct")==null || o.getAttribute("ct")==""))
    o=o.parentNode;
  if (o.getAttribute!=null && o.getAttribute("ct")!=null && o.getAttribute("ct")!="")
    return o;
}
