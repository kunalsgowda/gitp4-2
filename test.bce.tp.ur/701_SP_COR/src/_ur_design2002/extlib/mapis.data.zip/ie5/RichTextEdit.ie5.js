//* ************************************************************************
//* RichTextEditor
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : ur_Rte_Create
//* parameter   : sId  - Id of the RichTextEditor control
//*             : sText - Content to pre-populate
//*				: Evt - DOM Event Obj			
//* return      : none
//* description	: Initialize function for RichTextEditor
//* ------------------------------------------------------------------------

var rteChanged = {};

function ur_RTE_Create(sId,sText,Evt)
{
	rteChanged[sId] = false;
	
	if(ur_get(sId+"-rd"))
	{
		ur_get(sId+"-rd").innerHTML = sText;	
	}
}
//* ------------------------------------------------------------------------
//* function    : ur_RTE_IframeLoad
//* parameter   : sId  - Id of the RichTextEditor control
//* return      : none
//* description	: Onload function of Iframe, Inject HTML content done here
//* ------------------------------------------------------------------------


function ur_RTE_IframeLoad(sId,sText)
{
	rteChanged[sId] = false;
	
	try{
	var oIfrm = ur_get(sId+'-frm'),
	    oDoc = oIfrm.contentWindow.document;

	oDoc.body.setAttribute("id",sId);
	if(sText == "")
		sText = "<p></p>";

	sText = sText.replace(/<\/br>/g, "");

	var oLink = oDoc.getElementsByTagName("LINK")[0],
	    cssUrl = ur_system.stylepath+"ur_"+ur_system.browser_abbrev+".css";
        
	oLink.href = ur_RTE_relativeToAbsolutePath(cssUrl, location.href);
	
	oDoc.body.dir = ur_system.direction;

	oDoc.body.className = "urBdyStd urTrcBodyBox urFTxtV";
	oDoc.body.innerHTML = sText;	

	// Disabling is needed to avoid a false cursor, that allowed editing 
	// without firing a blur event, when leaving the RichTextEdit again
	oDoc.body.disabled = true;
	oDoc.body.contentEditable = true;
	oDoc.body.disabled = false;

	oDoc.attachEvent("onkeydown",ur_RTE_keyHandler);
	oDoc.attachEvent("onkeyup",ur_RTE_keyHandler);
	
	oDoc.attachEvent("onclick",ur_RTE_handleClick); 
	oDoc.attachEvent("onselect",ur_RTE_handleClick);
	
	oDoc.body.attachEvent("onblur",ur_RTE_blur);
	}catch(ex){};
	
}

function ur_RTE_blur(evt)
{
	
	var sId = evt.srcElement.getAttribute("id");
	if (rteChanged[sId]) ur_EVT_fire(ur_get(sId),"ochg");
	
	
}

//* ------------------------------------------------------------------------
//* function    : ur_RTE_keyHandler
//* parameter   : 
//*				: Evt - DOM Event Obj			
//* return      : none
//* description	: handles KeyPress events
//* ------------------------------------------------------------------------
function ur_RTE_keyHandler(evt)
{
	if (!evt) evt = window.event;
	
	var sId = evt.srcElement.getAttribute("id");
   
    	rteChanged[sId] = true;
    	ur_RTE_queryState(sId);

}

//* ------------------------------------------------------------------------
//* function    : ur_RTE_handleClick
//* parameter   : 
//*				: Evt - DOM Event Obj			
//* return      : none
//* description	: handles Mouse Click and Select  events
//* ------------------------------------------------------------------------

function ur_RTE_handleClick(evt)
{
	if (!evt) evt = window.event;
	
	var sId = evt.srcElement.getAttribute("id");
	
	if(sId == "" && (evt.srcElement).tagName != "BODY")
	{
		var elm = evt.srcElement;
		while(elm.tagName != "BODY")
			elm  = elm.parentNode;
		
		sId = elm.getAttribute("id");
		
	}
	ur_RTE_queryState(sId);
}

//* ------------------------------------------------------------------------
//* function    : ur_RTE_btnClk
//* parameter   : sIdCtrl  - Id of the RichTextEditor control
//*				: Evt - DOM Event Obj			
//* return      : none
//* description	: handles ToolBar Button Click
//* ------------------------------------------------------------------------
function ur_RTE_btnClk(sIdCtrl,Evt)
{
	if (!Evt) Evt = window.event;
	var elm;
	if(Evt.srcElement.tagName == "IMG")
		elm = Evt.srcElement.parentNode.parentNode;
		
	else if(Evt.srcElement.tagName == "A")
		elm = Evt.srcElement.parentNode;
	
	if(!elm || elm.getAttribute("id") == "" ) return;
	
	var sId = elm.getAttribute("id");

	if(sId.indexOf('-bld')> -1){
		ur_RTE_frmt(sIdCtrl,"","Bold");
	}
	else if(sId.indexOf('-itl')> -1)
	{
		ur_RTE_frmt(sIdCtrl,"","italic");
	}
	else if(sId.indexOf('-und')> -1)
	{
		ur_RTE_frmt(sIdCtrl,"","Underline");
	}
	else if(sId.indexOf('-head1')> -1)
	{
		if(ur_get(sIdCtrl).className == "urBtnStdD")
			ur_RTE_frmt(sIdCtrl,"<p>","formatblock");
		else
			ur_RTE_frmt(sIdCtrl,"<h1>","formatblock");
	}
	else if(sId.indexOf('-head2')> -1)
	{
		if(ur_get(sIdCtrl).className == "urBtnStdD")
			ur_RTE_frmt(sIdCtrl,"<p>","formatblock");
		else
			ur_RTE_frmt(sIdCtrl,"<h2>","formatblock");
	}
	else if(sId.indexOf('-head3')> -1)
	{		
		if(ur_get(sIdCtrl).className == "urBtnStdD")
			ur_RTE_frmt(sIdCtrl,"<p>","formatblock");
		else
			ur_RTE_frmt(sIdCtrl,"<h3>","formatblock");
	}	else if(sId.indexOf('-idnt')> -1)
	{
		ur_RTE_frmt(sIdCtrl,"","Indent");
	}
	else if(sId.indexOf('-odnt')> -1)
	{
		ur_RTE_frmt(sIdCtrl,"","Outdent");
	}
	else if(sId.indexOf('-olist')> -1)
	{
		ur_RTE_frmt(sIdCtrl,"","InsertOrderedList");
	}
	else if(sId.indexOf('-unolist')> -1)
	{
		ur_RTE_frmt(sIdCtrl,"","InsertUnorderedList");
	}

	rteChanged[sIdCtrl] = true;
	ur_RTE_queryState(sIdCtrl);
}

//* ------------------------------------------------------------------------
//* function    : ur_RTE_frmt
//* parameter   : sId  - Id of the RichTextEditor control
//*				: format - the format query command
//*				: selName - Not currenlty used... but will be used later
//* return      : none
//* description	: handles ToolBar Button Click
//* ------------------------------------------------------------------------

function ur_RTE_frmt(sId,format,selName)
{	
	if (sId.indexOf("-") > -1) sId = sId.split("-")[0];
	
	var oCtrl = ur_get(sId+"-frm");
	oCtrl.contentWindow.focus();
	oCtrl.contentWindow.document.execCommand(selName,false,format);	
	ur_RTE_queryState(sId);

}

//* ------------------------------------------------------------------------
//* function    : ur_RTE_queryState
//* parameter   : sId  - Id of the RichTextEditor control
//* return      : none
//* description	: Queries the state of Text
//* ------------------------------------------------------------------------

function ur_RTE_queryState(sId,target)
{
	
	var oIfrm = ur_get(sId+"-frm");
	
	if(ur_get(sId+"-tbar-itl"))
	{
		var bI = oIfrm.contentWindow.document.queryCommandState("Italic");
		if(bI)
			ur_TB_toggleDownState(sId+"-tbar-itl","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-itl","up");
	}
	if(ur_get(sId+"-tbar-bld"))
	{
		var bB = oIfrm.contentWindow.document.queryCommandState('Bold');
		if(bB)
			ur_TB_toggleDownState(sId+"-tbar-bld","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-bld","up");
	}
	if(ur_get(sId+"-tbar-und"))
	{
		var bU = oIfrm.contentWindow.document.queryCommandState('Underline');
		if(bU)
			ur_TB_toggleDownState(sId+"-tbar-und","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-und","up");
	}
	if(ur_get(sId+"-tbar-head1"))
	{
		var sH1 = "" + oIfrm.contentWindow.document.queryCommandValue('formatblock');
		if(sH1.indexOf("1") >= 0)
			ur_TB_toggleDownState(sId+"-tbar-head1","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-head1","up");
	}
	if(ur_get(sId+"-tbar-head2"))
	{
		var sH2 = "" + oIfrm.contentWindow.document.queryCommandValue('formatblock');
		if(sH2.indexOf("2") >= 0)
			ur_TB_toggleDownState(sId+"-tbar-head2","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-head2","up");
	}
	if(ur_get(sId+"-tbar-head3"))
	{
		var sH3 = "" + oIfrm.contentWindow.document.queryCommandValue('formatblock');
		if(sH3.indexOf("3") >= 0)
			ur_TB_toggleDownState(sId+"-tbar-head3","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-head3","up");
	}
	
	if(ur_get(sId+"-tbar-idnt"))
	{
		var bIdnt = oIfrm.contentWindow.document.queryCommandState("Indent");
		if(bIdnt)
			ur_TB_toggleDownState(sId+"-tbar-idnt","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-idnt","up");
	}
	if(ur_get(sId+"-tbar-odnt"))
	{
		var bOdnt = oIfrm.contentWindow.document.queryCommandState("Outdent");
		if(bOdnt)
			ur_TB_toggleDownState(sId+"-tbar-odnt","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-odnt","up");
	}
	if(ur_get(sId+"-tbar-olist"))
	{
		var bOlist = oIfrm.contentWindow.document.queryCommandState("InsertOrderedList");
		if(bOlist)
			ur_TB_toggleDownState(sId+"-tbar-olist","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-olist","up");
	}
	if(ur_get(sId+"-tbar-unolist"))
	{
		var bOlist = oIfrm.contentWindow.document.queryCommandState("InsertUnorderedList");
		if(bOlist)
			ur_TB_toggleDownState(sId+"-tbar-unolist","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-unolist","up");
	}

}

//* ------------------------------------------------------------------------
//* function    : ur_TB_toggleDownState
//* parameter   : sId  - Id of the RichTextEditor control
//* return      : none
//* description	: Toggles the Toolbar button state (***Once its stable, this will be moves to Toolbar JS file !!****)
//* ------------------------------------------------------------------------

function ur_TB_toggleDownState(sId,bSt)
{
	
	var oBtn = ur_get(sId);
	var oBtnR = ur_get(sId+"-r");
	if(bSt == "dn")
	{
		oBtn.className = "urBtnStdD";
		oBtnR.setAttribute("down","true");
	}
	else if(bSt == "up")
	{
		oBtn.className = "urBtnStd";
		oBtnR.setAttribute("down","false");
	}
	else
	{
		if(oBtn.className == "urBtnStd")
			oBtn.className == "urBtnStdD"
		else
			oBtn.className == "urBtnStd"
	}
}

//* ------------------------------------------------------------------------
//* Counter used for serialization to avoid problems with cyclic references
//* ------------------------------------------------------------------------
var ur_RTE_iSerializeCounter = 0;

//* ------------------------------------------------------------------------
//* function    : ur_RTE_getHTMLText
//* parameter   : sId  - Id of the RichTextEditor control
//* parameter   : oEvt - event object
//* return      : the content of the RichTextEdit in HTML format
//* description	: Retrieves the HTML content and makes it XHTML compliant
//* ------------------------------------------------------------------------
function ur_RTE_getHTMLText(sId,oEvt)
{
   if (!oEvt) oEvt = window.event;
   
   var node = ur_get(sId+'-frm').contentWindow.document.body,
       buffer = [],
       html;
   
   ur_RTE_iSerializeCounter++;    
   ur_RTE_serializeXHTML(buffer, node);
   html = buffer.join("");

   return html;
}

//* ------------------------------------------------------------------------
//* Map of allowed tags and attributes 
//* ------------------------------------------------------------------------
var ur_RTE_oValidTags = {
	"abbr":{empty:false},
	"acronym":{empty:false},
	"address":{empty:false},
	"blockquote":{empty:false},
	"br":{empty:true},
	"cite":{empty:false},
	"code":{empty:false},
	"dfn":{empty:false},
	"div":{empty:false},
	"em":{empty:false},
	"h1":{empty:false},
	"h2":{empty:false},
	"h3":{empty:false},
	"h4":{empty:false},
	"kbd":{empty:false},
	"p":{empty:false},
	"pre":{empty:false},
	"q":{empty:false},
	"samp":{empty:false},
	"span":{empty:false},
	"strong":{empty:false},
	"var":{empty:false},
	"dt":{empty:false},
	"dd":{empty:false},
	"ol":{empty:false},
	"ul":{empty:false},
	"li":{empty:false},
	"a":{empty:false, attrs:["href"]},
	"img":{empty:true, attrs:["src"]},
	
	"b":{mapped:"strong"},
	"i":{mapped:"em"}
};

//* ------------------------------------------------------------------------
//* Map of disallowed tags which content is omitted 
//* ------------------------------------------------------------------------
var ur_RTE_oOmitContentTags = {
	"script": true,
	"noscript": true,
	"style": true,
	"select": true,
	"button": true,
	"link": true,
	"iframe": true,
	"object": true
};

//* ------------------------------------------------------------------------
//* function    : ur_RTE_getHTMLText
//* parameter   : aBuffer - the buffer array for the 
//* parameter   : oNode - the node to be serialized
//* description	: 
//* Serializes the given DOM node to XHTML subset used by
//* Web Dynpro FormattedText into the given buffer array.
//* ------------------------------------------------------------------------
function ur_RTE_serializeXHTML(aBuffer, oNode) {
	switch(oNode.nodeType) {
		case 1: // ELEMENT_NODE
			var sTagName = oNode.tagName.toLowerCase(),
				oTagInfo = ur_RTE_oValidTags[sTagName];
			if (oTagInfo) {
				
				// DOM tree can be self referencing in IE (!!!),
				// so mark nodes as visited and break if needed
				if (oNode.cnt == ur_RTE_iSerializeCounter) {
					break;
				}
				oNode.cnt = ur_RTE_iSerializeCounter;
				
				if (oTagInfo.mapped) {
					sTagName = oTagInfo.mapped;
					oTagInfo = ur_RTE_oValidTags[sTagName];
				}
				
				aBuffer.push("<");
				aBuffer.push(sTagName);
				if (oTagInfo.attrs) {
					var aAttributes = oTagInfo.attrs,
						sName,
						sValue;
					for (var i = 0; i < aAttributes.length; i++) {
						sName = aAttributes[i];
						sValue = oNode.getAttribute(sName);
						if (sValue) {
							aBuffer.push(" ");
							aBuffer.push(sName); 
							aBuffer.push("=\""); 
							aBuffer.push(ur_RTE_sXmlEscape(sValue));
							aBuffer.push("\""); 
						}
					}
				}
				if (oTagInfo.empty) {
					aBuffer.push(" />");
				}	
				else {
					aBuffer.push(">");
				}
			}
			
			if (!ur_RTE_oOmitContentTags[sTagName]) {
				var childNodes = oNode.childNodes;
				if (childNodes) {
					for (var i = 0; i < childNodes.length; i++) {
						ur_RTE_serializeXHTML(aBuffer, childNodes[i]);
					}
				}
			}
			
			if (oTagInfo && !oTagInfo.empty) {
				aBuffer.push("</" + sTagName + ">");			
			}
			break;
		case 3: // TEXT_NODE
			aBuffer.push(ur_RTE_sXmlEscape(oNode.nodeValue));
			break;
		default: //ANYTHING ELSE
			// omit					
	}
};

//* ------------------------------------------------------------------------
//* function    : ur_RTE_sXmlEscape
//* parameter   : sText - the text to be escaped
//* return      : the XML escaped text
//* description : Escapes the characters &, < and "
//* ------------------------------------------------------------------------
function ur_RTE_sXmlEscape(sText) {
	sText = sText.replace(/\&/g, "&amp;");
	sText = sText.replace(/\</g, "&lt;");
	sText = sText.replace(/\"/g, "&quot;");
	return sText;
};

//* ------------------------------------------------------------------------
//* function    : ur_RTE_relativeToAbsolutePath
//* parameter   : strRel - relative URL 
//* parameter   : strAbs - base URL
//* return      : resolved URL
//* description : this code is completely braindead, see RFC 2396, Section 5
//* ------------------------------------------------------------------------
function ur_RTE_relativeToAbsolutePath(strRel,strAbs) {
  if (strRel.lastIndexOf("./")==-1) return strRel; //no relative path
  var strRelDots      = strRel.substring(0,strRel.lastIndexOf("./")+2);
  var strAbsPath      = strAbs.substring(0,strAbs.lastIndexOf("/")); 
  while(strRelDots.lastIndexOf("..")>-1) { //erase all double dots
    strAbsPath = strAbsPath.substring(0,strAbsPath.lastIndexOf("/")); 
    strRelDots = strRelDots.substring(0,strRelDots.lastIndexOf(".."))+"/";
  }
  if (strRelDots.lastIndexOf("./")>-1) {
    strRelDots = strRelDots.substring(0,strRelDots.lastIndexOf("./"))+"/";
    if (strRelDots.lastIndexOf("./")>-1) { 
      showError (strRel+" is not a valid relative url.");
    }
  }
  //build absolut path
  strNewAbsPath = strAbsPath + strRelDots + strRel.substring(strRel.lastIndexOf("./")+2,strRel.length);
  return strNewAbsPath;
}  


