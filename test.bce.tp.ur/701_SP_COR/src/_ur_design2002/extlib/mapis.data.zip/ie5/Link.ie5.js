//* ------------------------------------------------------------------------
//* function    : sapUr_Link_activate
//* parameter   : sLinkId - string - Id of the link
//*             : e - event object
//* description : triggers the menu open functions if there is a menu assigned to the link
//                or triggers the onclick event on the link
//* return      :
//* ------------------------------------------------------------------------
function sapUrMapi_Link_activate(sLinkId,e) {
	oLink = ur_get(sLinkId);

	var iKeyCode=e.keyCode;
	
	// spacebar
	if(iKeyCode==32 && oLink.onclick){
		oLink.click(); //click() instead of onclick() to work with space
		e.returnValue=false;
		return false;
	}
	// arrow down
	else if (oLink.getAttribute("hasmenu")=="true" && iKeyCode==40 && oLink.oncontextmenu) {
		oLink.oncontextmenu();
		e.returnValue=false;
		return false;
	}  

	//due to legacy - not sure if this coding is necessary - in 710 it was removed
	if (oLink.getAttribute("hasmenu")=="true" && (iKeyCode==32 || iKeyCode==40) && oLink.onmouseover) {
		oLink.onmouseover();
		e.returnValue=false;
		return false;
	}

  e.returnValue=true;
  return true;
}
