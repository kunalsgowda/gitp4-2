

function sapUrMapi_Focus_canFocus(o) {
	if (o==null) return;
	if (!o.tagName) return;
	var tag=","+o.tagName+",";
  //if (tag==",IFRAME,") return true; who added this. this produces bug in iframe control -->where is this needed?
	if((tag==",INPUT,")&&(o.type=="hidden"||o.disabled)){ 
		return false;
	}
	var search=",A,BODY,BUTTON,FRAME,IFRAME,INPUT,ISINDEX,OBJECT,SELECT,TEXTAREA,";
    if (o && o.currentStyle && (o.currentStyle.visibility == "hidden" || o.currentStyle.display == "none")) return false;
	if (search.indexOf(tag)>-1){
	   if (!ur_system.is508 && o.tabIndex<0)
	       return (o.ti>=0);
	   else
		  return (o.tabIndex>=0);
	}
	if (!o.getAttribute) return;
	if (o.getAttribute("ti")!=null) return (parseInt(o.getAttribute("ti"))>=0);
}

function sapUrMapi_Focus_getNextFocusableElement(o) {
	while (o!=null) {
		if (sapUrMapi_Focus_canFocus(o)) return o;
		o=o.parentNode;
	}
	return null;
}

var oOldFocus=null;
function sapUrMapi_Focus_showFocusRect(sId) {
	try
	{
		if ((document.activeElement!=null) && (document.activeElement.id=="ur-accfocus")) return;
	}
	catch(e)
	{
		return;
	}	
	var oTop = ur_get("ur-topfocus");
	if (oTop==null) return;
  var oNewActive=null;
	if (typeof(sId)!="undefined") {
		if (typeof(sId)=="string") {
    oNewActive=ur_get(sId);
	} else {
      oNewActive=sId;
		}
	} else {
    oNewActive=document.activeElement;
	}
	if (oOldFocus!=null) {
	  if (oOldFocus==oNewActive) return;
	}
	oNewActive=sapUrMapi_Focus_getNextFocusableElement(oNewActive);      
	if ((oNewActive==null)||(oNewActive.tagName=="BODY")) return;
	//Workaround for extra tabstop in portal. They render a iframe on their own.
	if (oNewActive.tagName =="IFRAME" && !oNewActive.getAttribute("ct")) {
		sapUrMapi_Focus_hideFocusRect();
		return;
	}
	if (ur_getAttD(oNewActive,"ct","")=="IF") {
	  oNewActive.firstChild.attachEvent("onactivate",sapUrMapi_Focus_hideFocusRect);
	  return;
	}

  var sType=sapUrMapi_getControlTypeFromObject(oNewActive);
	if(sType=="C"||sType=="R"||sType=="TRI"){ 
		oNewActive=ur_get(oNewActive.id.split("-")[0]+"-lbl");
	}
	if(oNewActive.getAttribute("urhf")=="true") return;
  var x=oNewActive.currentStyle.width;
  var y=oNewActive.offsetWidth;
	if (!oNewActive.hideFocus) oNewActive.hideFocus="true";
  if (y!=oNewActive.offsetWidth) oNewActive.style.width=x;
  
  //Special Handling
	//TabStrip
	if (sType=="TS") {
	  if (oNewActive.id.indexOf("-itm-")>-1 && oNewActive.id.indexOf("-txt")==-1 && oNewActive.id.indexOf("-a")==-1) 
	    oNewActive=oNewActive.firstChild;
	}
	//TableView Checkbox and RadioButton have to be corrected.
	else  if (sType=="TBV") {
		  if (oNewActive.className=="urImgCbgCbx") {
		    oNewActive=oNewActive.nextSibling;
		  } else if (oNewActive.className=="urImgRbgCbx") {
		    oNewActive=oNewActive.nextSibling;
		  }
	}
	//SelectableLinkbar
  else if (sType=="SB") {
	  if (oNewActive.tagName=="TABLE") {
	    oNewActive=oNewActive.parentNode.parentNode.parentNode;
	  }	else {
	    oNewActive=oNewActive.parentNode;
	  }
	}
	
  //ComboBox
  else if (sType=="CB") {
		oNewActive=oNewActive.parentNode;
  	if(oNewActive.tagName=="TD")	// ComboBox with table rendering
  		oNewActive=oNewActive.parentNode.parentNode;
  }
  else if (sType=="ILBM" || sType=="ILBS") {
  
  	if(oNewActive.tagName=="TD") {
  		oNewActive=oNewActive.parentNode.parentNode.parentNode.parentNode;
    }
  }

  
  //empty cells in the sap table
  else if (sType=="ST") {
		if (oNewActive.innerText=="") {
		  oNewActive=oNewActive.parentNode;
		}
  }

  var activeoffsetonscreen = sapUrMapi_Focus_getFocusOffset(oNewActive);
	var sccontrol = oNewActive.parentNode;
	var oC={top:ur_get("ur-topfocus"),bottom:ur_get("ur-bottomfocus"),left:ur_get("ur-leftfocus"),right:ur_get("ur-rightfocus")};
  if (oNewActive.offsetWidth>0) {
		oFocusRect=sapUrMapi_Focus_calcFocusRect(oNewActive,activeoffsetonscreen,oC.left,oC.right,oC.top,oC.bottom);
		if (oFocusRect==null) return;
		oCC={x1:"top",x2:"bottom",x3:"left",x4:"right"};
		for (xx in oCC) {
			if (xx.charAt(0) == "_") {continue;}
		  oC[oCC[xx]].style.top=oFocusRect[oCC[xx]].top;
		  oC[oCC[xx]].style.left=oFocusRect[oCC[xx]].left;
		  if (oCC[xx]=="top" || oCC[xx]=="bottom") 
		    oC[oCC[xx]].style.width=oFocusRect[oCC[xx]].width;
		  if (oCC[xx]=="left" || oCC[xx]=="right") 
		    oC[oCC[xx]].style.height=oFocusRect[oCC[xx]].height;
	}
}
}



function sapUrMapi_Focus_hideFocusRect() {
	sapUrMapi_Focus_DeflBtn_hideFocusRect(false);
 /* var oNewActive=null;
  try {
    oNewActive=document.activeElement;
  } catch (ex) { return; }
  oOldFocus=null;
	var oC={top:ur_get("ur-topfocus"),bottom:ur_get("ur-bottomfocus"),left:ur_get("ur-leftfocus"),right:ur_get("ur-rightfocus"),e1:ur_get("ur-edge1focus"),e2:ur_get("ur-edge2focus"),e3:ur_get("ur-edge3focus"),e4:ur_get("ur-edge4focus")};
  if (oC.top==null) return;
  for (var x in oC) {
  	if (x.charAt(0) == "_") {continue;}
  	oC[x].style.top="-10000px";
}*/
}


//add the focus rectangle to the page
function sapUrMapi_Focus_addFocusRect(sFocusElementId) {
	//adding the focus rectangle once to the page
	if (ur_get("ur-topfocus")==null) {

	  var oBody=document.getElementsByTagName("BODY")[0];
		//create the divs for the focus recangle
		var oFTop		 = document.createElement("DIV");
		var oFBottom = document.createElement("DIV");
		var oFLeft   = document.createElement("DIV");
		var oFRight  = document.createElement("DIV");
		//setting the ids and classnames for the elements.
	  //add the top focus line
		oFTop.setAttribute("id","ur-topfocus"); 
		oFTop.className="urFocTop";
		oFTop.style.top="-10000px";
		oFTop.appendChild(document.createTextNode(""));
		oBody.appendChild(oFTop);

	  //add the bottom focus line
		oFBottom.setAttribute("id","ur-bottomfocus"); 
		oFBottom.className="urFocBtm";
		oFBottom.style.top="-10000px";
		oFBottom.appendChild(document.createTextNode(""));
		oBody.appendChild(oFBottom);

	  //add the left focus line
		oFLeft.setAttribute("id","ur-leftfocus"); 
		oFLeft.className="urFocLft";
		oFLeft.style.top="-10000px";
		oFLeft.appendChild(document.createTextNode(""));
		oBody.appendChild(oFLeft);

	  //add the right focus line
		oFRight.setAttribute("id","ur-rightfocus"); 
		oFRight.className="urFocRgt";
		oFRight.style.top="-10000px";
		oFRight.appendChild(document.createTextNode(""));
		oBody.appendChild(oFRight);

		//attach events for the focus rectangle
		ur_focus_activate_handler=function (){sapUrMapi_Focus_showFocusRect()};
		document.attachEvent("onactivate",ur_focus_activate_handler); 
		document.attachEvent("ondeactivate",sapUrMapi_Focus_hideFocusRect);
		sapUrMapi_Resize_AddItem("ur-focus-rect", "sapUrMapi_Focus_showFocusRect()");
  }
		
	//adding the focus rectangle once to the page
	if (ur_get("ur-topdefault")==null) {

	  var oBody=document.getElementsByTagName("BODY")[0];
		//create the divs for the focus recangle
		var oDefaultTop=document.createElement("DIV");
		var oDefaultBottom=document.createElement("DIV");
		var oDefaultLeft=document.createElement("DIV");
		var oDefaultRight=document.createElement("DIV");
		oDefaultTop.setAttribute("id","ur-topdefault");
		oDefaultBottom.setAttribute("id","ur-bottomdefault");
		oDefaultLeft.setAttribute("id","ur-leftdefault");
		oDefaultRight.setAttribute("id","ur-rightdefault");

		oBody.appendChild(oDefaultTop);
		oBody.appendChild(oDefaultBottom);
		oBody.appendChild(oDefaultLeft);
		oBody.appendChild(oDefaultRight);
	  sapUrMapi_Resize_AddItem("ur-DBtn-rect", "sapUrMapi_DBTN_showDBtn()");
		ur_defaultbutton_activate_handler=function (){sapUrMapi_DBTN_showDBtn()};
		document.attachEvent("onactivate",ur_defaultbutton_activate_handler); 
		document.attachEvent("ondeactivate",ur_defaultbutton_activate_handler);
  	document.attachEvent("onactivate",ur_defaultbutton_activate_handler);

	}
	try {
  	sapUrMapi_focusElement(sFocusElementId);
	} catch(ex) {}
}
function sapUrMapi_Focus_RegisterCreate(sId) {
	//sapUrMapi_Create_AddItem("ur_focus", "sapUrMapi_Focus_addFocusRect(\""+sId+"\")");
	
	/*
	New method to create the highlight of a default button. Introduced after
	focus rectangle was removed as an alternative. See function in defaultButton.js
	for more information.
	*/
	ur_defaultbutton_activate_handler=function (){sapUrMapi_DBTN_showDBtn()};
	ur_defaultbutton_deactivate_handler = function () {sapUr_DBTN_removeFrame()};
	document.attachEvent("onactivate",ur_defaultbutton_activate_handler); 
	document.attachEvent("ondeactivate",ur_defaultbutton_deactivate_handler);
}

function sapUrMapi_Focus_getCurrentId () {
  var o = window.document.activeElement;
  if (o!=null) {
	  if (o.tagName=="LABEL") return o.htmlFor;
	  while (o.id=="") {
			if (o.tagName=="BODY") return "";
			o=o.parentNode;
	  }
	  return o.id;
  }
  return "";
}
function sapUrMapi_Focus_reset() {
	sapUrMapi_Focus_addFocusRect();
	var oTop = ur_get("ur-topfocus");
	var oBottom = ur_get("ur-bottomfocus");
	var oLeft = ur_get("ur-leftfocus");
	var oRight = ur_get("ur-rightfocus");
  if(oTop) {
	  var oParent=oTop.parentNode;
	  var oBody=document.getElementsByTagName("BODY")[0];
	  if (oParent!=oBody) {
			oParent.removeChild(oTop);	
			oBody.appendChild(oTop);	
			oParent.removeChild(oBottom);
			oBody.appendChild(oBottom);
			oParent.removeChild(oLeft);
			oBody.appendChild(oLeft);
			oParent.removeChild(oRight);
			oBody.appendChild(oRight);
		}
  }
}

function sapUrMapi_Focus_remove() {
	var oTop = ur_get("ur-topfocus");
	if(oTop==null) return;
	var oBottom = ur_get("ur-bottomfocus");
	var oLeft = ur_get("ur-leftfocus");
	var oRight = ur_get("ur-rightfocus");
  var oParent=oTop.parentNode;
	oParent.removeChild(oTop);
	oParent.removeChild(oBottom);
	oParent.removeChild(oLeft);
	oParent.removeChild(oRight);
	oParent.removeChild(oEdg1);
	oParent.removeChild(oEdg2);
	oParent.removeChild(oEdg3);
	oParent.removeChild(oEdg4);
}
//returns the height of the focus rect bar
function sapUrMapi_Focus_getFocusRectHeight() {
	var oTop = ur_get("ur-topfocus");
	if (oTop) return oTop.offsetHeight;
	return 0;
}

function sapUrMapi_Focus_calcFocusRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom)
{
	var oFcsRect = sapUrMapi_Focus_DflBtn_calcFocusRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom,false);
	return oFcsRect;
}

function sapUrMapi_Focus_getFocusOffset(oNewActive)
{
	var activeoffsetonscreen = sapUrMapi_Focus_DflBtn_getFocusOffset(oNewActive,false);
	return activeoffsetonscreen;
}


function sapUrMapi_Focus_DflBtn_getFocusOffset(object,IsDeflBtn) {
	var position= { top: 0, left: 0};
	position = sapUrMapi_getAbsolutePosition(object);
	var sccontrol = object.parentNode;
	var bFoundFirstScrollContainer=false;	
	if(IsDeflBtn)
		var oC={top:ur_get("ur-topdefault"),bottom:ur_get("ur-bottomdefault"),left:ur_get("ur-leftdefault"),right:ur_get("ur-rightdefault")};
	else
		var oC={top:ur_get("ur-topfocus"),bottom:ur_get("ur-bottomfocus"),left:ur_get("ur-leftfocus"),right:ur_get("ur-rightfocus")};	
	while ((sccontrol) && (!bFoundFirstScrollContainer)) {
	  if (sccontrol.tagName=="DIV" || sccontrol.tagName=="SPAN") {
	    if (sccontrol.currentStyle.overflow!="visible" && sccontrol.currentStyle.height!="auto" ) {
				if (sccontrol!=oC.top.parentNode) {
				  oParent=oC.top.parentNode;
					for (var n in oC) {
						if (n.charAt(0) == "_") {continue;}
						oParent.removeChild(oC[n]);
					  sccontrol.appendChild(oC[n]);
				   }
				}
				bFoundFirstScrollContainer=true;
				var pos=sapUrMapi_getOffsetOnScreen(sccontrol);
        //MS subract the position of the scroll container
	      position.top-=pos.top;
	      position.left-=pos.left;
	      if (sccontrol.currentStyle.borderTopStyle!="none") {
					if (!isNaN(parseInt(sccontrol.currentStyle.borderTopWidth)))
						position.top-=parseInt(sccontrol.currentStyle.borderTopWidth);
	      }
	      if (sccontrol.currentStyle.borderLeftStyle!="none") {
					if (!isNaN(parseInt(sccontrol.currentStyle.borderLeftWidth)))
						position.left-=parseInt(sccontrol.currentStyle.borderLeftWidth);
        }
	    } 
	  }
	  sccontrol = sccontrol.parentNode;
	}
	if (!bFoundFirstScrollContainer) {
			oBody=document.getElementsByTagName("BODY").item(0);
			if (oBody!=oC.top.parentNode) {
			  oParent=oC.top.parentNode;
				for (var n in oC) {
					if (n.charAt(0) == "_") {continue;}
					oParent.removeChild(oC[n]);
					oBody.appendChild(oC[n]);
			}
	}
	}
	return position;
}

function sapUrMapi_Focus_DflBtn_calcFocusRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom,IsDeflBtn) {
	
	var o=new Array();
	o.top = {top:0,left:0,width:0};
	o.bottom = {top:0,left:0,width:0};
	o.left = {top:0,left:0,height:0};
	o.right = {top:0,left:0,height:0};
	sType=sapUrMapi_getControlTypeFromObject(oElement);
	sParentType=sapUrMapi_getControlTypeFromObject(oElement.parentNode);
	//find a table cell that might have a different width
	var oWidthCalc = oElement.parentNode;
	var iRealWidth = oElement.offsetWidth;
	var iLeftOffset = 0;
	
	//Bugfix for focus inside table cells with fixed layout where the width of the cell is smaller than the 
	//content.
	while(oWidthCalc && oWidthCalc.tagName!="BODY" && oWidthCalc.offsetWidth >= iRealWidth){
		iLeftOffset+=oWidthCalc.offsetLeft;
		oWidthCalc = oWidthCalc.parentNode;
	}
	if (oWidthCalc && (oWidthCalc.tagName=="TD" ||oWidthCalc.tagName=="TH")) {
		iRealWidth = oWidthCalc.offsetWidth - iLeftOffset - 2;
	}
	
	if (sType=="PI") {
	  if (oElement.id.indexOf("-itm-")>-1){
	    o.top.top+=parseInt(oTop.currentStyle.height);
	    o.bottom.top-=parseInt(oBottom.currentStyle.height);
	    o.left.left+=parseInt(oLeft.currentStyle.width);
	    o.right.left-=parseInt(oRight.currentStyle.width);
	  } else {
	    o.top.top+=parseInt(oTop.currentStyle.height);
	    o.bottom.top-=(parseInt(oBottom.currentStyle.height)+1);
	    o.left.left+=parseInt(oLeft.currentStyle.width);
	    o.right.left-=parseInt(oRight.currentStyle.width);
	  }
	} else if (oElement.className.indexOf("urTreN")>-1) {
	  if (!(oElement.childNodes.length>0 && oElement.childNodes[0].tagName=="TABLE")) {
	    o.bottom.top-=4;
	  }
	} 
	

	if(IsDeflBtn==true) // Default Button
		o.top.top+=oOffsets.top-1;
	else
		o.top.top+=oOffsets.top-parseInt(oLeft.currentStyle.width);
	o.top.left+=oOffsets.left;
	o.top.width+=iRealWidth;
	o.bottom.top+=(oOffsets.top+oElement.offsetHeight);
	o.bottom.left=o.top.left;
	o.bottom.width=o.top.width;
	o.left.top=o.top.top;
	if(IsDeflBtn==true) // Default Button
		o.left.left+=oOffsets.left-1;
	else
		o.left.left+=(-1*parseInt(oLeft.currentStyle.width))+oOffsets.left;
	o.right.top=o.top.top;
	if(IsDeflBtn==true) // Default Button
		o.right.left+=o.left.left+o.top.width +1;
	else
		o.right.left+=(o.left.left+o.top.width+parseInt(oLeft.currentStyle.width));
	if (oElement.offsetHeight>0) {
		if(IsDeflBtn==true) // Default Button
			o.left.height+=o.bottom.top-o.top.top;
		else
			o.left.height+=o.bottom.top-o.top.top+parseInt(oBottom.currentStyle.height);
		//(oElement.offsetHeight+(parseInt(oLeft.currentStyle.width)*2));
		o.right.height+=o.left.height;
		//(oElement.offsetHeight+(parseInt(oRight.currentStyle.width)*2));
	}

  //the focus rectangle is inset in all controls to avoid additional scrolbars
  try {
    //exclude some contorls
    sExclude=",B,I,CB,C,R,TE,TS,TV,CP,RM,PG,";
    if (!IsDeflBtn && sExclude.indexOf(","+sType+",")==-1 && oElement.tagName!="A" && oElement.tagName!="INPUT"  ) {
      var w=ur_get("ur-leftfocus").offsetWidth;
  		o.top.top+=w; 
  		o.top.left+=w 
  		o.top.width-=w; 
	  	
			o.bottom.top-=w;
			o.bottom.left+=w;
			o.bottom.width-=w;
			
			o.left.top+=w;
			o.left.left+=w;
			o.left.height-=w*2;
			
			o.right.top+=w;
			o.right.left-=w;
			o.right.height-=w*2;
		}
  } catch (ex) {
  }

	//add pixels (px) to all values
	for (var iter1 in o) {
		if ((IsDeflBtn==false) && (iter1.charAt(0) == "_")) {continue;}
	  for (var iter2 in o[iter1]) {
	  	if ((IsDeflBtn==false) && (iter2.charAt(0) == "_")) {continue;}
	    if (isNaN(o[iter1][iter2])) return null;
	    o[iter1][iter2]+="px";
	  }
	}
	return o;
}

function sapUrMapi_Focus_DeflBtn_hideFocusRect(IsDeflBtn) {
  var oNewActive=null;
  try {
    oNewActive=document.activeElement;
  } catch (ex) { return; }
  oOldFocus=null;
	if (IsDeflBtn)
	   var oC={top:ur_get("ur-topdefault"),bottom:ur_get("ur-bottomdefault"),left:ur_get("ur-leftdefault"),right:ur_get("ur-rightdefault")};
	else
		var oC={top:ur_get("ur-topfocus"),bottom:ur_get("ur-bottomfocus"),left:ur_get("ur-leftfocus"),right:ur_get("ur-rightfocus")};
  if (oC.top==null) return;
  for (var x in oC) {
  	if (x.charAt(0) == "_") {continue;}
  	oC[x].style.top="-10000px";
}
}
