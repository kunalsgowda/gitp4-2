//------------------------------------
// Unified Rendering Modification API
//        (c) 2002, SAP AG
//------------------------------------

//* ************************************************************************
//* Global Variables
//* ************************************************************************
var sapUrDomainRelaxing = {NONE:"NONE",MINIMAL:"MINIMAL",MAXIMAL:"MAXIMAL"};

try {ur_system==null;} catch(e) {ur_system = {doc : window.document , stylepath : document.location.pathname.substring(0,document.location.pathname.substring(1).indexOf("/")+1)+"/resources/style/", is508 : true, domainrelaxing:sapUrDomainRelaxing.MINIMAL, dateformat:1, firstdayofweek:0};}
try {ur_language==null;} catch(e) {ur_language=""};
ur_txt=new Array();
ur_system.browser_abbrev = "ie6";
if (ur_system.mimepath == null) ur_system.mimepath = ur_system.stylepath.substring(0,ur_system.stylepath.indexOf("/ur"))+"/common/";
if(ur_system.emptyhoverurl==null) ur_system.emptyhoverurl = ur_system.mimepath+"emptyhover.html";
ur_KEYS = {TAB:9,ESCAPE:27,
           UP:38,DOWN:40,LEFT:37,RIGHT:39,
           BEGIN:36,END:35,PAGE_UP:33,PAGE_DOWN:34,POS1:36,
           BACKSPACE:8,DELETE:46,ENTER:13,SPACE:32,INSERT:45,
           F4:115}