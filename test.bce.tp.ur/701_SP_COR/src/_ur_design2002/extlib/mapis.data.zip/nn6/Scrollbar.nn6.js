var ur_SCB_obj;      //stores the scrollbar object during interaction
var ur_SCB_handle;   //stores the handle object during interaction
var ur_SCB_mousePos; //stores the mouseposition during interaction
var ur_SCB_max;      //stores the available max pixels of the bar during interaction
var ur_SCB_margin;   //stores the current margin during
var ur_SCB_timer;    //stores a timer for intercal of fireing events
var ur_SCB_pixelStop;  //stores the pixel value where to stop scrolling when on the bar element
var ur_SCB_src;      //stores the event source after mouse down
var ur_SCB_arr = new Array(); //array of all available scrollbars on the screen
var ur_SCB_evt; // stores the event object to pass to the framework on scroll finished
var ur_SCB_showst=false; // stores the event object to pass to the framework on scroll finished

function sapUrMapi_Scrollbar_handler(oEvt) {
  ur_SCB_evt=oEvt;
  ur_SCB_src=ur_EVT_src(oEvt);  //events src element
  
  
  //MS: this line exists in IE as well
  if (ur_SCB_src.className=="urSCBBtn") ur_SCB_src=ur_SCB_src.parentNode;
	
	
	var o=ur_getRootObj(ur_SCB_src);

  sArea=ur_getAttD(ur_SCB_src,"area",""); //attribute b holds all types of areas

  if(o && o.id && oEvt.type!="mousemove" && oEvt.type!="mouseup") {
    ur_SCB_obj=ur_Scrollbar_getObj(o.id);
    if(ur_Scrollbar_isDisabled(ur_SCB_obj)) return false;
  }


	
  //mousedown
  if (oEvt.type=="mousedown" && oEvt.button==0) { //left mouse button pressed
    //mousedown on the scroll handle
    ur_SCB_obj=ur_Scrollbar_getObj(o.id);
    
    if (ur_SCB_src.id.indexOf("-h")>-1) { //the handle was clicked
      ur_SCB_handle=ur_SCB_src;
      //ur_SCB_handle.setCapture();
      //ur_SCB_handle.attachEvent("onmousemove",sapUrMapi_Scrollbar_handler);
      //ur_SCB_handle.attachEvent("onmouseup",sapUrMapi_Scrollbar_handler);
      window.captureEvents(Event.MOUSEMOVE);
      window.captureEvents(Event.MOUSEUP);
      window.captureEvents(Event.MOUSEOUT);
      window.addEventListener("mousemove",sapUrMapi_Scrollbar_handler,true);
      window.addEventListener("mouseup",sapUrMapi_Scrollbar_handler,true);
      window.addEventListener("mouseout",sapUrMapi_Scrollbar_handler,true);
      ur_SCB_handle.className=ur_SCB_handle.className.replace("urSCBBtn","urSCBBtnDrag");

      if (ur_SCB_obj.sdir=="v") {
        ur_SCB_margin=parseInt(ur_SCB_src.style.marginTop);
        ur_SCB_mousePos=oEvt.clientY-ur_SCB_margin;
        ur_SCB_max=ur_SCB_src.parentNode.offsetHeight - ur_SCB_src.offsetHeight;
      } else {
        if (ur_system.direction=="rtl") {
          ur_SCB_margin=parseInt(ur_SCB_src.style.marginRight);
          ur_SCB_mousePos=oEvt.clientX - ur_SCB_margin;
        } else {
          ur_SCB_margin=parseInt(ur_SCB_src.style.marginLeft)
          ur_SCB_mousePos=oEvt.clientX-ur_SCB_margin;
        }
        ur_SCB_max = ur_SCB_src.parentNode.offsetWidth - ur_SCB_src.offsetWidth;
      }
      ur_EVT_cancel(oEvt);

    //mousedown on the scroll bar area for
    } else if (sArea == "bar") {
      ur_SCB_handle=ur_get(o.id+"-h");
      ur_SCB_handle.className=ur_SCB_handle.className.replace("urSCBBtn","urSCBBtnDrag");
      var iPos=0;
      //ur_SCB_src.setCapture();
      if (ur_SCB_obj.sdir=="v") {
        var iEvtPos=oEvt.layerY;
        iPos=parseInt(ur_SCB_handle.style.marginTop);
        ur_SCB_pixelStop=ur_SCB_obj.range/ur_SCB_obj.totalPixels*iEvtPos+ur_SCB_obj.min;
        if (iEvtPos<iPos) {//pageup;
          ur_Scrollbar_page(ur_SCB_obj,"up");
          ur_scrollDir="up";
          ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'up')",300);
        } else if (iEvtPos>iPos) {//pagedown;
          ur_Scrollbar_page(ur_SCB_obj,"down");
          ur_scrollDir="down";
          ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'down')",300);
        }
      } else {
        var iEvtPos=oEvt.layerX;
        if (ur_system.direction=="rtl") {
          iPos=parseInt(ur_SCB_src.firstChild.style.marginRight);
          ur_SCB_pixelStop=ur_SCB_obj.range/ur_SCB_obj.totalPixels*iEvtPos+ur_SCB_obj.min;
          if (iEvtPos>iPos) {//pageup;
            ur_Scrollbar_page(ur_SCB_obj,"up");
            ur_scrollDir="up";
            ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'up')",300);
          } else if (iEvtPos<iPos) {//pagedown;
            ur_Scrollbar_page(ur_SCB_obj,"down");
            ur_scrollDir="down";
            ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'down')",300);
          }
        } else {
          iPos=parseInt(ur_SCB_src.firstChild.style.marginLeft);
          ur_SCB_pixelStop=ur_SCB_obj.range/ur_SCB_obj.totalPixels*iEvtPos+ur_SCB_obj.min;
          if (iEvtPos<iPos) {//pageup;
            ur_Scrollbar_page(ur_SCB_obj,"up");
            ur_scrollDir="up";
            ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'up')",300);
          } else if (iEvtPos>iPos) {//pagedown;
            ur_Scrollbar_page(ur_SCB_obj,"down");
            ur_scrollDir="down";
            ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'down')",300);
          }
        }
      }
      ur_SCB_src.addEventListener("mouseup",ur_Scrollbar_stopButton,true);
      ur_SCB_src.addEventListener("mousemove",ur_Scrollbar_correctStopValue,true);

    //mousedown on the scroll buttons
    } else if ("ebudpn".indexOf(sArea)>-1) {
      ur_SCB_handle=ur_get(o.id+"-h");
      //ur_SCB_src.setCapture();
      //window.captureEvents(Event.MOUSEUP);
      ur_SCB_src.addEventListener("mouseup",ur_Scrollbar_stopButton,true);
      ur_SCB_src.addEventListener("mouseout",ur_Scrollbar_stopButton,true);
      ur_SCB_src.className=ur_SCB_src.className.replace("urSCBBtn","urSCBBtnPressed");
      ur_SCB_handle.className=ur_SCB_handle.className.replace("urSCBBtn","urSCBBtnDrag");
      //ur_SCB_src.attachEvent("onmouseup",ur_Scrollbar_stopButton);

      //mousedown on the scroll end button
      if (sArea=="e") {
        ur_Scrollbar_bounce(ur_SCB_obj,"down");
      //mousedown on the scroll begin button
      } else if (sArea=="b") {
        ur_Scrollbar_bounce(ur_SCB_obj,"up");
      //mousedown on the scroll up/prev button
      } else if (sArea=="u" || sArea=="p") {
        ur_Scrollbar_scroll(ur_SCB_obj,"up");
        ur_SCB_timer=setInterval("ur_Scrollbar_scrollStart(ur_SCB_obj,'up')",180);
      //mousedown on the scroll up/prev button
      } else if (sArea=="d" || sArea=="n") {
        ur_Scrollbar_scroll(ur_SCB_obj,"down");
        ur_SCB_timer=setInterval("ur_Scrollbar_scrollStart(ur_SCB_obj,'down')",180);
      }
    }

  //mousemove
  } else if (oEvt.type=="mousemove") {
  	
  	
    if (ur_SCB_handle)
      if (ur_SCB_obj.sdir=="v")
        iNewPos=oEvt.clientY - ur_SCB_mousePos;
      else
        iNewPos=oEvt.clientX - ur_SCB_mousePos;
      if (iNewPos<0) iNewPos=0;
      if (iNewPos>ur_SCB_max) iNewPos=ur_SCB_max;
      ur_SCB_margin=iNewPos;
      if (ur_SCB_obj.sdir=="v")
        ur_SCB_handle.style.marginTop=iNewPos;
      else
        if (ur_system.direction=="rtl")
          ur_SCB_handle.style.marginRight=iNewPos;
        else
          ur_SCB_handle.style.marginLeft=iNewPos;

    ur_SCB_showst=true;
    ur_Scrollbar_showScrollTip(ur_SCB_obj,Math.floor(ur_SCB_obj.range/ur_SCB_max*ur_SCB_margin+ur_SCB_obj.min));
    ur_EVT_cancel(oEvt);

  //mouseup
  } else if (oEvt.type=="mouseup" || (oEvt.type=="mouseout" && oEvt.target==window.document.documentElement)) {
    //ur_SCB_handle.releaseCapture();
    window.releaseEvents(Event.MOUSEMOVE);
    window.releaseEvents(Event.MOUSEUP);
    window.releaseEvents(Event.MOUSEOUT);
    window.removeEventListener("mousemove",sapUrMapi_Scrollbar_handler,true);
    window.removeEventListener("mouseup",sapUrMapi_Scrollbar_handler,true);
    window.removeEventListener("mouseout",sapUrMapi_Scrollbar_handler,true);
    ur_SCB_handle.className=ur_SCB_handle.className.replace("urSCBBtnDrag","urSCBBtn");
    ur_SCB_handle=null;
    //set the new value
    ur_SCB_obj.newvalue=Math.floor(ur_SCB_obj.range/ur_SCB_max*ur_SCB_margin+ur_SCB_obj.min);
    ur_Scrollbar_applyHandlePos(ur_SCB_obj);
    //fire the change
    ur_Scrollbar_fireChange(ur_SCB_obj, ur_SCB_evt);
  }
}

function ur_Scrollbar_fireChange(ur_SCB_obj, oEvt) {
  ur_Scrollbar_hideScrollTip();
  ur_SCB_showst=false;
  var iMod=ur_SCB_obj.newvalue%ur_SCB_obj.smallChange;
  if (Math.abs(iMod)>0) {
    if (ur_SCB_obj.smallChange/2>iMod) ur_SCB_obj.newvalue=ur_SCB_obj.newvalue-iMod;
    else ur_SCB_obj.newvalue=ur_SCB_obj.newvalue+ur_SCB_obj.smallChange-iMod;
  }
  if (ur_SCB_obj.newvalue!=ur_SCB_obj.value) {
    ur_SCB_obj.value=ur_SCB_obj.newvalue;
    ur_SCB_obj.ref.setAttribute("val",ur_SCB_obj.value);
    oEvt.ur_param=new Array();
    oEvt.ur_param["pos"]=ur_SCB_obj.value;
    oEvt.ur_param["dir"]=ur_SCB_obj.sdir;
    ur_EVT_fire(ur_SCB_obj.ref,"oscrlf",oEvt);
  }
}

function ur_Scrollbar_pageStart(o,sDir) {
  clearInterval(ur_SCB_timer);
  ur_Scrollbar_page(o,sDir);
  ur_SCB_showst=true;
  ur_SCB_timer=setInterval("ur_Scrollbar_page(ur_SCB_obj,'"+sDir+"')",100)
}

function ur_Scrollbar_scrollStart(o,sDir) {
  clearInterval(ur_SCB_timer);
  ur_Scrollbar_scroll(o,sDir);
  ur_SCB_showst=true;
  ur_SCB_timer=setInterval("ur_Scrollbar_scroll(ur_SCB_obj,'"+sDir+"')",50)
}

function ur_Scrollbar_correctStopValue(oEvt) {
  if (ur_SCB_obj.sdir=="v") {
    var newValue=ur_SCB_obj.range / ur_SCB_obj.totalPixels * oEvt.offsetY + ur_SCB_obj.min;
    var iPos=parseInt(ur_SCB_handle.style.marginTop);
    if (ur_scrollDir=="up" && newValue<iPos) ur_SCB_pixelStop=newValue;
    if (ur_scrollDir=="down" && newValue>iPos) ur_SCB_pixelStop=newValue;
  } else {
    var newValue=ur_SCB_obj.range / ur_SCB_obj.totalPixels * oEvt.clientX + ur_SCB_obj.min;
    var iPos=parseInt(ur_SCB_handle.style.marginLeft);
    if (ur_scrollDir=="up" && newValue<iPos) ur_SCB_pixelStop=newValue;
    if (ur_scrollDir=="down" && newValue>iPos) ur_SCB_pixelStop=newValue;
  }
}

function ur_Scrollbar_stopButton(oEvt) {
  ur_SCB_evt=oEvt;
  if (ur_SCB_timer) window.clearInterval(ur_SCB_timer);
  //reset the button
  if (ur_SCB_src) {
    ur_SCB_src.className=ur_SCB_src.className.replace("urSCBBtnPressed","urSCBBtn");
    //window.releaseEvents(Event.MOUSEUP);
    ur_SCB_src.removeEventListener("mouseup",ur_Scrollbar_stopButton,true);
    ur_SCB_src.removeEventListener("mouseout",ur_Scrollbar_stopButton,true);
    ur_SCB_src.removeEventListener("mousemove",ur_Scrollbar_correctStopValue,true);
    ur_SCB_handle.className=ur_SCB_handle.className.replace("urSCBBtnDrag","urSCBBtn");
    //ur_SCB_src.releaseCapture();
    ur_SCB_src=null;
  }
  ur_Scrollbar_fireChange(ur_SCB_obj, ur_SCB_evt);
  ur_SCB_handle=null;
}

function sapUrMapi_Scrollbar_registerCreate(sId) {
  sapUrMapi_Create_AddItem(sId, "ur_Scrollbar_init('"+sId+"')");
  //sapUrMapi_Resize_AddItem(sId, "ur_Scrollbar_resize('"+sId+"')");
}

function ur_Scrollbar_resize(oEvt) {
  if (!oEvt) return;
  var sId = ur_EVT_src(oEvt).id;
  ur_SCB_arr[sId]=null;
  ur_callDelayed("ur_Scrollbar_init('"+sId+"')",0);
}


function ur_Scrollbar_EnvironmentCleanUp() {
  ur_SCB_arr=null;
  ur_iScrollbarResizeProcessObject = null;
}

function ur_Scrollbar_EnvironmentInit() {
  ur_SCB_arr = new Array();
  ur_iScrollbarResizeProcessObject = {};
}

function ur_Scrollbar_getObj(sId) {
  var o = ur_get(sId);
  if (!o) return null;
  if (!ur_SCB_arr[sId]) {
    var obj = {id:sId,
         sid:ur_getAttD(o,"sid",""),
         sdir:ur_getAttD(o,"sdir",""),
         value:parseInt(ur_getAttD(o,"val","0")),
         newvalue:parseInt(ur_getAttD(o,"val","0")),
         max:parseInt(ur_getAttD(o,"max","")),
         min:parseInt(ur_getAttD(o,"min","")),
         smallChange:parseInt(ur_getAttD(o,"sml","")),
         largeChange:parseInt(ur_getAttD(o,"lrg","")),
         showscrolltip:ur_getAttD(o,"scs","")=="1",
         scrolltipdefault:ur_getAttD(o,"scd",""),
         sScrolltips:ur_getAttD(o,"sct",""),
         scrolltips:null,
         ref:o,
         handle:ur_get(sId+"-h")};
         
    // When firstVisibleRow is outside the allowed range while the table entries fit
    // in the visibleRowCount, the ScrollBar has to be enabled to allow a scrolling back to the
    // beginning
    if(obj.value > 1 && o.min >= o.max) obj.max=obj.value;     
         
    if (obj.sdir == "v") {
      obj.ref.style.height = obj.ref.parentNode.offsetHeight;
      obj.totalPixels = obj.handle.parentNode.offsetHeight;
    } else {
      obj.totalPixels = obj.handle.parentNode.offsetWidth;
    }
    if (obj.showscrolltip) {
      if (!document.getElementById("ur-scrolltip")) {
        var oScrollTip=document.createElement("SPAN");
        oScrollTip.setAttribute("id","ur-scrolltip");
        oScrollTip.style.position="absolute";
        oScrollTip.style.visibility="hidden";
        oScrollTip.style.top="0";
        oScrollTip.style.left="0";
        document.getElementsByTagName("BODY")[0].appendChild(oScrollTip);
      }
      obj.scrolltip=document.getElementById("ur-scrolltip");
      while ( obj.sScrolltips.indexOf("_")>0) obj.sScrolltips=obj.sScrolltips.replace("_","'");
      if(obj.sScrolltips) obj.scrolltips =eval("result=" + obj.sScrolltips +";");
    }
    if (obj.value < obj.min) obj.value = obj.min;
    obj.range = obj.max-obj.min;
    obj.handlesize=ur_Scrollbar_getHandleSize(obj);
    
    // handle adaption
    if (obj.sdir == "v") {
    	obj.handle.style.width = (obj.handle.parentNode.offsetWidth-2) + "px";
      obj.handle.style.height = obj.handlesize;
    } else {
      obj.handle.style.width = obj.handlesize;
      obj.handle.style.height = (obj.handle.parentNode.offsetHeight-2) + "px";
    }
    
    ur_SCB_arr[sId] = obj;
    ur_get(sId).addEventListener("resize",ur_Scrollbar_resize,true);

    if (ur_Scrollbar_isDisabled(obj)) {
      //set the images to disabled

    } else {
      //set the images to enabled
    }
    return obj;
  } else {
    return ur_SCB_arr[sId];
  }
}

function ur_Scrollbar_page(o,dir,oEvt) {
  if (!oEvt) oEvt=ur_SCB_evt;
  if (dir=="up") o.newvalue=o.newvalue-o.largeChange;
  else o.newvalue=o.newvalue+o.largeChange;
  if (o.newvalue>o.max) o.newvalue=o.max;
  if (o.newvalue<o.min) o.newvalue=o.min;

  //if (ur_SCB_pixelStop && dir=="up" && o.newvalue < ur_SCB_pixelStop - o.largeChange) o.newvalue = ur_SCB_pixelStop;
  //if (ur_SCB_pixelStop && dir=="down" && o.newvalue > ur_SCB_pixelStop  - o.largeChange) o.newvalue = ur_SCB_pixelStop;

  o.newvalue=Math.ceil(o.newvalue);
  ur_Scrollbar_applyHandlePos(o);
  ur_Scrollbar_showScrollTip(o,o.newvalue);
}

function ur_Scrollbar_scroll(o,dir,oEvt) {
  if (!oEvt) oEvt=ur_SCB_evt;
  if (dir=="up") o.newvalue=o.newvalue-o.smallChange;
  else o.newvalue=o.newvalue+o.smallChange;
  if (o.newvalue>o.max) o.newvalue=o.max;
  if (o.newvalue<o.min) o.newvalue=o.min;
  ur_Scrollbar_applyHandlePos(o);
  ur_Scrollbar_showScrollTip(o,o.newvalue);
}

function ur_Scrollbar_bounce(o,dir,oEvt) {
  if (!oEvt) oEvt=ur_SCB_evt;
  if (dir=="up") o.newvalue=o.min;
  else o.newvalue=o.max;
  ur_Scrollbar_applyHandlePos(o);
}

function ur_Scrollbar_getHandleSize(o) {

  if(ur_Scrollbar_isDisabled(o)) return 0;

  var iTotal = 0;
  var elemCount = o.range + o.largeChange;
  var iSize=Math.floor(o.totalPixels / elemCount * o.largeChange);

  if (iSize<6) iSize=6;
  if (o.totalPixels <= iSize) iSize=0;
  o.totalPixels = o.totalPixels;
  return iSize;
}

function ur_Scrollbar_applyHandleSize(o) {
  if(ur_Scrollbar_isDisabled(o)) {
    o.handle.style.display = "none";
  } else if (o.sdir == "v") {
    o.handle.style.height = o.handlesize+"px";
    o.handle.firstChild.style.height = (o.handlesize-2)+"px";
  } else {
    o.handle.style.width = o.handlesize+"px";
    o.handle.firstChild.style.width = (o.handlesize-2)+"px";
  }
}

function ur_Scrollbar_isDisabled(o) {
  return (o)? o.min >= o.max: false;
}

function ur_Scrollbar_applyHandlePos(o) {

  if(ur_Scrollbar_isDisabled(o)) return;

  var iVal = o.newvalue - o.min;
  iVal = Math.floor((o.totalPixels / o.range) * iVal);
  //correction of the position. The actual value moves from top to bottom of the handle depending on the handles position.
  if (o.totalPixels == 0) return;
  iVal=iVal - Math.ceil((o.handlesize / o.totalPixels) * iVal);

  if (iVal != 0) {
    if (iVal + o.handlesize >= o.totalPixels) iVal = o.totalPixels - o.handlesize - 1;
  }

  var iBorderWidth=parseInt(document.defaultView.getComputedStyle(o.handle, '').getPropertyValue("border-top-width"));
  if(iVal>o.totalPixels-o.handlesize-2) iVal=o.totalPixels-o.handlesize-(iBorderWidth*2);

  if (o.sdir == "v") {
    o.handle.style.marginTop = iVal;
  } else {
    if (ur_system.direction=="rtl")
      o.handle.style.marginRight = iVal;
    else
      o.handle.style.marginLeft = iVal;
  }
}

function ur_Scrollbar_init(sId) {
   var o = ur_Scrollbar_getObj(sId);
   if (!o) return;
   ur_Scrollbar_applyHandleSize(o);
   ur_Scrollbar_applyHandlePos(o);

}

function sapUrMapi_Scrollbar_scroll(sId,oEvt) {
   var o = ur_get(sId);
   var oScr=ur_Scrollbar_getObj(ur_getRootObj(ur_EVT_src(oEvt).id));
   if (o && o.style.overflow=="hidden") {
      if (oScr.sdir=="v")
        o.scrollTop=(o.scrollHeight/oScr.range)*(oScr.value-oScr.min); //scroll in relation to the scroll container
      else
        o.scrollleft=(o.scrollWidth/oScr.range)*(oScr.value-oScr.min); //scroll in relation to the scroll container
   }
}

function ur_Scrollbar_hideScrollTip() {
  if (oPopup)
    oPopup.hide();
}

var myLock=false;

function ur_Scrollbar_showScrollTip(obj,val) {
	
	if(myLock) return;
	myLock=true;
  // shows a scrolltip for a specific scroll position
  // val = current position index of scrollbar
  if (obj.showscrolltip && ur_SCB_showst) {
    var oScrollTip=ur_get('ur-scrolltip');

    var s="<table class=\"urDataTipStd urDataTipTxt\" style=\"text-align:right;padding:1px 3px;height:16px;width:1px;\">";

    // row for application text is created
    if (obj.scrolltips) { // has application provided scrolltips
      var lastMatchValue;
      s += "<tr><td nowrap><b>";
      for(var n in obj.scrolltips) { //Search for the scrolltip given by the application
        if (n>val) break;
        else lastMatchValue=n;
      }
      //in the object the index of the corresponding scrolltip is stored
      var sDomObjIndex = obj.scrolltips[lastMatchValue];
      //with the index we can extract the html from the dom object with the id obj.id + "-sct-"+ sDomObjIndex
      var sHTML = ur_get(obj.id + "-sct-" + sDomObjIndex).innerHTML;
      s += sHTML + "</b></td></tr>";
    }

    // now the standard text is created (e.g. "Row X - Y of Z")
    var fromIndex=val, toIndex=fromIndex+obj.largeChange-1, ofCount=obj.max+obj.largeChange-1;

    if (obj.sdir=="v" && obj.scrolltipdefault=="ROW") {
      s += "<tr><td nowrap>" + getLanguageText("SAPUR_PG_ROW") + " " + fromIndex + " - " + toIndex + " " + getLanguageText("SAPUR_PG_INDEX") + " " + ofCount + "</td></tr>";
    } else if (obj.sdir=="h" && obj.scrolltipdefault=="COL") {
      s += "<tr><td nowrap>" + getLanguageText("SAPUR_PG_COLUMN") + " " + fromIndex + " - " + toIndex + " " + getLanguageText("SAPUR_PG_INDEX") + " " + ofCount + "</td></tr>";
    }

    oScrollTip.innerHTML= s + "</table>";

    if (obj.sdir=="v") {
      oScrollTip.firstChild.style.textAlign="right";
    } else
      oScrollTip.firstChild.style.textAlign="left";

    var arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
    oPopup = new sapPopup(window,arrUrls,oScrollTip,obj.handle,null,0);
    oPopup.positionbehavior = sapPopupPositionBehavior.MENURIGHT;
    if (obj.sdir=="v") {
      oPopup.position.left-=obj.ref.offsetWidth;
      oPopup.position.top-=obj.handle.offsetHeight;
    } else {
      oPopup.position.left-=obj.handle.offsetWidth-oScrollTip.offsetWidth;
      oPopup.position.top-=obj.handle.offsetHeight+oScrollTip.offsetHeight;
    }
    oPopup.show(true);
  } else {
    if (oPopup)
      oPopup.hide();
  }
  
  myLock=false;
  
}