function sapUrMapi_Focus_getFocusOffset(object){}
function sapUrMapi_Focus_canFocus(o){}
function sapUrMapi_Focus_getNextFocusableElement(o){}
function sapUrMapi_Focus_showFocusRect(sId){}
function sapUrMapi_Focus_RegisterCreate(sId){}
function sapUrMapi_Focus_getCurrentId(){}
function sapUrMapi_Focus_reset(){}
function sapUrMapi_Focus_remove(){}
function sapUrMapi_Focus_getFocusRectHeight() {return 0;}
function sapUrMapi_Focus_calcFocusRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom){}
function sapUrMapi_Focus_DeflBtn_hideFocusRect(IsDeflBtn){};
