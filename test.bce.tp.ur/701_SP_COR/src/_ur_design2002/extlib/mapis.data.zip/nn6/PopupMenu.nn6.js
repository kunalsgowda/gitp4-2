
//* ************************************************************************
//* Popup Menu
//* ************************************************************************
//HOVER
var _ur_POMN = {all:new Array(),menus:new Array(),level:0};
var	_ur_POMN_triggerId="";
var mnu = new Object();
mnu.intv = null;
mnu.active = false;
mnu.delay = 250;
mnu.cancel = false;
mnu.mnuWin = null;
mnu.mnuE = null;
var sapPopupMenuLevel = 0;
var subMenus = new Array(null,null,null,null,null,null);
var subMenuItems = new Array(null,null,null,null,null,null);
var itemsArray = new Array(null,null,null,null,null,null,null,null);
var urOldFocus = window.onfocus;
var baseMenu = null;
var oPopup;
me=window;
var initMenus = new Array();

function sapUrMapi_PopupMenu_init(id,e) {
	if (me.menuObject) {
	  sapUrMapi_PopupMenu_exit(id,e);
	}
	if (!me.menuObject) {
//GPR
	  //var items =window.document.getElementById(id).childNodes.item(0).childNodes.item(1).childNodes;
	  var items = window.document.getElementById(id+"-r").childNodes.item(1).childNodes;
	  var menu = new sapUrMapi_PopupMenu(items);
	  me.menuObject = menu;
    me.menuObject.standalone=true;
  }
}

function sapUrMapi_PopupMenu_exit(id,e) {
	if (e.target.id==id) {
		if (me.menuObject) {
			sapUrMapi_PopupMenu_hideAll();
			sapUrMapi_PopupMenu_setItemActive(me,-1, id);
		  me.menuObject = null;
		}
	} else {
		if (me.menuObject) {
			if (me.menuObject.out) {
		    sapUrMapi_PopupMenu_setItemActive(me,-1, id);
		  }
		}

	}
}

function sapUrMapi_PopupMenu_hoverItem(mywindow,id,e) {
	//needed for portal
	if(e==null) return;
	//find the popup with the event
	var o=e.target;
  if(o.parentNode.className=="urMnuDvdr"){
      iIdx = "dvdr"
      sapUrMapi_PopupMenu_setItemActive(mywindow,iIdx, id);
      if (mywindow.mylevel<=sapPopupMenuLevel) {
                  for (var n=mywindow.mylevel+1;n<=sapPopupMenuLevel;n++) {
                       subMenus[n].hide();
                  }
      }
      return;
  }
  if(typeof o.tagName=="undefined") o=o.parentNode;//if o is the text
  if (o.tagName=="IMG" || o.tagName=="NOBR" || o.tagName=="SPAN")o=o.parentNode;
  if (o.tagName=="TD") {
		iIdx = parseInt(o.parentNode.getAttribute("Idx"));
	  if (mywindow.menuObject==null) {
	    sapUrMapi_PopupMenu_init(id,e);
	  }
	//GPR
	  //var items=mywindow.document.getElementsByTagName("BODY").item(0).childNodes.item(0).childNodes.item(0).childNodes.item(0).childNodes;
	  var items = mywindow.document.getElementById(id+"-r").childNodes.item(1).childNodes;
	  mywindow.menuObject = sapUrMapi_PopupMenu(items);
	  if (mywindow.menuObject.activeItem==iIdx) return;

	//GPR:  need to escape hover behavior for scrollers
	if(o.getAttribute("isscroll")=="true") {
		e.stopPropagation();
		return false;
	}

	  sapUrMapi_PopupMenu_setItemActive(mywindow,iIdx, id);
	  if (mywindow.mylevel<=sapPopupMenuLevel) {
	  	for (var n=mywindow.mylevel+1;n<=sapPopupMenuLevel;n++) {
	      subMenus[n].hide();
      }
	  }
	  ur_focus(mywindow);
	  if (ur_getAttD(mywindow.menuObject.items[mywindow.menuObject.activeItem],"st","").indexOf("d")==-1) {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"opensub", id);
	  }
	}
	e.cancelBubble=true;
}


function sapUrMapi_PopupMenu_hideAll() {
  for (var n=0;n<sapPopupMenuLevel+1;n++) {
	 if (subMenus[n]!=null) {
    subMenus[n].hide();
   }
  }
  if (baseMenu!=null) {baseMenu.hide();}
  baseMenu=null;
  if(oPopup!=null){
	    try {
          //CSN: 340942 2010, If a td is focused here the browser scrolls
          //Therefore focus the first child if any
          var oSrc = oPopup.source.object;
          if (oSrc && oSrc.tagName=="TD") {
            if (oSrc.firstChild && oSrc.firstChild.nodeType == 1) 
                ur_focus(oSrc.firstChild);
          } else {
            ur_focus(oSrc);
          }
	    } catch(e) {}	
  }
  oPopup=null;
  sapPopupMenuLevel=0;
  //window.onfocus=urOldFocus;
}

function sapUrMapi_PopupMenu_showMenu(idTrigger,idContent,enumAlignment,e ) {
	var styles = document.getElementsByTagName("LINK");
	var arrUrls;
	_ur_POMN_triggerId=idTrigger;
	arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
  //close all opend submenus
  for (var i=0;i<subMenus.length;i++) {
  	if (subMenus[i]!=null) {
  		subMenus[i].hide();
  	}
  }
	var o = ur_get(idContent);
	if (!o) return;
	if (o.hasChildNodes() && o.firstChild.tagName=="XMP") {
	  o.innerHTML=o.firstChild.innerHTML; 
	}
	//FF1.5 had wrong width for popup menu
	if (o.firstChild.firstChild.offsetWidth!=0)
		o.firstChild.style.width = o.firstChild.firstChild.offsetWidth;
  
  sapUrMapi_PopupMenu_drawInit(idContent);
	oPopup = new sapPopup(window,arrUrls,o,ur_get(idTrigger),e,0);
  oPopup.onblur=oPopup.hide;
  if (!enumAlignment)
    if (ur_system.direction== "rtl")
      enumAlignment= sapPopupPositionBehavior.MENURIGHT;
    else
      enumAlignment= sapPopupPositionBehavior.MENULEFT;
  oPopup.positionbehavior = enumAlignment;
  oPopup.show();
  baseMenu=oPopup;
	window.onfocus=sapUrMapi_PopupMenu_hideAll;
}

function sapUrMapi_PopupMenu_setItemActive(win,newActive, sId) {
	if (sId=="blank") return;
	var remActive = newActive;
	if (!win.menuObject) {
	  var items=win.document.getElementsByTagName("BODY").item(0).childNodes.item(0).childNodes.item(0).childNodes.item(0).childNodes.item(1).childNodes;
	  win.menuObject = sapUrMapi_PopupMenu(items);
	}
	var menuObj=win.menuObject;
	if (newActive==menuObj.activeItem) return;

	menuObj.out=false;
	if ((newActive=="opensubkey")||(newActive=="opensub")) {
		if (!menuObj.items[menuObj.activeItem]) return;
		var sSubMenuId = menuObj.items[menuObj.activeItem].getAttribute("smnu");
		if ((sSubMenuId!="") && (sSubMenuId!=null)) {
		  if (!oPopup) {
		  	var iStartLevel=-1;
		  } else {
		  	var iStartLevel=win.mylevel;
		  }
		  if (iStartLevel<sapPopupMenuLevel) {
				for (var n=iStartLevel+1;n<sapPopupMenuLevel+1;n++) {
				  if (subMenus[n]!=null) {
  				  subMenus[n].hide();
  				}
				}
			  sapPopupMenuLevel=iStartLevel;
			}

			var arrUrls;
			arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");

			if (!oPopup) {
			   subwindow = window;
  			 sapPopupMenuLevel = 0;
			} else {
			  subwindow = win;
			  sapPopupMenuLevel = win.mylevel+1;
			}
			var src = menuObj.items[menuObj.activeItem];
			var o = ur_get(sSubMenuId);
			if (o.hasChildNodes() && o.firstChild.tagName=="XMP") {
				o.innerHTML=o.firstChild.innerHTML; 
			}
			//FF1.5 did had wrong width for popup menu
			o.firstChild.style.width=o.firstChild.firstChild.offsetWidth;
  		sapUrMapi_PopupMenu_drawInit(sSubMenuId);
		  subMenu = new sapPopup(window,arrUrls,o,src,null,sapPopupMenuLevel);
	    subMenu.onblur=subMenu.hide;
	    subMenu.positionbehavior = sapPopupPositionBehavior.SUBMENU;
	    subMenu.show();
	    subMenus[sapPopupMenuLevel] = subMenu;
		}
	  return;
	}
	if (newActive=="closesub") {
		if (win.mylevel) {
			subMenus[win.mylevel].hide();
			if (win.mylevel>1) {
  			ur_focus(subMenus[win.mylevel-1].frame.window);
				sapUrMapi_PopupMenu_setItemActive(subMenus[win.mylevel-1].frame.window,subMenus[win.mylevel-1].frame.window.menuObject.activeItem, sId)
				win.onkeydown=void(0);
			} else {
  			sapUrMapi_PopupMenu_setItemActive(oPopup.frame.window,itemsArray[0].activeItem, sId)
				ur_focus(oPopup.frame.window);
				win.onkeydown=void(0);
			}
			subMenus[win.mylevel].hide();
		}
	  return;
	}
	if (newActive=="first") {
	  newActive=menuObj.activeItem+1;
	  if (newActive>menuObj.items.length-1) newActive=0;
	}
	var bDown = "true";
	if (newActive=="next") {
	  newActive=menuObj.activeItem+1;
		if (newActive>menuObj.items.length-1){
			if (menuObj.items[0].style.display != "none"){
				newActive=0;
			}
			else{
			   newActive = menuObj.items.length-1;
			   return;
			}

		}
	}
	if (newActive=="prev") {
		newActive=menuObj.activeItem-1;
		if (newActive<0){
			if (menuObj.items[menuObj.items.length-1].style.display != "none"){
				newActive=menuObj.items.length-1;
			}
			else{
			   newActive = 0;
			   return;
			}
	}
		bDown = "false";
	}
  if (newActive=="dvdr") {
             if (menuObj.activeItem>-1) {
                  if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) {
                  menuObj.items[menuObj.activeItem].className="urMnuRowDsbl";
                  } else {
                          menuObj.items[menuObj.activeItem].className="urMnuRowOff";
                  }
             }
  }
	if (newActive>-1) {
		if (menuObj.activeItem>-1) {
			if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) {
			  menuObj.items[menuObj.activeItem].className="urMnuRowDsbl";
		  } else {
			  menuObj.items[menuObj.activeItem].className="urMnuRowOff";
		  }
		  if (ur_system.is508) {
		  	with(menuObj.items[menuObj.activeItem]) {
		  	  for (var i=0;i<childNodes.length;i++) {
		  	    if (childNodes.item(i).className=="urMnuTxt") {
		  	    	sapUrMapi_setTabIndex(childNodes.item(i),-1);
		  	    	break;
		  	    }
		  	  }
		  	}
		  }
		}
		menuObj.activeItem =  newActive;
		if (menuObj.activeItem>-1) {
		  if (ur_system.is508) {
				while (menuObj.items[menuObj.activeItem].style.display == "none"){
					sapUrMapi_PopupMenu_manualScroll(win, sId, bDown, true);
				}
		  	with(menuObj.items[menuObj.activeItem]) {
		  	  for (var i=0;i<childNodes.length;i++) {
		  	    if (childNodes.item(i).className=="urMnuTxt") {
		  	    	sapUrMapi_setTabIndex(childNodes.item(i),0);
		  	    	//ur_focus(childNodes.item(i));
		  	    	break;
		  	    }
		  	  }
		  	}
		  }
     if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) {
			  menuObj.items[menuObj.activeItem].className="urMnuRowDsblOn";
		  } else {
			  menuObj.items[menuObj.activeItem].className="urMnuRowOn";
		  }
		}
	} else {
		if (newActive==-1) {
			if (ur_system.is508) {
				if (menuObj) {
					if (menuObj.items) {
				  	for (var j=0;j<menuObj.items.length;j++) {
				 			if (menuObj.items[j]) {
					  		with(menuObj.items[j]) {
						  	  for (var i=0;i<childNodes.length;i++) {
						  	    if (childNodes.item(i).className=="urMnuTxt") {
						  	    	sapUrMapi_setTabIndex(childNodes.item(i),-1);
						  	    	break;
						  	    }
						  	  }
						  	}
					  	}
					  }
					}
				}
		  }
		  if (menuObj) {
			  if (menuObj.items.length>0) {
			  	if (menuObj.items[menuObj.activeItem]) {
						if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) {
						  menuObj.items[menuObj.activeItem].className="urMnuRowDsbl";
					  } else {
						  menuObj.items[menuObj.activeItem].className="urMnuRow";
					  }
					}
				}
			}
		}
	}
}

function sapUrMapi_PopupMenu(items) {
	this.activeItem = -1;
	this.items = new Array();
	for (var i=0;i<items.length;i++) {
		if (items.item(i).childNodes.item(0).className!="urMnuDvdr") {
			this.items[this.items.length]=items.item(i);
			if (this.items[this.items.length-1].className.indexOf("On")>-1) {
				this.activeItem=this.items.length-1;
			}
			this.items[this.items.length-1].setAttribute("Idx",this.items.length-1);
		}
	}
	return this;
}

function sapUrMapi_PopupMenu_keyDown(mywindow,id,e) {
	if (e.keyCode==27) {
		if (mywindow.menuObject) {
			if (mywindow.menuObject.standalone) {
				sapUrMapi_PopupMenu_exit(id,e);
		    ur_focus(me.menuObject.items[me.menuObject.activeItem].parentNode.parentNode.parentNode);
		  } else {
		  	try {
			    ur_focus(oPopup.source.object);
			  } catch(e) {
			  }
			  hidePopupMenu();
		  }
		}
		return;
	}
	if (e.keyCode==40) { //down
	  sapUrMapi_PopupMenu_setItemActive(mywindow,"next", id);
	}
	if (e.keyCode==38) { //up
	  sapUrMapi_PopupMenu_setItemActive(mywindow,"prev", id);
	}
	if (e.keyCode==39) { //right
	  if (ur_system.direction == "rtl") {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"closesub", id);
		e.cancelBubble=true;
		return;
	  } else {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"opensubkey", id);
	  }
    }
	if (e.keyCode==37) { //left
	  if (ur_system.direction == "rtl") {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"opensubkey", id);
	  } else {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"closesub", id);
		e.cancelBubble=true;
		return;
	  }
	}
	if (e.keyCode==13) { //
	  ur_PopupMenu_click(mywindow,id,e);
	}
	if (e.keyCode!=9) {
	  e.cancelBubble=true;
	  e.returnValue=false;
	} else {
		if (mywindow.menuObject) {
			mywindow.menuObject.out=true;
		}
		if(oPopup.source.object!=null){
			try {
			    ur_focus(oPopup.source.object);
			} catch(e) {}	
		}	
		hidePopupMenu();
	  e.cancelBubble=false;
	  e.returnValue=true;
	}
	return false;
}

function sapUrMapi_PopupMenu_ExecuteLink(id) {
  oItem = window.document.getElementById(id);
  sTarget = oItem.getAttribute("target");
  sHref   = oItem.getAttribute("href");
  oTarget = top.frames[sTarget];
  if (oTarget) {
  	oTarget.location.href=sHref;
  } else {
    window.open(sHref,sTarget,"");
	}
  }



function sapUrMapi_PopupMenu_drawInit( sId,oSubWindow ){
    var tbl = window.document.getElementById(sId+"-r");
/*
	//escape the function if we can't draw it correctly
		if (typeof(tbl)=="undefined")  {
		  window.ur_callDelayed("window.sapUrMapi_PopupMenu_drawInit('" + sId +"')", 100);
		  return;
	  }
  //escape the function if we can't draw it correctly
	if (tbl.offsetWidth == 0){
		window.ur_callDelayed("window.sapUrMapi_PopupMenu_drawInit('" + sId +"')", 100);
		return;
}
*/
	var rows = tbl.childNodes.item(1).rows;
	var visIdx = tbl.getAttribute("visidx") - 0;
    var visCnt = tbl.getAttribute("viscnt") - 0;
	var maxVisCnt = rows.length - visIdx;

//	tbl.width = tbl.offsetWidth;
  tbl.style.width = tbl.offsetWidth + "px";

	//get max height of window
	var maxHt = window.document.body.offsetHeight;
	var mnuHt = tbl.offsetHeight;
	var visBtns = true;
	if (visCnt==0){visCnt=rows.length}
	var oHead,oFoot;
	oHead=tbl.getElementsByTagName("THEAD")[0];
	oFoot=tbl.getElementsByTagName("TFOOT")[0];
  oHead.style.display = "";		
	oFoot.style.display = "";		

		//see if we need buttons, if not, turn them off
	//if (((visIdx == 0) && (visCnt >= rows.length)) && maxHt > (mnuHt - btnHt) ){
	if ((visIdx == 0) && (visCnt >= rows.length)){
		oHead.style.display = "none";
		oFoot.style.display = "none";
		//resize the seperator height
		for (var i = 0; i < rows.length; i++){
			if (rows[i].cells[0].className == "urMnuDvdr"){
				rows[i].cells[0].style.fontSize="5px";
			}
		}
		}
	//mnuHt = 0 + tbl.childNodes.item(0).rows[0].offsetHeight + tbl.childNodes.item(2).rows[0].offsetHeight;

	for (var i = 0; i < rows.length; i++){
        for (var z = 0; z < rows[i].cells.length; z++){
			rows[i].cells[z].width = rows[i].cells[z].offsetWidth;
            rows[i].cells[z].style.width = rows[i].cells[z].offsetWidth +"px";
        }
    }
	if (visCnt <= 0){
		//just escape the function
		return false;
	}
	if (visCnt > maxVisCnt) {
	    //reset the visible count
		visCnt = maxVisCnt;
		//tbl.setAttribute("viscnt", visCnt);
	}
	var resetVisCnt = false;
	var upOn = false;
	var dnOn = false;
    for (var n = 0; n < rows.length; n++){
		//turn off all rows before our active row
        if (n < visIdx){
   			//rows[n].style.display = "none";
			for (var i = 0;i < rows[n].cells.length; i++){
				rows[n].cells[i].style.display = "none";
			}
			upOn = true;
        }
		else if (n == visIdx){
				//mnuHt += rows[n].offsetHeight
		}
		//always show the visible index
		else if (n > visIdx && n < (visIdx + visCnt)){
				/*if (mnuHt + rows[n].offsetHeight > maxHt){
					rows[n].style.display = "none";
				for (var i = 0; i < rows[n].cells.length; i++){
					rows[n].cells[i].style.display = "none";
				}
				if (resetVisCnt == false){
					resetVisCnt = true;
					visCnt = n - visIdx;
					tbl.setAttribute("viscnt", visCnt);
				}
			}
			mnuHt += rows[n].offsetHeight;
				*/
		}
		else if (n >= (visIdx + visCnt)){
			//rows[n].style.display = "none";
			for (var i = 0; i < rows[n].cells.length; i++){
				rows[n].cells[i].style.display = "none";
			}
			dnOn = true;
	}
}

	//and activate our buttons
	if (visBtns) {
	  if (!oSubWindow) {
	    sapUrMapi_PopupMenu_setButtons( sId, false, upOn );
	    sapUrMapi_PopupMenu_setButtons( sId, true, dnOn );
	  } else {
		sapUrMapi_PopupMenu_setButtons( sId, false, upOn, oSubWindow );
		sapUrMapi_PopupMenu_setButtons( sId, true, dnOn, oSubWindow );
	  }
    }
	  }

function sapUrMapi_PopupMenu_timeScroll(oWindow, sId, bDown, bCancel, e) {
    //assign our arguments to global variables
    mnu.mnuWin = oWindow;
	e.stopPropagation();

    if (bCancel & mnu.intv == null){
        mnu.active = false;
        return false;
    }
    else if (bCancel){
        mnu.cancel = true;
        mnu.mnuWin.parent.clearInterval(mnu.intv);
        mnu.intv = null;
        //now call to finish out our onclick event
        if (mnu.active == false){
            sapUrMapi_PopupMenu_scrollItem(sId, bDown);
        }
        mnu.active = false;
    }
    else{
        mnu.cancel = false;
		mnu.intv = mnu.mnuWin.parent.setInterval("sapUrMapi_PopupMenu_scrollItem('" + sId + "', '" + bDown + "')", mnu.delay);
    }
}

function sapUrMapi_PopupMenu_manualScroll(oWindow, sId, bDown, bCancel, e ){
    //assign our arguments to global variables
    mnu.mnuWin = oWindow;
    //mnu.mnuWin.event.cancelBubble = true;
	if (bCancel){
        mnu.cancel = true;
        mnu.mnuWin.parent.clearInterval(mnu.intv);
        mnu.intv = null;
        //now call to finish out our onclick event
        if (mnu.active == false){
            sapUrMapi_PopupMenu_scrollItem(sId, bDown);
        }
        mnu.active = false;
	}
	else{
    return false;
}
}

function sapUrMapi_PopupMenu_scrollItem(sId, bDown) {
    mnu.active = true;
    //find the menu wrapper and other elements
	var tbl = mnu.mnuWin.document.getElementById(sId+"-r");
    var tbody = tbl.childNodes.item(1);

    //get indexes and scroll
    var rIdx = tbl.getAttribute("visidx") - 0;
    var visCnt = tbl.getAttribute("viscnt") - 0;

    //change scroll direction
    if (bDown == "true"){
        if ((rIdx + visCnt) >= tbody.rows.length){
            mnu.cancel = true;
        }
        else{
			//tbody.rows[rIdx].style.display = "none";
			for (var i = 0; i < tbody.rows[rIdx].cells.length; i++){
				tbody.rows[rIdx].cells[i].style.display = "none";
			}
			//tbody.rows[rIdx + visCnt].style.display = "";
			for (var i = 0; i < tbody.rows[rIdx + visCnt].cells.length; i++){
				tbody.rows[rIdx + visCnt].cells[i].style.display = "";
			}
            ++rIdx;
            tbl.setAttribute("visidx", rIdx);
            mnu.cancel = false;
        }
    }
    else{
       if (rIdx <= 0){
           mnu.cancel = true;
       }
       else{
           //tbody.rows[rIdx + visCnt - 1].style.display = "none";
		   for (var i = 0; i < tbody.rows[rIdx + visCnt - 1].cells.length; i++){
				tbody.rows[rIdx + visCnt - 1].cells[i].style.display = "none";
		   }
           --rIdx;
		   //tbody.rows[rIdx].style.display = "";
		   for (var i = 0; i < tbody.rows[rIdx].cells.length; i++){
				tbody.rows[rIdx].cells[i].style.display = "";
		   }
           tbl.setAttribute("visidx", rIdx);
           mnu.cancel = false;
       }
    }
    //manage the timeout
    if(mnu.cancel){
        mnu.mnuWin.parent.clearInterval(mnu.intv);
        mnu.intv = null;
        return;
    }
    else{
       //toggle up menu
       if ((rIdx + visCnt - 0) >= tbody.rows.length){
           sapUrMapi_PopupMenu_setButtons(sId, true, false);
       }
       else{
           sapUrMapi_PopupMenu_setButtons(sId, true, true);
      }
       if (rIdx - 0 <= 0){
          sapUrMapi_PopupMenu_setButtons(sId, false, false);
	  }
       else{
          sapUrMapi_PopupMenu_setButtons(sId, false, true);
	  }
	}
}

function sapUrMapi_PopupMenu_setButtons( sId, bUp, bOn, oMenuWin ){
    var x;
    var node;
    (bUp)? x = 2 : x = 0;
		try {
			if (oMenuWin) {
			  node = oMenuWin.document.getElementById(sId+"-r").childNodes.item(x).childNodes.item(0).childNodes.item(0);
			} else {
	        if (mnu.mnuWin != null){
	         node = mnu.mnuWin.document.getElementById(sId+"-r").childNodes.item(x).childNodes.item(0).childNodes.item(0);
	        } else {
	         node = window.document.getElementById(sId+"-r").childNodes.item(x).childNodes.item(0).childNodes.item(0);
	        }
			}
			if (!bOn){
			  node.className = node.className.split("Dsbl")[0] + "Dsbl";
			} else {
		      node.className = node.className.split("Dsbl")[0];
			}
		}
		catch(e){
		}
}

function sapUrMapi_PopupMenu_setEvents(o,bExit) {
	if (o) {
//GPR
		var tbls = o.frame.window.document.getElementsByTagName("TABLE");
		for (var z = 0; z < tbls.length; z++){
			if (tbls[z].getAttribute("viscnt") != null){
				var tbl = tbls[z];
			}
		}
//GPR
//		var items=o.frame.window.document.getElementsByTagName("BODY").item(0).childNodes.item(0).childNodes.item(0).childNodes.item(1).childNodes;
		if (tbl.childNodes.item(1) != null){
		var items=tbl.childNodes.item(1).childNodes;
		}
		else{
		   var items=tbl.childNodes.item(0).childNodes;
		}
		o.frame.window.menuObject = sapUrMapi_PopupMenu(items);
		try {
		  o.frame.window.onkeydown=o.frame.window.document.getElementsByTagName("BODY").item(0).childNodes.item(0).childNodes.item(0).childNodes.item(0).onkeydown;
		} catch(ex) {}
		ur_focus(o.frame.window);
		itemsArray[o.frame.window.mylevel]=o.frame.window.menuObject;
		if (o.frame.window.mylevel>1) {
			sapUrMapi_PopupMenu_setItemActive(o.frame.window,subMenus[o.frame.window.mylevel].frame.window.menuObject.activeItem, "blank")
		} else {
	  	if (bExit==2){
		  	//sapUrMapi_PopupMenu_setItemActive(oPopup.frame.window,-1);
  } else {
			 if (oPopup == null && oDatePicker != null){
				sapUrMapi_PopupMenu_setItemActive(oDatePicker.frame.window,-1, "blank");
			 }
			 if (oPopup != null && oDatePicker == null){
				sapUrMapi_PopupMenu_setItemActive(oPopup.frame.window,-1, "blank");
			 }

		  }
		}
		if (bExit==1){
	    sapUrMapi_PopupMenu_setItemActive(o.frame.window,"first", "blank");
	  }
  }
}


function sapUrMapi_PopupMenuItem_setDisabled( sPopupMenuId, iIdx){
  var tbl = window.document.getElementById(sPopupMenuId+"-r");
	if (isNaN(iIdx)) { return; }
	var rows = tbl.childNodes.item(1).rows;
	rows(iIdx).className="urMnuRowDsbl";
	rows(iIdx).setAttribute("dsbl","true");
	rows(iIdx).cells(1).oldTitle=rows(iIdx).cells(1).title;
       //rows(iIdx).cells(1).title=getLanguageText("SAPUR_POPUP_ITEM_DISABLED_WHL",new Array(rows(iIdx).cells(1).innerText,"SAPUR_POPUP_ITEM_DISABLED"))
}

function sapUrMapi_PopupMenuItem_setEnabled( sPopupMenuId, iIdx){
  var tbl = window.document.getElementById(sPopupMenuId+"-r");
	if (isNaN(iIdx)) { return; }
	var rows = tbl.childNodes.item(1).rows;
	rows(iIdx).className="urMnuRowOff";
	rows(iIdx).setAttribute("dsbl","false");
	rows(iIdx).cells(1).title=rows(iIdx).cells(1).oldTitle;
}

function sapUrMapi_ToolbarButton_openMenu( sButtonId, e){
	var sPopupId=document.getElementById(sButtonId+"-r").getAttribute("popup");
	if ((e.type!="click")&&(e.type!="contextmenu")) {
		if (!sapUrMapi_checkKey(e,"keydown",new Array("32","40"))) {
	    e.cancelBubble=true;
	    e.returnValue=true;
		  return false;
		}
	}
	if (ur_system.direction=="rtl") {
	  sapUrMapi_PopupMenu_showMenu(sButtonId+"-r",sPopupId,sapPopupPositionBehavior.MENURIGHT,e);
	} else {
	  sapUrMapi_PopupMenu_showMenu(sButtonId+"-r",sPopupId,sapPopupPositionBehavior.MENULEFT,e);
	}
  e.cancelBubble=false;
	if ((e.type=="contextmenu")) {
    e.returnValue=false;
  } else {
    e.returnValue=true;
  }
}

function sapUrMapi_PopupMenu_selectItem(oWnd,sItemId,bChecked,oEvt) {
   oWnd.me.sapUrMapi_ToolbarButton_setFunctionFromMenuItem(sItemId);  
   oWnd.me.sapUrMapi_PopupMenu_hideAll();
   ur_EVT_cancel(oEvt);
}
// returns the popup menu js object 
function mf_PopupMenu_getObj(sId,hWnd) {
	//get the popupmenu on the page
	if (typeof(hWnd)=="undefined") hWnd=window;
	var o=hWnd.document.getElementById(sId);
	if (o.hasChildNodes() && o.firstChild.tagName=="XMP") {
	  o.innerHTML=o.firstChild.innerHTML; 
	}
	//not found or not an popup menu -> return
  if (o==null) return;
  if (hWnd._ur_POMN.all[sId]==null) {
    //create the object
		var oPMn={id:sId,
		          ref:o,
		          evtref:o.childNodes[0],
		          items:new Array(),
		          shown:false,
		          frame:null};
		var oRows=o.getElementsByTagName("TBODY")[0].getElementsByTagName("TR");
		var iIdx=0;
		for (var i=0;i<oRows.length;i++) {
			var bHasSep=false;
			var oSepRef=null;
			if (oRows[i].firstChild.className.indexOf("urMnuDvdr")>-1) {
				bHasSep=true; 
				oSepRef=oRows[i];
				i++;
			}
			var oRow=oRows[i];
			var sSt=ur_getAttD(oRow,"st","");
			var sAtt=ur_getAttD(oRow,"att","");
			var sSmnu=ur_getAttD(oRow,"smnu","");
			oPMn.items.push({ref:oRow,
			                 sepref:oSepRef,
			                 idx:iIdx,
			                 Id:oRow.id,
			                 Enabled:sSt.indexOf("d")==-1,
			                 HasSubMenu:sSmnu!="",
											 SubMenuId:sSmnu,
			                 HasSeparator:sAtt.indexOf("s")>-1,
			                 Text:ur_getAttD(oRow,"t",""),
			                 CanCheck:(sSt.indexOf("n")>-1 || sSt.indexOf("s")>-1),
			                 GroupId:ur_getAttD(oRow,"gid",""),
			                 Checked:sSt.indexOf("s")>-1,
			                 HasIcon:sAtt.indexOf("i")>-1,
			                 IsLink:sAtt.indexOf("l")>-1,
			                 EnabledIconSrc:ur_getAttD(oRow,"eis",""),
			                 DisabledIconSrc:ur_getAttD(oRow,"dis",""),
			                 HasEllipsis:sAtt.indexOf("e")>-1,
			                 POPUPMENUITEMSELECT:ur_getAttD(oRow,"ocl",""),
			                 POPUPMENUITEMLINKCLICK:ur_getAttD(oRow,"olc",""),
			                 Hovered:false,
			                 Hidden:false,
			                 Menu:oPMn});
			iIdx++;
		}
		hWnd._ur_POMN.all[sId]=oPMn;
	}
	return hWnd._ur_POMN.all[sId];
}

//returns the id of the element that triggered the last opened popupmenu
function mf_PopupMenu_getTriggerId() {
	return _ur_POMN_triggerId.split("-")[0];
}

//Popupmenu Object

function ur_PopupMenu_render(oPMn) {
  var oTBdy=oPMn.ref.getElementsByTagName("TBODY")[0];
  var oTable=oPMn.ref.getElementsByTagName("TABLE")[0];
  while (oTBdy.childNodes.length>0) oTBdy.removeChild(oTBdy.lastChild);
  for (var i=0;i<oPMn.items.length;i++) {
    var oItm=oPMn.items[i];
    var oH=document.createElement("TR");
    var oHTxtTd=document.createElement("TD");
    var oHTxtSpan=document.createElement("SPAN");
 
    var oHIcoTd=document.createElement("TD");
    var oHChkTd=document.createElement("TD");
    var oHTd=document.createElement("TD");
    var oHSubTd=document.createElement("TD");
    
    
    if (oItm.Enabled) oH.className="urMnuRowOff";
    else oH.className="urMnuRowDsbl";
    
    //handle the checked cell
    if (oItm.CanCheck) {
      if(oItm.GroupId!='')
        if (oItm.Checked) oHChkTd.className="urMnuChkRbgOn";
        else oHChkTd.className="urMnuChkRbg";
      else if (oItm.Checked) oHChkTd.className="urMnuChkOn";
      else oHChkTd.className="urMnuChk";
    } else {
     oHTxtTd.className="urMnuTxt";
    } 
    if (oItm.CanCheck) oHChkTd.innerHTML="&nbsp;&nbsp;&nbsp;";
    else oHChkTd.innerHTML="&nbsp;";

    //handle the icon cell
    if (oItm.HasIcon) {
      oHIcoTd.className="urMnuTxt";
      if (ur_system.direction=="RTL") oHIcoTd.style.paddingLeft="3px";
      else oHIcoTd.style.paddingRight="3px";
      oImg=document.createElement("IMG");
      if (oItm.Enabled) oImg.src=oItm.EnabledIconSrc;
      else oImg.src=oItm.DisabledIconSrc;		
      oImg.border="0";
      oHIcoTd.appendChild(oImg);
    } else {
      oHIcoTd.innerHTML="&nbsp;";
    }
    
    //handle the text
    var sEll="";
    if (oItm.HasEllipsis) sEll="\u2026";
    var oHTxt=document.createTextNode(oItm.Text+sEll);
    oHTxtTd.className="urMnuTxt";
    oHTxtTd.appendChild(oHTxtSpan);
    oHTxtSpan.style.whiteSpace="nowrap";
    
    
    //handle the submenu
    if (oItm.HasSubMenu) { oHSubTd.className="urMnuSubOn";oHSubTd.innerHTML="&nbsp;&nbsp;&nbsp;";
    } else {oHSubTd.className="urMnuSub";oHSubTd.innerHTML="&nbsp;";}
    
    //build tree
    oH.appendChild(oHChkTd);
    oH.appendChild(oHIcoTd);
    oH.appendChild(oHTxtTd);
    oH.appendChild(oHSubTd);
    oHTxtSpan.appendChild(oHTxt);
    if (oItm.HasSeparator) {
      var oHSep=document.createElement("TR");
      oHSep.setAttribute("class","urMnuRowOff");
      var oHSepTd=document.createElement("TD");
      oHSepTd.className="urMnuDvdr";
      oHSepTd.colSpan="4";
      var oHSepTmp=document.createElement("DIV")
      oHSepTmp.innerHTML="&nbsp;";
      oHSepTd.appendChild(oHSepTmp);
      oHSep.appendChild(oHSepTd);
	    oTBdy.appendChild(oHSep);
    }

    //set the id
    oH.setAttribute("id",oItm.Id);
    //set the custom attributes again
    var sAtt="";
    sAtt+=oItm.HasSeparator?"s":"";
    sAtt+=oItm.HasEllipsis?"e":"";
    sAtt+=oItm.HasIcon?"i":"";
    sAtt+=oItm.IsLink?"l":"";
    oH.setAttribute("att",sAtt);
    var sSt="";
    if (!oItm.Enabled) sSt+="d";
    if (oItm.CanCheck) {
      if (oItm.Checked) sSt+="s";
      else sSt+="n";
    } 
    oH.setAttribute("st",sSt);
    oH.setAttribute("ocl",oItm.POPUPMENUITEMSELECT);
    oH.setAttribute("olc",oItm.POPUPMENUITEMLINKCLICK);
    
    if (oItm.HasSubMenu && oItm.SubMenuId!='') oH.setAttribute("smnu",oItm.SubMenuId);
    oH.setAttribute("t",oItm.Text);
    if (oItm.HasIcon) {
      oH.setAttribute("eis",oItm.EnabledIconSrc);
      oH.setAttribute("dis",oItm.DisabledIconSrc);
    }
	  oTBdy.appendChild(oH);
  }
  //empty the object array and reinit
  var sId=oPMn.id;
  _ur_POMN.all[sId]=null;
  if (!initMenus)  initMenus=new Array();
  if (initMenus[sId]) initMenus[sId]=null;
  mf_PopupMenu_getObj(sId);
}

function mf_PopupMenu_addItem (oPMn,oItm) {
  oPMn.items[oPMn.items.length]=oItm;
}
function mf_PopupMenu_removeItem (oPMn,oItm) {
  var j=0;
  var items=new Array();
  for (var i=0;i<oPMn.items.length;i++) 
    if (oItm.Id!=oPMn.items[i].Id) items.push(oPMn.items[i]);
  oPMn.items=items
}

function mf_PopupMenu_replaceItem (oPMn,oOldItm,oNewItm) {
  var j=0;
  var oNewItems=new Array();
  for (var i=0;i<oPMn.items.length;i++) 
    if (oOldItm.Id==oPMn.items[i].Id) oPMn.items[i].Id=oNewItm;
}

function mf_PopupMenu_removeAllItems (oPMn) {
  oPMn.items=new Array();
  return oPMn;
}

function mf_PopupMenu_apply (oPMn) {
  ur_PopupMenu_render(oPMn);
}
function mf_PopupMenu_getItemById (oPMn,sItemId) {
  for (var i=0;i<oPMn.items.length;i++) 
    if (sItemId==oPMn.items[i].Id) return oPMn.items[i];
  return null;
}
function mf_PopupMenu_getItemByIdx (oPMn,iIdx) {
  return oPMn.items[iIdx];
}
function mf_PopupMenu_createItem (sId) {
  return {Id:sId,Enabled:true,HasSubMenu:false,SubMenuId:"",HasSeparator:false,Text:"",CanCheck:false,GroupId:"",Checked:false,HasIcon:false,EnabledIconSrc:"",DisabledIconSrc:"",HasEllipsis:false,TextDirection:"ltr",POPUPMENUITEMSELECT:"",POPUPMENUITEMLINKCLICK:"",Menu:null};
}

//default handler for all click events
function ur_PopupMenu_click(hWnd,sId,oEvt) {
  var oItm=ur_EVT_src(oEvt);
  while (ur_getAttD(oItm,"ocl","")=="" && ur_getAttD(oItm,"olc","")=="") {
    if (oItm.tagName=="BODY" || oItm.className=="urMnuDvdr") return;
	else oItm=oItm.parentNode;
  }
  if (ur_getAttD(oItm,"st","").indexOf("d")>-1) return
  if (ur_getAttD(oItm,"ocl","")!="")  ur_EVT_fire(oItm,"ocl",oEvt,hWnd);  //fire the item select event(oEvt) on oItm of the iframe
  if (ur_getAttD(oItm,"olc","")!="") ur_EVT_fire(oItm,"olc",oEvt,hWnd);	//fire the link click event(oEvt) on oItm of the iframe 
  ur_EVT_cancel(oEvt);
}

//default handler for keydown
function ur_PopupMenu_keydown(hWnd,sId,oEvt) {
	if (oEvt.keyCode==27) {
		if (hWnd.menuObject) {
			if (hWnd.mylevel>0) {
				for (var i=hWnd.mylevel+1;i<subMenus.length;i++) {
				  if (subMenus[i]!=null) subMenus[i].hide();
				}
				sapUrMapi_PopupMenu_setItemActive(hWnd,"closesub", sId);
			} else {
				oPopup.source.object.focus();
				hidePopupMenu();
			}
		}
		return;
	}
	if (oEvt.keyCode==40) { //down
	  var iIdx=hWnd.menu.activeItem.idx;
	  if (iIdx==hWnd.menu.items.length-1) iIdx=0;
	  else iIdx++;
	  var oItm=mf_PopupMenu_getItemByIdx(hWnd.menu,iIdx);
	  mf_PopupMenu_setItemDisplay(hWnd,oItm,"overkey",oEvt);
	  ur_EVT_cancel(oEvt);

	} else if (oEvt.keyCode==38) { //up
	  var iIdx=hWnd.menu.activeItem.idx;
	  if (iIdx==0) iIdx=hWnd.menu.items.length-1;
	  else iIdx--;
	  var oItm=mf_PopupMenu_getItemByIdx(hWnd.menu,iIdx);
	  mf_PopupMenu_setItemDisplay(hWnd,oItm,"overkey",oEvt);
	  ur_EVT_cancel(oEvt);

	} else if (oEvt.keyCode==39) { //right
	  if (ur_system.direction == "rtl") {
		  mf_PopupMenu_setItemDisplay(hWnd,hWnd.menu.activeItem,"closekey",oEvt);
	  } else {
		  mf_PopupMenu_setItemDisplay(hWnd,hWnd.menu.activeItem,"openkey",oEvt);
	  }

  } else if (oEvt.keyCode==37) { //left
	  if (ur_system.direction == "rtl") {
		  mf_PopupMenu_setItemDisplay(hWnd,hWnd.menu.activeItem,"closekey");
	  } else {
		  mf_PopupMenu_setItemDisplay(hWnd,hWnd.menu.activeItem,"closekey");
	  }
	} else if (oEvt.keyCode==13) { //return
		var item=hWnd.menuObject.items[hWnd.menuObject.activeItem];
    if (item.getAttribute("ocl")!=null && item.getAttribute("ocl")!="") ur_EVT_fire(item,"ocl",oEvt,hWnd);
    if (item.getAttribute("olc")!=null && item.getAttribute("olc")!="") ur_EVT_fire(item,"olc",oEvt,hWnd);
	} else if (oEvt.keyCode!=9) {
	  oEvt.cancelBubble=true;
	  oEvt.returnValue=false;
	} else {
		if (hWnd.menuObject) {
			hWnd.menuObject.out=true;
		}
		if(oPopup.source.object!=null) ur_focus(oPopup.source.object);
		hidePopupMenu();
	  oEvt.cancelBubble=false;
	  oEvt.returnValue=true;
	}
	return false;
}

function mf_PopupMenu_setScrollSettings(iFirstVisibleItem,iMaxVisibleItems) {
  var o=ur_get(sId+"-r");
  o.setAttribute("viscnt",iMaxVisibleItems);
  o.setAttribute("visidx",iFirstVisibleItem);
}

//Returns the UserData given to a PopupTrigger element if the control that opened the menu was a PopupTrigger. Otherwise the functin will return the id of the element that triggered the PopupMenu
function mf_PopupMenu_getTriggeredUserData() {
  var o=ur_get(_ur_POMN_triggerId);
  if (o && o.getAttribute && o.getAttribute("ud")) {
	  return ur_getAttD(o,"ud","");
  }
  return _ur_POMN_triggerId;
}
