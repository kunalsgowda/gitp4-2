//* ************************************************************************
//* Tray
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_RegisterCreate
//* parameter   : sId - string - Id of the Tray
//*				: bScroll - boolean - indicates whether the tray is scrollable
//*				: bCollapsed - boolean - indicates whether the tray is collapsed
//* description : Registers the tray with the create item registry to be
//*				  initialized when the page loads
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_RegisterCreate(sId, bScroll, bCollapsed) {
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_Tray_create('" + sId + "',"+bScroll+","+bCollapsed+")");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_create
//* parameter   : sId  - string - Id of the Tray
//* 			: bScroll - boolean - indicates weather the Tray is scrollable
//*  			: bCollapsed - boolean - indicates weather the Tray is collapsed
//* description : This is a dummy function to be implemented in the future.
//*               It is used in Netscape though
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_create(sId,bScroll,bCollapsed) {
  if (bCollapsed==true) {
    sapUrMapi_Tray_toggle(sId);
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_showOptionMenu
//* parameter   : sTrayId    - string - Id of the Tray
//  							sTriggerId - string - The Id of the DOM Objects that
//                                      is the trigger for the menu
//  							sMenuContentId - string- The Id of the DOM Objects that
//                                         contains the menu
//  							enumPositionBehavior - string- Defines at which position the PopupMenu
//																			 will appear. Default is Right
//							  e - EventObject - the events object
//* description : Opens the Menu that is applied as option menu to that tray.
//								There is an icon shown if a menu is connected to the tray
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_showOptionMenu2(sTrayId,sMenuContentId,oEvt) {
 	if (ur_system.direction=="rtl")
	  sapUrMapi_Tray_showOptionMenu(sTrayId,sTrayId+"-menu",sMenuContentId,sapPopupPositionBehavior.MENULEFT,oEvt) 
	else
	  sapUrMapi_Tray_showOptionMenu(sTrayId,sTrayId+"-menu",sMenuContentId,sapPopupPositionBehavior.MENURIGHT,oEvt) 
}
function sapUrMapi_Tray_showOptionMenu(idTray,idTrigger,idContent,pos,e) {
	if (e.type!="click") {
		if (!sapUrMapi_checkKey(e,"keydown",new Array("32","40"))) {
		  ur_EVT_cancel(e);
		  return false;
		}
	}
	sapUrMapi_PopupMenu_showMenu(idTrigger,idContent,pos,e);
}

//* ------------------------------------------------------------------------
//* function : sapUrMapi_Tray_toggle
//* parameter : sTrayId - string - Id of the Tray
// e - EventObject - the events object
//* description : Expand / Collapses the tray
//* return : none
//* sample :
//* Docu: Special Handling only for Mozilla, coz if we add a iframe inside a Tray and
//*		  try to do the expand collapse, The iframe still remained.
//* ------------------------------------------------------------------------

ur_trayBody=new Array();
ur_trayValues = new Array();
var tywd = -1;
var tyht = -1;

function sapUrMapi_Tray_toggle( idTray,e)
{
	sCtlType="SAPUR_TRAY";
	if(typeof(e)!="undefined")
	{
		if ((e.type!="click") && (!sapUrMapi_checkKey(e,"keydown",new Array("32","30","107","109")))) return false;
		ur_EVT_cancelBubble(e);
	}
	var elBody = ur_get(idTray+"-tbd");
	var sTitle = ur_get(idTray+"-hd");
	var elExpander = ur_get(idTray+"-exp");
	var elHeader = ur_get(idTray+"-hd");
	var oSkip=ur_get(idTray);
	var elExpandState = ur_get(idTray+"-es");
	if (elBody.getAttribute("col") == 1)
	{

		elBody.removeAttribute('style');
		elBody.style.visibility="static";
		elBody.style.height=tyht;
		elBody.style.width=tywd;
		elBody.setAttribute("col","0");
		ur_get(idTray+"-bd").style.display ="block"; 
		ur_trayBody[idTray]=null;

		if ( elExpander.className.indexOf("Closed") != -1)

		{

			var re = /Closed/gi;
			var clsNm = elExpander.className;
			elExpander.className = clsNm.replace(re, "Open");
			ur_setSt(oSkip,ur_st.COLLAPSED,true);
			ur_setSt(oSkip,ur_st.EXPANDED,false);

		}
		if ( elHeader.className == "urTrcHdBgClosedIco" )
			elHeader.className = "urTrcHdBgOpenIco";
		if ( elExpandState )
			elExpandState.value = "1";
		if (ur_system.is508)
		{
			elExpander.title=getLanguageText("SAPUR_TY_BTNE");
		} 
		else
		{
			elExpander.title=getLanguageText("SAPUR_TY_BTNE");		
		}

	}
	else
	{

		ur_trayBody[idTray]=elBody.innerHTML;
		ur_Tray_CollectValues(elBody);
		// Try to get the width and height offset of the content inside. and reset it when you expand the Tray.
		if(tywd == -1)
		tywd =elBody.offsetWidth;
		if(tyht == -1)
		tyht = elBody.offsetHeight;
		elBody.style.position ="absolute";
		elBody.style.overflow="hidden";
		ur_get(idTray+"-bd")
		elBody.style.visibility="hidden";
	
		elBody.style.height= "0px"; //the old value of -2000px causes issues in firefox. To be save add top and left -9000
		elBody.style.width= "0px";
		elBody.style.top= "-9000px";
		elBody.style.left= "-9000px";			
		
		elBody.setAttribute("col","1");
		ur_get(idTray+"-bd").style.display ="none";

		if ( elExpander.className.indexOf("Open") != -1)
		{
			var re = /Open/gi;
			var clsNm = elExpander.className;
			elExpander.className = clsNm.replace(re, "Closed");
			ur_setSt(oSkip,ur_st.COLLAPSED,false);
			ur_setSt(oSkip,ur_st.EXPANDED,true);
		}
			if ( elHeader.className == "urTrcHdBgOpenIco" )
				elHeader.className = "urTrcHdBgClosedIco";
			if ( elExpandState )
				elExpandState.value = "0";
			if (ur_system.is508)
			{
				elExpander.title=getLanguageText("SAPUR_TY_BTNC");
			}
			else
			{
				elExpander.title=getLanguageText("SAPUR_TY_BTNC");		
			}
	  }
          return true;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_keydown
//* parameter   : sTrayId - Id of the Tray using keydown
//*							e - event object
//* return      : true if keydown was successful
//*	description	: The keydown event is captured and checked for skipping and toggle events.
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_keydown(sTrayId,e)
{
/*	var elBody = ur_get(sTrayId+"-tbd"); //tray body
	var elHeader = ur_get(sTrayId+"-hd");
	var oSkip=document.getElementById(sTrayId);
	// numpad +: expand tray 
	if(e.keyCode==107)
	 {
		sapUrMapi_Tray_toggle(sTrayId,e);
		oSkip.fireEvent("onactivate");
		return true;
	 }
	 // numpad -: collapse tray
	 else  if(e.keyCode==109)
	 {
		 sapUrMapi_Tray_toggle(sTrayId,e);
		 oSkip.fireEvent("onactivate");
		 return true;
	 }
	 else
		return sapUrMapi_skip(sTrayId,e);	*/
     
}






//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_keydown
//* parameter   : sTrayId - Id of the Tray using keydown
//*							e - event object
//* return      : true if keydown was successful
//*	description	: The keydown event is captured and checked for skipping and toggle events.
//* ------------------------------------------------------------------------
/*function sapUrMapi_Tray_keydown(sTrayId,e)
{

 if(e.keyCode==107)
 {
	sCtlType="SAPUR_TRAY";
	ur_EVT_cancelBubble(e);
	var elBody = ur_get(sTrayId+"-tbd"); //tray body
	var sTitle = ur_get(sTrayId+"-hd");
	var elHeader = ur_get(sTrayId+"-hd");
	var oSkip=document.getElementById(sTrayId);
	var elExp = ur_get(sTrayId+"-exp"); //the expander icons domobject
	if ( elBody != null && elExp != null )
	{
		if ( elBody.style.display == "none" )
		{
			elBody.style.display = "block";
            
			if (elExp.className.indexOf("Closed") != -1)
			{
				var re = /Closed/gi;
				var clsNm = elExp.className;
				//unselect step cell and it's text
				elExp.className = clsNm.replace(re, "Open");
				//elExp.className = "urTrcExpOpenIco";
			}
			if (elHeader.className == "urTrcHdBgClosedIco" )	elHeader.className = "urTrcHdBgOpenIco";
			if (ur_system.is508)
			{
				if (oSkip.getAttribute("ot")==null || oSkip.getAttribute("ot")=="")
				{
				  oSkip.title=getLanguageText("SAPUR_TRAY_WHL",new Array(oSkip.getAttribute("ttl"),"SAPUR_TRAY","SAPUR_EXPANDED","SAPUR_SKIPSTART","SAPUR_ENTERTAB"));
				  
				} 
				else
				{
				  oSkip.title=getLanguageText("SAPUR_TRAY_WHL",new Array(oSkip.getAttribute("ttl"),"SAPUR_TRAY","SAPUR_EXPANDED","SAPUR_SKIPSTART","SAPUR_ENTERTAB"));
				}
				elExp.title=getLanguageText(sCtlType + "_COLLAPSE_ACC");
			} 
			else
			{
				elExp.title=getLanguageText(sCtlType + "_COLLAPSE");
			}
		} 
		sapUrMapi_focusElement(elExp);
	}
	return true;
 }
 else  if(e.keyCode==109)
 {
	sCtlType="SAPUR_TRAY";
	ur_EVT_cancelBubble(e);
	var elBody = ur_get(sTrayId+"-tbd"); //tray body
	var sTitle = ur_get(sTrayId+"-hd");
	var elHeader = ur_get(sTrayId+"-hd");
	var oSkip=document.getElementById(sTrayId);
	var elExp = ur_get(sTrayId+"-exp"); //the expander icons domobject
	elBody.style.display = "none";
	ur_setSt(oSkip,ur_st.COLLAPSED,true);
	ur_setSt(oSkip,ur_st.EXPANDED,false);
	if (elExp.className.indexOf("Open") != -1)
	{
		var re = /Open/gi;
		var clsNm = elExp.className;
		elExp.className = clsNm.replace(re, "Closed");
	}
	if (elHeader.className == "urTrcHdBgOpenIco" ) elHeader.className = "urTrcHdBgClosedIco";
	if (ur_system.is508) 
	{
		if (oSkip.getAttribute("ot")==null || oSkip.getAttribute("ot")=="")
		{
			oSkip.title=getLanguageText("SAPUR_TRAY_WHL",new Array(oSkip.getAttribute("ttl"),"SAPUR_TRAY","SAPUR_COLLAPSED","SAPUR_SKIPSTART","SAPUR_ENTERTAB"));
		} 
		else
		{
		   oSkip.title=getLanguageText("SAPUR_TRAY_WHL",new Array(oSkip.getAttribute("ttl"),"SAPUR_TRAY","SAPUR_COLLAPSED","SAPUR_SKIPSTART","SAPUR_ENTERTAB"));
		}
		elExp.title=getLanguageText(sCtlType + "_EXPAND_ACC");
	} 
	else 
	{
		elExp.title=getLanguageText(sCtlType + "_EXPAND");
	}
    sapUrMapi_focusElement(elExp);
    return true;
}
else
    return sapUrMapi_skip(sTrayId,e);	

}*/

function ur_Tray_restoreValues(obj)
{
	
	var oInpColl = obj.getElementsByTagName("INPUT");
	var oTaColl = obj.getElementsByTagName("textarea");
	 for(i=0 ; i<oInpColl.length;i++)
    {	
		if(oInpColl[i].getAttribute("id"))
		oInpColl[i].value = ur_trayValues[oInpColl[i].getAttribute("id")] ;
		
    }
    for(i=0 ; i<oTaColl.length;i++)
    {
		if(oTaColl[i].getAttribute("id")){
		var sId = oTaColl[i].getAttribute("id");
		oTaColl[i].value = ur_trayValues[sId]  ;
		}
    }
}
function ur_Tray_CollectValues(obj)
{
	var oInpColl = obj.getElementsByTagName("INPUT");
	var oTaColl = obj.getElementsByTagName("textarea");
	
    for(i=0 ; i<oInpColl.length;i++)
    {	
		if(oInpColl[i].getAttribute("id"))
		ur_trayValues[oInpColl[i].getAttribute("id")] = oInpColl[i].value;
		
    }
    
    for(i=0 ; i<oTaColl.length;i++)
    {
		if(oTaColl[i].getAttribute("id")){
		var sId = oTaColl[i].getAttribute("id");
		ur_trayValues[sId] = oTaColl[i].value;
		}
    }
    
}
