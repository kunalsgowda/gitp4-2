//* ************************************************************************
//* DateNavigator
//* ************************************************************************
//* PUBLIC FUNCTIONS
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_DateNavigator_keydown
//* parameter   : sId  - Id of the DateNavigator control
//*								oEvt - event object
//* return      :
//* description	: 
//* ------------------------------------------------------------------------
function sapUrMapi_DateNavigator_keydown(sId,oEvt) {}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_DateNavigator_mousemove
//* parameter   : sId  - Id of the DateNavigator control
//*								oEvt - event object
//* return      :
//* description	: 
//* ------------------------------------------------------------------------
function sapUrMapi_DateNavigator_mousemove(sId,oEvt) {}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_DateNavigator_activate
//* parameter   : sId  - Id of the DateNavigator control
//*								oEvt - event object
//* return      :
//* description	: sets the 508 tooltip for days	and month
//* ------------------------------------------------------------------------
function sapUrMapi_DateNavigator_activate(sId,oEvt){}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_DateNavigator_getDateFromId
//* parameter   : sId  - Id of the DateNavigator control
//* return      :
//* description	: 
//* ------------------------------------------------------------------------
function sapUrMapi_DateNavigator_getDateFromId(sId){}
