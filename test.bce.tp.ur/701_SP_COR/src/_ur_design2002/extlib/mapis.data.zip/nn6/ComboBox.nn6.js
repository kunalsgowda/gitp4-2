
//* ************************************************************************
//* ComboBox
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : ur_ComboBox_fireBeforeListLoad
//* parameter   : sId			- id of the ComboBox control
//*								sListId - id of the associated ItemListBox control
//*								oEvt    - event object
//* return      : true if event is fired
//* description	: fire the obbll (onbeforelistload) event to update the list
//*								before it is used
//* ------------------------------------------------------------------------
function ur_ComboBox_fireBeforeListLoad(sId,sListId,oEvt){
	var o=sapUrMapi_ComboBox_getObject(sId);
  var sFunc=o.main.getAttribute("onbll");	
  if(sFunc && sFunc.indexOf("UR_NotHandled")<0){
		o.main.fBefListLoad = new Function("event",sFunc);
		o.main.fBefListLoad(oEvt);
  }
  else return false;
  return true;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_getObject
//* parameter   : sId - id of the combo box control
//* return      : combo box object
//* description	: create an JS Object for the combo box control
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_getObject(sId) {
	var o=new Object();
	var sLblFor="";
	o.main=ur_get(sId+"-r");
	o.txt=ur_get(sId);
	o.isdd=o.txt.getAttribute("tp")=="DD";
	o.isro=ur_isSt(sId,ur_st.READONLY);
	o.isdsbl=ur_isSt(sId,ur_st.DISABLED);
	o.isinv=ur_isSt(sId,ur_st.INVALID);
	o.isreq=ur_isSt(sId,ur_st.REQUIRED);	
	o.key=o.txt.getAttribute("k");
	o.vt=o.txt.getAttribute("vt")=="true";
	o.lid=o.txt.getAttribute("lid");
	o.open=o.txt.getAttribute("op")=="true";
	sLblFor=o.txt.getAttribute("f");
	if(sLblFor!=null && sLblFor!="")
		o.lblFor=ur_get(sLblFor);
	else
		o.lblFor=null;
	return o;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_registerCreate
//* parameter   : sId     - id of the combo box control
//*								sListId - item listbox id
//*								sWidth  - width 
//* return      : 
//* description	: set initial width of the combo box
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_registerCreate(sId,sListId,sWidth){
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_ComboBox_setWidth('"+sId+"','"+sListId+"','"+sWidth+"')");
}

var aCoB=new Array();
var aCoBWidth=new Array();
function sapUrMapi_ComboBox_setWidth(sId,sListId,sWidth){
	if(sWidth!="") return;
	var o=ur_get(sId);
	var oL=ur_get(sListId+"-r");
	if(oL==null) return;
	sapUrMapi_ItemListBox_setDim( sListId, "10px" );
	aCoB[aCoB.length]=o;
	oL=ur_get(sListId);
	aCoBWidth[aCoBWidth.length]=oL.firstChild.offsetWidth;
	sapUrMapi_Create_AddItem("CoB", "sapUrMapi_ComboBox_set()",true);
}

function sapUrMapi_ComboBox_set(){
	for(var i=0; i<aCoB.length; i++)
		if(aCoB[i]!=null && typeof(aCoB[i])=="object")
		aCoB[i].style.width=parseInt(aCoBWidth[i]);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_addClass
//* parameter   : sId			- id of the combo box control
//*							: sClass  - classname to set
//*							: bSetIt  - whether set it or remove it
//* return      : none
//*	description	: add or removes selected style class sClass from the combo box
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_addClass(sId,sClass,bSetIt) {
  var o=sapUrMapi_ComboBox_getObject(sId);
  var bInTbl=o.main.parentNode.className.indexOf("STTD")>=0;
  
	if (o.txt.className.indexOf(sClass)==-1 && bSetIt){
		o.txt.className=o.txt.className+" "+sClass; 
		if(bInTbl) o.main.className=o.main.className+" "+sClass;
	}
	else if(o.txt.className.indexOf(sClass)>=0 && !bSetIt){
		o.txt.className=o.txt.className.replace(" "+sClass,"");
		if(bInTbl) o.main.className=o.main.className.replace(" "+sClass,"");
	}
	return o;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_mousedown
//* parameter   : sId - id of the combo box control
//*							: e   - event Object
//* return      : none
//*	description	: prevent a combo box from blur if you click on the button
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_mousedown(sId,e) {
	var o=sapUrMapi_ComboBox_getObject(sId);
	if(e.button!=0 && o.open) return;
  o.txt.setAttribute("noblur","true");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_click
//* parameter   : sId - id of the combo box control
//*							: e   - event Object
//* return      : none
//*	description	: open list
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_click(sId,e) {
	var o=sapUrMapi_ComboBox_getObject(sId);
	if (o.isdsbl) return;
	if (o.isdd || e.type=="keydown" || ur_EVT_src(e).className.indexOf("urCoB2Btn")>=0) {
	  if (!o.open) 
			sapUrMapi_ComboBox_showList(sId,e);
		else{
			sapUrMapi_ComboBox_hideList(sId);
			if(o.isdd) sapUrMapi_ComboBox_addClass(sId,"urCoB2Hv",true);			
		}
		if(ur_EVT_src(e).className.indexOf("urCoB2Btn")>=0) 
			ur_focus(o.txt);
  }
  o.txt.setAttribute("noblur","false");
  return ur_EVT_cancel(e);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_focusDdlb
//* parameter   : sId - id of the combo box control
//*							: e   - event Object
//* return      : none
//*	description	: set the focus visualization in case the combo box is run with behavior
//*								dropdownselect
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_focusDdlb(sId,e) { 
	var o=sapUrMapi_ComboBox_getObject(sId);
	if (!o.open) sapUrMapi_DataTip_show(sId,"focus");
	if (o.isdsbl) return;
	o.txt.setAttribute("noblur","false");
	if(!o.isdd) return;
	if (o.open) sapUrMapi_ComboBox_addClass(sId,"urCoB2Hv",false);
	else sapUrMapi_ComboBox_addClass(sId,"urCoB2Hv",true);
	ur_setEditCellColor(o.txt);
	return ur_EVT_cancel(e);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_prepareFireSelectionChange
//* parameter   : o    - combobox object
//*							: oEvt - event object
//* return      : none
//*	description	: prepare fire selection change event 
//* ------------------------------------------------------------------------
var oComboBoxSCTimer=null;
var oComboBoxSCEvent=null;
function sapUrMapi_ComboBox_prepareFireSelectionChange(o, oEvt){
	/* check if key or value has changed */
  if(o.txt.getAttribute("ks")==o.txt.getAttribute("k") && o.txt.getAttribute("vs")==o.txt.value) 
		return;
  
  /* return if the list is open and you navigate within the list */
   if((oEvt.type=="keydown" || oEvt.type=="keypress") && o.open && oEvt.keyCode!=13) 
		return;
		
	/* save event, necessary for timeout call */
	oComboBoxSCEvent = oEvt;
	
	/* fire selection change event directly if you click on an item
	   or if you press enter */
	if(oComboBoxSCTimer) clearTimeout(oComboBoxSCTimer);  
  if(oEvt.type=="blur" || oEvt.type=="click" || oEvt.keyCode==13) { 
		sapUrMapiComboBox_fireSelectionChange(o, oEvt);
	}
	/* fire selection change event delayed,clear previously fired selection change events before */
	else{	
			var sId=o.txt.id;
    	oComboBoxSCTimer=setTimeout("sapUrMapiComboBox_fireSelectionChange(\""+sId+"\")",500);  	                 
    }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapiComboBox_fireSelectionChange
//* parameter   : o    - combobox object
//*							: oEvt - event object
//* return      : none
//* description	: fire change event 
//* ------------------------------------------------------------------------
function sapUrMapiComboBox_fireSelectionChange(o, oEvt){
	/* get combo boxobject if id is passed */
	if(typeof(o)=="string"){
		o=sapUrMapi_ComboBox_getObject(o);
	}

	/* update label text if the combo boxis used as label for an other control */
	if(o.lblFor!=null){
		o.lblFor.setAttribute("lbl",o.txt.value);	
  }
  
  /* update saved values */
  o.txt.setAttribute("vs",o.txt.value);
  o.txt.setAttribute("ks",o.txt.getAttribute("k"));
    
  /* fire change event */
  var sFunc=o.main.getAttribute("onsc");
  if(sFunc){
		o.main.fSelCh = new Function("event",sFunc);
		o.main.fSelCh(oComboBoxSCEvent);
  }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_blurDdlb
//* parameter   : sId - id of the combo box control
//*							: e   - event Object
//* return      : none
//*	description	: hide list
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_blurDdlb(sId,e) { 
	var o=sapUrMapi_ComboBox_getObject(sId);
	ur_removeEditCellColor();
	// check if you really left the combo box or if the button or popup is active
	if (o.isdsbl) {sapUrMapi_DataTip_hide(sId);return;}
	if(o.txt.getAttribute("noblur")=="true" || (oPopup!=null && oPopup.frame.window.mover && o.open)){
		o.txt.setAttribute("noblur","false");
		ur_focus(o.txt);
		return ur_EVT_cancel(e);
	}
	// hide list and clear selection color
	if (o.isdd) sapUrMapi_ComboBox_addClass(sId,"urCoB2Hv",false);
	if (oPopup!=null && o.open) sapUrMapi_ComboBox_hideList(sId);
	if (oPopup!=null && !o.open) sapUrMapi_DataTip_hide(sId);
	sapUrMapi_ComboBox_prepareFireSelectionChange(o,e);
	return ur_EVT_cancel(e);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_setReadonly
//* parameter   : sId       - id of the combo box control
//*							: bReadonly - set readonly state or remove it
//* return      : none
//*	description	: set the readonly state of a combo box
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_setReadonly(sId,bReadonly) {
  var o=ur_get(sId);
  if(bReadonly && ur_isSt(o,ur_st.READONLY)) return;
  ur_setSt(o,ur_st.READONLY,bReadonly);
  if(bReadonly)
		o.className+=" urCoB2Ro";
	else
		o.className=o.className.replace(" urCoB2Ro","");
  o.readOnly=bReadonly;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_setDisabled
//* parameter   : sId		- id of the combo box control
//*							: bSet	- true:		set disabled state
//*												false:	reset disabled state 
//* return      : none
//*	description	: set or reset disabled state
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_setDisabled(sId,bSet) {
  var o=ur_get(sId);
  var oBtn=o.nextSibling;
  if(bSet && ur_isSt(o,ur_st.DISABLED)) return;
  ur_setSt(o,ur_st.DISABLED,bSet);
  if(bSet){
		o.className+=" urCoB2Dsbl";
		oBtn.className="urCoB2BtnDsbl";
	}
	else{
		o.className=o.className.replace(" urCoB2Dsbl","");
		oBtn.className="urCoB2Btn";
	}
  o.readOnly=bSet;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_setInvalid
//* parameter   : sId      - id of the combo box control
//*							: bInvalid - set invalid state or remove it
//* return      : none
//*	description	: set the readonly state of a combo box
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_setInvalid(sId,bInvalid) {
  var o=ur_get(sId);
  if(bInvalid && ur_isSt(o,ur_st.INVALID)) return;
  ur_setSt(o,ur_st.INVALID,bInvalid);
  if(bInvalid)
		o.className+=" urCoB2Inv";
	else
		o.className=o.className.replace(" urCoB2Inv","");
}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_keydown
//* parameter   : sId - id of the combo box control
//*							: e   - event Object
//* return      : none
//*	description	: handle keydown events
//* ------------------------------------------------------------------------
var sUrComboBox_virtualTyping="";
function sapUrMapi_ComboBox_keydown(sId,e) {
	var o=sapUrMapi_ComboBox_getObject(sId);

	// return if disabled
	if (o.isdsbl) return;
	
	// handle tab
	if (e.keyCode==9) {
		if(o.open) sapUrMapi_ItemListBox_selectHoveredItem(o.lid, oPopup.frame.window.document,e);
		if (o.isdd) sapUrMapi_ComboBox_addClass(sId,"urCoB2Hv",false);
		if (oPopup!=null && o.open) sapUrMapi_ComboBox_hideList(sId);
		return;
	}
	
	// alt+arrow up/down or f4 => open or close the list
	if( (e.altKey && (e.keyCode==40||e.keyCode==38)) || e.keyCode==115 ){
		sapUrMapi_ComboBox_click(sId,e);
		return ur_EVT_cancel(e);
	}
	
	// handle arrow up & down, page up & down, end & home
	if(e.keyCode==40 || e.keyCode==38 || e.keyCode==33 || e.keyCode==34 || e.keyCode==35 || e.keyCode==36){
		if(o.open) sapUrMapi_ItemListBox_keydown(o.lid, oPopup.frame.window.document, e );
		else{
			// fire onbll (onbeforelistload) event
			if(ur_ComboBox_fireBeforeListLoad(sId,o.lid,e))
				return ur_EVT_cancel(e);
			sapUrMapi_ItemListBox_setParentId(o.lid, sId);
			sapUrMapi_ItemListBox_setSelectedKey(o.lid,o.key,document,false);
			sapUrMapi_ItemListBox_keydown(o.lid, document, e );
		}		
		return ur_EVT_cancel(e);
	}
	
	// handle escape
  if (e.keyCode==27 && o.open) { 
		o.txt.value=o.txt.getAttribute("vs");
		o.txt.setAttribute("k",o.txt.getAttribute("ks"));
  	sapUrMapi_ComboBox_hideList(sId);
  	sapUrMapi_ComboBox_focusDdlb(sId,e);
  	return ur_EVT_cancel(e);
  }
  else if (e.keyCode==27 && !o.open) 
		sapUrMapi_DataTip_hide(sId);
  
  // handle enter
  if (e.keyCode==13 && o.open) { 
		sapUrMapi_ItemListBox_selectHoveredItem(o.lid, oPopup.frame.window.document,e);
  	sapUrMapi_ComboBox_hideList(sId);
  	o.open=false;
  	return ur_EVT_cancel(e);
  }
  else if (e.keyCode==13 && !o.isdd){
    	if(!sapUrMapi_ComboBox_findItem(sId,o.txt.value,true,e))
    		sapUrMapi_ComboBox_prepareFireSelectionChange(o, e);
  }  
  // any key => find item if dropdown, clear key if combo 
  	if ((e.keyCode>64 && e.keyCode<126)||(e.keyCode>127 && e.keyCode<192)) {
		if (o.isdd){
	  	if (o.vt) sapUrMapi_ComboBox_initVirtualTyping();
	  	var sSearch=String.fromCharCode(e.keyCode);
	  	if (!o.vt) sUrComboBox_virtualTyping=sSearch;
			else sUrComboBox_virtualTyping+=sSearch;
	  	sapUrMapi_ComboBox_findItem(sId,sUrComboBox_virtualTyping,true,e);
	  	if(o.open){
	  		o=sapUrMapi_ComboBox_getObject(sId);
	  		sapUrMapi_ItemListBox_setSelectedKey(o.lid,o.key,oPopup.frame.window.document,true);
	  	}	  	
	 	}
		else{
				o.txt.setAttribute("k","");
	  	}
		}
	}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_keypress
//* parameter   : sId - id of the combo box control
//*							: e   - event Object
//* return      : none
//*	description	: handle keypress events
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_keypress(sId,e) {
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_initVirtualTyping
//* parameter   : none
//*								none
//*	description	: initialize a timer that waits for 250ms for keydowns on the
//*               combobox. this is only called if allowvirtualtyping=true
//* ------------------------------------------------------------------------
var oVTTimer=null;
function sapUrMapi_ComboBox_initVirtualTyping() {
  if (oVTTimer!=null) clearTimeout(oVTTimer); //there was a keydown in the timetrame 250ms now clear the old and wait for another one.
 	oVTTimer=ur_callDelayed("sUrComboBox_virtualTyping='';clearTimeout(oVTTimer);oVTTimer=null;",250);
 }

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_findItem
//* parameter   : sId - string - Id of the combo box control
//*							: sSearch - string  - search items with this string
//* return      : true if an item was found else false
//*	description	: search sSearch in the ItemListBox connected to the combobox
//*               via its id and selects first maching item
//*               if allowvirtualtyping is true (waits 250ms for next keypress)
//*               otherwise the next matching item is selected
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_findItem(sId,sSearch,bSelect,oEvt) {
	var o=sapUrMapi_ComboBox_getObject(sId);
	var sKey=o.txt.getAttribute("k");
	var sNewKey = sapUrMapi_ItemListBox_findItem(o.lid,sSearch,sKey,document);
  if (bSelect && sNewKey && sNewKey != "")
		sapUrMapi_ComboBox_setValue(sId,sNewKey,sVal,null,oEvt);	
	return true;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_showList
//* parameter   : sId - string - Id of the combo box control
//* return      : none
//*	description	: shows the lsit of the combobox
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_showList(sId,oEvt) {
	var o=sapUrMapi_ComboBox_getObject(sId);
	var oIlb;
	var arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");

	// fire onbll (onbeforelistload) event
	if(ur_ComboBox_fireBeforeListLoad(sId,o.lid,oEvt))
		return ur_EVT_cancel(oEvt);

	o.open=o.txt.setAttribute("op","true");
  if (o.isdd) sapUrMapi_ComboBox_addClass(sId,"urCoB2Hv",false);
  	
	//clear timeout for DataTip
	clearTimeout(_ur_DataTip_timer);
	
	// open popup
	sapUrMapi_ItemListBox_setParentId(o.lid, sId);	
	oIlb=sapUrMapi_ItemListBox_getObject(o.lid,document,null);
	sapUrMapi_ItemListBox_setDim(o.lid, o.main.offsetWidth);
	sapUrMapi_ItemListBox_setSelectedKey(o.lid,o.key,document,false);
	sapUrMapi_ItemListBox_setReadonly(oIlb,o.isro);	
	oPopup = new sapPopup(window,arrUrls,ur_get(o.lid+"-r"),ur_get(sId),oEvt,0);
	oPopup.size.height=oIlb.box.offsetHeight;
	oPopup.size.width=oIlb.box.offsetWidth;
	oPopup.sizebehaviour=sapPopupSizeBehavior.USER
	if (ur_system.direction=="rtl") oPopup.positionbehavior = sapPopupPositionBehavior.MENURIGHT;
	else sapPopupPositionBehavior.MENULEFT;	
	oPopup.show(true,true);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_hideList
//* parameter   : sId - string - Id of the combo box control
//* return      : none
//*	description	: hide the list of the combobox
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_hideList(sId) {
  var o=sapUrMapi_ComboBox_getObject(sId);
	o.txt.setAttribute("op","false");
	o.txt.setAttribute("noblur","false");
	if (oPopup) oPopup.hide();
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_setValue
//* parameter   : sId      - string - Id of the combo box control
//*							  sKey     - string - unique key of new selected item
//*							  sValue   - string - value of new selected item that is displayed
//*							  sImgSrc  - string - (optional) url to an image;
//* return      : none
//*	description	: set a new value to the combo box
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_setValue(sId,sKey,sValue,sImgSrc,oEvt) {
  var o = sapUrMapi_ComboBox_getObject(sId);

  if(!o.isro && !o.isdsbl && sKey!=null && (o.txt.ks!=sKey || o.txt.k!=sKey)){
		// update key, value and icon
			o.txt.setAttribute("k",sKey);
			o.txt.value=sValue;
			if (sImgSrc!="" && sImgSrc!=null)
  			if (sImgSrc.indexOf("url(")!=0 && sImgSrc.length>0) o.txt.style.backgroundImage="url("+sImgSrc+")";
  			else o.txt.style.backgroundImage=sImgSrc;
		// fire selection change event
		sapUrMapi_ComboBox_prepareFireSelectionChange(o,oEvt);
  }
  
  // focus combo box if necessary
  if (oEvt!=null && oEvt.type=="click"){
		sapUrMapi_ComboBox_hideList(sId);
		ur_focus(o.txt);
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_getSelectedKey
//* parameter   : sId      - id of the combo box control
//* return      : selected key
//*	description	: return the selected key of the cb
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_getSelectedKey(sId) {
  var o=sapUrMapi_ComboBox_getObject(sId);
  return o.txt.getAttribute("k");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ComboBox_getSelectedValue
//* parameter   : sId      - id of the combo box control
//* return      : selected value
//*	description	: returns the selected value of the cb
//* ------------------------------------------------------------------------
function sapUrMapi_ComboBox_getSelectedValue(sId) {
  var o=sapUrMapi_ComboBox_getObject(sId);
	return o.txt.value;
}
