//* ************************************************************************
//* CheckBox
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_toggle
//* parameter   : sId - Id of the checkbox
//*								e   - event object
//* return      : true if the checkbox was toggled, else false
//*	description	: select/deselect checkbox if not disabled or read only
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_toggle(sId,e) {
  var oIn=ur_get(sId);
 if ( ur_isSt(oIn,ur_st.READONLY) || ur_isSt(oIn,ur_st.DISABLED) ) return false;  
  var oLbl=ur_get(sId+"-lbl");
 var oImg=ur_get(sId+"-img");
	// focus the real, hidden checkbox control 
  ur_focus(oIn);
  // checkbox is selected => deselect checkbox 
	if(ur_isSt(oIn,ur_st.SELECTED)){
		oIn.checked=false;
		ur_setSt(oIn,ur_st.SELECTED,false);
		ur_setSt(oIn,ur_st.NOTSELECTED,true);
		oImg.className=oImg.className.replace("On","Off");
  }
  // checkbox is not selected => select checkbox 
	else{
		oIn.checked=true;
		ur_setSt(oIn,ur_st.NOTSELECTED,false);
		ur_setSt(oIn,ur_st.SELECTED,true);
		oImg.className=oImg.className.replace("Off","On");
	}
	return true;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_setDisabled
//* parameter   : sId - Id of the checkbox
//*	description	: sets an disabled checkbox to enabled and also the connected
//								label
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_setDisabled(sId) {
  var oIn=ur_get(sId);
	var oLbl=ur_get(sId+"-lbl");
	var oImg=ur_get(sId+"-img");
	if(ur_isSt(oIn,ur_st.DISABLED)) return;
	if(ur_isSt(oIn,ur_st.READONLY)){
		oImg.className=oImg.className.replace("Dsbl","");
		ur_setSt(sId,ur_st.READONLY,false);
	}
	oLbl.className=oLbl.className.replace("Lbl","LblDsbl");
  if(ur_isSt(oIn,ur_st.SELECTED))
		oImg.className=oImg.className.replace("On","OnDsbl");
	else if(ur_isSt(oIn,ur_st.UNDEFINED))
		oImg.className=oImg.className.replace("Ind","IndDsbl");
	else
		oImg.className=oImg.className.replace("Off","OffDsbl");	
	if(ur_system.is508)
		sapUrMapi_setTabIndex(oLbl,"0");
  oIn.disabled=true;	
	ur_setSt(sId,ur_st.DISABLED,true);
	sapUrMapi_Label_setDisabled(sapUrMapi_Label_getInputLabel(sId));
	if(ur_system.is508)
		oLbl.st=oIn.st;	
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_setEnabled
//* parameter   : sId - Id of the checkbox
//*	description	: sets an enabled checkbox to disabled and also the connected
//								label
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_setEnabled(sId) {
  var oIn=ur_get(sId);
	var oLbl=ur_get(sId+"-lbl");
	var oImg=ur_get(sId+"-img");
	oLbl.className=oLbl.className.replace("Dsbl","");
	oLbl.className=oLbl.className.replace("Ro","");
	oLbl.className=oLbl.className.replace("Inv","");
	oImg.className=oImg.className.replace("Dsbl","");
	oIn.disabled=false;
	ur_setSt(sId,ur_st.DISABLED,false);
	ur_setSt(sId,ur_st.READONLY,false);
	if(ur_system.is508)
		sapUrMapi_setTabIndex(oLbl,"-1");
	sapUrMapi_Label_setEnabled(sapUrMapi_Label_getInputLabel(sId));
	if(ur_system.is508)
		oLbl.st=oIn.st;	
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_setReadonly
//* parameter   : sId - Id of the checkbox
//*								bSet - set/unset the checkbox readonly
//*	description	: sets/unsets a checkbox readonly and the connected
//								label enabled
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_setReadonly(sId,bSet){
  var oIn=ur_get(sId);
	var oLbl=ur_get(sId+"-lbl");
	var oImg=ur_get(sId+"-img");
	if(bSet){
		if (ur_isSt(oIn,ur_st.READONLY)) return;
		if (ur_isSt(oIn,ur_st.DISABLED)){
			oLbl.className=oLbl.className.replace("Dsbl","");
			oImg.className=oImg.className.replace("Dsbl","");
			ur_setSt(sId,ur_st.DISABLED,false);
		}
		if(ur_isSt(oIn,ur_st.SELECTED))
			oImg.className=oImg.className.replace("On","OnDsbl");
		else if(ur_isSt(oIn,ur_st.UNDEFINED))
			oImg.className=oImg.className.replace("Ind","IndDsbl");			
		else
			oImg.className=oImg.className.replace("Off","OffDsbl");	
		oIn.disabled=true;	
		ur_setSt(sId,ur_st.READONLY,true);
		if(ur_system.is508)
			sapUrMapi_setTabIndex(oLbl,"0");
	}
	else{
		if (!ur_isSt(oIn,ur_st.READONLY)) return;
		oLbl.className=oLbl.className.replace("Ro","");
		oIn.disabled=false;	
		ur_setSt(sId,ur_st.READONLY,false);
		if(ur_system.is508)
			sapUrMapi_setTabIndex(oLbl,"-1");	
	}
	sapUrMapi_Label_setEnabled(sapUrMapi_Label_getInputLabel(sId));
	if(ur_system.is508)
		oLbl.st=oIn.st;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_setInvalid
//* parameter   : sId - Id of the checkbox
//*	description	: sets invalid state
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_setInvalid(sId) {
  var oIn=ur_get(sId);
	var oLbl=ur_get(sId+"-lbl");
	var oImg=ur_get(sId+"-img");
	if (ur_isSt(oIn,ur_st.INVALID) || ur_isSt(oIn,ur_st.READONLY) || ur_isSt(oIn,ur_st.DISABLED))
		return;
	oLbl.className=oLbl.className.replace("Lbl","LblInv");
	
	ur_setSt(sId,ur_st.INVALID,true);
	sapUrMapi_Label_setInvalid(sapUrMapi_Label_getInputLabel(sId),true);
	if(ur_system.is508)
		oLbl.st=oIn.st;	
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_focus
//* parameter   : sId - Id of the checkbox
//*								oEvt - event object
//*	description	: show data tip
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_focus(sId,oEvt) {
	sapUrMapi_DataTip_show(sId,"focus");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_blur
//* parameter   : sId - Id of the checkbox
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_blur(sId,oEvt) {
	sapUrMapi_DataTip_hide();
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_keydown
//* parameter   : sId - Id of the checkbox
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_keydown(sId,oEvt) {
}
