//* ************************************************************************
//* Tree
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_collapseAll
//* parameter   : sTreeId  - Id of the Tree
//* description : Collapses all Nodes of the tree
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_collapseAll(sTreeId) {
    var eRootNode = ur_get(sTreeId + "-r");
    var eNodes = eRootNode.getElementsByTagName("DIV");

    //now loop through all the child nodes
    for (var i =  eNodes.length-1; i >-1; i--){
            var childDiv = ur_get(eNodes[i].id + "-child");
      if (childDiv) {
        sapUrMapi_Tree_toggle( sTreeId, eNodes[i].id, true, true)
      }
    }
            }
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_expandAll
//* parameter   : sTreeId  - Id of the Tree
//* description : Expands all Nodes of the tree
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_expandAll(sTreeId) {
    var eRootNode = ur_get(sTreeId + "-r");
    var eNodes = eRootNode.getElementsByTagName("DIV");

    //now loop through all the child nodes
    for (var i =  eNodes.length-1; i >-1; i--){
      var childDiv = ur_get(eNodes[i].id + "-child");
      if (childDiv) {
        sapUrMapi_Tree_toggle( sTreeId, eNodes[i].id, false, true)
        }
    }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_toggle
//* parameter   : sTreeId  - string  - Id of the Tree
//						  : sNodeId  - string  - Id of the TreeNode
//              : bClose   - boolean - optional true if the node should be
//								                     closed use only with bKey=true
//              : bKey     - boolean - optional true if explicit open
//																		 or close is used (bClose)
//* description : Toggles a tree node and focus it using bKey you can
//                explicit close oropen a node specified by sNodeId
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_toggle(sTreeId, sNodeId, bClose, bKey, e) {
	var nodeDiv = ur_get(sNodeId);
  var oMainContainerNode = ur_get(sTreeId+"-r");
  if (window.event)
    ur_EVT_cancel(window.event);
  if (!bKey) {
    oMainContainerNode.setAttribute("focuced_id",sNodeId);
    try { sapUrMapi_Tree_focusNode(sTreeId,sNodeId); } catch (e) {};
  }
	var childrenDiv = ur_get( nodeDiv.id + "-child" );
  if (!childrenDiv) return;
	var expander = ur_get( nodeDiv.id + "-exp" );

	if ((ur_isSt(nodeDiv,ur_st.COLLAPSED) && !bKey)||(bKey && !bClose && ur_isSt(nodeDiv,ur_st.COLLAPSED)))
	{
	  nodeDiv.className = nodeDiv.className+" urTreNlExp";
		childrenDiv.style.display="block";
		//show the maximum of the opened folder is a bit too much
		//childrenDiv.scrollIntoView();
		eLength = expander.className.length;
		expander.className = expander.className.substr(0,eLength-3) + "Op";
    nodeDiv.setAttribute("st",nodeDiv.getAttribute("st").replace("-","+"));
    try { sapUrMapi_Tree_focusNode(sTreeId,sNodeId); } catch (e) {};
    return;
	}
	if ((ur_isSt(nodeDiv,ur_st.EXPANDED)&&!bKey)||(bKey && bClose && ur_isSt(nodeDiv,ur_st.EXPANDED)))
	{
		if (nodeDiv.className.lastIndexOf(" ")>-1) {
		  nodeDiv.className = nodeDiv.className.substring(0,nodeDiv.className.lastIndexOf(" "));
		}
		childrenDiv.style.display="none";
		eLength = expander.className.length;
		expander.className = expander.className.substr(0,eLength-2) + "Clo";
    nodeDiv.setAttribute("st",nodeDiv.getAttribute("st").replace("+","-"));
    try { sapUrMapi_Tree_focusNode(sTreeId,sNodeId); } catch (e) {};
		return;
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TreeNode_keyDown
//* parameter   : sTreeId  - string  - Id of the Tree
//						  : sNodeId  - string  - Id of the TreeNode on which a keydown
//								                     event was fired
//						    e - EventObject 	 - the event itself
//* description : raises events on the TreeNode specified by sNodeId
//								Spacebar - will raise the onclick event of the Node
//								Shift+Control+F10 - will raise the oncontextmenu event of the Node
//								Tab and Arrow Keys will be handled in sapUrMapi_Tree_keyDown
//* return      : none, cancels bubbling if the events are not handled in the node
//* ------------------------------------------------------------------------
function sapUrMapi_TreeNode_keyDown(sTreeId,sNodeId,e) {
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_controlEnter
//* parameter   : sTreeId  - string  - Id of the Tree
//                sNodeId  - string  - the Node that contains a control and
//							  entered now
//						    e - EventObject 	 - the event
//* description : If a Node contains other controls this function is called
//						    before the first control will get the focus
//
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_controlEnter(sTreeId, sNodeId,e) {
	if (ur_get(sNodeId+"-cnt-end")) {
	  return true;
	}
	return false;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_InvokeNodeClick
//* parameter   : sNodeId  - string  - Id of the node to invoke the click on
//* description : Invokes the onclick event method for the item found by the id param.
//
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_InvokeNodeClick(sNodeId) {
	ur_get(sNodeId+":exp").onclick();
}

function sapUrMapi_TreeNode_hover(sTreeId,sNodeId,bIn,e) {
	if ((e.target.level) && (!e.target.container)) {
    if (bIn) e.target.className="urTreNoEnblClk urTreNoEnblClkHover"
    else e.target.className="urTreNoEnblClk";
  }
}
function sapUrMapi_TreeNode_mouseover(sTreeId,sNodeId,e) {
	sapUrMapi_TreeNode_hover(sTreeId, sNodeId, true, e);
}
function sapUrMapi_TreeNode_mouseout(sTreeId,sNodeId,e) {
	sapUrMapi_TreeNode_hover(sTreeId, sNodeId, false, e);
}
function sapUrMapi_Tree_getNodeId(sId) {
	var o=ur_get(sId);
	while (o.tagName!="BODY") {
		if (o.tagName=="DIV" && ((String(o.getAttribute("tp")).indexOf("F")>-1) || (String(o.getAttribute("tp")).indexOf("L")>-1))) return o.id;
		o=o.parentNode;
	}
	return "";
}

function sapUrMapi_Tree_selectNode(sTreeId, sNodeId, iSelLevel) {
	var oNode   = ur_get(sNodeId);
	var bExp    = oNode.className.indexOf("urTreNlExp")>0;
	var sClass = oNode.className.substring(0,oNode.className.indexOf(" "));
	if (sClass=="") {
  	var sClass = oNode.className;
	}
	oNode.setAttribute("sellevel",""+iSelLevel);
	ur_get(sNodeId+"-cnt-start").setAttribute("sellevel",""+iSelLevel);
	if (iSelLevel==1) sClass+=" urTreNSel";
	if (iSelLevel==2) sClass+=" urTreNSel2";
	if (bExp) sClass+=" urTreNlExp";
	oNode.className=sClass;
}

function sapUrMapi_Tree_deselectAll(sTreeId) {
	var colNodes   = document.getElementsByTagName("DIV");
	for (var n=0;n<colNodes.length;n++) {
		if (colNodes.item(n).getAttribute("sellevel")) sapUrMapi_Tree_selectNode(sTreeId,colNodes.item(n).id,0);
	}
}

//EXPAND ALL
function sapUrMapi_Tree_expandAll(sTreeId) {
    var eRootNode = ur_get(sTreeId + "-r");
    var eNodes = eRootNode.getElementsByTagName("DIV");

    //now loop through all the child nodes
    for (var i =  eNodes.length-1; i >-1; i--){
      var childDiv = ur_get(eNodes[i].id + "-child");
      if (childDiv) {
        sapUrMapi_Tree_toggle( sTreeId, eNodes[i].id, false, true)
      }
    }
}
function sapUrMapi_TreeNode_mouseover(sTreeId,sNodeId,e) {
}
function sapUrMapi_TreeNode_mouseout(sTreeId,sNodeId,e) {
}
function sapUrMapi_Tree_enter (sTreeId,e) {
}

function sapUrMapi_Tree_showMenu(sTreeId,sNodeId,sPopupMenuId,oEvt) {
	sapUrMapi_PopupMenu_showMenu(sNodeId,sPopupMenuId,sapPopupPositionBehavior.EVENT,oEvt);
	ur_EVT_cancel(oEvt);
}

