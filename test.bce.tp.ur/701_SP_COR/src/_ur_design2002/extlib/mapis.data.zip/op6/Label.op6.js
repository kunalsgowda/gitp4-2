function sapUrMapi_Label_getInputLabel(sId) {
	var ur_arrLabels = document.getElementsByTagName("LABEL");
	for (var i=0;i<ur_arrLabels.length;i++) {
		if (ur_arrLabels.item(i).getAttribute("f")==sId) {
			return ur_arrLabels.item(i);
		}
	}
	for (var i=0;i<ur_arrLabels.length;i++) {
		if (ur_arrLabels.item(i).getAttribute("htmlFor")==sId) {
			return ur_arrLabels.item(i);
		}
	}
	return null;
}
function sapUrMapi_Label_FocusLabeledElement(sForId) {
}
function sapUrMapi_Label_getLabelText(sId) {
	var oLbl=sapUrMapi_Label_getInputLabel(sId);
	if(oLbl==null) return null;
	return oLbl.innerText;
}
function sapUrMapi_Label_clickLabeledElement(sForId) {
}
function sapUrMapi_Label_focus(sId,sForId,oEvt) {
}
