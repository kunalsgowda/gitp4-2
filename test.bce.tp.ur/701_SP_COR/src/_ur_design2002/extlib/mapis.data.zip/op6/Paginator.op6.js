UR_PAGINATOR_BUTTON = {BEGIN:0, PREVIOUS_PAGE:1, PREVIOUS_ITEM:2,NEXT_ITEM:3,NEXT_PAGE:4,END:5};
function sapUrMapi_Paginator_setStates(sId, arrBtns, arrStates) {
}
function sapUrMapi_Paginator_buttonDisabled(o) {
}
function sapUrMapi_Paginator_getInputValue(sId) {
  var oInp=ur_get(sId+"-inp");
  if (oInp!=null) return parseInt(oInp.value);
}
function sapUrMapi_Paginator_setInputValue(sId,iNewValue) {
  var oInp=ur_get(sId+"-inp");
  if (oInp!=null) oInp.value=iNewValue;
}
function sapUrMapi_Paginator_keydown(sId,sConId,oEvt) {
}
function sapUrMapi_Paginator_navBegin(sId,sConId,oEvt) {
    return true;
}
function sapUrMapi_Paginator_navEnd(sId,sConId,oEvt) {
    return true;
}
function sapUrMapi_Paginator_navPrevPage(sId,sConId,oEvt) {
    return true;
}
function sapUrMapi_Paginator_navNextPage(sId,sConId,oEvt) {
    return true;
}
function sapUrMapi_Paginator_navPrev(sId,sConId,oEvt) {
    return true;
}
function sapUrMapi_Paginator_navNext(sId,sConId,oEvt) {
    return true;
}
function sapUrMapi_Paginator_showMenu(sId,sMenuId,sConId,oEvt) {
}
function ur_Paginator_triggerClick(sId,enumButton) {
}
function sapUrMapi_Paginator_enrichParameters(sConId) {
	return "";
}