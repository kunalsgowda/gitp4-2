/*-------------------------------------*/
/*  Global Control Services            */
/*  (c) 2002 SAP AG                    */
/*-------------------------------------*/
  
/*----------------------------------------------------------------------*/
/*  General                                                             */
/*----------------------------------------------------------------------*/
// domainrelaxing
  // domainrelaxing
  
  /*var  strDomainRelaxScript  = '<S'+'CRIPT> var liBehindFirstDot = document.domain.indexOf( "." ) + 1;';
       strDomainRelaxScript += 'if (liBehindFirstDot > 0) {';
       strDomainRelaxScript += 'document.domain = document.domain.substr( liBehindFirstDot );';
       strDomainRelaxScript += '}</S'+'CRIPT>';
  */
  strDomainRelaxScript  = "";
  var docBody = null;  
//------------------------------------------------------------------------------

//----------------------------------------------------------------------------
//  Popup Object                                                        
//----------------------------------------------------------------------------
//Events provided by this Object 
// onbeforerender  = use that event to set other positions than the precalculated;
// onblur          = fired when the popup blurs, use to hide it
//----------------------------------------------------------------------------

//consts enums 
  
//----------------------------------------------------------------------------
// sapPopupSizeBehavior used with attribute o.sizebehaviour
// o.sizebehaviour.USER    - you can set the size of the popup, 
//                           use o.size.width,o.size.height
//                         
// o.sizebehaviour.CONTENT - the popup will automatically adjust to the the
//                           size of its content
//----------------------------------------------------------------------------
  sapPopupSizeBehavior     = { CONTENT : "CONTENT", USER : "USER" };
//----------------------------------------------------------------------------
if(ur_system.emptyhoverurl==null) ur_system.emptyhoverurl = ur_system.mimepath+"emptyhover.html";
document.write("<div id='urFrames'><iframe id=\"sapPopupMainId_X0\" name=\"sapPopupMainId_X0\" src=\""+ur_system.emptyhoverurl+"\" style=\"z-index:1001;display:block;position:absolute;top:-5000;width:0;height:0\"  frameborder=\"0\" border=\"no\" scrolling=\"no\" tabindex=\"-1\"></iframe></div>");
  
//----------------------------------------------------------------------------
// sapPopupPositionBehavior used with attribute o.positionbehaviour
// o.positionbehaviour.MENULEFT      - popup shows left aligned under the 
//                                     source element.
// o.positionbehaviour.MENURIGHT     - popup shows right aligned under the 
//                                     source element.
// o.positionbehaviour.BROWSERCENTER - popup shows centered in the browser 
//                                     window. 
// o.positionbehaviour.USER          - you can set the position
//                                     use o.position.left, o.position.top
//----------------------------------------------------------------------------
  
  sapPopupPositionBehavior = { MENULEFT : "MENULEFT", MENURIGHT : "MENURIGHT", BROWSERCENTER : "BROWSERCENTER", USER : "USER", SUBMENU : "SUBMENU",EVENT:"EVENT" }
//----------------------------------------------------------------------------

  var sapPopupMainId = "sapPopupMainId_X";

//Variables
  var sapPopupStore = new Array(); 
  var sapOpenLevel  = false; 
  
/*----------------------------------------------------------------------*/
/*  Constructor                                                         */
/*----------------------------------------------------------------------*/
// desc : create a new popup
// in   : sourcewindow   : DOM window object - caller window
//        stylesheets    : Array             - stylesheet urls to use in the popup
//        contentobject  : DOM element       - that contains the html to show in the popup
//        sourceobject   : DOM element       - source element to align the popup
//        sourceevent    : DOM event object  - fired on the sourceobject to position the popup
// out  : none 
// brw  : NN6>
//----------------------------------------------------------------------------
  function sapPopup(sourcewindow,stylesheets,contentobject,sourceobject,sourceevent,level) {
    //Attributes
    this.level = level;
    this.sizebehaviour = sapPopupSizeBehavior.CONTENT;
    this.positionbehavior = sapPopupPositionBehavior.MENULEFT;
    
    this.position = { left: -1, top: -1, right: -1, bottom: -1 };
    this.size     = { width: -1, height: -1 };
    if (document.getElementById(sapPopupMainId+(level+1))==null) {
    	 var oFramesContainer = document.getElementsByTagName("BODY").item(0);
    	 for (var f=level+1;f<level+3;f++) {
    	 	 var oFrame = document.createElement("IFRAME");
    	 	 oFrame.setAttribute("id",sapPopupMainId+(f));
    	 	 oFrame.setAttribute("name",sapPopupMainId+(f));
    	 	 oFrame.setAttribute("src",ur_system.emptyhoverurl);
    	 	 oFrame.setAttribute("style","width:0;height:0;z-index:1001;display:block;position:absolute;top:-5000;");
    	 	 oFrame.setAttribute("tabindex","-1");
    	 	 oFrame.setAttribute("frameborder","0");
    	 	 oFrame.setAttribute("border","no");
    	 	 oFrame.setAttribute("scrolling","no");
    	   oFramesContainer.appendChild(oFrame);
    	 }
    }
    
    this.frame = { object: document.getElementById(sapPopupMainId+level), 
                   window: window.frames[sapPopupMainId+level]};
    
    this.content = { html: contentobject.innerHTML,
                     size: contentobject.childNodes[0] };
    //store information about the source of that popuprequest
    this.source = { event:sourceevent, 
                    object:sourceobject, 
                    window: sourcewindow, 
                    document:sourcewindow.document, 
                    body: sourcewindow.document.getElementsByTagName("BODY").item(0) };
    
    this.canrender   = true;
    this.domainrelax = true;
    this.scrolling   = true; 
    this.stylesheets = stylesheets;

    //Methods
    this.write   = sapPopup_write;
    this.show    = sapPopup_show;
    this.showOld = sapPopup_showOld;
    this.hide    = sapPopup_hide;
    this.poscalc = sapPopup_poscalc;
    
    //Events
    this.onbeforerender  = null;
    this.onblur          = null;
        
    //define a global variable with the body element for all popups once
    if (!docBody) docBody = window.document.getElementsByTagName("BODY")[0];

    //if relative urls are used for styles try to absolute them
    for (var n=0; n<this.stylesheets.length;n++) {
      this.stylesheets[n]=relativeToAbsolutePath(this.stylesheets[n],sourcewindow.location.href);
    }

    //set a variable inside sourcewindow to itself, used to refer events back
    this.source.window.me = this.source.window;
	  if (this.source.window.ur_system.domainrelaxing==this.source.window.sapUrDomainRelaxing.MINIMAL) {
	    strDomainRelaxScript  = "<s"+"cript>var hostname = document.domain;if( !(/^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$/.test(hostname)) ) {var posBehindFirstDot = hostname.indexOf(\".\") + 1;if (posBehindFirstDot>0) {document.domain=hostname.substr(posBehindFirstDot);}};</scri"+"pt>";
	  } else {
	      if (this.source.window.ur_system.domainrelaxing==this.source.window.sapUrDomainRelaxing.MAXIMAL){
	      strDomainRelaxScript  = "<s"+"cript>try { while(document.domain.indexOf(\".\")>0) { document.domain = document.domain.substr(document.domain.indexOf(\".\")+1); }} catch(e) {}};</scri"+"pt>";
	    }
	  }
    
    sapPopupStore[this.level] = this;
    return this; 
 }
 

/*----------------------------------------------------------------------*/
/*  Methods                                                               */
/*----------------------------------------------------------------------*/
//----------------------------------------------------------------------------
// method write
//----------------------------------------------------------------------------
// desc : writes the popup into its iframe
//        internal use only
// in   : none
// out  : none 
// brw  : NN6>
//----------------------------------------------------------------------------
function sapPopup_write(bDoNotAutoFocus) {
  //potentially this is faster with dom operations but what about relaxing domains?
  strContent = "<html><head>";
  //add domain relaxing
  if (this.domainrelax) strContent += strDomainRelaxScript;
  if( bDoNotAutoFocus )
		strContent += "<sc"+"ript>me=parent.sapPopupStore["+this.level+"].source.window;mylevel="+this.level+";</scr"+"ipt>";
	else
		strContent += "<sc"+"ript>me=parent.sapPopupStore["+this.level+"].source.window; window.focus();mylevel="+this.level+";</scr"+"ipt>";
      
  //add the content and the rest
  strContent+= "</head><body class='urBdyStd' scroll=";
  strContent+= this.scrolling?"'no'":"'auto'";
  if(this.object!=null && this.object.getAttribute("ct")!="ComboBox"){  
		strContent+= " onload='parent.sapUrMapi_PopupMenu_setEvents(parent.sapPopupStore["+this.level+"],1);'";
		if (this.level==0) {
			strContent+= " onfocus='parent.sapUrMapi_PopupMenu_setEvents(parent.sapPopupStore["+this.level+"],2);' onblur='if ((parent.sapPopupStore[mylevel]) && (!parent.sapOpenLevel)) {parent.sapPopupStore[mylevel].onblur();}'";
		} else {
			strContent+= " onfocus='parent.sapUrMapi_PopupMenu_setEvents(parent.sapPopupStore["+this.level+"],2);' onblur='if ((parent.sapPopupStore[mylevel]) && (!parent.sapOpenLevel)) {parent.sapPopupStore[mylevel].onblur();}'";
		}
	}
  strContent+= " style='margin:0;border:none;'>"+this.content.html+"</body></html>";
  //write it!
  //this.frame.window.document.open();
  this.frame.window.document.write(strContent);
  this.frame.window.document.close();

  //add stylesheets 
  for (var n=0; n<this.stylesheets.length;n++) {
    var newLink = this.frame.window.document.createElement("LINK");
    newLink.setAttribute("href",this.stylesheets[n]);
    newLink.setAttribute("type","text/css");
    newLink.setAttribute("rel","stylesheet");
    this.frame.window.document.getElementsByTagName("HEAD")[0].appendChild(newLink);
  }

}

var intLeftFramePx;
var intTopFramePx;

//----------------------------------------------------------------------------
// method poscalc
//----------------------------------------------------------------------------
// desc : calculates the position of the popup depending on 
//        - sizebehaviour
//        - positionbehavior
//        changes the position if right or/and bottom might be 
//        not in the visible area to ensure the whole popup is visible
// in   : none
// out  : none 
// brw  : NN6>
//----------------------------------------------------------------------------
function sapPopup_poscalc() {
  //set the size of the frame depending on its content
  if (this.sizebehaviour==sapPopupSizeBehavior.CONTENT) {
    this.size.width  = this.content.size.offsetWidth;
    this.size.height = this.content.size.offsetHeight;
  } else {
    if ((this.size.width<=0) || (this.size.height<=0)) {
      showError("Please set\n   int sapPopup.size.width\n   int sapPopup.size.height\n to a value > 0.");
      this.canrender = false
    }
  } 
  //find relative position to sourceobject;
  var sourceoffset    = getAbsolutePosition(this.source.object);
  var sourcesize      = getElementSize(this.source.object);
  var oldPosLeft = this.position.left;
  var oldPosRight = this.position.right;
  var oldPosTop = this.position.top;  

  //event object is available
  if ( this.positionbehavior.indexOf("MENU")>-1) {
      this.position.left = sourceoffset.left;
      this.position.top  = sourceoffset.top + sourcesize.height;
      if (this.positionbehavior == sapPopupPositionBehavior.MENURIGHT) {
	      this.position.left = this.position.left + sourcesize.width - this.size.width;
      }
      
      if (this.positionbehavior == sapPopupPositionBehavior.SUBMENU) {
	    this.position.left = this.position.left + sourcesize.width;
	    this.position.top  = this.position.top - sourcesize.height;
        if (this.level>0) { 
          this.position.left = this.position.left+sapPopupStore[this.level-1].position.left;
          this.position.top = this.position.top+sapPopupStore[this.level-1].position.top;
        } 
      }
      //calculate right and bottom 
      this.position = setPosBottomRight(window, this.position, this.size)
      
      // if submenue does not fit on usual place,
      // try to position on other side of parent menu,
      // but only, of there is enough space available
      var setsubmenubelow=false;
      if (this.positionbehavior == sapPopupPositionBehavior.SUBMENU) {
        if (this.position.right<0) {
          if (this.position.left-(sourcesize.width)+7-this.size.width>window.pageXOffset) {
            this.position.left=this.position.left-(sourcesize.width)+7-this.size.width;
          } else {
            this.position.top = this.position.top + sourcesize.height;
            setsubmenubelow=true;
          }
          //calculate right and bottom 
          this.position = setPosBottomRight(window, this.position, this.size)
        } 
      }     
    
      //reposition horizontally
      if (this.position.right<0) this.position.left  = window.innerWidth + window.pageXOffset - this.size.width;
      if (this.position.left-window.pageXOffset<0) this.position.left  = 0 + window.pageXOffset;
      // reposition vertically
      if (this.position.bottom<0) {											 //too bottom
        if (this.positionbehavior == sapPopupPositionBehavior.SUBMENU) {
          if (setsubmenubelow) 
            this.position.top = this.position.top - sourcesize.height - this.size.height; 
          else  
            this.position.top = this.position.top + sourcesize.height - this.size.height; 
        }  
        if ((this.positionbehavior == sapPopupPositionBehavior.MENULEFT) ||
            (this.positionbehavior == sapPopupPositionBehavior.MENURIGHT)) {
          this.position.top = this.position.top - sourcesize.height - this.size.height;  
        }
      }  
      if (this.position.top-window.pageYOffset<0) this.position.top  = 0 + window.pageYOffset;
        
      //recalculate right and bottom according to changed values
      this.position = setPosBottomRight(window, this.position, this.size)
      
   } else if ( this.positionbehavior == sapPopupPositionBehavior.BROWSERCENTER ) {
	  this.position.left = Math.floor((window.innerWidth/2)-(this.size.width/2)) + this.source.window.pageXOffset;
	  this.position.top  = Math.floor((window.innerHeight/2)-(this.size.height/2)) + this.source.window.pageYOffset;
      this.position.right   = window.innerWidth  - this.position.left - this.size.width + window.pageXOffset;
	  this.position.bottom  = window.innerHeight - this.position.top  - this.size.height + window.pageYOffset;
	  
  } else if (this.positionbehavior == sapPopupPositionBehavior.EVENT) {
	  this.position.left = this.source.event.pageX;
	  this.position.top  = this.source.event.pageY;
      this.position.right   = window.innerWidth  - this.position.left - this.size.width;
      this.position.bottom  = window.innerHeight - this.position.top  - this.size.height;
      
      //repositioning
      if (this.position.right<0) this.position.left  = this.position.left - this.size.width;
      if (this.position.bottom<0) this.position.top  = this.position.top - this.size.height;
      if (this.position.left-window.pageXOffset<0) this.position.left  = 0 + window.pageXOffset;
      if (this.position.top-window.pageYOffset<0) this.position.top  = 0 + window.pageYOffset;
	  //recalculate right and bottom
      this.position = setPosBottomRight(window, this.position, this.size)
   } else if ((this.position.top<0) || (this.position.left<0)) {
      showError("Please set\n   int sapPopup.position.left\n   int sapPopup.position.top\n to a value > 0.");
      this.canrender = false
  }
  if ((this.position.left-window.pageXOffset<0) || (this.position.right<0)) {
     this.position.left  = 0 + window.pageXOffset;
  }
  if ((this.position.top-window.pageYOffset<0) || (this.position.bottom<0)){
      if (this.canrender) this.scrolling=true;
      this.position.top  = 0 + window.pageYOffset;
  }
  
  if (ur_system.direction=="rtl")
		this.position.right += oldPosRight+1;
	else
		this.position.left+=oldPosLeft+1;
		
	this.position.top +=oldPosTop+1;
  
}
//----------------------------------------------------------------------------
// method show
//----------------------------------------------------------------------------
// desc : shows the popup
// in   : none
// out  : none 
// brw  : NN6>
//----------------------------------------------------------------------------
function sapPopup_show(noRecalc,bDoNotAutoFocus) {
  //creating another child 
  sapOpenLevel = true;
  this.poscalc();
  if (this.onbeforerender) { if (!this.onbeforerender(this)) return; }
  if (!this.canrender) { showError("Cannot render Popup. Sizes and positions are not set."); return; }
  try {  	
		if (this.frame.window.mylevel==null) {
		  this.write(bDoNotAutoFocus);
		} else {
		  this.frame.window.document.getElementsByTagName("BODY").item(0).innerHTML=this.content.html;
		  window.sapUrMapi_PopupMenu_setEvents(this,1);
		}
  } catch (e){
    this.write(bDoNotAutoFocus);
  }
  //show the menu
  
  this.frame.object.style.left   = this.position.left;
  this.frame.object.style.top    = this.position.top;
  this.frame.object.style.width  = this.size.width;
  this.frame.object.style.height = this.size.height;

  activePopup = this;
  this.oldresize = window.onresize;
  //window.onresize = top.hidePopups;
  return true;
}
//----------------------------------------------------------------------------
// method showOld
//----------------------------------------------------------------------------
// desc : shows the popup, does not calculate the position and does not
//        write the content
// in   : none
// out  : none 
// brw  : NN6>
//----------------------------------------------------------------------------
function sapPopup_showOld() {
  sapOpenLevel = true;
  this.frame.object.style.left   = this.position.left;
  this.frame.object.style.top    = this.position.top;
  this.frame.object.style.width  = this.size.width;
  this.frame.object.style.height = this.size.height;
  activePopup = this;
  this.oldresize = window.onresize;
  return true;
}
//----------------------------------------------------------------------------
// method hide
//----------------------------------------------------------------------------
// desc : hides the popup
// in   : none
// out  : none 
// brw  : NN6>
//----------------------------------------------------------------------------
function sapPopup_hide() {
  //hide the menu
  this.frame.object.style.top="-15001";
  if (this.level<sapPopupStore.length-1) {
  	sapPopupStore[this.level+1].hide();
  }
  sapPopupStore[this.level] = null; 
  var sapPopNew = new Array();
  for (var n=0;n<sapPopupStore.length;n++) {
  	if (sapPopupStore[n]!=null) {
  		sapPopNew[sapPopNew.length]=sapPopupStore[n];
  	}
  }
  sapPopupStore = sapPopNew;
  return true;
}
function hidePopupMenu(level) {
  if (sapPopupStore[0]) {
    sapPopupStore[0].hide();
  }
}

/*----------------------------------------------------------------------*/
/*  Helpers                                                             */
/*----------------------------------------------------------------------*/
//----------------------------------------------------------------------------
// function setPosBottomRight
//----------------------------------------------------------------------------
// desc : returns Right and Bottom  relative from a oBody DOM Body
// in   : oWindow  - window object, oPos - object - Position Object , oSize
// out  : oPos   - object Position Object
// brw  : NN6>
//----------------------------------------------------------------------------
function setPosBottomRight ( oWindow, oPos, oSize) {
  oPos.right   = oWindow.innerWidth - oPos.left - oSize.width + oWindow.pageXOffset;
  oPos.bottom  = oWindow.innerHeight - oPos.top - oSize.height + oWindow.pageYOffset;
  return oPos;
}   

//----------------------------------------------------------------------------
// function getAbsolutePosition
//----------------------------------------------------------------------------
// desc : returns position object x.left, x.right and x.top from a dom element 
//        absolute to the left, right and top borders of the document. 
// in   : obj  - object
// out  : position - object 
// brw  : left and top: IE5+, NN6+  right: IE5+
//----------------------------------------------------------------------------
function getAbsolutePosition (obj) {
  if (obj)
	  return sapUrMapi_getAbsolutePosition (obj);
}  

//----------------------------------------------------------------------------
// function getElementSize
//----------------------------------------------------------------------------
// desc : returns size object .width and .height on a dom element
// in   : obj  - object
// out  : size - object 
// brw  : IE5>, NN6>
//----------------------------------------------------------------------------
function getElementSize (obj) {
  if (obj)
	  return { height : obj.offsetHeight, width: obj.offsetWidth };
}

//----------------------------------------------------------------------------
// function relativeToAbsolutePath
//----------------------------------------------------------------------------
// desc : returns the absolute url of strRel from an absolute url strAbs
// in   : strRel - string
//        strAbs - string
// out  : absolute path - string 
// brw  : IE5>, NN6>
//----------------------------------------------------------------------------
function relativeToAbsolutePath(strRel,strAbs) {
    if (strRel.lastIndexOf("./")==-1) {
	if((strRel.indexOf("http://") !=-1) && (strRel.indexOf(".css"))) return strRel;
	if((strRel.indexOf("https://") !=-1) && (strRel.indexOf(".css"))) return strRel;

  	if(strRel.indexOf("/") == 0) {
  		strRel = strRel.substr(1);
  	}
  
  	if (strAbs.indexOf("?")!=-1) {
  		var strAbs = strAbs.substring(0,strAbs.indexOf("?"));
  	}
  
  	var urlParts = strAbs.split("//");
  	var domain = urlParts[1].substring(0,urlParts[1].indexOf("/"));
  	var strAbsPath = urlParts[0] + "//" + domain + "/";
  
    	strNewAbsPath = strAbsPath + strRel;
    	return strNewAbsPath;
    }
    else {
  	  if (strAbs.indexOf("?")==-1) {
  		var strRelDots      = strRel.substring(0,strRel.lastIndexOf("./")+2);
  		var strAbsPath      = strAbs.substring(0,strAbs.lastIndexOf("/"));
  	  }
  	  else {
  		var strRelDots      = strRel.substring(0,strRel.lastIndexOf("./")+2);
  		var strAbsPath      = strAbs.substring(0,strAbs.indexOf("?"));
  		var strAbsPath      = strAbsPath.substring(0,strAbsPath.lastIndexOf("/"));
  	  }
  }
  while(strRelDots.lastIndexOf("..")>-1) { //erase all double dots
    strAbsPath = strAbsPath.substring(0,strAbsPath.lastIndexOf("/")); 
    strRelDots = strRelDots.substring(0,strRelDots.lastIndexOf(".."))+"/";
  }
  if (strRelDots.lastIndexOf("./")>-1) {
    //erase last dots slash
    strRelDots = strRelDots.substring(0,strRelDots.lastIndexOf("./"))+"/";
    if (strRelDots.lastIndexOf("./")>-1) { 
      showError (strRel+" is not a valid relative url.");
    }
  }
  //build absolut path
  strNewAbsPath = strAbsPath + strRelDots + strRel.substring(strRel.lastIndexOf("./")+2,strRel.length);
  return strNewAbsPath;
}  
//----------------------------------------------------------------------------
// function showError
//----------------------------------------------------------------------------
// desc : shows an error text strTxt in an alert window could be replaces 
//        in the futur to display nicer messages
// in   : strTxt - string
// out  : none 
// brw  : IE5>, NN6>
//----------------------------------------------------------------------------
function showError(strTxt) {
  alert("Error:"+strTxt);
}

/****************************************** popup *************************************************************************************/


//-------------------------------------------------------------------------
var ptrPopup = new URPopupManager();

function URPopupManager()
{
  this.hostWindow = null;
  this.popups = null;	

  this.ptrActiveXArray = new Array();

  this.IE = !document.addEventListener;

  this.bEncHTML = false;
  
};

//-------------------------------------------------------------------------
URPopupManager.prototype.isRTL = function()
{
  return this.IE && ur_system.direction == "rtl";
};

//-------------------------------------------------------------------------
//assigned to ptrPopup
function ptrGetPopupWindow()
{
    return ptrPopup;
};

//-------------------------------------------------------------------------

URPopupManager.prototype.getPopups = function()
{
  if (this.popups != null)
    return this.popups;

  if (typeof(this.getHostWindow().urclassic_popupwindows) == "undefined"  )
    this.getHostWindow().urclassic_popupwindows = new this.getHostWindow().Array();

  return this.popups = this.getHostWindow().urclassic_popupwindows;
};
//-------------------------------------------------------------------------

URPopupManager.prototype.getHostWindow = function()
{
    //search uppermost window / frame
    
  if (this.hostWindow != null)
      return this.hostWindow;

  var windows = new Array();
	
	var oWindow = window; 
	windows[windows.length] = oWindow;
	
	while (oWindow != oWindow.parent)
	{
		windows[windows.length] = oWindow.parent;
		oWindow = oWindow.parent;
	}
		
	for (var x = windows.length-1; x >= 0; x--)
	{
		var upperMostWindow = windows[x];
		
		//test access
		try
		{
			upperMostWindow.document.domain;
		}
		catch(e)
		{
			continue;
		}
		
		
		//has window a framset?
		var iBs = upperMostWindow.document.getElementsByTagName("frameset").length;
		if (iBs > 0)
			continue;
		
		return this.hostWindow = upperMostWindow;		
	}
}

var CONSTANTS = 
{
    borderSize: 2, 
    left: 2,
    top: 23,
    right: 2,
    bottom: 31,
    typeLeft: 72,
    typeRight: 72,
    modlessOffset: 10,
    modalOffset: 30,
    waveBottom: 22,
    waveMid: 40,
    waveTop: 15,
    waveResize: 22
};

//-------------------------------------------------------------------------
function URPopupWindow(
        sourceWindow,
        index,
        title,
        hasCloseButton,
        isResizable,
        text,
        popupManager, 
	    	initLeft,
    		initRight,
    		initTop,
        desiredWidth,
        desiredHeight,
        buttonStyle,
        sourceFocusId, 
        type,
        dialogMode, 
        popupId,
        url )
{
	  this.sourceWindow = sourceWindow;
	  this.index = index;
	  this.title = title;
    this.popupManager = popupManager;
    this.left = "0px";
    this.right = "0px";
    this.top = "0px";
    this.text = text;
    this.initLeft = initLeft;
    this.initRight = initRight;
    this.initTop = initTop;
    this.hasCloseButton = hasCloseButton;
    this.isResizable = isResizable;
    this.isInitial = true;
    this.isResized = false;
    this.isMoved = false;
    this.isMaximized = false;
    this.frameIndex = 0;
    this.strDomainRelaxScript = "<s"+"cript>try{parent.document.domain;}catch(e){document.domain='" + this.popupManager.getHostWindow().document.domain + "';}</scri" + "pt>";
    this.sourceWindow = sourceWindow;
    this.desiredWidth = desiredWidth;
    this.desiredHeight = desiredHeight;
    this.buttonStyle = buttonStyle;
    this.sourceFocusId = sourceFocusId;
  
    this.messageType = type;
    this.dialogMode = dialogMode;
    this.popupId = popupId;
    this.url = url;
    
    var iframeIndex = this.iframeIndex = this.popupManager._getAvailableIFrameIndex();
    
    //create outeriframe
    this.outerIFrame = this.createIFrame("urPopupOuter" + iframeIndex);
    this.outerIFrame.setAttribute("scrolling", "no");	
    
    var that = this;
    this.initOuterHandler = function(){that.createHTML();};
    helperAddEventListener(this.outerIFrame,"load",this.initOuterHandler);  
    
   if (url.length > 0)
   {
        this.innerIFrame = this.createIFrame("urPopupInner" + iframeIndex);
        this.initInnerHandler = function(){that.initializeInnerIFrame();};
        
        helperAddEventListener(this.innerIFrame,"load",this.initInnerHandler);
         	
   }
       
}

//------------------------------------------------------------------------------------------------------------
URPopupWindow.prototype.initializeInnerIFrame = function()
{
    if (!this.innerIFrame)
      return;
      
    helperRemoveEventListener(this.innerIFrame,"load",this.initInnerHandler);
    
    var html = "";
    if (this.popupManager.isRTL())
        html = "<html dir=\"rtl\"><head>";
    else
        html = "<html><head>";
    html += this.strDomainRelaxScript;
    
    var absoluteURL = this.relativeToAbsolutePath(this.url,this.sourceWindow.location.href);
    
    html += "</head>";
    html += "<body id=\"ptrBodyLoading\" unselectable=\"on\" oncontextmenu=\"return false;\" style=\"margin:0;\" scroll=\"no\">";
    html += "<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" style=\"height:100%;width:100%;\">";
    html += "<tbody><tr><td align=\"center\" style=\"font-family:Arial\"><span style=\"font-size:0.8em\">Loading...</span></table>";
    html += "<sc" + "ript>window.setTimeout(function(){location.href='" + absoluteURL + "';},0);" + "</sc" + "ript>";
    html += "</body></html>";
    
    var innerWindow = this.innerIFrame.contentWindow;
    innerWindow.document.write(html);
    innerWindow.document.close();
}

//------------------------------------------------------------------------------------------------------------
URPopupManager.prototype._getAvailableIFrameIndex = function()
{
    //theres always an outer popup so lets check this
    
    var index = 0;
    while(true)
    {
        var iframe = this.getHostWindow().document.getElementById("urPopupOuter" + index);
         
        //no iframe at this index ->free "slot"
        if (!iframe)
           return index;
            
        //iframe already exists   
        //now check if it is available
        if (iframe.style.top == "-5000px")
        {
           iframe.style.top = "-4000px";
           return index;
        } 
        index++;
    }
    
}

//----------------------------------------------------------------------------------------------------------------
//central function for popup
URPopupManager.prototype._ptrShowPopupWindow = function (
		sourceWindow,
		initLeft,initRight,initTop,
		width,height,
	 	url ,
	 	title,
	 	text,
	 	buttonStyle, 	
	 	type,		//messagebox
	 	logout,
	 	isMaximized,
	 	isResizable,
	 	dialogMode,
	 	popupId,
	 	hasCloseButton,
    sourceFocusId,
    hasTimeout)
{
    
   this._createBlocklayer();
   
    if (typeof sourceFocusId == "undefined")
    {
      sourceFocusId = "";
      
      if (this.IE)
      {
        if(event && event.srcElement)
        {
            sourceFocusId=event.srcElement.id;
        }
      }
    }
    
    this._blockActiveXControls();
		
	
	//FIX: focus body of sourceWindow and popup inner windows
	//when F4 is called on input field the focus handling gets weird
	 try
	 {
        var popups = this.getPopups();
        for (var x = 0; x < popups.length; x++)
            popups[x].innerIFrame.contentWindow.document.body.focus();
        
	    sourceWindow.document.body.focus();
	}
    catch (e)
    {}
	//END FIX
		
	//create popupObject and insert it
	var index = this.getPopups().length;
	var newPopup = this.getPopups()[index] = new URPopupWindow(sourceWindow,index,title,hasCloseButton,isResizable,text,this,initLeft,initRight,initTop,width,height,buttonStyle,sourceFocusId,type,dialogMode,index,url);
   	//for showing the blocklayer early
  this.focusPopup(null);
		
  if (popupId.length > 0)
    newPopup.popupId = popupId;
          
}

URPopupWindow.prototype.createHTML = function()
{
  if (!this.outerIFrame)
    return;
  
  helperRemoveEventListener(this.outerIFrame,"load",this.initOuterHandler);
  
  var html = "";
  if (this.popupManager.isRTL())
      html = "<html dir=\"rtl\"><head>";
  else
      html = "<html><head>";
  
  //insert link to stylesheet
  //ur_dia: wave / font sizes / etc
  html += "<link rel=\"stylesheet\" href=\"" + this.getPopupStyles() + "\"/>";
  html += "<link rel=\"stylesheet\" href=\"" + this.getFoundationStyles() + "\"/>";
	
  //relax the popup containers domain to domain of calling app
  html += this.strDomainRelaxScript;
  
  var outerIFrameWindow = this.outerIFrame.contentWindow;
  
  if (typeof(outerIFrameWindow.parent.popupRef) == "undefined"  )
    outerIFrameWindow.parent.popupRef = new (outerIFrameWindow.parent).Array()
  
  outerIFrameWindow.parent.popupRef[this.popupId] = this;
  html += "<script>var thisPopup = parent.popupRef['" + this.popupId + "'];</script>";
    
  //inject hardcoded styles
  //rtl considered    
  html += this._getCSS();
  html += "</head>";
      
  html += "<body onkeydown='if (event.keyCode==8) return false;' id=\"iframePopupBody\" unselectable=\"on\" oncontextmenu=\"return false;\" class=\"urPopBdyStd urPopFont\">";
  		
  var width = 200;
  var height = 120;
     
  //create html 
  html += "<div tabindex=\"0\" id=\"ptrFocusReverse\" onfocus=\"thisPopup.focusLastElement()\"></div>";
  html += "<div id=\"iframePopupDivOuterFrame\" class=\"urPopFrame1\" style=\"width:" + width + ";height:" + height + ";\">";
  html += "<div class=\"urPopFrame2\" id=\"urPopFrame2\" style=\"width:100%;height:100%\">";
  html += "<div id=\"iframePopupDivHeader\" tabindex=\"0\" class=\"urPopTitleArea\">";
  html += "<table width='100%' class='urPopFont' cellspacing='0' cellpadding='0' border='0'><tr>";
  html += "<td id='urPopupWindowTitle' class='urPopTitleAreaHeader'";
  if (ur_system.is508 == false && this.isResizable == true)
  {
      html += " ondblclick='thisPopup.toggleMinMax();'";
  }
  html += ">";
  
  //title
  html += "<div id=\"iframePopupDivHeaderText\" class=\"urPopTitle urPopFont\" style='height:100%;width:" + 150 + ";' onmousedown='return thisPopup.startDrag(event,false)' title='";
  if (ur_system.is508 == false)
  {
      if (this.popupManager.bEncHTML)
          html += toHTMLEntities(this.title);
      else
          html += this.title;
  }
  else
  {
      var transText = ur_txt[ur_language].SAPUR_POPUP.replace("{0}", this.title);
      html += transText;
  }
  html += "'>";
  
  if (this.popupManager.bEncHTML)
      html += toHTMLEntities(this.title);
  else
      html += this.title;
          
   html += "</div></td>";
  
  //MIN MAX
  if (this.isResizable)
  {
      html += "<td align='";
      if (this.popupManager.isRTL())
      		html += "left";
      else
          html += "right"; 
      
      html += "' class='urPopTitleAreaResize'>";
      html += "<div tabindex=\"0\" border='0' id='ptrPopupToggleIconId' onkeypress='if(event.keyCode==13){thisPopup.toggleMinMax();};'";
      html += " onClick='thisPopup.toggleMinMax()' class='urPopFrameMax'><img src='" + ur_system.mimepath + "1x1.gif' style='width:16px;height:16px'";
      
      var sTitle = "Resize";
      if (ur_system.is508)
      {
          sTitle += " - " + ur_txt[ur_language].SAPUR_B + " - " + ur_txt[ur_language].SAPUR_B_TUT;
      }
      html += " title='" + sTitle + "'>";
      html += "</div></td>";
  }
  
  //CLOSE BUTTON
  if (this.hasCloseButton == true)
  {
      html += "<td align='";
      if (this.popupManager.isRTL())
          html += "left";
      else
          html += "right";

      html += "' class='urPopTitleAreaClose'><div onkeypress='if(event.keyCode==13||event.keyCode==32){thisPopup.popupManager._closePopup(thisPopup,\"CANCEL\")};' id=\"headerCancel\" tabindex=\"0\" border='0' onClick='thisPopup.popupManager._closePopup(thisPopup,\"CANCEL\")' class='urPopFrameClose'";
      
      var sTitle = "Cancel";
      if (ur_system.is508)
      {
          sTitle += " - " + ur_txt[ur_language].SAPUR_B + " - " + ur_txt[ur_language].SAPUR_B_TUT;
      }
      html += " title='" + sTitle + "'>";
      html += "<img src='" + ur_system.mimepath + "1x1.gif' style='width:16px;height:16px'></div></td>";
  }
  html += "</tr></table>";
  html += "</div>";
	
//now to the content
//take the outer measures and subtract "padding" constants
  height -= CONSTANTS.top + CONSTANTS.bottom;
  width  -= CONSTANTS.left + CONSTANTS.right;
	
  var messageIconClass = "";
  var message508Text = "";
  if (this.messageType.length > 0)
  {
      if (this.messageType == "PTR_WARNING")
      {
          messageIconClass = "urPopIconWarning";
          message508Text = "Warning";
      }
      else if (this.messageType == "PTR_INFORMATION")
      {
          messageIconClass = "urPopIconInformation";
          message508Text = "Information";
      }
      else if (this.messageType == "PTR_QUESTION")
      {
          messageIconClass = "urPopIconQuestion";
          message508Text = "Question";
      }
      else if (this.messageType == "PTR_SUCCESS")
      {
          messageIconClass = "urPopIconSuccess";
          message508Text = "Success";
      }
      else if (this.messageType == "PTR_ERROR")
      {
          messageIconClass = "urPopIconError";
          message508Text = "Error";
      }
      else if (this.messageType == "PTR_STOP" || this.messageType == "PTR_STOPP")
      {
          messageIconClass = "urPopIconStopp";
          message508Text = "Stopp";
      }
  }

  if (messageIconClass.length > 0)
  {
      html += "<table width='100%' style=\"table-layout:fixed;\" cellspacing='0' cellpadding='0' border='0'><tr>";
      html += "<td valign='top' id='messageIcon' tabindex=\"0\"";
      if (ur_system.is508 == true)
      {
          html += " title='" + message508Text + " - " + ur_txt[ur_language].SAPUR_IMG + "'";
      }
      html += " class='urPopIconArea " + messageIconClass + "'><img src='" + ur_system.mimepath + "1x1.gif' style='width:32px;height:32px' alt=''></td>";
      if (this.url.length == 0)
      {
          var align = this.messageType.length > 0 ? this.popupManager.isRTL() ?  "right" : "left": "center";
          html += "<td style='text-align:" + align + ";vertical-align:middle;'>";
          html += "<div id='iframePopupDivInnerFrame' tabindex=\"0\" style='overflow:auto;position:relative;left:0;top:1px;height:" + height + ";'>";
          html += "<table class='urPopFont' style='height:100%;' cellspacing='0' cellpadding='0' border='0'><tr><td><div class='urPopTxtStd urPopFont'>" + this.text + "</div></td></tr></table>";
          html += "</div></td>";
      }
      else
      {
          html += "<td><div id=\"iframePopupDivInnerFrame\" tabindex=\"0\" onfocus=\"thisPopup.innerIFrame.contentWindow.document.getElementById('ptrFocusStart').focus();\">&nbsp;</div></td>";
      }
      html += "</tr></table>";
  }
  else // no message icon
  {
      html += "<div id=\"iframePopupDivInnerFrame\" tabindex=\"0\"";
      if (this.url.length > 0)
      {
          html += " onfocus=\"thisPopup.innerIFrame.contentWindow.document.getElementById('ptrFocusStart').focus();\"";
      }
      html += " style=\"overflow:auto;position:relative;top:1px;width:" + width + ";height:" + height + ";\">";
      if (this.url.length == 0)
      {
          html += "<table class='urPopFont' style='height:100%;' cellspacing='0' cellpadding='0' border='0'><tr>";
          html += "<td valign='top' style='padding:16px 22px 16px 22px'><div class='urPopTxtStd urPopFont'>" + this.text + "</div></td>";
          html += "</tr></table>";
      }
      html += "</div>";
  }

  /*
  ptrMessageBox Styles:
  PTR_ABORTRETRYIGNORE :The messagebox contains Abort, Retry, and Ignore buttons.
  PTR_OK               :The messagebox contains OK button.
  PTR_NONE             :The messagebox contains Cancel button.
  PTR_CLOSE            :The messagebox contains Close button.
  PTR_OKCANCEL         :The messagebox contains OK and Cancel buttons.
  PTR_RETRYCANCEL      :The messagebox contains Retry and Cancel buttons.
  PTR_YESNO            :The messagebox contains Yes and No buttons.
  PTR_YESNOCANCEL      :The messagebox contains Yes, No, and Cancel buttons.
   */
  if (typeof(this.buttonStyle) == "number" || (typeof(this.buttonStyle) == "string" && this.buttonStyle.length > 0 && this.buttonStyle!= "PTR_NONE"))
  {
      html += '<table id="ptrToolbarArea" style="height:' + (CONSTANTS.bottom - CONSTANTS.borderSize) + 'px;width:100%" cellpadding="0" border="0" cellspacing="0" class="urPopTbarWhl urPopFont" >';
      html += '<tr>';
      
      html += '<td valign="top" nowrap class="urPopWaveBottom"><img border = "0" style = "height:1px;width:' + CONSTANTS.waveBottom + 'px" src = "' + ur_system.mimepath + '1x1.gif" ></td>';
      html += '<td valign="top" nowrap class="urPopWaveMid"><img border="0" style = "height:1px;width:' + CONSTANTS.waveMid + 'px" src = "' + ur_system.mimepath + '1x1.gif" ></td>';
      html += '<td nowrap class="urPopWaveTop" style="width:' + CONSTANTS.waveTop + 'px;">  <img border = "0" style="height:1px;width:' + CONSTANTS.waveTop + 'px" src="' + ur_system.mimepath + '1x1.gif">';
      
      //TD for buttons
      html += '<td valign="middle" align="right" nowrap class="urPopWaveTop">';
      html += '<table id="ptrToolbar" cellpadding="0" border="0" cellspacing="0" class="urPopFont"><tr><td valign="top" nowrap style="padding-top:4px" id="ptrToolbarContent" > ';
      
      html += _getButtonHTML(this.buttonStyle, this.index);
      
      
      html += '</tr></table></td>';
      
      if (ur_system.is508 == false && this.isResizable == true)
      {
          var align = "right";
          var padding = "left";
          if (this.popupManager.isRTL())
          {
              align = "left";
              padding = "right";
          }
          html += '<td nowrap style="width:' + CONSTANTS.waveResize + 'px;" class = "urPopWaveTop" valign = "bottom" align = "' + align + '" > ';
          html += '<div id="ptrPopupResizeIconId" class = "urPopFrameResize" onmousedown = "return thisPopup.startDrag(event,true);"><img src = "' + ur_system.mimepath + '1x1.gif" style = "width:17px;height: 17px "></div>';
      }
      else
      {
          html += '<td nowrap style="width:' + CONSTANTS.waveResize + 'px;" class = "urPopWaveTop"><img border = "0" style = "height:1px;width:22px" src = "' + ur_system.mimepath + '1x1.gif" > ';
      }
      html += '</table>';
  }
  else
  {
      html += '<table id="ptrToolbarArea" style="height:' + (CONSTANTS.bottom - CONSTANTS.borderSize) + 'px;width:100%" cellpadding="0" border="0" cellspacing="0" class="urPopTbarWhl urPopFont" >';
      html += '<tr>';
      
      html += '<td valign="top" nowrap class=""><img border = "0" style = "height:1px;width:' + CONSTANTS.waveBottom + 'px" src = "' + ur_system.mimepath + '1x1.gif" ></td>';
      html += '<td valign="top" nowrap class=""><img border="0" style = "height:1px;width:' + CONSTANTS.waveMid + 'px" src = "' + ur_system.mimepath + '1x1.gif" ></td>';
      html += '<td nowrap class="" style="width:' + CONSTANTS.waveTop + 'px;">  <img border = "0" style="height:1px;width:' + CONSTANTS.waveTop + 'px" src="' + ur_system.mimepath + '1x1.gif">';
      
      //TD for buttons
      html += '<td valign="middle" align="right" nowrap class="">';
      html += '<table id="ptrToolbar" cellpadding="0" border="0" cellspacing="0" class="urPopFont"><tr><td valign="top" nowrap style="padding-top:4px" id="ptrToolbarContent" > ';
      html += '</tr></table></td>';
      
      if (ur_system.is508 == false && this.isResizable == true)
      {
          var align = "right";
          var padding = "left";
          if (this.popupManager.isRTL())
          {
              align = "left";
              padding = "right";
          }
          html += '<td nowrap style="width:' + CONSTANTS.waveResize + 'px;" class = "" valign = "bottom" align = "' + align + '" > ';
          html += '<div id="ptrPopupResizeIconId" class = "urPopFrameResize" onmousedown = "return thisPopup.startDrag(event,true);"><img src = "' + ur_system.mimepath + '1x1.gif" style = "width:17px;height: 17px "></div>';
      }
      else
      {
          html += '<td nowrap style="width:' + CONSTANTS.waveResize + 'px;" class = ""><img width="22" border = "0" style = "height:1px;width:22px" src = "' + ur_system.mimepath + '1x1.gif" > ';
      }
      html += '</table>';
  }
      
  html += "</div></div><div tabindex=\"0\" onfocus=\"thisPopup.focusTitle();\"></div>";
  html += "</body>";
  
      
      
  if (this.url.length == 0)
      html += "<sc" + "ript>setTimeout(function(){thisPopup.forceInitialize();},0);" + "</sc" + "ript>";
  
  
  html += "</html>";
  
  
  outerIFrameWindow.document.onhelp = function(){return false;};
  outerIFrameWindow.document.write(html);
  outerIFrameWindow.thisPopup = this;
  
  //removed: mozilla
  if (this.popupManager.IE || navigator.userAgent.indexOf("Firefox") != -1)
  { 
    //not closing causes QTP to fail
    outerIFrameWindow.document.close();    
  }  
}

//-------------------------------------------------------------------------
URPopupWindow.prototype.forceInitialize = function()
{
    this.initialize(this.sourceWindow.ptrDialogObj,false);
}

//-------------------------------------------------------------------------
URPopupWindow.prototype.createIFrame = function(id)
{
    
    
    var iFrame = this.popupManager.getHostWindow().document.getElementById(id);
    if (iFrame == null)
    {
        iFrame = this.popupManager.getHostWindow().document.createElement("IFRAME");
    }
    
    
    iFrame.src = "javascript:void(0)";
    iFrame.setAttribute("frameBorder", "0");
    iFrame.setAttribute("id", id);
    iFrame.setAttribute("name", id);
    iFrame.setAttribute("tabIndex", "-1");
    iFrame.setAttribute("border", "no");
    iFrame.setAttribute("scrolling", "auto");
    iFrame.style.position = "absolute";
    iFrame.style.zIndex = "1001";
    iFrame.style.width = "0px";
    iFrame.style.height = "0px";
    iFrame.style.display = "block";
    iFrame.style.left = "0px";
    iFrame.style.right = "0px";
    iFrame.style.top = -4000;
    iFrame.style.overflow = "auto";
    
    if (!iFrame.parentNode)
      this.popupManager.getHostWindow().document.body.appendChild(iFrame);

    iFrame.src = this.getEmptyHoverUrl();
    return iFrame;
}
//-------------------------------------------------------------------------

URPopupWindow.prototype.enableFocusRect = function(enable)
{
    var innerIFrameWindow = this.innerIFrame.contentWindow;
    try
    {
        var oC={top:innerIFrameWindow.ur_get("ur-topfocus"),bottom:innerIFrameWindow.ur_get("ur-bottomfocus"),left:innerIFrameWindow.ur_get("ur-leftfocus"),right:innerIFrameWindow.ur_get("ur-rightfocus")};
        for (x in oC)
        {
            oC[x].style.display = enable ? "block" : "none";
        }
    }catch(e){}
}

//-------------------------------------------------------------------------

URPopupWindow.prototype.initialize = function(translationObj,resize)
{
    
    if (typeof(translationObj) != "undefined")
    {
        this.initLabels(translationObj);
        
        if (typeof(translationObj.sourceFocusId) == "string")
        {
            this.sourceFocusId = translationObj.sourceFocusId;
        }
    }
    
    var sourceWindow = this.sourceWindow;
    var innerIFrameWindow = null;
    if (this.innerIFrame != null)
    {
        innerIFrameWindow = this.innerIFrame.contentWindow;
        innerIFrameWindow.sourceWindow = sourceWindow;
        
        if (innerIFrameWindow.document.body.className.indexOf("urPopBdyEmp") < 0)
        	innerIFrameWindow.document.body.className += " urPopBdyEmp";
    }
    
    var width = this.getWidth();
    var height = this.getHeight();
    
    var viewportSize = this.popupManager.getViewPortSize(this.popupManager.getHostWindow());
    var scrollOffset = this.popupManager.getScrollOffset(this.popupManager.getHostWindow());
    var modalOffset = CONSTANTS.modalOffset;
    
    if (!this.isResized)
    {
        var currentWidth = this.getWidth();
        var currentHeight = this.getHeight();
        
        if (innerIFrameWindow != null)
        {
            //bugfix: using 1px led to unexpected large width calculations...
            this.innerIFrame.style.width = "150px";
            this.innerIFrame.style.height = "150px";
            
            
            if (this.isInitial)
            {
                //if the application provides initial values,
                //calculate the size depending on these
                //provides problems with wrapping tables, etc
                //also guarantees minsize
                
                if (this.desiredHeight != null)
                    this.innerIFrame.style.height = this.desiredHeight;
                
                if (this.desiredWidth != null)
                    this.innerIFrame.style.width = this.desiredWidth;
            }
            else if (this.popupManager.isRTL())
            {
              this.innerIFrame.style.width = this.desiredWidth;
            }
            
            
            
            if (this.popupManager.isRTL())
            {
                //workaround: focus rect disturbing in RTL
                this.enableFocusRect(false);
                //workaround: rtl-mode - you have to touch some element, else the calculation can fail delivering too large values for width
                var bg = innerIFrameWindow.document.body.style.backgroundColor;
                innerIFrameWindow.document.body.style.backgroundColor = "transparent";
                innerIFrameWindow.document.body.style.backgroundColor = bg;
            }
            
            var pageSize = this.popupManager.getPageSize(innerIFrameWindow.document);
            
            if (this.popupManager.isRTL())
            { 
                this.enableFocusRect(true);
            }
            
            pageSize.height += 21 + 29 + 4;
	        pageSize.width += 4; //+4 for outerborder
            
	        width = pageSize.width;
	        height = pageSize.height;
	    }
        
        if (this.messageType.length > 0)
            width += CONSTANTS.typeLeft;
        
        
        /* consider desired sizes if set */
        if (this.isInitial)
        {
            if (this.desiredHeight != null)
                height = Math.max(height,parseInt(this.desiredHeight));
            
            if (this.desiredWidth != null)
                width  = Math.max(width,parseInt(this.desiredWidth));
        }
        
        //constrain to viewport
        height = Math.min(height,viewportSize.height - modalOffset);
        width = Math.min(width,viewportSize.width - modalOffset);    
        
        //dont allow shrinking
        height = Math.max(height,currentHeight);
        width = Math.max(width,currentWidth);
        
	      //min size fix for loading animation and datepicker!
        height = Math.max(height,21 + 29 + 4 + 150);
        width = Math.max(width,4 + 160);        
        
        this.setWidth(width);
        this.setHeight(height);
        
        if (innerIFrameWindow != null)
        {
            
            var innerBody = innerIFrameWindow.document.body;
            innerIFrameWindow.document.body.scroll = "auto";
              
            var sw = innerBody.scrollWidth;
            var cw = innerBody.clientWidth;
            var ow = innerBody.offsetWidth;
            
            var sh = innerBody.scrollHeight;
            var ch = innerBody.clientHeight;
            var oh = innerBody.offsetHeight;
            
            if (ch < sh && this.isInitial)
            {
               
                width += 21;
                this.setWidth(width);
                
                if (!this.popupManager.IE)
                {
                    height += 1;
                    this.setHeight(height);
                }
                this.updateScrollBars();
            }
            
            
            
        }
    }   
    
    var position = this.getPosition();
    
    var left = position.left;
    var right = position.right;
    var top = position.top;
    
    if (this.isInitial)
    {
       
      //take initial values if existing else null
	    left = this.initLeft;
	    right = this.initRight;
	    top = this.initTop;
	    
	    if (left == null)
        left = scrollOffset.x  + viewportSize.width / 5 + this.index * modalOffset;
        
        
      if (right == null)
        right = scrollOffset.x  + viewportSize.width  / 5 + this.index * modalOffset;
           
      if (top == null)
        top = scrollOffset.y  + viewportSize.height  / 5  + this.index * modalOffset;
        
            
    }
    
    //reposition if the popup has not been moved
    if (!this.isMoved)
    {
  
      var bottomRight = scrollOffset;
      bottomRight.x += viewportSize.width - modalOffset/2;
      bottomRight.y += viewportSize.height - modalOffset/2;
          
      if (right + width > bottomRight.x)
          right = bottomRight.x - width- modalOffset/2;
      
      if (left + width > bottomRight.x )
          left = bottomRight.x - width- modalOffset/2;
      
    if (top + height > bottomRight.y )
        top = bottomRight.y  - height;
	
	}
	
	this.setPosition(left,right,top);
    
  if (resize == false && this.index == this.popupManager.getPopups().length - 1)
  {
      //on initial call resize == false
      this.popupManager.getPopups()[this.popupManager.getPopups().length-1].focusDefaultElement(translationObj);
  }  
  
  if (innerIFrameWindow != null)
      this.createFocusHelpers();
  
  if (this.isInitial)
  {
      this.popupManager.focusPopup(null);
      
      var that = this;
      var closeCallback = function(event)
      {
          if (!event)
              event = that.outerIFrame.contentWindow.event;
          
          if (!event && innerIFrameWindow)
              event = innerIFrameWindow.event;    
          
          //escape key
          if (event && event.keyCode == 27 && that.hasCloseButton)
          {
              if (event.preventDefault)
                event.preventDefault();//avoid cancelling of request
                
              that.popupManager._closePopup(that,"CANCEL");   
          }
      }
      
      helperAddEventListener(this.outerIFrame.contentWindow.document,"keypress", closeCallback);
      
      if (innerIFrameWindow)
          helperAddEventListener(innerIFrameWindow.document,"keypress", closeCallback);    
  }
  
  //fix for IE CSN: 02075023 2009: popup would show horizontal scrollbar initially
  if (this.innerIFrame)
      this.innerIFrame.contentWindow.document.body.style.overflow = "";
      
  //FIX for FF3: popup would appear behind PDF
  if (this.innerIFrame)
      this.innerIFrame.style.overflow = "";
  if (this.outerIFrame)
      this.outerIFrame.style.overflow = "";
  
  var that = this;
  setTimeout(function()
  {
      if (that.innerIFrame)
        that.innerIFrame.style.overflow = "auto";
      if (that.outerIFrame)
        that.outerIFrame.style.overflow = "auto";
      
      //fix for IE CSN: 02075023 2009: popup would show horizontal scrollbar initially
      if (that.innerIFrame)
        that.innerIFrame.contentWindow.document.body.style.overflow = "auto";
      
  },100);
  //ENDFIX
  
  this.isInitial = false;
  return innerIFrameWindow;
}

URPopupWindow.prototype.updateScrollBars = function()
{
  
  if (!this.innerIFrame)
    return;
  
  var innerBody = this.innerIFrame.contentWindow.document.body;
  
  var sw = innerBody.scrollWidth;
  var cw = innerBody.clientWidth;
  var ow = innerBody.offsetWidth;
  
  var sh = innerBody.scrollHeight;
  var ch = innerBody.clientHeight;
  var oh = innerBody.offsetHeight;
  
  var scroll = "no";
  if (sw > cw || sh > ch)
      scroll = "auto";
  
  this.innerIFrame.contentWindow.document.body.scroll = scroll;
  
}



URPopupManager.prototype._getIndexOfPopup = function(popup)
{
    for (var x = 0; x < this.getPopups().length; x++)
    {
        if (this.getPopups()[x] == popup)
            return x;
    }
    return null;
}
//-------------------------------------------------------------------------
//toggles between full screen and free float mode
URPopupWindow.prototype.toggleMinMax = function()
{	
    
  //mark as moved to prevent automatic cascading when another popup is opened
  this.isMoved = true;
  
  var outerWindow = this.outerIFrame.contentWindow;
  var iframePopupDivHeaderTextObj =  outerWindow.document.getElementById("iframePopupDivHeader");
  var titleAnimationDiv = this.popupManager.getHostWindow().document.getElementById("titleAnimationDiv");
  titleAnimationDiv.innerText = outerWindow.document.getElementById("iframePopupDivHeaderText").innerText;

  var height = iframePopupDivHeaderTextObj.clientHeight;
  
  var bodyLeft = this.popupManager.getHostWindow().document.body.scrollLeft;
  var bodyRight = this.popupManager.getHostWindow().document.body.scrollWidth - document.body.clientWidth - document.body.scrollLeft;
  var bodyWidth = this.popupManager.getHostWindow().document.body.clientWidth;
  var bodyTop = this.popupManager.getHostWindow().document.body.scrollTop;
  
  var position = this.getPosition();
  
  var popupRight = position.right;
	var popupTop = position.top;
	var popupLeft = position.left;
	var popupWidth = null;
	
	if (this.isMaximized)
	{
		popupRight = parseInt(this.midRight);
		popupTop = parseInt(this.midTop);
		popupLeft = parseInt(this.midLeft);
		popupWidth = parseInt(this.midWidth);
		
	}
	else
	{
	    this.midWidth = this.getWidth();
	    this.midHeight = this.getHeight();
	}
		
    titleAnimationDiv.style.display = "block";
    titleAnimationDiv.style.zIndex = this.outerIFrame.style.zIndex + 10;
    
    this.animateMinMax(titleAnimationDiv, 20, popupLeft,  bodyLeft, popupRight, bodyRight, popupWidth, bodyWidth, popupTop, bodyTop, height); 
    
}

//-------------------------------------------------------------------------
// animation method
URPopupWindow.prototype.animateMinMax = function( titleAnimationDiv, countAnimation, popupLeft, bodyLeft, popupRight, bodyRight, popupWidth, bodyWidth, popupTop, bodyTop, height)
{
  var left = 0;
  var right = 0;
  var width = 0;
  var top = 0;
  
  var factor = this.isMaximized == false ? 20-countAnimation: countAnimation;
  
  left = popupLeft;
  right = popupRight;
      
  if (countAnimation > 0)
  {
      left = popupLeft - parseInt((popupLeft - bodyLeft) / 20) * factor;
      right = popupRight - parseInt((popupRight - bodyRight) / 20) * factor;
  }
  else if (this.isMaximized == false)
  {
      left = bodyLeft;
      right = bodyRight;
  }
  	
  //
  width = popupWidth;
  if (countAnimation > 0)
  {
      width = popupWidth - parseInt((popupWidth - bodyWidth) / 20) * factor;
  }
  else if (this.isMaximized == false)
  {
      width = bodyWidth;
  }
  
  //
  top = popupTop;
  if (countAnimation > 0)
  {
      top = popupTop - parseInt((popupTop - bodyTop) / 20) * factor;
  }
  else if (this.isMaximized == false)
  {
      top = bodyTop;
  }
  
  titleAnimationDiv.style.top = top + "px";
  titleAnimationDiv.style.left = left + "px";
  titleAnimationDiv.style.right = right + "px";
  titleAnimationDiv.style.width = width + "px";
  titleAnimationDiv.style.height = height + "px";
      
  countAnimation--;
  
  if (countAnimation >= 0)
  {
      var that = this;
      window.setTimeout(function()
      {
          that.animateMinMax( titleAnimationDiv, countAnimation, popupLeft, bodyLeft, popupRight, bodyRight,
              popupWidth, bodyWidth, popupTop, bodyTop, height); 
      }
      , 0);
  }
  else
  {
      var that = this;
      window.setTimeout(function()
      {
        var outerWindow = that.outerIFrame.contentWindow;
        var toggleIcon = outerWindow.document.getElementById("ptrPopupToggleIconId");
        var resizeIcon = outerWindow.document.getElementById("ptrPopupResizeIconId");
          
        titleAnimationDiv.style.display = "none";
        
    	  if (that.isMaximized == false)
    	  {
  		    that.isMaximized = true;
  	       
  	      var position = that.getPosition();
  	        	
	        that.midLeft = position.left;
	        that.midRight = position.right;
	        that.midTop = position.top;
        	
	        resizeIcon.className = "urPopFrameResizeHide";
	        toggleIcon.className = "urPopFrameMid";
        		        	
	        that.maximize();
        	
	        that.autoResizeHandler = function()
	        {
	            that.maximize();
	        }
        	
	        helperAddEventListener(that.popupManager.getHostWindow(),"resize",that.autoResizeHandler);
  	        	
    	  }
        else if (that.isMaximized == true)
        {
      	  that.isMaximized = false;
      	  resizeIcon.className = "urPopFrameResize";
      	  toggleIcon.className = "urPopFrameMax";
        	
      	  that.setPosition(that.midLeft,that.midRight,that.midTop);
      	  that.setWidth(that.midWidth);
      	  that.setHeight(that.midHeight);
        	
      	  if (that.autoResizeHandler)
      	  {
      	      helperRemoveEventListener(that.popupManager.getHostWindow(),"resize",that.autoResizeHandler);
      	      that.autoResizeHandler = null;
      	  }
        }
         
      }
      , 0);
      
  }
}


URPopupWindow.prototype.maximize = function()
{
    
  var hostBody = this.popupManager.getHostWindow().document.body;
  
  var viewPortSize = this.popupManager.getViewPortSize(this.popupManager.getHostWindow());
  var pageSize = this.popupManager.getPageSize(this.popupManager.getHostWindow().document);
    
  var width = viewPortSize.width;//hostBody.clientWidth;
	var height = viewPortSize.height;//hostBody.clientHeight;
	var top = hostBody.scrollTop;
	var left = hostBody.scrollLeft;
  var right = hostBody.scrollWidth - hostBody.clientWidth - hostBody.scrollLeft;
	
	
	this.setPosition(left,right,top);
	this.setWidth(width);
	this.setHeight(height);
	
}
//-------------------------------------------------------------------------
//api method called to adapt inner application size
URPopupManager.prototype.ptrResizeModalDialog = function(popupId, style, translationObj)
{
    //used for button texts
    if (typeof(translationObj) != "object")
    	translationObj = new Object();
    
    
    var currentIndex = this.getPopups().length - 1;
    
    //popid: external id from ABAP WD
    if (typeof(popupId) == "string" && popupId.length > 0)
    {
        for (var i = 0; i < this.getPopups().length; i++)
        {
            if (this.getPopups()[i].popupId == popupId)
            {
                currentIndex = i;
                translationObj.popupId = popupId;
                break;
            }
        }
    }
	var thePopup = this.getPopups()[currentIndex];
    if (thePopup.innerIFrame == null)
        return ;
    
    //avoid resizing on initial popup
    var ptrBodyLoadingObj = thePopup.innerIFrame.contentWindow.document.body;
    if (ptrBodyLoadingObj.id == "ptrBodyLoading")
        return;
    
   
   	//could be deleted
    if (thePopup.innerIFrame.contentWindow.document.body.className.indexOf("urPopBdyEmp") < 0)
    	thePopup.innerIFrame.contentWindow.document.body.className += " urPopBdyEmp";
    
    
    if (thePopup.innerIFrame != null)
    {
        //set focus
        thePopup.createFocusHelpers();
    }
		
	//dynamic replacement of buttons
    if (typeof(style) == "number")
    {
        if (typeof(thePopup.style) != "number" || thePopup.style != style)
        {
            thePopup.style = style;
            var html = "";
            for (var i = 0; i < style; i++)
            {
                html += _createButton(this.getPopups().length - 1, "BUTTON_" + i, "");
            }
           
            thePopup.outerIFrame.contentWindow.document.getElementById("ptrToolbarContent").innerHTML = html;
        }
    }
    //MIN-> max icon shown -> normal size
    
    var imgObj = thePopup.outerIFrame.contentWindow.document.getElementById("ptrPopupToggleIconId");
    if (imgObj == null || thePopup.isMaximized == false)
        this.ptrInitModalDialog(translationObj, true);
        
    if (thePopup.isMaximized)
      thePopup.updateScrollBars();    
    
}
//-------------------------------------------------------------------------

URPopupWindow.prototype.buttonClick = function(buttonDomRef,keyCode)
{
  if (buttonDomRef.getAttribute("status") == "enabled")
    this.popupManager._closePopup(this,keyCode);

}

function _createButton(index, keyCode, text)
{
    var html = '<span><a tabindex="0" href="javascript:void(0);" onmouseover="window.status=\'\';return true;" onfocus="window.status=\'\';return true;" onkeypress="if(event.keyCode==13||event.keyCode==32){thisPopup.buttonClick(this,\'' + keyCode + '\');};" ';
    html += 'onClick="thisPopup.buttonClick(this,\'' + keyCode + '\');" ';
    html += 'class="urBtnStd urPopFont" ';
    html += 'status="enabled" ';
    html += 'id="' + keyCode + '" title="' + text;
    if (ur_system.is508 == true)
        html += " - " + ur_txt[ur_language].SAPUR_B + " - " + ur_txt[ur_language].SAPUR_B_TUT;

    html += '">'+text;
    html += '</a><span style="width:2px;">&nbsp;</span></span>';
    
    
    return html;

    var classes = "urPopTbarBtnStd urPopFont";
       
    var html = 	'<span onmousedown="event.cancelBubble=true" class="urPopTbarItmBtn" id="' + keyCode + '-r" show="true" cancollapse="false" > ';
    html += '<a href="javascript:void(0);" onmouseover="window.status=\'\';return true;" onkeypress="if(event.keyCode==13||event.keyCode==32){this.click();};" ';
    html += 'onClick="thisPopup.popupManager._closePopup(thisPopup,\'' + keyCode + '\');" ';
    
    html += 'class="' + classes + '" ';
    html += 'status="enabled" ';
    html += 'id="' + keyCode + '" title="' + text;
    
    if (ur_system.is508 == true)
        html += " - " + ur_txt[ur_language].SAPUR_B + " - " + ur_txt[ur_language].SAPUR_B_TUT;
    
    html += '">';
    html += '<span style="white-space:nowrap;">' + text + '</span>';
    html += '</a>';
    html += '</span>';
   
    
    return html;
}
//-------------------------------------------------------------------------
//replaces the text of the button
URPopupWindow.prototype._ptrUpdateButton = function(buttonDefinition, buttonDomRef)
{
  
  if (typeof(buttonDefinition) == "undefined" || buttonDomRef == null)
  	return;
  
  var text = "";
  var tooltip = "";
  
  if (typeof(buttonDefinition.title) != "undefined" || typeof(buttonDefinition.tooltip) != "undefined")
  {
    tooltip = typeof(buttonDefinition.title) != "undefined" ? buttonDefinition.title : buttonDefinition.tooltip;
  }
  
  if (ur_system.is508 == true)
  {
      //button text
      text = buttonDefinition.text;
      
      //control type
      text += " - " + (ur_txt[ur_language].SAPUR_B?ur_txt[ur_language].SAPUR_B:ur_txt[ur_language].SAPUR_BUTTON);
      
      //tooltip
      if (tooltip != "" && tooltip != buttonDefinition.text)
        text += " - " + tooltip;
      
      //tutor text
      if (typeof(buttonDefinition.enabled) == "boolean" && !buttonDefinition.enabled)
      {
        text += " - " + ur_txt[ur_language].SAPUR_DISABLED;
      }
      else
      {
        text += " - " + ur_txt[ur_language].SAPUR_B_TUT;
      }
  }
  else
  {
      if (tooltip)
        text = tooltip;
      else
        text = buttonDefinition.text;
  }
  
  buttonDomRef.title = text;
  
  var html = "";
  if (typeof(buttonDefinition.image) == "object" && typeof(buttonDefinition.image.src) == "string")
  {
    html = '<img border="0" align="absmiddle" src=   "' + buttonDefinition.image.src + '"alt = "';
    if (typeof(buttonDefinition.image.alt) == "string")
    {
        html += buttonDefinition.image.alt;
    }
    else
    {
        html += buttonDefinition.image.src;
    }
    html += '">&nbsp;';
  }
  
  //enable disable button				
  if (typeof(buttonDefinition.enabled) == "boolean")
  {
    
    if (!buttonDefinition.enabled)
    {
      buttonDomRef.className = "urBtnStdDsbl urPopFont";
      buttonDomRef.setAttribute("status", "disabled");
      buttonDomRef.setAttribute("tabIndex", "-1");
    }
    else
    {
      buttonDomRef.className = "urBtnStd urPopFont";
      buttonDomRef.setAttribute("status", "enabled");
      buttonDomRef.setAttribute("tabIndex", "0");
    }
    
  }
  if (buttonDefinition.text)
    html += buttonDefinition.text;
  
  buttonDomRef.innerHTML = html;
}

//-------------------------------------------------------------------------

URPopupWindow.prototype.initLabels = function(translationObj)
{
    
  if (typeof(translationObj) == "undefined")
      return;
  
  var popupWindow = this.outerIFrame.contentWindow;

  if (typeof(this.buttonStyle) == "number")
  {
    for (var i = 0; i < this.buttonStyle; i++)
    {
     this._ptrUpdateButton(translationObj["BUTTON_" + i], popupWindow.document.getElementById("BUTTON_" + i));
    }
  }
  else
  {
    if (popupWindow.document.getElementById("ABORT"))
      this._ptrUpdateButton(translationObj.ABORT, popupWindow.document.getElementById("ABORT"));
    
    if (popupWindow.document.getElementById("CLOSE"))
      this._ptrUpdateButton(translationObj.CLOSE, popupWindow.document.getElementById("CLOSE"));
    
    if (popupWindow.document.getElementById("RETRY"))
      this._ptrUpdateButton(translationObj.RETRY, popupWindow.document.getElementById("RETRY"));
    
    if (popupWindow.document.getElementById("IGNORE"))
      this._ptrUpdateButton(translationObj.IGNORE,popupWindow.document.getElementById("IGNORE"));
    
    if (popupWindow.document.getElementById("OK"))
      this._ptrUpdateButton(translationObj.OK,  popupWindow.document.getElementById("OK"));
    
    if (popupWindow.document.getElementById("YES"))
      this._ptrUpdateButton(translationObj.YES, popupWindow.document.getElementById("YES"));
    
    if (popupWindow.document.getElementById("NO"))
      this._ptrUpdateButton(translationObj.NO,  popupWindow.document.getElementById("NO"));
      
    if (popupWindow.document.getElementById("CANCEL"))  
      this._ptrUpdateButton(translationObj.CANCEL, popupWindow.document.getElementById("CANCEL"));
  }
  
  var titlebar = popupWindow.document.getElementById("iframePopupDivHeaderText");
  
	//TITLE
  if (typeof(translationObj.title) != "undefined")
  {
    titlebar.innerHTML = translationObj.title;
    if (ur_system.is508 == true)
    {
       titlebar.title = ur_txt[ur_language].SAPUR_POPUP.replace("{0}", translationObj.title);
    }
    else
    {
      titlebar.title = translationObj.title;
    }
  }
  if (ur_system.is508 == true)
  {
    if (typeof(translationObj.accessibilityDescribtion) != "undefined")
    {
      titlebar.title = ur_txt[ur_language].SAPUR_POPUP.replace("{0}", translationObj.accessibilityDescribtion);
    }
    if (typeof(translationObj.accessibilityCancelButtonText) != "undefined")
    {
      var cancelButton = popupWindow.document.getElementById("headerCancel");
      
      if (cancelButton)
          cancelButton.title = translationObj.accessibilityCancelButtonText 
                             + " - " 
                             + ur_txt[ur_language].SAPUR_B 
                             + " - " 
                             + ur_txt[ur_language].SAPUR_B_TUT;
    }
    if (typeof(translationObj.accessibilityMessageIconText) != "undefined")
    {
      
      var messageIcon = popupWindow.document.getElementById("messageIcon");
      
      if (messageIcon)
          messageIcon.title = translationObj.accessibilityMessageIconText 
                              + " - " 
                              + ur_txt[ur_language].SAPUR_IMG;
    }
  }
}

//-------------------------------------------------------------------------
URPopupManager.prototype.ptrSetTitle = function(popupId, title)
{
    var currentIndex = null;
    for (var i = 0; i < this.getPopups().length; i++)
    {
        if (this.getPopups()[i].popupId == popupId)
        {
            currentIndex = i;
            break;
        }
    }
    if (currentIndex == null)
        return;
        
    this.getPopups()[currentIndex].initLabels({title: title});
}

//-------------------------------------------------------------------------
//return inner frame�s window
URPopupManager.prototype.ptrGetWinRefById = function(popupId)
{
  var urlWindow = null;
  
  for (var i = 0; i < this.getPopups().length; i++)
  {
    if (popupId == this.getPopups()[i].popupId)
    {
      urlWindow = this.getPopups()[i].innerIFrame.contentWindow;
      break;
    }
  }
  return urlWindow;
}

//-------------------------------------------------------------------------
//
URPopupManager.prototype.ptrInitDialogByWindow = function(urlWindow)
{
    this.ptrInitModalDialog( {popupId:ptrGetPopupId(urlWindow)} );
}

//-------------------------------------------------------------------------

URPopupManager.prototype.ptrInitDialogById = function(popupId)
{
    this.ptrInitModalDialog( {popupId: popupId} );
}

//-------------------------------------------------------------------------
//return popupId by inner window
URPopupManager.prototype.ptrGetPopupId = function(urlWindow)
{
    
  var popupId = null;
  for (var i = 0; i < this.getPopups().length; i++)
  {
      
    if (urlWindow == this.getPopups()[i].innerIFrame.contentWindow)
    {
      popupId = this.getPopups()[i].popupId;
      break;
    }
  }
  return popupId;
}

//-------------------------------------------------------------------------
//return popupId by inner window
URPopupManager.prototype.getPopupById = function(id)
{
    
  var popup = null;
  for (var i = 0; i < this.getPopups().length; i++)
  {
      
    if (id == this.getPopups()[i].popupId)
    {
      return this.getPopups()[i];
    }
  }
  return null;
}

//-------------------------------------------------------------------------

//called by framework
URPopupManager.prototype.ptrInitModalDialog = function(translationObj, resize)
{
	
	//resize == true -> caller of this method is ptrResizePopup
	if (this.getPopups().length == 0)
        return ;
    
  var currentIndex = this.getPopups().length-1;
  
  if (typeof(translationObj) != "undefined" && translationObj != null)
  {
    if (typeof(translationObj.popupId) != "undefined")
    {
      for (var i = 0; i < this.getPopups().length; i++)
      {
        if (this.getPopups()[i].popupId == translationObj.popupId)
        {
          currentIndex = i;
          
          break;
        }
      }
    }
  }
    
  if (typeof(resize) == "undefined")
    resize = false;
    
  var popup = this.getPopups()[currentIndex];
  
  popup.initialize(translationObj,resize);
  
 	var innerIFrameWindow = popup.innerIFrame.contentWindow;
 	innerIFrameWindow.sourceWindow = popup.sourceWindow;
 	return innerIFrameWindow;
}
//-------------------------------------------------------------------------
URPopupWindow.prototype.getWidth = function()
{
  var width = parseInt(this.outerIFrame.style.width);
  if (isNaN(width))
    width = 0;
  return width;
}
	
//-------------------------------------------------------------------------
URPopupWindow.prototype.getHeight = function()
{
  var height = parseInt(this.outerIFrame.style.height);
  if (isNaN(height))
      height = 0;
  return height;
    
}
//-------------------------------------------------------------------------


URPopupWindow.prototype.getPosition = function()
{
  var left = parseInt(this.outerIFrame.style.left);
  if (isNaN(left))
    left = 0;
  
  var right = parseInt(this.outerIFrame.style.right);
  if (isNaN(right))
    right = 0;
  
  var top = parseInt(this.outerIFrame.style.top);
  if (isNaN(top))
    top = 0;
  
  return {left:left,right:right,top:top};
}

//-------------------------------------------------------------------------	
URPopupWindow.prototype.setHeight = function(height)
{
  height = Math.max(height, 21 + 29 + 4 + 90); //90 => loading animation
  
  var outerWindow = this.outerIFrame.contentWindow;
  var outerBorderDiv = outerWindow.document.getElementById("iframePopupDivOuterFrame");
  var innerBorderDiv = outerWindow.document.getElementById("iframePopupDivInnerFrame");
  
  this.outerIFrame.style.height = height + "px";
  
  outerWindow.document.getElementById("urPopFrame2").style.height = (height - 4) + "px";
  
  outerBorderDiv.style.height = (height - 2) + "px";
  innerBorderDiv.style.height = (height - 1 - CONSTANTS.top - CONSTANTS.bottom) + "px";
  if (this.innerIFrame != null)
  {
    this.innerIFrame.style.height = (height - CONSTANTS.top - CONSTANTS.bottom) + "px";
  }
}


//-------------------------------------------------------------------------

URPopupWindow.prototype.setWidth = function( width)
{
    
  width = Math.max(width,this.getToolbarWidth());
  width = Math.max(width,210);
      
  var outerWindow = this.outerIFrame.contentWindow;
  var outerBorderDiv = outerWindow.document.getElementById("iframePopupDivOuterFrame");
  var innerBorderDiv = outerWindow.document.getElementById("iframePopupDivInnerFrame");
  var iframePopupDivHeaderTextObj = outerWindow.document.getElementById("iframePopupDivHeaderText");
  
  this.outerIFrame.style.width = width + "px";
  outerBorderDiv.style.width = width + "px";
  iframePopupDivHeaderTextObj.style.width = (width - 50)  + "px";
  
  if (!this.popupManager.IE)
  {
    outerBorderDiv.style.width = (width - 2) + "px";
    outerWindow.document.getElementById("urPopFrame2").style.width = (width - 4) + "px";
  }
  
  
  if (this.innerIFrame)
  {
	  var innerIFrameStyle = this.innerIFrame.style;
    if (this.messageType.length == 0)
    {
      innerIFrameStyle.width = (width - (CONSTANTS.left + CONSTANTS.right)) + "px";
        
    }
    else
    {
      if (this.popupManager.isRTL())
      {
        innerIFrameStyle.width = (width- CONSTANTS.left	- CONSTANTS.typeRight) + "px";
      }
      else
      {
    	  innerIFrameStyle.width = (width - CONSTANTS.right - CONSTANTS.typeLeft) + "px";
      }
    }
  }
  else 
  {
      
    var innerWidth = width - CONSTANTS.left - CONSTANTS.right;
    if (this.messageType.length > 0)
    {
      if (this.popupManager.isRTL())
      {
        innerBorderDiv.style.width = (innerWidth - CONSTANTS.typeRight) + "px";
      }
      else
      {
        innerBorderDiv.style.width = (innerWidth - CONSTANTS.typeLeft) + "px";
      }
    
    }
    else
    {
      innerBorderDiv.style.width = innerWidth + "px";
        
    }
      
  }
}

//-------------------------------------------------------------------------

URPopupManager.prototype.focusTitle = function(popupId)
{
  for (var x = 0; x < this.getPopups().length; x++)
  {
    if (this.getPopups()[x].popupId == popupId)
    {
      return this.getPopups()[x].focusTitle();
    }    
  }
  return false;
}
//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
URPopupWindow.prototype.focusTitle = function()
{
  try
  {
    this.outerIFrame.contentWindow.document.getElementById("iframePopupDivHeader").focus();
  }
  catch (e)
  {
    return false;
  }          
  return true;
}

//-------------------------------------------------------------------------

URPopupWindow.prototype.focusDefaultElement = function(obj)
{
	
	if (ur_system.is508)
	{
	  this.focusTitle();
	  return;
	}
	
  var outerWindow = this.outerIFrame.contentWindow;
  var focusId = "iframePopupDivHeader";
  
  if (!obj)
    return;
  	
	if (typeof(obj.applFocusId) != "undefined")
	{
    focusId = obj.applFocusId;
    try
    {
        this.innerIFrame.contentWindow.document.getElementById(focusId).focus();
    }
    catch (e)
    {
        outerWindow.document.getElementById("iframePopupDivHeader").focus();
    }
  }
  else if (typeof(obj.defaultFocusId) != "undefined")
  {
    focusId = obj.defaultFocusId;
    try
    {
        outerWindow.document.getElementById(focusId).focus();
    }
    catch (e)
    {
        
        if (outerWindow.document.getElementById("iframePopupDivHeader").focus)
          outerWindow.document.getElementById("iframePopupDivHeader").focus();
        
    }
  }
  
}

//-------------------------------------------------------------------------

function _canFocus(domElement)
{
   if (domElement == null)
      return false;
  if (!domElement.tagName)
      return false;
      
  var tag = "," + domElement.tagName + ",";
  
  if ((tag == ",INPUT,") && (domElement.type == "hidden" || domElement.disabled))
     return false;
  
  var search = ",A,BODY,BUTTON,FRAME,IFRAME,INPUT,ISINDEX,OBJECT,SELECT,TEXTAREA,";
  
  if (!domElement.getAttribute)
      return false;
  
  if (search.indexOf(tag) >  -1)
  {   
      return (parseInt(domElement.getAttribute("tabIndex")) >= 0);
  }
      
  if (domElement.getAttribute("ti") != null)
  {
      return (parseInt(domElement.getAttribute("ti")) >= 0);
  }
  return false;
}

//-------------------------------------------------------------------------

URPopupWindow.prototype.focusLastElement = function()
{
  try
  {
    //side effect -> focus button
    if(this._findChildFocus(this.outerIFrame.contentWindow.document.getElementById('ptrToolbar'))==false)
    {
        this.focusElement(this.innerIFrame.contentWindow.document.getElementById('ptrFocusEnd').previousSibling,false);
    }
 
  }
  catch(e){};
   
}
//-------------------------------------------------------------------------
URPopupWindow.prototype._findChildFocus = function(ele)
{
  var hasFocus = false;
  for (var i = 0; hasFocus == false && i < ele.childNodes.length; i++)
  {
    if (_canFocus(ele.childNodes.item(i)) == true)
    {
      ele.childNodes.item(i).focus();
      return true;
    }
    hasFocus = this._findChildFocus(ele.childNodes.item(i));
  }
  return hasFocus;
}

//-------------------------------------------------------------------------

URPopupWindow.prototype.focusElement = function(ele,next)
{
   
  do
  {
    if (ele.id != 'urFrames' && ele.id != 'sapPopup_Event')
    {    
       
      //log(ele.innerHTML +" --> " + _canFocus(ele) + "<br>");
      if (_canFocus(ele))
      {
        ele.setAttribute("tabIndex",0);
        try
        {
          ele.focus();
          return true;
        }
        catch (e){};
      }
                  
      var x = next? ele.firstChild:ele.lastChild;
    
      if (x && this.focusElement(x,next))
         return true;   
    }
    
    if (next)
        ele = ele.nextSibling;
    else
        ele = ele.previousSibling;    
     
  }
  while (ele != null);
  
  return false;
}

//-------------------------------------------------------------------------


URPopupWindow.prototype.createFocusHelpers = function()
{
  var documentBody = this.innerIFrame.contentWindow.document.body;

  var spanFocusStart2 = null;
  if (this.innerIFrame.contentWindow.document.getElementById("ptrFocusStart2") == null)
  {
      
    spanFocusStart2 = this.innerIFrame.contentWindow.document.createElement("SPAN");
    spanFocusStart2.id = "ptrFocusStart2";
    spanFocusStart2.tabIndex = "0";
    var that = this;
    helperAddEventListener(spanFocusStart2,"focus",function(){try{that.outerIFrame.contentWindow.document.getElementById('iframePopupDivHeader').focus();}catch(e){};});
    documentBody.insertBefore(spanFocusStart2, documentBody.childNodes[0]);
  }
  
  if (this.innerIFrame.contentWindow.document.getElementById("ptrFocusStart") == null)
  {
      
    var spanFocusStart = this.innerIFrame.contentWindow.document.createElement("SPAN");
    spanFocusStart.id = "ptrFocusStart";
    spanFocusStart.tabIndex = "0";
    var that = this;
    helperAddEventListener(spanFocusStart,"focus",function(){try{that.focusElement(spanFocusStart2.nextSibling,true);}catch(e){};});
    documentBody.insertBefore(spanFocusStart, documentBody.childNodes[0]);
  }
  
  if (this.innerIFrame.contentWindow.document.getElementById("ptrFocusEnd") == null)
  {
    var spanFocusEnd = this.innerIFrame.contentWindow.document.createElement("SPAN");
    spanFocusEnd.id = "ptrFocusEnd";
    spanFocusEnd.tabIndex = "0";
    
    var that = this;
    var method = function()
    {
      try
      {
        //side effect -> focus button
        if( that._findChildFocus(that.outerIFrame.contentWindow.document.getElementById('ptrToolbar'))==false)
        {
            that.outerIFrame.contentWindow.document.getElementById('iframePopupDivHeader').focus();
        }
     
      }
      catch(e){};
   }
    
   helperAddEventListener(spanFocusEnd,"focus",method);
   documentBody.appendChild(spanFocusEnd);
  }
   
}

//-------------------------------------------------------------------------

URPopupManager.prototype.ptrGetSourceWindow = function(urlWindow)
{
    if (this.getPopups().length == 0)
        return urlWindow;

    var currentIndex = this.getPopups().length - 1;
    if (typeof(urlWindow) != "undefined")
    {
        for (var i = 0; i < this.getPopups().length; i++)
        {
            if (urlWindow == this.getPopups()[i].innerIFrame.contentWindow)
            {
                currentIndex = i;
            }
        }
    }
    
    return this.getPopups()[currentIndex].sourceWindow;
}

//--------------------------------------------------------------------
URPopupWindow.prototype.getPopupStyles = function()
{
  //if ur_system.stylepath is relative
  //make it absolute to the application's window
  var abs = this.sourceWindow.location.href;
  
  var stylepathUrl = ur_system.stylepath;
  var stylepathArray = ur_system.stylepath.split("/");
  if (stylepathArray[stylepathArray.length - 2] != "ur")
  {
      stylepathUrl += "ur/";
  }
  var stylesheet = stylepathUrl + "ur_dia_" + ur_system.browser_abbrev + ".css";
  
  return this.relativeToAbsolutePath(stylesheet,abs);
}
//--------------------------------------------------------------------
URPopupWindow.prototype.getFoundationStyles = function()
{
  //if ur_system.stylepath is relative
  //make it absolute to the application's window
  var abs = this.sourceWindow.location.href;
  
  var stylepathUrl = ur_system.stylepath;
  var stylepathArray = ur_system.stylepath.split("/");
  if (stylepathArray[stylepathArray.length - 2] != "ur")
  {
      stylepathUrl += "ur/";
  }
  //fc_ causes problems 
  var stylesheet = stylepathUrl + "ur_" + ur_system.browser_abbrev + ".css";
  
  return this.relativeToAbsolutePath(stylesheet,abs);
}
//--------------------------------------------------------------------
URPopupWindow.prototype.getEmptyHoverUrl = function()
{
    var abs = this.sourceWindow.location.href;
    var rel = ur_system.emptyhoverurl;
    
    return this.relativeToAbsolutePath(rel,abs);
}
//--------------------------------------------------------------------
URPopupWindow.prototype.relativeToAbsolutePath = function(relativeURL,baseURL)
{
    
  if(relativeURL.indexOf("http:/"+"/") !=-1 ) return relativeURL;
	if(relativeURL.indexOf("https:/"+"/") !=-1) return relativeURL;    
  if(relativeURL.indexOf("file:/"+"/") !=-1) return relativeURL;    
    
  if (relativeURL.indexOf("./") == -1) 
  {
	    
    if (baseURL.indexOf("?")!=-1) 
    {
      baseURL = baseURL.substring(0,baseURL.indexOf("?"));
    }
    
    if(relativeURL.indexOf("/") == 0) 
    {
      //relative to root
      var urlParts = baseURL.split("/"+"/");
      var domain = urlParts[1].substring(0,urlParts[1].indexOf("/"));
      var baseURLPath = urlParts[0] + "/"+"/" + domain;
      
      return baseURLPath + relativeURL;
    }
    else
    {
      //relative to base path
      var baseURLPath = baseURL.substring(0,baseURL.lastIndexOf("/")+1);
      return baseURLPath + relativeURL;
    }
	    
  }
    
    var baseURLPath = baseURL;
    
    if (baseURLPath.indexOf("?") != -1) 
      baseURLPath = baseURLPath.substring(0,baseURLPath.indexOf("?"));
            
    baseURLPath = baseURLPath.substring(0,baseURLPath.lastIndexOf("/"));
    
    var relativeURLDots = relativeURL.substring(0,relativeURL.lastIndexOf("./")+2);
    
    while(relativeURLDots.lastIndexOf("..")>-1) 
    { //erase all double dots
      baseURLPath = baseURLPath.substring(0,baseURLPath.lastIndexOf("/"));
      relativeURLDots = relativeURLDots.substring(0,relativeURLDots.lastIndexOf(".."))+"/";
    }
  
    if (relativeURLDots.lastIndexOf("./")>-1) 
    {
        
      relativeURLDots = relativeURLDots.substring(0,relativeURLDots.lastIndexOf("./"))+"/";
      if (relativeURLDots.lastIndexOf("./")>-1) 
      {
        showError (relativeURL + " is not a valid relative url.");
      }
    }
    //build absolut path
    strNewAbsPath = baseURLPath + relativeURLDots + relativeURL.substring(relativeURL.lastIndexOf("./")+2,relativeURL.length);
    return strNewAbsPath;

}


//-------------------------------------------------------------------------
//public api used by abap (popupId)
URPopupManager.prototype.ptrCloseModalDialog = function(popupId, okCode)
{
  if (typeof(okCode) == "undefined")
  {
    okCode = null;
  }
  var currentIndex = this.getPopups().length - 1;
  if (typeof(popupId) != "undefined" && popupId.length > 0)
  {
    for (var i = 0; i < this.getPopups().length; i++)
    {
      if (this.getPopups()[i].popupId == popupId)
      {
        currentIndex = i;
      }
    }
  }
  this._closePopup(this.getPopups()[currentIndex],okCode);
}

//-------------------------------------------------------------------------
URPopupManager.prototype._closePopup = function(thePopup,okCode)
{
  var close = (okCode == null)? true : thePopup.callback("ptrOnHideModalDialog",[okCode]);
  if (close == false)
  	return;
  
  if (thePopup.innerIFrame)
  {
    //force hiding of popups like datepicker etc.
    try
    {
        thePopup.innerIFrame.contentWindow.sapUrMapi_PopupMenu_hideAll();
    }
    catch (e)
    {
    }
  }
  
  if (thePopup.autoResizeHandler)
  {
    helperRemoveEventListener(this.getHostWindow(),"resize",thePopup.autoResizeHandler);
    thePopup.autoResizeHandler = null;
  }
  

  this._unblockActiveXControls();
  
  
  //last open popup sets focus back
  if (this.getPopups().length == 1)
  {
    //set focus back to calling element
    try
    {
      var sourceWindow = thePopup.sourceWindow;
      if (typeof(thePopup.sourceFocusId) == "string" && thePopup.sourceFocusId.length > 0)
      {
        sourceWindow.document.getElementById(thePopup.sourceFocusId).setActive();
        sourceWindow.document.getElementById(thePopup.sourceFocusId).focus();
      }
      else
      {
        sourceWindow.document.body.setActive();
        sourceWindow.document.body.focus();
      }
    }
    catch (e){}
  }
  
  if (thePopup.outerIFrame.contentWindow.parent.popupRef)
    thePopup.outerIFrame.contentWindow.parent.popupRef[thePopup.popupId] = null;
  thePopup.outerIFrame.parentNode.removeChild(thePopup.outerIFrame);
  delete thePopup.outerIFrame;
  //same for inner
  if (thePopup.innerIFrame != null)
  {
    thePopup.innerIFrame.parentNode.removeChild(thePopup.innerIFrame);
    delete thePopup.innerIFrame;
      
  }
	
		
	var index = this._getIndexOfPopup(thePopup);
	this.getPopups().splice(index,1);		
	
	if (index > 0)
	{
    this.focusPopup(this.getPopups()[index-1]);
    this.getPopups()[index-1].focusDefaultElement(null);
	}
	else
	  this.focusPopup(null);
	
}
//-------------------------------------------------------------------------

URPopupManager.prototype._createBlocklayer = function()
{
  var documentBody = this.getHostWindow().document.body;
  var blockLayer = this.getHostWindow().document.getElementById("ptrBlockLayer");
  if (blockLayer == null)
  {    
      
    blockLayer = this.getHostWindow().document.createElement('div');
    blockLayer.id = "ptrBlockLayer";
    blockLayer.style.position = "absolute";
    blockLayer.style.left = "0px";
    blockLayer.style.right = "0px";
    blockLayer.style.top = "0px";
    blockLayer.style.display = "none";
    blockLayer.style.zIndex = "4999";
    blockLayer.tabIndex = "0";
    blockLayer.style.backgroundColor = "#FFFFFF";
    blockLayer.style.opacity = "0.6";
    blockLayer.style.filter = "alpha(opacity=60)";
	  
    var firstChild = documentBody.firstChild;
    documentBody.insertBefore(blockLayer,firstChild);
  }
  
  
  //animated title line
  var titleAnimationBlock = this.getHostWindow().document.getElementById("titleAnimationDiv");
  if (titleAnimationBlock == null)
 	{
    titleAnimationBlock = this.getHostWindow().document.createElement('div');
    titleAnimationBlock.id = "titleAnimationDiv";
    titleAnimationBlock.style.fontFamily = "font-family:Arial,Helvetica,sans-serif";
    titleAnimationBlock.style.fontWeight = "bold";
    titleAnimationBlock.style.fontStyle = "normal";
    titleAnimationBlock.style.backgroundColor = "#999999";
    titleAnimationBlock.style.fontSize = "11px";
    titleAnimationBlock.style.color = "#FFFFFF";
    titleAnimationBlock.style.position = "absolute";
    titleAnimationBlock.style.left = "0px";
    titleAnimationBlock.style.top = "0px";
    titleAnimationBlock.style.display = "none";
    titleAnimationBlock.style.zIndex = "5999";
    titleAnimationBlock.style.width = "100%";
    titleAnimationBlock.style.paddingTop = "2px";
    titleAnimationBlock.style.overflow = "hidden";
    titleAnimationBlock.style.textOverflow = "ellipsis";
    documentBody.appendChild(titleAnimationBlock);
  }
}

//-------------------------------------------------------------------------

URPopupManager.prototype._showBlocklayer = function(zIndex)
{
	this._resizeBlocklayer();
	var blockLayer = this.getHostWindow().document.getElementById("ptrBlockLayer");
	
  blockLayer.style.cursor = "not-allowed"; //progress wait
  blockLayer.style.display = "block";
  blockLayer.style.zIndex = zIndex;
  
  if (!ur_system.is508)
      blockLayer.style.backgroundColor = "#FFFFFF";
	
	blockLayer.oncontextmenu =  function(event)
  {
    event = event || window.event;
    if (event)
      event.cancelBubble=true;
        
    return false;             
      
  };
  var that = this;
  
  if (!blockLayer.onclick)
  {
    blockLayer.onclick = function()
    {
      var popups = that.getPopups();
      popups[popups.length-1].blink();
      
    };
  }
  if (!blockLayer.ondragstart)
  {
    blockLayer.ondragstart = function(event)
    {
      event = event || window.event;
      event.returnValue = false;
      return false;
    };
  }
  if (!blockLayer.onfocus)
  {
    blockLayer.onfocus = function()
    {
     
      var popups = that.getPopups();
      popups[popups.length-1].focusTitle();
         
    };
  }
	
	if (!this.focusCall)
  {    
    var that = this;
    this.focusCall = function()
    {
      var popups = that.getPopups();
      if (popups.length > 0)
        popups[popups.length-1].focusTitle();
    }
    helperAddEventListener(this.getHostWindow(),"focus", this.focusCall);
  }
	
	if (!this.resizeCall)
  {    
    var that = this;
    this.resizeCall = function()
    {
      that._resizeBlocklayer();
    }
    helperAddEventListener(this.getHostWindow(),"resize", this.resizeCall);
  }
    
}


//-------------------------------------------------------------------------

URPopupManager.prototype._resizeBlocklayer = function()
{
    
  var blockLayer = this.getHostWindow().document.getElementById("ptrBlockLayer");
  var hostBody = this.getHostWindow().document.body;
  
  var viewPortSize = this.getViewPortSize(this.getHostWindow());
  
  var bodyScrollHeight = hostBody.scrollHeight;
  var bodyScrollWidth = hostBody.scrollWidth;
  var bodyClientHeight = viewPortSize.height;//hostBody.clientHeight;
  var bodyClientWidth = viewPortSize.width;
  
  blockLayer.style.height = Math.max(bodyScrollHeight, bodyClientHeight) + "px";
  blockLayer.style.width = Math.max(bodyScrollWidth, bodyClientWidth) + "px";
    
}
//-------------------------------------------------------------------------

URPopupManager.prototype._hideBlocklayer = function()
{
	var blockLayer = this.getHostWindow().document.getElementById("ptrBlockLayer");
    
  blockLayer.style.cursor = "default";
  blockLayer.style.display = "none";
  
  if (typeof(this.resizeCall) != "undefined")
      helperRemoveEventListener(this.getHostWindow(),"resize",this.resizeCall);
  this.resizeCall = null; 

  if (typeof(this.focusCall) != "undefined")
      helperRemoveEventListener(this.getHostWindow(),"focus",this.focusCall);
  this.focusCall = null;
};

//-------------------------------------------------------------------------


URPopupWindow.prototype.blink = function(step)
{
  if (typeof(step) == "undefined")
  {
    this.blink(5);
    return;
  }
  
  var visibility = (step % 2 == 0)? "visible" : "hidden"; 
	
	if (this.outerIFrame)
	  this.outerIFrame.style.visibility = visibility;
	
	var that = this;
	if (step > 0)
	{
		setTimeout (function () { that.blink( step-1); },80); 
	}
	else
	{
	  this.focusTitle();
	}
  
}

//-------------------------------------------------------------------------


URPopupWindow.prototype.startDrag = function(event,resize)
{
  this.popupManager.focusPopup(this);
  
  if (this.isMaximized == true)
      return false;
  
  var outerIFrame = this.outerIFrame;
  var outerWindow = this.outerIFrame.contentWindow;
  var innerWindow = this.innerIFrame? this.innerIFrame.contentWindow : null;
      
  var srcElement;
  var theEvent;
  if (this.popupManager.IE)
  {
    if (outerWindow.event == null)
        return false;
    
    theEvent = outerWindow.event; 
    srcElement = theEvent.srcElement;
      
  }
  else
  {
    theEvent = event;
    srcElement = theEvent.target;
  } 
  
  this.popupManager.viewportSize = this.popupManager.getViewPortSize(this.popupManager.getHostWindow());
  this.popupManager.scrollOffset = this.popupManager.getScrollOffset(this.popupManager.getHostWindow());	
  

  this.moveData = 
  {
    srcElement: srcElement,
    startX: 	parseInt(outerIFrame.style.left),
    startXR: 	parseInt(outerIFrame.style.right),
    startY:		parseInt(outerIFrame.style.top), 
    startW: 	parseInt(outerIFrame.style.width), 
    startH: 	parseInt(outerIFrame.style.height),
    x: 			theEvent.screenX, 
    y: 			theEvent.screenY
  };
  
  this.resizeData = (resize == true);
  
  var that = this;
  this.movePopupCall = function(event)
  {
    if (!event)
        event = outerWindow.event;
    that.drag(event);
  }
  this.endPopupCall = function()
  {
    that.endDrag();
  }
  
  if (this.popupManager.IE)
  {
    srcElement.onmousemove = this.movePopupCall;
    srcElement.onmouseup = srcElement.onlosecapture = this.endPopupCall;
    srcElement.setCapture();
  }
  else
  {
    outerWindow.document.documentElement.addEventListener("mousemove",this.movePopupCall,false);
    outerWindow.document.documentElement.addEventListener("mouseup",this.endPopupCall,false);
    if(innerWindow!=null)
    {
      innerWindow.document.documentElement.addEventListener("mousemove",this.movePopupCall,false);
      innerWindow.document.documentElement.addEventListener("mouseup",this.endPopupCall,false);
    }
    this.popupManager.getHostWindow().document.documentElement.addEventListener("mousemove",this.movePopupCall,false);
    //using document captures events also outside the browser window
    this.popupManager.getHostWindow().document.addEventListener("mouseup",this.endPopupCall,false);
    
  
  }
  
  return false;
  
}
URPopupWindow.prototype.drag = function(event)
{
    
  if (!this.popupManager.IE)
       event.cancelBubble = true;
    
	var outerIFrame = this.outerIFrame;
	var innerIFrame = null;
	if (this.innerIFrame != null)
	{
		innerIFrame = this.innerIFrame;
		try
		{
		   //dont hide the loading animation
		   if (!this.innerIFrame.contentWindow._ur_LoadingPopup)
		    this.innerIFrame.contentWindow.sapUrMapi_PopupMenu_hideAll();
		}
		catch(e){};
	}
	
	var position = this.getPosition();
	var left = position.left;
	var right = position.right;
	var top = position.top;
	var width = this.getWidth();
	var height = this.getHeight();
			
  if (this.resizeData == true)
  {
    this.isResized = true;
    var minimumWidth = this.getToolbarWidth();
    
    if (this.innerIFrame != null)
      this.innerIFrame.contentWindow.document.body.scroll = "auto";
  
    var x = event.screenX - this.moveData.x;
    if (this.popupManager.isRTL())
    	x *= -1;
    
    var width = parseInt(this.moveData.startW + x);
    if (left + width < this.popupManager.scrollOffset.x + this.popupManager.viewportSize.width)
    {
        this.setWidth(width);
    }
    
    var height = this.moveData.startH + event.screenY - this.moveData.y;
    
    if (top + height < this.popupManager.scrollOffset.y + this.popupManager.viewportSize.height)
    {
       this.setHeight(height);    
    }
    
  }
  else
  {
  	this.isMoved = true;
  	
  	left = Math.max(this.moveData.startX + event.screenX - this.moveData.x, this.popupManager.scrollOffset.x);
  	right = Math.max(this.moveData.startXR - event.screenX + this.moveData.x,0);
  	top = Math.max(this.moveData.startY + event.screenY - this.moveData.y,this.popupManager.scrollOffset.y);
  	
  	left = Math.min(left, this.popupManager.scrollOffset.x+this.popupManager.viewportSize.width - this.getWidth());
  	top = Math.min(top, Math.max(0, this.popupManager.scrollOffset.y+this.popupManager.viewportSize.height - this.getHeight()));
  	
      
  }
     
  this.setPosition(left,right,top);
   
  return false;
}
URPopupWindow.prototype.endDrag = function()
{
  var innerWindow = null;
	if (this.innerIFrame != null)
	{
		innerWindow = this.innerIFrame.contentWindow;
	}
  
  var position = this.getPosition();
  
  var params = [this.popupId,position.left,position.right,position.top,this.getWidth(),this.getHeight()]
  
  if (this.resizeData == true)
      this.callback("ptrPopupResized",params);
  else    
      this.callback("ptrPopupMoved",params);
  
  var outerWindow = this.outerIFrame.contentWindow;    
  
  
  if (this.popupManager.IE)
  {
      var srcElement = this.moveData.srcElement;
      srcElement.releaseCapture();
      srcElement.onmousemove = srcElement.onmouseup = srcElement.onlosecapture =  null;
  }
  else
  {
    
    outerWindow.document.documentElement.removeEventListener("mousemove",this.movePopupCall,false);
    outerWindow.document.documentElement.removeEventListener("mouseup",this.endPopupCall,false);
    
    if(innerWindow != null)
    {
      innerWindow.document.documentElement.removeEventListener("mousemove",this.movePopupCall,false);
      innerWindow.document.documentElement.removeEventListener("mouseup",this.endPopupCall,false);
    }
    this.popupManager.getHostWindow().document.documentElement.removeEventListener("mousemove",this.movePopupCall,false);
    this.popupManager.getHostWindow().document.documentElement.removeEventListener("mouseup",this.endPopupCall,false);
  
  }
  
  this.movePopupCall = null;
  this.endPopupCall = null;
      
  this.popupManager._resizeBlocklayer();
}

URPopupManager.prototype.focusPopup = function(thePopup)
{
  this.focussedPopup = thePopup;
		
	var zIndex = 5000;
	var blocklayerZIndex = null;
		
	for (var x = 0; x <  this.getPopups().length; x++)
	{
		if (this.getPopups()[x])
		{
			var popup = this.getPopups()[x];
			
			
			//floating getPopups() are uppermost
			if (popup.dialogMode == "alwaysOnTop")
			{
				popup.setZIndex(zIndex++ +100);
			}
			else if (popup.dialogMode == "modal")
			{
				blocklayerZIndex = zIndex+=2;
				
				popup.setZIndex(zIndex+=2);
				
			}
			else if (popup.dialogMode == "amodal")
			{
				popup.setZIndex(zIndex+=2);
				
			}
		}
	}
	
	if (this.focussedPopup != null)
	{
		this.focussedPopup.setZIndex(zIndex+ 101);
		try
		{
		  var oHeaderDomRef = this.focussedPopup.outerIFrame.contentWindow.document.getElementById("iframePopupDivHeader");
		}
		catch(e){};
		
		if (oHeaderDomRef && oHeaderDomRef.focus)
		  oHeaderDomRef.focus();
	}
	if (blocklayerZIndex != null)
	{
    if (this.focussedPopup) 
        this.focussedPopup.callback("ptrShowBlocklayer",[]);
	        
		this._showBlocklayer(blocklayerZIndex);
	}
	else
	{
		this._hideBlocklayer();
		
	}
}

//-------------------------------------------------------------------------
URPopupWindow.prototype.setZIndex = function(zIndex)
{
	this.outerIFrame.style.zIndex = zIndex;
	
	if (!this.innerIFrame)
		return;
	
	this.innerIFrame.style.zIndex = zIndex+1;
}
//-------------------------------------------------------------------------

URPopupWindow.prototype.callback = function(methodName,parameters)
{
    
  var res = null;
  if (this.innerIFrame)
  {
    var iframeInnerPopupWindow = this.innerIFrame.contentWindow;
    try
    {
  	  //call to inner popup api
      res = iframeInnerPopupWindow[methodName].apply(iframeInnerPopupWindow,parameters);
    }
    catch (e)
    {};
  }

  var sourceWindow = this.sourceWindow;
  if (res == null)
  {
    try
    {
      //call to mother application
      res = sourceWindow[methodName].apply(sourceWindow,parameters);
    }
    catch (e)
    {};
  }
  return res;
}


//-------------------------------------------------------------------------
URPopupWindow.prototype.getToolbarWidth = function()
{
	var toolbarWidth = 0;
	try
	{
	  toolbarWidth += parseInt(this.outerIFrame.contentWindow.document.getElementById("ptrToolbar").scrollWidth);
	}
	catch(e){}
	
	return toolbarWidth 
		    + CONSTANTS.left 
		    + CONSTANTS.right 
		    + CONSTANTS.waveBottom 
		    + CONSTANTS.waveMid 
		    + CONSTANTS.waveTop 
		    + CONSTANTS.waveResize;	
}
//-------------------------------------------------------------------------

URPopupWindow.prototype.setPosition = function(left, right, top)
{
	this.left = left + "px";
  this.right = right + "px";
  this.top = top + "px";

  var outerIFrame = this.outerIFrame;
  
  outerIFrame.style.right = right + "px";
  outerIFrame.style.left = left + "px";
  outerIFrame.style.top = top + "px";
  
  if (!this.innerIFrame)
	  return;
	
	var innerIFrame = this.innerIFrame;
	
	innerIFrame.style.top = (top + CONSTANTS.top + (this.popupManager.IE?0:1)) + "px";
		
  if (this.messageType.length == 0)
  {
  	innerIFrame.style.left = (left + CONSTANTS.left) + "px";
    innerIFrame.style.right = (right + CONSTANTS.right) + "px";
              
  }
  else
  {
  	innerIFrame.style.left = (left + CONSTANTS.typeLeft) + "px";
    innerIFrame.style.right = (right + CONSTANTS.typeRight)  + "px";
  }
       
}

/*********************************** STATIC HELPER METHODS ************************************/



function _getButtonHTML(buttonStyle, index)
{
	
	var html = "";
	
	//free enumeration
  if (typeof(buttonStyle) == "number")
  {
    for (var i = 0; i < buttonStyle; i++)
    {
      html += _createButton(index, "BUTTON_" + i, "");
    }
  }
  //create buttons accordingly
  else
  {
    if (buttonStyle == "PTR_ABORTRETRYIGNORE")
        html += _createButton(index, "ABORT", "Abort");
    if (buttonStyle == "PTR_CLOSE")
        html += _createButton(index, "CLOSE", "Close");
    if (buttonStyle == "PTR_ABORTRETRYIGNORE" || buttonStyle == "PTR_RETRYCANCEL")
        html += _createButton(index, "RETRY", "Retry");
    if (buttonStyle == "PTR_ABORTRETRYIGNORE")
        html += _createButton(index, "IGNORE", "Ignore");
    if (buttonStyle == "PTR_OK" || buttonStyle == "PTR_OKCANCEL")
        html += _createButton(index, "OK", "OK");
    if (buttonStyle == "PTR_YESNO" || buttonStyle == "PTR_YESNOCANCEL")
        html += _createButton(index, "YES", "Yes");
    if (buttonStyle == "PTR_YESNO" || buttonStyle == "PTR_YESNOCANCEL")
        html += _createButton(index, "NO", "No");
    if (buttonStyle == "PTR_OKCANCEL" || buttonStyle == "PTR_RETRYCANCEL" || buttonStyle == "PTR_YESNOCANCEL")
        html += _createButton(index, "CANCEL", "Cancel");
  }	

	return html;
}


//----------------------------------------------------------------------------------------------------------------------------------------------------

function toHTMLEntities(text)
{

    text = text.replace( /&/g, "&amp;");
    text = text.replace( /"/g,"&quot;");
    text = text.replace( /'/g,"&apos;");
    text = text.replace( /</g, "&lt;");
    text = text.replace( />/g, "&gt;");
    return text; 
}

//----------------------------------------------------------------------------------------------------------------------------------------------------

URPopupWindow.prototype._getCSS = function()
{
	var css = "<st" + "yle>";
    
  if (this.popupManager.IE)
  {
    css += ".urPopFrameMax{background-position:center;background-repeat:no-repeat;vertical-align:middle;width:16px;height:16px;}";
    css += ".urPopFrameMid{background-position:center;background-repeat:no-repeat;vertical-align:middle;width:16px;height:16px;}";
    css += ".urPopFrameClose{background-position:center;background-repeat:no-repeat;vertical-align:middle;width:16px;height:16px;}";
    css += ".urPopFrameResizeHide{cursor:default;width:22px;height:17px;}";
    css += ".urPopFrameResize{width:22px;height:17px;background-repeat:no-repeat;background-position:";
    if (this.popupManager.isRTL())
        css += "left bottom;cursor:sw-resize;";
    else
        css += "right bottom;cursor:nw-resize;";
    css += "}";
    
 
    css += ".urPopTitleArea{border-width:0px 0px 1px 0px;border-style:solid;cursor:default;height:21px;padding:";
    if (this.popupManager.isRTL())
        css += "0px 5px 0px 1px";
    else
        css += "0px 1px 0px 5px";
    css += "}";
    css += ".urPopTitle{vertical-align:top;padding-top:1px;font-weight:bold;font-style:normal;font-size:11px;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;}";
  
    css += ".urPopTitleAreaHeader{padding-top:1px}";
    css += ".urPopTitleAreaResize{padding:";
    if (this.popupManager.isRTL())
        css += "0px 2px 0px 0px";
    else
        css += "0px 0px 0px 2px";
    css += ";width:18px;}";
    css += ".urPopTitleAreaClose{padding:";
    if (this.popupManager.isRTL())
        css += "0px 0px 0px 2px";
    else
        css += "0px 2px 0px 2px";
    css += ";width:20px;}";
    css += ".urPopIconArea{text-align:center;width:72px;padding:";
    if (this.popupManager.isRTL())
	    css += "0px 22px 0 18px;"
    else
        css += "0px 18px 0 22px;";
    
    css += "}";
  }
  else
  {
    css += ".urPopFrameMax{background-position:center;background-repeat:no-repeat;height:20px;}";
    css += ".urPopFrameMid{background-position:center;background-repeat:no-repeat;height:20px;}";
    css += ".urPopFrameClose{background-position:center;background-repeat:no-repeat;height:20px;}";
    css += ".urPopFrameResizeHide{width:22px;height:17px;}";
    css += ".urPopFrameResize{width:22px;height:17px;background-position:right bottom;cursor:nw-resize;background-repeat:no-repeat;}";
  
    css += ".urPopTitleArea{border-width:0px 0px 1px 0px;border-style:solid;cursor:default;height:21px;padding:0px 1px 0px 5px}";
    css += ".urPopTitle{vertical-align:top;padding-top:1px;font-weight:bold;font-style:normal;font-size:11px;white-space:nowrap;overflow:hidden;}";
    
    css += ".urPopTitleAreaHeader{padding-top:2px}";
    css += ".urPopTitleAreaResize{padding:0px 0px 0px 2px;width:16px;}";
    css += ".urPopTitleAreaClose{padding:0px 2px 0px 2px;width:16px;}";
    css += ".urPopIconArea{text-align:center;width:32px;padding-left:22px;padding-right:18px;}";
  }
  
  css += ".urPopIconArea{background-position:50% 16px;background-repeat:no-repeat;}";
  css += ".urPopFrame1{border-width:1px;border-style:solid;cursor:default;font-size:11px;}";
  css += ".urPopFrame2{border-width:1px;border-style:solid;cursor:default;font-size:11px;}";
  
  css += ".urPopWaveBottom{background-repeat:repeat-x;width:100%;}";
  css += ".urPopWaveMid{background-repeat:no-repeat;width:40px;}";
  css += ".urPopWaveTop{background-repeat:repeat-x;}";
  css += ".urPopFont{font-size:11px;}";
  css += ".urPopTxtStd{font-size:11px;font-style:normal;}";
  css += ".urPopBdyStd{overflow:hidden;margin:0px;}";
  css += "</st" + "yle>";
  return css;	
}

//---------------------------------------------------------------------------------
function helperAddEventListener(element,type, method)
{
  if (element.attachEvent)
	{
		
		element.attachEvent("on" + type, method);
	}
	else
	{
		element.addEventListener(type,method,false);
	}
}

function helperRemoveEventListener(element,type, method)
{
	if (element.detachEvent)
	{
		element.detachEvent("on" + type, method);
	}
	else
	{
		element.removeEventListener(type,method,false);
	}
}
//---------------------------------------------------------------------------------
URPopupManager.prototype.getPageSize = function(oDocument)
{
	var x,y;
	
	var test1 = oDocument.body.scrollWidth;
	var test2 = oDocument.body.offsetWidth;
	if (test1 > test2) // all but Explorer Mac
	{
		x = oDocument.body.scrollWidth;
		y = oDocument.body.scrollHeight;
	}
	else // Explorer Mac;
	     //would also work in Explorer 6 Strict, Mozilla and Safari
	{
		x = oDocument.body.offsetWidth;
		y = oDocument.body.offsetHeight;												
	}
	
	x = Math.max(oDocument.body.scrollWidth,oDocument.body.offsetWidth);
	y = Math.max(oDocument.body.scrollHeight, oDocument.body.offsetHeight);
	
	return {width:x,height:y};
	
}
//---------------------------------------------------------------------------------
URPopupManager.prototype.getViewPortSize = function(oWindow)//regarding scrollbars
{
	var width,height;
	if (document.addEventListener) 
	// all except Explorer
	{
		//this works
		width = oWindow.document.body.offsetWidth;
		
		//TODO: check this
		height = oWindow.innerHeight;
	}
	else if (oWindow.document.documentElement && oWindow.document.documentElement.clientHeight)
	// Explorer 6 Strict Mode
	{
		width = oWindow.document.documentElement.clientWidth;
		height = oWindow.document.documentElement.clientHeight;
	}
	else if (oWindow.document.body) 
	// other Explorers
	{
		width = oWindow.document.body.clientWidth;
		height = oWindow.document.body.clientHeight;
	}
	return {width:width,height:height};
}

//---------------------------------------------------------------------------------	
URPopupManager.prototype.getScrollOffset = function(oWindow)
{
	var body = oWindow.document.body;
	var x,y;
	if (oWindow.pageYOffset) // all except Explorer
	{
		x = oWindow.pageXOffset;
		y = oWindow.pageYOffset;
	}
	else if (oWindow.document.documentElement && oWindow.document.documentElement.scrollTop)
		// Explorer 6 Strict
	{
		
		x = oWindow.document.documentElement.scrollLeft;
		y = oWindow.document.documentElement.scrollTop;
	}
	else if (body) // all other Explorers
	{
		
		x = body.scrollLeft;
		
		if (this.isRTL())
		  x = body.scrollWidth - body.scrollLeft - body.clientWidth;
		
		y = body.scrollTop;
	}
			
	return {x:x,y:y};
	
}      
                                                 

//-------------------------------------------------------------------------
//API METHOD called by applicationcalled by framweork

URPopupManager.prototype.ptrRegisterActiveXComponent = function(sourceWindow, enable, ptrFunction)
{
    for (var i = 0; i < this.ptrActiveXArray.length; i++)
    {
        var item = this.ptrActiveXArray[i];
        if (item.sourceWindow == sourceWindow && item.enable == enable)
        {
            item.isActive = true;
            item.ptrFunction = ptrFunction;
            break;
        }
    }
    if (i >= this.ptrActiveXArray.length)
    {
        this.ptrActiveXArray[this.ptrActiveXArray.length] = 
        {
            sourceWindow: sourceWindow,
            enable: 			enable,
            ptrFunction:  ptrFunction, 
            isActive: 		true
        };
    }
}

//-------------------------------------------------------------------------
//called by framework
URPopupManager.prototype.ptrUnregisterActiveXComponent = function(sourceWindow)
{
    for (var i = 0; i < this.ptrActiveXArray.length; i++)
    {
        var item = this.ptrActiveXArray[i];
        if (item.sourceWindow == sourceWindow)
        {
            item.isActive = false;
        }
    }
}

//---------------------------------------------------------------------------------
URPopupManager.prototype._unblockActiveXControls = function()
{
  this._toggleActiveXControls(true);
}
URPopupManager.prototype._blockActiveXControls = function()
{
  this._toggleActiveXControls(false);
}

URPopupManager.prototype._toggleActiveXControls = function(enable)
{
  if (!this.IE)
    return;
  //Block ActiveX Controls...
  for (var i = 0; i < this.ptrActiveXArray.length; i++)
  {
      var item = this.ptrActiveXArray[i];
      if (item.isActive == true && item.enable == enable)
      {
          try
          {
              item.ptrFunction();
          }
          catch (e){}
      }
  }
}

/*********************************** PUBLIC API HERE!  ****************************************/

//-------------------------------------------------------------------------
//api constructor variant -> calls main method at the end of the day
URPopupManager.prototype.ptrMessageBox = function(sourceWindow, text, title, style, type)
{
    this.ptrShowModalDialog(sourceWindow, text, title, style, type);
}

//-------------------------------------------------------------------------
//api constructor variant -> calls main method at the end of the day
URPopupManager.prototype.ptrModalDialogUrl = function(sourceWindow, url, title, style, width, height)
{
    if (typeof(style) == "string" && style.length == 0)
        style = "PTR_OKCANCEL";
    
    this.ptrShowModalDialog(sourceWindow, '', title, style, '', width, height, url,  false, false, true, false, '', true);
}

//-------------------------------------------------------------------------
//api constructor variant -> calls main method at the end of the day
URPopupManager.prototype.ptrModalDialogWdr = function(sourceWindow, popupId, url, title, style, type,
    width, height, hasCloseButton, initLeft, initTop)
{
    if (typeof(style) == "string" && style.length == 0)
        style = "PTR_OKCANCEL";
        
    this.ptrShowModalDialog(sourceWindow, '', title, style, type, width, height, url, false, false, true, false, popupId, false, hasCloseButton,initLeft,initLeft,initTop);
}
//-------------------------------------------------------------------------
//api constructor variant -> calls main method at the end of the day
URPopupManager.prototype.ptrFloatingDialogWdr = function(sourceWindow, popupId, url, title, style, type, width, height, hasCloseButton, initLeft, initTop)
{
    if (typeof(style) == "string" && style.length == 0)
        style = "PTR_OKCANCEL";
          
    this.ptrShowModalDialog(sourceWindow, '', title, style, type, width, height, url, false, false, true, "alwaysOnTop", popupId, false, hasCloseButton,initLeft,initLeft,initTop);
}

//-------------------------------------------------------------------------
//api constructor variant -> calls main method at the end of the day
URPopupManager.prototype.ptrModelessDialogUrl = function(sourceWindow, url, title, style, width, height)
{
    this.ptrModlessDialogUrl(sourceWindow, url, title, style, width, height);
}

//-------------------------------------------------------------------------
//api constructor variant -> calls main method at the end of the day
URPopupManager.prototype.ptrModelessDialogWdr = function(sourceWindow, popupId, url, title, style, width, height, hasCloseButton, initLeft, initTop)
{
    
    //TODO: add position
    this.ptrModlessDialogWdr(sourceWindow, popupId, url, title, style, width, height, hasCloseButton, initLeft, initLeft, initTop);
}

//-------------------------------------------------------------------------
//api constructor variant -> calls main method at the end of the day
URPopupManager.prototype.ptrDialogWdr = function(isModal, sourceWindow, popupId, url, title, style, type, width, height, hasCloseButton)
{
    if (typeof(isModal) == "boolean")  
    {
        if (isModal == true)
            this.ptrModalDialogWdr(sourceWindow, popupId, url, title, style, type, width, height, hasCloseButton);
        else
            this.ptrModlessDialogWdr(sourceWindow, popupId, url, title, style, width,  height, hasCloseButton);
    }
    else
    {
        this.ptrFloatingDialogWdr(sourceWindow, popupId, url, title, style, type, width, height, hasCloseButton);        
    }
}

//-------------------------------------------------------------------------
//api constructor variant -> calls main method at the end of the day
URPopupManager.prototype.ptrModlessDialogUrl = function(sourceWindow, url, title, style, width, height)
{
    if (typeof(style) == "string" && style.length == 0)
    {
        style = "PTR_OKCANCEL";
    }
   
    this.ptrShowModalDialog(sourceWindow, '', title, style, '', width, height, url, false, true, true, true, '', true);
}

//-------------------------------------------------------------------------
//api constructor variant -> calls main method at the end of the day
URPopupManager.prototype.ptrModlessDialogWdr = function(sourceWindow, popupId, url, title, style, width, height, hasCloseButton)
{
    if (typeof(style) == "string" && style.length == 0)
        style = "PTR_OKCANCEL";
     
    this.ptrShowModalDialog(sourceWindow, '', title, style, '', width, height, url, false, true, true, true, popupId, true, hasCloseButton);
}

//-------------------------------------------------------------------------
//api constructor variant -> calls main method at the end of the day
URPopupManager.prototype.ptrModalDialog = function(sourceWindow, text, title, style, width, height)
{
    this.ptrShowModalDialog(sourceWindow, text, title, style, '', width, height, '',  false, false, true);
}

//-------------------------------------------------------------------------
//api constructor variant -> calls main method at the end of the day
URPopupManager.prototype.ptrLogout = function(sourceWindow, text, title)
{
    this.ptrShowModalDialog(sourceWindow, text, title, "PTR_YESNO", "PTR_QUESTION", 200, 120, '', true, true);
}

//-------------------------------------------------------------------------
//all variants call this method
//finalizes and corrects all parameters for the main method
URPopupManager.prototype.ptrShowModalDialog = function(sourceWindow, text, title, style, type, width,
    height, url, logout, mode, resize, aModal, popupId, isFix, hasCloseButton,initLeft,initRight,initTop)
{
    if (typeof(sourceWindow) != "object")
        return ;

    if (typeof(text) == "undefined")
        text = "Your request is being processed!";
    
    if (typeof(title) == "undefined")
        title = "SAP";
    
    if (typeof(style) == "undefined")
        style = "PTR_OK";
    
    if (typeof(type) == "undefined")
        type = "";
    
    if (typeof(width) == "undefined" || width == 0)
        width = null;
    
    if (typeof(height) == "undefined" || height == 0)
        height = null;
    
    if (typeof(url) == "undefined")
        url = "";
    
    if (typeof(logout) == "undefined")
        logout = false;
    
    if (typeof(mode) == "undefined")
        mode = false;
    
    if (typeof(resize) == "undefined")
        resize = false;
    
    if (typeof(aModal) == "undefined")
        aModal = false;
    
    var dialogMode = null;
    if (typeof(aModal) == "boolean" )
    {
        if (aModal == true)
        {
            dialogMode = "amodal";
        }
        else
        {
            dialogMode = "modal";
        }
    }
    else 
    {
        dialogMode = aModal;
    }
        
    
    if (typeof(popupId) == "undefined")
        popupId = "";
    
    if (typeof(isFix) == "undefined")
        isFix = false;
    
    if (typeof(hasCloseButton) != "boolean")
        hasCloseButton = true;
    
    if (typeof(initLeft) == "undefined")
        initLeft = null;
    
    if (typeof(initRight) == "undefined")
        initRight = null;
    
    if (typeof(initTop) == "undefined")
        initTop = null;
    
    this._ptrShowPopupWindow(sourceWindow,initLeft,initRight,initTop, width, height, url, title, text, style, type, logout, mode, resize, dialogMode, popupId, hasCloseButton);
}
