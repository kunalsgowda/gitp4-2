The folder testpages/samples/previews contains lsx files for preview examples for the
Theme Editor Plugin. They can be used in the test suite also, of course.

For use in the Theme Edito Plugin they must have theextension .lsx.jsp
Previews are available in the Eclipse plugin after adding a tag to the pageinfo files 
contained in this folder too.
Please make sure not to overwrite the pageinfo data from uicore\...\src\_urJspPreviewsForPortal\java\pageInfoXX0.xml
The texts and their translation have to be clarified

A sample entry of pageInfoXX0.xml:

	<group groupId="lsxtest" titleId="lsxtest">
      <preview textId="lsxtest" eventType="urpreview" event="ls/button/largebutton.lsx">
        <themePart>ls</themePart>
      </preview>
       <group groupId="ParGrpStylesTextAll" titleId="ParGrpStylesTextAll">
        <parameter name="parFontFamily" />
        <parameter name="parBaseFontSize" />
      </group>
    </group>

The attribute event must start with 'ls/' followed by the path to LSX file behind 'previews'.
The LSX "jsp/previews/ls/button/largebutton.lsx.jsp" is referred by
event="ls/button/largebutton.lsx".