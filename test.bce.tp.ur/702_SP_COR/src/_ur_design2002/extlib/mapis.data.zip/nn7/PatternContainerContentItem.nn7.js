//* ************************************************************************
//* PatternContainer
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function:			sapUrMapi_Pc_Resize
//* parameter:			sId : the Id of the control to target
//* return:				none
//* description:		Handles the onresize event from the controls and delegates
//*						it to the resize registry
//* ------------------------------------------------------------------------
function sapUrMapi_Pc_Resize(sId) {
	sapUrMapi_Resize_AddItem(sId, "sapUrMapi_PcTabSeq_Draw('" + sId + "')");
}

function sapUrMapi_Pc_RegisterCreate(sId) {
	sapUrMapi_PcTabSeq_Create(sId);
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_PcTabSeq_Draw('" + sId + "')");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Pc_toggle
//* parameter   : sId    - string - Id of the Tray
//							  e - EventObject - the events object
//* description : Expand / Collapses the tray
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_Pc_toggle(sId, sCtlType, e) {
	if ((e.type!="click") && (!sapUrMapi_checkKey(e,"keydown",new Array("32","30")))) return false;
	e.cancelBubble=true;
	var tbdy = ur_get(sId+"-tbd");
	var tbl = tbdy.parentNode;
	var tbar = ur_get(sId+"-tbar");
	var thead = ur_get(sId+"-hd");
	var ico = ur_get(sId+"-exp");
	if ( tbdy != null && ico != null ) {
		if ( tbdy.style.display == "none" ) {
			if (tbar) tbar.style.display = "";
			tbdy.style.display = "";
			//we have to re-create our object here or things will not work properly
			if (tbl.getAttribute("sized") != "true"){
				sapUrMapi_Pc_Create(sId, tbl.getAttribute("scrolltype"), false );
			}

			if (ico.className.indexOf("urPcExpClosedIco") != -1){ ico.className = ico.className.replace("urPcExpClosedIco", "urPcExpOpenIco");}
			if (thead != null && thead.className == "urPcHdBgClosedIco" ){ thead.className = "urPcHdBgOpenIco";}
			if (ur_system.is508) {
				ico.title=getLanguageText(sCtlType + "_COLLAPSE",new Array(thead.innerText,sCtlType + "_COLLAPSE_KEY"));
			}
		} else {
			if (tbar){ tbar.style.display = "none";}
			var helper = tbdy.parentNode.offsetWidth;
			tbdy.style.display = "none";
			tbdy.parentNode.style.width=helper+"px";

			if (ico.className.indexOf("urPcExpOpenIco") != -1 ){ ico.className = ico.className.replace("urPcExpOpenIco", "urPcExpClosedIco");}
			if (thead != null && thead.className == "urPcHdBgOpenIco" ){ thead.className = "urPcHdBgClosedIco";}
			if (ur_system.is508) {
				ico.title=getLanguageText(sCtlType + "_EXPAND",new Array(thead.innerText, sCtlType + "_EXPAND_KEY"));
			}
	}
		//GRP:  ur_focus(ico);
		sapUrMapi_focusElement(sId+"-exp")
}
	return true;
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Pc_showOptionMenu
//* parameter   : sTrayId    - string - Id of the Tray
//  							sTriggerId - string - The Id of the DOM Objects that
//                                      is the trigger for the menu
//  							sMenuContentId - string- The Id of the DOM Objects that
//                                         contains the menu
//  							enumPositionBehavior - string- Defines at which position the PopupMenu
//																			 will appear. Default is Right
//							  e - EventObject - the events object
//* description : Opens the Menu that is applied as option menu to that tray.
//								There is an icon shown if a menu is connected to the tray
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_Pc_showOptionMenu(sId,e) {
  var sTrayId=sId;
  var sTriggerId=sId+"-menu";
  var sMenuContentId=ur_get(sTriggerId).getAttribute("mid");
 	if (ur_system.direction=="rtl")
	  var enumPositionBehavior=sapPopupPositionBehavior.MENULEFT;
	else
	  var enumPositionBehavior=sapPopupPositionBehavior.MENURIGHT;
  var sControlType=sapUrMapi_getControlTypeFromObject(ur_get(sId));
	switch (sControlType) {
		case "PCTAB" :
			if (e.type!="click") {
				if (sapUrMapi_checkKey(e,"keydown",new Array("32","40","13"))){
					sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
				}
				else if (sapUrMapi_checkKey(e,"keydown",new Array("39","37"))) {
					var intTabCount = parseInt(ur_get(sTrayId + "-tbl").getAttribute("tabcount"));
					if (ur_system.direction=="rtl") {
					  sapUrMapi_PcTabs_focusItem(sTrayId,null,null,e.keyCode==37,e.keyCode==39);
					} else {
					  sapUrMapi_PcTabs_focusItem(sTrayId,null,null,e.keyCode==39,e.keyCode==37);
					}
					return;
				}
				else {
					return false;
				}
			}
			else {
				sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
			}
			break;
		case "PCSEQ" :
			if (e.type!="click") {
				if (sapUrMapi_checkKey(e,"keydown",new Array("32","40","13"))){
					sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
				}
				else if (sapUrMapi_checkKey(e,"keydown",new Array("39","37"))) {
					var intTabCount = parseInt(ur_get(sTrayId + "-tbl").getAttribute("tabcount"));
					if (ur_system.direction=="rtl") {
					  sapUrMapi_PcSeq_focusItem(sTrayId,null,null,e.keyCode==37,e.keyCode==39);
					} else {
					  sapUrMapi_PcSeq_focusItem(sTrayId,null,null,e.keyCode==39,e.keyCode==37);
					}
					return;
				}
				else {
					return false;
				}
			}
			else {
				sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
			}

			break;
		case "PCTIT" :
			if (e.type!="click") {
				if (sapUrMapi_checkKey(e,"keydown",new Array("32","40","13"))){
					sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
				}
			}
			else {
			  sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
			}

			break;
		default :
			return;
	}
}


//* ************************************************************************
//* PatternContainerTabs
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function:			sapUrMapi_PcTab_Resize
//* parameter:			sId : the Id of the control to target
//* return:				none
//* description:		Handles the onresize event from the controls and delegates
//*						it to the resize registry
//* ------------------------------------------------------------------------
function sapUrMapi_PcTab_Resize(sId) {
	sapUrMapi_Resize_AddItem(sId, "sapUrMapi_PcTabSeq_Draw('" + sId + "')");
}

function sapUrMapi_PcTabSeq_RegisterCreate(sId) {
	sapUrMapi_PcTabSeq_Create(sId);
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_PcTabSeq_Draw('" + sId + "')");
}

var sapUrMapi_PcTabSeq_Registry = new Array();
//* ------------------------------------------------------------------------
//* function:			sapUrMapi_PcTabSeq_Create
//* parameter:			sId : the Id of the control to target
//* return:				none
//* description:		Based on the scroll type parameter, resizes the control and sets the overflow
//*						property to allow for the correct horizontal scrolling mode.
//* ------------------------------------------------------------------------
function sapUrMapi_PcTabSeq_Create(sId) {
	sapUrMapi_PcTabSeq_Registry[sId] = false;

	//if this control is collapsed, we will need to initialize it again.
	var bCollapsed = ur_get(sId).getAttribute("collapsed");
	var tbl = ur_get(sId + "-tbd").parentNode;
	if (bCollapsed == "true"){
		tbl.setAttribute("sized", "false");
	}
	else{
		tbl.setAttribute("sized", "true");
	}

	//register with the resize handler
	sapUrMapi_Resize_AddItem(sId, "sapUrMapi_PcTabSeq_Draw('" + sId + "')");
	sapUrMapi_PcTabSeq_Registry[sId] = true;
}

//* ------------------------------------------------------------------------
//* function:			sapUrMapi_PcTabSeq_Draw
//* parameter:			none
//* return:				none
//* description:		This loops all the PatternContainerTab controls and
//*						resizes them
//* ------------------------------------------------------------------------
function sapUrMapi_PcTabSeq_Draw() {
	var divlist = new Array();
	var tbdylist = new Array();
	var iIdx = "null";

	for (var ctls in sapUrMapi_PcTabSeq_Registry) {
		if (ctls.indexOf("_") == 0) {continue;}
		var tbdy = ur_get(ctls + "-tbd");
		tbdylist[ctls] = tbdy;
		divlist[ctls] = null;
		if (tbdy.style.display == "none") {
			continue;
		}
		iIdx = ur_get(ctls + "-tbl").getAttribute("selectedtab");
		if (iIdx == -9999) {
			iIdx = "Title";
		}
		var div = ur_get(ctls + "-cnt-" + iIdx);
		if (div==null) return;
		divlist[ctls] = div;
		for (i = 0; i < div.childNodes.length; i++) {
			if (div.childNodes[i].nodeType == 1) {div.childNodes[i].style.display = "none";}
		}
	}

	for (var ctls in sapUrMapi_PcTabSeq_Registry) {
		if ((ctls.indexOf("_") == 0) || (tbdylist[ctls].style.display == "none")) {
			continue;
		}
		var div = divlist[ctls];
		var maxWidth = parseInt(div.offsetWidth);
		for (var i = 0; i < div.childNodes.length; i++) {
			if (div.childNodes[i].nodeType == 1) {div.childNodes[i].style.width = (maxWidth - 1) + "px";}
		}
	}

	for (var ctls in sapUrMapi_PcTabSeq_Registry) {
		if ((ctls.indexOf("_") == 0) || (tbdylist[ctls].style.display == "none")) {
			continue;
		}
		var div = divlist[ctls];
		for (var i = 0; i < div.childNodes.length; i++) {
			if (div.childNodes[i].nodeType == 1) {
			if (div.childNodes[i].style.display == "none") {
				div.childNodes[i].style.display = "";
				}
			}
		}
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PcTabs_getSelectedItemId
//* parameter   : sTabStripId
//* return      : the item id of the selected tabstrip. this is the id of
//                the td (cell).
//                the id is a concatination of sTabstripId the index of the
//                selected item and a text -itm-.
//*	sample			: ur_get(sapUrMapi_PcTabs_getSelectedItemId("yourid")
//* ------------------------------------------------------------------------
function sapUrMapi_PcTabs_getSelectedItemId(sTabStripId) {
  var oTabTable 	= ur_get(sTabStripId+"-tbl");
	var iSelTab			=	parseInt(oTabTable.getAttribute("selectedtab"));
	return sTabStripId+"-itm-"+iSelTab;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PcTabs_focusItem
//* parameter   : sTabStripId - Id of the TabStrip (required)
//							: iFocusIdx   - Index of the Item to focus (optional),
//														  if not set the selectedItem will be focused
//							: iTabCount - set if you bNext and bPrev use Count of all TabStrips - optional
//							: bNext - if set the next Item gets the focus - optional
//							: bPrev - if set the previous Item gets the focus - optional
//* return      : false
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_PcTabs_focusItem(sTabStripId,iFocusIdx,iTabCount,bNext,bPrev) {
	var oTabTable = ur_get(sTabStripId+"-tbl");
	if (isNaN(iFocusIdx)) {iFocusIdx = parseInt(oTabTable.getAttribute("selectedtab"));}
	if (isNaN(iTabCount)) {iTabCount = parseInt(oTabTable.getAttribute("tabcount"));}
	var ico = ur_get(sTabStripId + "-menu");

	var iNewIndex=iFocusIdx;
	if (ico != null && ico.getAttribute("hasfocus") == "true") {
		if (bNext) {
			iNewIndex = parseInt(oTabTable.getAttribute("starttab"));
		}
		if (bPrev) {
			iNewIndex = parseInt(oTabTable.getAttribute("starttab")) - 1 + parseInt(oTabTable.getAttribute("vistabs"));
		}
	}
	else {
		if (bNext) {
			if (iFocusIdx<iTabCount-1) iNewIndex=iFocusIdx+1;
			else iNewIndex=0;
		}
		if (bPrev) {
			if (iFocusIdx>0) iNewIndex=iFocusIdx-1;
			else iNewIndex=iTabCount-1;
		}
	}
	oFocusedTab = ur_get(sTabStripId+"-itm-"+iNewIndex);
	if (oFocusedTab.style.display != "none") {
		var iOldFoc     = parseInt(oTabTable.getAttribute("focusedtab"));
		if (!isNaN(iOldFoc)) {
			sapUrMapi_setTabIndex(ur_get(sTabStripId+"-itm-"+iOldFoc+"-txt"),-1);
		}
		var oFoc = ur_get(sTabStripId+"-itm-"+iNewIndex+"-txt");
		sapUrMapi_setTabIndex(oFoc,0);
		//GPR ur_focus(oFoc);
		sapUrMapi_focusElement(oFoc.id);
		oTabTable.setAttribute("focusedtab",iNewIndex);
		if (ico != null) {
			ico.setAttribute("hasfocus", "false");
		}
		if ((oFocusedTab.getAttribute("dsbl")=="true")&&(!ur_system.is508)) {
			sapUrMapi_PcTabs_focusItem(sTabStripId,iNewIndex,iTabCount,bNext,bPrev);
			return;
		}
	}
	else {
	    if (ico != null) {
			sapUrMapi_setTabIndex(ico,0);
			ico.setAttribute("hasfocus", "true");
			sapUrMapi_focusElement(ico.id);
	    }
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PcTabs_enter
//* parameter   : sId - Id of the TabStrip
//* description : with the 508 flag turned on this function will check for
//*               keydowns and skip the tabstrip or lead the user to
//								the selected tab item in case of tab, left or right arrow is pressed
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_PcTabs_enter (sId,e) {
	if (e.target.id==sId+"-skipstart") {
		if (sapUrMapi_Skip(sId,true,e)) return;
    if (!e.shiftKey) { //shift tabs not allowed here
		  if (sapUrMapi_checkKey(e,"keydown",new Array("9","39","37"))){
	      sapUrMapi_PcTabs_focusItem(sId);
			  e.cancelBubble=false;
		  }
	  }
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PcTabs_setActiveItem
//* parameter   : sId  - Id of the TabStrip
//  							iIdx - Index of the Item to activate (select)
//* description : selects an item of the tabstrip with the id sId
//* return      : true if the item was selected, else false
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_PcTabs_setActiveItem(sId,iIdx) {
	with (document) {
		var oTabTable 	= getElementById(sId+"-tbl");
		var tbdy = getElementById(sId+"-tbd");
		var iSelTab			=	parseInt(oTabTable.getAttribute("selectedtab"));
		var iTabLength	=	parseInt(oTabTable.getAttribute("tabcount"));
		var iCurIdx = parseInt(oTabTable.getAttribute("starttab"));
		var iVisTabs = parseInt(oTabTable.getAttribute("vistabs"));
		if (isNaN(iIdx)) return;
		if (getElementById(sId+"-itm-"+iIdx).getAttribute("dsbl")=="true") return false; //this item is disabled
		if ((iTabLength==1) || (iSelTab==iIdx)) return true; //tab is already selected
		var oCurrentTxt  = getElementById(sId+"-itm-"+iSelTab+"-txt");
		var oCurrentCell = getElementById(sId+"-itm-"+iSelTab);
		var oCurrentCon = getElementById(sId+"-itm-"+iSelTab+"-c");

		var oClickedTxt  = getElementById(sId+"-itm-"+iIdx+"-txt");
		var oClickedCell = getElementById(sId+"-itm-"+iIdx);
		var oClickedCon = getElementById(sId+"-itm-"+iIdx+"-c");

		var oFirstImage  = getElementById(sId+"-p");
		var oLastImage   = getElementById(sId+"-n");

		if (oCurrentCell != null){
			oCurrentCell.className="urPcTbsLabelOff"; //set current selected cell bgcolor to unselected
			oCurrentTxt.className = "urPcTbsTxtOff";  //set current selected cell font color to unselected
			if (oCurrentCon != null){
				oCurrentCon.className = "urPcConOff";	//set current connector cell to off
			}
		}

		oClickedTxt.className = "urPcTbsTxtOn";   //set new selected cell font color to selected
		oClickedCell.className="urPcTbsLabelOn";  //set new selected cell bgcolor to selected
		if (oClickedCon != null){
			oClickedCon.className = "urPcConOn";	//set new connector cell to on
		}

		// handle prev icons
		if (iCurIdx != 0){
			if (iIdx!=iCurIdx){oFirstImage.className="urPcTbsFirstAngOffPrevOn"; /*starting image in tab row unselected*/}
			else{oFirstImage.className="urPcTbsFirstAngOnPrevOn"; /*selected*/}
		}
		else{
			if (iIdx!=iCurIdx){oFirstImage.className="urPcTbsFirstAngOffPrevOff"; /*starting image in tab row unselected*/}
			else{oFirstImage.className="urPcTbsFirstAngOnPrevOff"; /*selected*/}
		}

		// handle next icons
		if (iCurIdx + iVisTabs >= iTabLength){
			if (iIdx == iTabLength - 1){
				oLastImage.className="urPcTbsLastOnNextOff"; /*selected*/
			}
			else{
				if (iIdx != (iCurIdx + iVisTabs - 1)){oLastImage.className="urPcTbsLastOffNextOff"; /*last image in tab row unselected*/}
				else{oLastImage.className="urPcTbsLastOnNextOff"; /*selected*/}
			}
		}
		else{  /* we shouldn't have next icons */
			if (iIdx != (iCurIdx + iVisTabs - 1))oLastImage.className="urPcTbsLastOffNextOn"; //last image in tab row unselected
			else{oLastImage.className="urPcTbsLastOnNextOn"; /*selected*/}
		}

		//set the seperation images between the tabs to unselected states
		if (iSelTab == iCurIdx){
			getElementById(sId+"-itm-"+(iSelTab)+"-a").className="urPcTbsAngOffOff";
			getElementById(sId+"-itm-"+(iSelTab+1)+"-a").className="urPcTbsAngOffOff";
		} else  {
			getElementById(sId+"-itm-"+(iSelTab)+"-a").className="urPcTbsAngOffOff";
			if (iSelTab != iTabLength - 1){
				getElementById(sId+"-itm-"+(iSelTab+1)+"-a").className="urPcTbsAngOffOff";
			}
		}

		//set the seperation images between the tabs to selectedstates
		if (iIdx==iCurIdx){
			getElementById(sId+"-itm-"+(iIdx)+"-a").className="urPcTbsAngOffOn";
			getElementById(sId+"-itm-"+(iIdx+1)+"-a").className="urPcTbsAngOnOff";
		} else {
			getElementById(sId+"-itm-"+(iIdx)+"-a").className="urPcTbsAngOffOn";
			if (iIdx != iTabLength - 1) {
				getElementById(sId+"-itm-"+(iIdx+1)+"-a").className="urPcTbsAngOnOff";
			}
		}

		oTabTable.setAttribute("selectedtab",iIdx); //set custom attribute selectedtab to current index
		sapUrMapi_PcTabs_focusItem(sId,iIdx); //focus the item

		//switch the content of the tabs
		var oCurrentContent  = getElementById(sId+"-cnt-"+iSelTab);
		var oClickedContent  = getElementById(sId+"-cnt-"+iIdx);

		//set the width of the newly visible item
		if (tbdy.style.display != "none") {
			var maxwidth = parseInt(oCurrentContent.clientWidth);
			for (var i = 0; i < oClickedContent.childNodes.length; i++){
				oClickedContent.childNodes[i].style.width = (maxwidth - 1) + "px";
				}
			}

		//change the content and resize the vertical height
		oClickedContent.className = "urPcTbsDspSel";
		oCurrentContent.className = "urPcTbsDsp";


	}
	if (ur_system.is508) {
		oClickedTxt.title = getLanguageText("SAPUR_PCTABS_ITEM",new Array(oClickedTxt.innerText,"SAPUR_PCTABS_ITEM_SELECTED"));
		oCurrentTxt.title = getLanguageText("SAPUR_PCTABS_ITEM",new Array(oCurrentTxt.innerText,"SAPUR_PCTABS_ITEM_ENABLED"));
	}
	return true
}
//* ------------------------------------------------------------------------
//* function:			sapUrMapi_PcTabs_keySelect
//* parameter:	  sId : the Id of the control to target
//* return      : none
//* description:		Handles the keyboardevent
//* ------------------------------------------------------------------------
function sapUrMapi_PcTabs_keySelect(sId, iSelectedIdx, iTabCount,e) {
	if (sapUrMapi_checkKey(e,"keydown",new Array("39","37"))){
	  if (ur_system.direction=="rtl") {
	    sapUrMapi_PcTabs_focusItem(sId,iSelectedIdx,iTabCount,e.keyCode==37,e.keyCode==39);
		return;
	  } else {
		sapUrMapi_PcTabs_focusItem(sId,iSelectedIdx,iTabCount,e.keyCode==39,e.keyCode==37);
		return;
	  }
	}
	if (sapUrMapi_checkKey(e,"keydown",new Array("32"))){
		sapUrMapi_PcTabs_setActiveItem(sId,iSelectedIdx,0,false);
		return;
	}
}
//* ------------------------------------------------------------------------


//* ************************************************************************
//* PatternContainerScrollable Functions
//* ************************************************************************
/**
 * This handles scrolling single tabs through either direction.  It delegates
 * the actual transformation of HTML elements to other functions.
 *
 * @declare public
 * @param sId Sting The id of the control to check
 * @param iDir int The direction for the scrolling
 * @param sCtlType String One of the constants available in the system as a scrolling control type.
 */
function sapUrMapi_scrollItem( sId, iDir, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	if (iDir != -1 && iDir != 1){
		return false;
	}
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
	var diff = vistabs;

	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs - 1;}
	}

	if (lasttab != firsttab + vistabs - 1){
		diff = lasttab - firsttab;
	}

	if (iDir == 1){
		//scroll up
		if (lasttab == tabcount - 1){return false;}
		//first shift off the firsttab
		SCROLL_FUNCTIONS[sCtlType](sId, firsttab, false, true, false);
		//reset our first tab and show it
		firsttab += 1;
		SCROLL_FUNCTIONS[sCtlType](sId, firsttab, true, true, false);
		if (diff > 2) {
			//shift down or current last tab
			SCROLL_FUNCTIONS[sCtlType](sId, lasttab, true, false, false);
		}
		if (diff != 1) {
		//reset our last tab and show it
		lasttab += 1;
		SCROLL_FUNCTIONS[sCtlType](sId, lasttab, true, false, true);
	}
	else{
		//reset the last tab equal to the first tab
		lasttab = firsttab;
		SCROLL_FUNCTIONS[sCtlType](sId, lasttab, true, true, true);
		}

	}
	else{
		//scroll down
		if (firsttab == 0){return false;}
		//to handle odd tab groupings don't turn off the last tab unless we
		//have a full visible set
		if (diff >= vistabs - 1){
			//shift off the last tab
			SCROLL_FUNCTIONS[sCtlType](sId, lasttab, false, false, true);
			//reset our last tab and show it
			lasttab -= 1;
			SCROLL_FUNCTIONS[sCtlType](sId, lasttab, true, false, true);
		}
		if (diff > 1) {
		//hide our old first tab
		SCROLL_FUNCTIONS[sCtlType](sId, firsttab, true, false, false);
		//shift up our current tab
		firsttab -= 1;
		SCROLL_FUNCTIONS[sCtlType](sId, firsttab, true, true, false);
	}
		else {
		//shift up our current tab
    SCROLL_FUNCTIONS[sCtlType](sId, firsttab, true, false, true);
		firsttab -= 1;
		SCROLL_FUNCTIONS[sCtlType](sId, firsttab, true, true, true);
		}

	}
	//call the function to set the icons
	ICON_FUNCTIONS[sCtlType]( sId, firsttab, lasttab, tabcount );

	//now we have to reset the page information
	var newtabpage = Math.floor(firsttab / vistabs);
	oTabs.setAttribute("starttab", firsttab);
	oTabs.setAttribute("lasttab", lasttab);
	sapUrMapi_Pc_togglePager(sId)
}

/**
 * Scrolls the tabset by a "page" of items.
 *
 * @declare public
 * @param sId String The Id of the control to change.
 * @param iDir Int The direction of the page scroll, either -1/1.
 */
function sapUrMapi_pageItem( sId, iDir, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	if (iDir != 1 && iDir != -1){
		return false;
	}
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));

	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs-1;}
	}
	//see if we have any pages in the desired direction, if not return false
	if ((iDir == -1 && firsttab == 0) || ( iDir == 1 && lasttab == tabcount -1)){
		return false;
	}

	//change our current tabpage
	if (((iDir == 1) && ((tabpage + iDir) * vistabs) < (tabcount)) ||
		((iDir == -1) && (tabpage + iDir >= 0) )){
		tabpage = tabpage + iDir;
	}

	//get the upper and lower bounds of our visible page
	var lbound = Math.floor(tabpage * vistabs);
	var ubound = lbound + vistabs - 1;
	//if our ubound is greater than the tabcount, reset the ubound
	if (ubound > tabcount - 1){
		ubound = tabcount -1;
	}

	//loop over the tabs and turn off items outside of our visible range
	for (var i = 0; i < tabcount; i++){
		//turn off tabs outside of our bounds
		if (i < lbound || i > ubound){
			if (i == firsttab){
				SCROLL_FUNCTIONS[sCtlType](sId, i, false, true, false);
			}
			else if (i == lasttab){
				SCROLL_FUNCTIONS[sCtlType](sId, i, false, false, true);
			}
			else{
			   SCROLL_FUNCTIONS[sCtlType](sId, i, false, false, false);
			}
		}
		else{
		   if (i == lbound){
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, true, false);
		   }
		   else if (i == tabcount -1 || i == ubound){
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, false, true);
		   }
		   else{
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, false, false);
		   }
		}
	}
	//call the function to set the icons
	ICON_FUNCTIONS[sCtlType]( sId, lbound, ubound, tabcount );

	//re-assign our attributes
	oTabs.setAttribute("starttab", lbound);
	oTabs.setAttribute("lasttab", ubound);
	oTabs.setAttribute("tabpage", tabpage);
	sapUrMapi_Pc_togglePager(sId)
}

/**
 * Scrolls the tabset by a "page" of items.
 *
 * @declare public
 * @param sId String The Id of the control to change.
 * @param iDir Int The direction of the page scroll, either -1/1.
 */
function sapUrMapi_boundsItem( sId, iDir, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	if (iDir != 1 && iDir != -1){
		return false;
	}
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));

	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs-1;}
	}
	//see if we have any pages in the desired direction, if not return false
	if ((iDir == -1 && firsttab == 0) || ( iDir == 1 && lasttab == tabcount -1)){
		return false;
	}

	//change our current tabpage
	if (iDir == 1){
		tabpage = Math.ceil(tabcount / vistabs) - 1;
	}
	else{
		tabpage = 0;
	}

	//get the upper and lower bounds of our visible page
	var lbound = Math.floor(tabpage * vistabs);
	var ubound = lbound + vistabs - 1;
	//if our ubound is greater than the tabcount, reset the ubound
	if (ubound > tabcount - 1){
		ubound = tabcount -1;
	}

	//loop over the tabs and turn off items outside of our visible range
	for (var i = 0; i < tabcount; i++){
		//turn off tabs outside of our bounds
		if (i < lbound || i > ubound){
			if (i == firsttab){
				SCROLL_FUNCTIONS[sCtlType](sId, i, false, true, false);
			}
			else if (i == lasttab){
				SCROLL_FUNCTIONS[sCtlType](sId, i, false, false, true);
			}
			else{
			   SCROLL_FUNCTIONS[sCtlType](sId, i, false, false, false);
			}
		}
		else{
		   if (i == lbound){
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, true, false);
		   }
		   else if (i == tabcount -1 || i == ubound){
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, false, true);
		   }
		   else{
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, false, false);
		   }
		}
	}
	//call the function to set the icons
	ICON_FUNCTIONS[sCtlType]( sId, lbound, ubound, tabcount );

	//re-assign our attributes
	oTabs.setAttribute("starttab", lbound);
	oTabs.setAttribute("lasttab", ubound);
	oTabs.setAttribute("tabpage", tabpage);
	sapUrMapi_Pc_togglePager(sId)
}

/**
 * Scrolls the tabs by jumping to a particular tab and selecting that tab.
 *
 * @declare public
 * @param sId String The Id of the control to scroll.
 * @param iTab int The index of the tab to jump to.
 * @param sCtlType String The type of control being acted upon.
 */
function sapUrMapi_jumpItem( sId, iTab, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
	var seltab = parseInt(oTabs.getAttribute("selectedtab"));

	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs-1;}
	}

	//prevent unavailable values.
	if (iTab >= tabcount || iTab < 0){
		return false;
	}

	//get our new tab page
	var tabpage = Math.floor(iTab / vistabs);
	//get the upper and lower bounds of our visible page
	var lbound = Math.floor(tabpage * vistabs);
	var ubound = lbound + vistabs - 1;
	//if our ubound is greater than the tabcount, reset the ubound
	if (ubound > tabcount - 1){
		ubound = tabcount -1;
	}

	//loop over the tabs and turn off items outside of our visible range
	for (var i = 0; i < tabcount; i++){
		//turn off tabs outside of our bounds
		if (i < lbound || i > ubound){
			if (i == firsttab){
				SCROLL_FUNCTIONS[sCtlType](sId, i, false, true, false);
			}
			else if (i == lasttab){
				SCROLL_FUNCTIONS[sCtlType](sId, i, false, false, true);
			}
			else{
			   SCROLL_FUNCTIONS[sCtlType](sId, i, false, false, false);
			}
		}
		else{
		   if (i == lbound){
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, true, false);
		   }
		   else if (i == tabcount -1 || i == ubound){
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, false, true);
		   }
		   else{
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, false, false);
		   }
		}
	}

	//re-assign our attributes
	oTabs.setAttribute("starttab", lbound);
	oTabs.setAttribute("lasttab", ubound);
	oTabs.setAttribute("tabpage", tabpage);
	sapUrMapi_Pc_togglePager(sId)

	//TODO:  now select our item by calling the appropriate function
	//the signature for the methods needs to be the same all the time...
	SELECT_FUNCTIONS[sCtlType](sId, iTab, seltab, false);

	//call the function to set the icons
	ICON_FUNCTIONS[sCtlType]( sId, lbound, ubound, tabcount );
}

/**
 * This will show/hide a given tab element.
 *
 * @declare public
 * @param iIdx int The index of the tab to show or hide
 * @param bShow bool True to show, false to hide
 * @param bIsFirst bool True if the current tab is the first visible tab.
 * @param bIsLast bool True if the current tab is the last visible tab.
 */
function showTab(sId, iIdx, bShow, bIsFirst, bIsLast ){
	//get our HTML elements
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var tabimg = ur_get(sId + "-itm-" + iIdx + "-a");
	var tabcell = ur_get(sId + "-itm-" + iIdx);
	//get connector row if there is one
	var conimg = ur_get(sId + "-itm-" + iIdx + "-ca");
	var concell = ur_get(sId + "-itm-" + iIdx + "-c");
	if (bShow){
		//show the tab
		if (!bIsFirst && !bIsLast){
			tabimg.style.display = "";
			tabcell.style.display = "";
			if (concell != null){
				concell.style.display = "";
				conimg.style.display = "";
			}
		}
		else if (bIsFirst){
			tabimg.style.display = "none";
			tabcell.style.display = "";
			if (concell != null){
				concell.style.display = "";
				conimg.style.display = "none";
			}
		}
		else if (bIsLast && !bIsFirst){
			tabimg.style.display = "";
			tabcell.style.display = "";
			if (concell != null){
				concell.style.display = "";
				conimg.style.display = "";
			}
		}
	}
	else{
		//hide the tab
		tabimg.style.display = "none";
		tabcell.style.display = "none";
		if (concell != null){
			concell.style.display = "none";
			conimg.style.display = "none";
		}
	}
}

/**
 * Method to try and get the icons to change properly.
 *
 * @declare public
 * @param sId String The Id of the control we are working on.
 * @param firsttab int The index of the current first tab.
 * @param lasttab int The index of the current last tab.
 * @param tabcount int The current tabcount on the control.
 */
function setTabIcons( sId, firsttab, lasttab, tabcount ){
	var prev = ur_get(sId + "-p");
	var next = ur_get(sId + "-n");
	var first = ur_get(sId + "-itm-" + firsttab);
	var last = ur_get(sId + "-itm-" + lasttab);

	var prevtmp = prev.className;
	var nexttmp = next.className
	//change the prev tab first
	if (firsttab == 0){
		if (first.className.indexOf("LabelOn") != -1){
			prev.className = "urPcTbsFirstAngOnPrevOff";
		}
		else{
			prev.className = "urPcTbsFirstAngOffPrevOff";
		}
	}
	else{
		if (first.className.indexOf("LabelOn") != -1){
			prev.className = "urPcTbsFirstAngOnPrevOn";
		}
		else{
			prev.className = "urPcTbsFirstAngOffPrevOn";
		}
	}
	//change the next tab
	if (lasttab == tabcount - 1){
		if (last.className.indexOf("LabelOn") != -1){
			next.className = "urPcTbsLastOnNextOff";
		}
		else{
			next.className = "urPcTbsLastOffNextOff";
		}
	}
	else{
		if (last.className.indexOf("LabelOn") != -1){
			next.className = "urPcTbsLastOnNextOn";
		}
		else{
			next.className = "urPcTbsLastOffNextOn";
		}
	}

	prev.childNodes.item(0).className = "urPcTbsPreFirstAng";
	next.childNodes.item(0).className = "urPcTbsAfterLastAng";
}

// use function struct to allow easy factory model for show functions, to use, add a new TYPE:function pair
// which can get set from the server.
//  !! THESE *MUST* FOLLOW THE PRECEDING FUNCTIONS OR A RUNTIME ERROR WILL OCCUR !!
try{
SCROLL_FUNCTIONS = {PCTAB:showTab,PCSEQ:showItem};
ICON_FUNCTIONS = {PCTAB:setTabIcons,PCSEQ:setSeqIcons}
SELECT_FUNCTIONS = {PCTAB:sapUrMapi_PcTabs_setActiveItem,PCSEQ:sapUrMapi_PcSeq_setActiveItem}
}catch(ex){};


function debug_jumpItem(elm){
	for (var i = 0; i < elm.options.length; i++){
		if (elm.options[i].selected == true){
			sapUrMapi_jumpItem( elm.getAttribute("control"), i, elm.getAttribute('controltype'));
		}
	}
}

function sapUrMapi_Pc_togglePager(sId) {
  if (ur_get(sId+"-pag")!=null) {
    var sPagerId=ur_get(sId+"-pag").firstChild.id;
  } else {
    return;
  }
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
  var arrButtonArray = new Array();
	var arrStateArray = new Array();
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.BEGIN;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.PREVIOUS_PAGE;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.PREVIOUS_ITEM;
	if (firsttab!=0) {
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	} else {
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	}
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.END;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.NEXT_PAGE;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.NEXT_ITEM;
	if (lasttab!=tabcount-1) {
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	} else {
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	}
  sapUrMapi_Paginator_setStates(sPagerId,arrButtonArray,arrStateArray);
}