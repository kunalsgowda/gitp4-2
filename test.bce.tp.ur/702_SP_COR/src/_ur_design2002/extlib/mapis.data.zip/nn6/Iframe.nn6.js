//* ************************************************************************
//* Iframe
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Iframe_adaptSize
//* parameter   : sId  - Id of the Iframe control
//*             : oEvt - Event Object
//* return      : none
//* description	: Adapt the size of the Iframe to its content
//* ------------------------------------------------------------------------
function sapUrMapi_Iframe_adaptSize(sId, oEvt) {
  var oIf = ur_get(sId);
  if (oIf) {
    var iWidth = oIf.getAttribute("width"), 
        iHeight = oIf.getAttribute("height");
    if (iWidth == null || iHeight == null) {
      // use try catch if access to content document is denied
      try {
        var oIfBody = oIf.contentWindow.document.body;
	if (iWidth == null) 
          oIf.setAttribute("width", oIfBody.scrollWidth + 16);
        if (iHeight == null) 
          oIf.setAttribute("height", oIfBody.scrollHeight + 16);
      } 
      catch (e) {
        // nothing to do
      }
    }
  }
}
