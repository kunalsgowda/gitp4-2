
//* ************************************************************************
//* MenuBar
//* ************************************************************************
//HOVER
function sapUrMapi_MenuBar_hover(sId,e){
	var oTxt=ur_get(sId+"-txt");
	var oBtn=ur_get(sId+"-btn");
	var oMnuBar=ur_get(sId).parentNode;
	var sAi=oMnuBar.getAttribute("ai");
	
	if(ur_isSt(sId,ur_st.DISABLED)) return;
	
	if (oTxt.className.indexOf("Hover")==-1){
		oTxt.className+="Hover";
		oBtn.className+="Hover";
	}
	if(e.type=="mouseout"){
		oTxt.className=oTxt.className.replace("Hover","");
		oBtn.className=oBtn.className.replace("Hover","");
	}
	if(oPopup!=null){
		var sSrcPopup = oPopup.source.object.parentNode.getAttribute("id");
		var sMenu = oMnuBar.getAttribute("id");
		if (sSrcPopup == sMenu && sAi!=sId){
 			oTxt.parentNode.click();
			oMnuBar.setAttribute("ai",sId);
		}
	}
}

/* CLICK */
function sapUrMapi_MenuBarItem_click(sItemId,sPopupId,oEvt) {
  sapUrMapi_PopupMenu_showMenu(sItemId,sPopupId,sapPopupPositionBehavior.MENULEFT,oEvt);
  ur_EVT_cancel(oEvt);
}
