//* ************************************************************************
//* PopupTrigger
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupTrigger_hover
//* parameter   : sId - string id of the trigger
//*             : e   - Event Object
//* return      : none
//* description	: hovers the trigger and displays an arrow
//* ------------------------------------------------------------------------
function sapUrMapi_PopupTrigger_hover(sId,oEv) {
	var oT=ur_get(sId);
	var oCt=oT.childNodes[0];
	var sCt=oCt.getAttribute("ct");
	var sSt=oCt.className;
	var sIa=oT.getAttribute("ia");
	if (oEv.type=="mouseover") {
		if(sIa=="t"){
			oT.className = "urPopUpTrgWhl urPopUpTrgIndHover";
		}else{
			oT.className=oT.className.replace("urPopUpTrgInd","urPopUpTrgIndHover");
		}
		if (oEv.type=="focus") {
	      oT.setAttribute("opened","false");
	      oT.setAttribute("focused","true");
	    }
		if(sCt=="TV")oCt.className=sSt+" urPopUpTrHover";
	} 
	if (oEv.type=="mouseout"){
   	if (oT.getAttribute("opened")!="true"){
		  if (oT.getAttribute("focused")=="true"){
		  } else {
		    if(sIa=="t"){
				oT.className = "urPopUpTrgWhl";
			}else{
				oT.className=oT.className.replace("urPopUpTrgIndHover","urPopUpTrgInd");
			}
		  }
		  if (oEv.type=="blur") {
		    oT.setAttribute("focused","false");
		    oT.className = "urPopUpTrgWhl";
		  }
		}
	if(sCt=="TV"){
	sSt=sSt.split(" urPopUpTrHover");
	oCt.className=sSt[0];
	}
  }
	ur_EVT_cancelBubble(oEv);
  oEv.returnValue=true;
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupTrigger_openMenu
//* parameter   : sId - string id of the trigger
//*             : e   - Event Object
//* return      : none
//* description	: hovers the trigger and displays an arrow
//* ------------------------------------------------------------------------
function sapUrMapi_PopupTrigger_openMenu(sId,sMenuId,e) {
	if ((e.type!="click")&&(e.type!="contextmenu")) {
		if (!sapUrMapi_checkKey(e,"keydown",new Array("32","40"))) {
			ur_EVT_cancelBubble(e);
	    e.returnValue=true;
		  return false;
		}
	}
	if (ur_system.direction=="rtl") {
	  sapUrMapi_PopupMenu_showMenu(sId,sMenuId,sapPopupPositionBehavior.MENURIGHT,e);
	} else {
	  sapUrMapi_PopupMenu_showMenu(sId,sMenuId,sapPopupPositionBehavior.MENULEFT,e);
	}
  e.cancelBubble=false;
	if ((e.type=="contextmenu")) {
    e.returnValue=false;
  } else {
    e.returnValue=true;
  }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupTrigger_RegisterCreate
//* parameter   : sId - string - Id of the PopupTrigger
//* description : Registers the trigger with the create item registry to be
//*				  initialized when the page loads
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_PopupTrigger_RegisterCreate(sId) {
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_PopupTrigger_init('" + sId + "')");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupTrigger_init
//* parameter   : sId - string id of the trigger
//* return      : none
//* description	: checks whether a less than 100% is given to the content object
//* ------------------------------------------------------------------------
function sapUrMapi_PopupTrigger_init(sId){}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupTrigger_focus
//* parameter   : sId - string - Id of the PopupTrigger
//* description : 
//*				 
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_PopupTrigger_focus(sId,oEv){}
