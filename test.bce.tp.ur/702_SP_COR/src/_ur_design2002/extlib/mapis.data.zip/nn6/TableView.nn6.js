

//* ************************************************************************
//* TableView
//* ************************************************************************
//SELECTROW
function sapUrMapi_Table_selectRow(sTableId,iRow,e) {
  var oInput = ur_get(sTableId+'-itm-'+iRow);
  var oInputGrp = document.getElementsByName(oInput.name);
  if ((oInputGrp.length==1)&&(oInput.type!="radio")) {
    if (e.target.tagName=="IMG") oInput.checked = (!oInput.checked);
		var oImg = ur_get(oInput.id + "-img");
	  oImg.className = "urImgCbgImg";
		if (oInput.checked) oImg.className = "urImgCbgImgChk";
		// find corresponding row
		var oRow = oInput.parentNode;
		while(!oRow.getAttribute("rr")) {
			oRow=oRow.parentNode;
		}
		for (var n=0;n<oRow.cells.length;n++) {
			var oCell = oRow.cells[n];
			if (oInput.checked) {
			  oCell.setAttribute("unselectedclass",oCell.className);
			  //oCell.className = oCell.className + " urETbvCellSel";
			} else {
	  	  //oCell.className=oCell.getAttribute("unselectedclass");
			}
		}
  } else {
	  for (var i = 0; i < oInputGrp.length; i++){
	    var oImg = ur_get(oInputGrp[i].id + "-img");
	    if (oInputGrp[i]==oInput){
			  if (e.target.tagName=="IMG") oInput.checked=true;
			  if (e.target.tagName=="IMG") ur_focus(oInputGrp[i]);
		    oImg.className = "urImgRbgImgChk";
	    } else {
			 if (oImg.onclick) {
			 oInputGrp[i].checked=false;
	     oImg.className = "urImgRbgImg";
	    }
   }
  }
  }
	ur_EVT_cancelBubble(e);
}

function sapUrMapi_Table_getClickedRowIndex(sId,oEvent) {
 	 oSrc = oEvent.target;
   var obj = oEvent.target;
   while ( (obj!=null) && (obj.tagName!='TD') )
      obj = obj.parentNode;
   if(obj==null) return;
   var parent = obj.parentNode;
   var rowIndex = parent.getAttribute("rr");
   return parseInt(rowIndex);
}

function sapUrMapi_Table_getClickedColIndex(sId,oEvent) {
 	 oSrc = oEvent.target;
   var obj = oEvent.target;
   while ( (obj!=null) && (obj.tagName!='TD') )
      obj = obj.parentNode;
   var oCell = obj;
   while ( (obj!=null) && (obj.tagName!='TR') )
      obj = obj.parentNode;
   var oRow = obj;
   while ( (obj!=null) && (obj.tagName!='TABLE') )
      obj = obj.parentNode;
   var oTable = obj;
   if ( obj==null ) return;
   var idx = 0;
   while (oRow.childNodes.item(idx)!=oCell) {
   	 idx++;
   }
   var colidx =  idx - parseInt( oTable.getAttribute("nmi"));
   return colidx;
}

function sapUrMapi_Table_getClickedCellId(sId,oEvent) {
 	 oSrc = oEvent.target;
   var obj = oEvent.target;
   while ( (obj!=null) && (obj.tagName!='TD') )
      obj = obj.parentNode;
   var oCell = obj;
   var cellid =  oCell.getAttribute("id");
   return cellid;
}

function sapUrMapi_Table_keydown(sId,e){}

function sapUrMapi_Table_activate(sId,e){}
