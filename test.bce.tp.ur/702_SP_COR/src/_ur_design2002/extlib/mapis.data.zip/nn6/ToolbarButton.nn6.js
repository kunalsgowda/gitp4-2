var ur_replace_function=false;
var ur_replace_function_button_id="";
function sapUrMapi_ToolbarButton_openMenu( sButtonId, e){
	var sPopupId=ur_get(sButtonId+"-r").getAttribute("popup");
	if (ur_get(sPopupId)==null) return;
	if (ur_get(sButtonId+"-r").getAttribute("replaceable")=="true") {
	  ur_replace_function=true;
	  ur_replace_function_button_id=sButtonId;

	}
	if ((e.type!="click")&&(e.type!="contextmenu")) {
		if (!sapUrMapi_checkKey(e,"keydown",new Array("32","40"))) {
			ur_EVT_cancelBubble(e);
    	e.returnValue=true;
		  return false;
		}
	}
	if (ur_system.direction=="rtl") {
	  sapUrMapi_PopupMenu_showMenu(sButtonId+"-r",sPopupId,sapPopupPositionBehavior.MENURIGHT,e);
	} else {
	  sapUrMapi_PopupMenu_showMenu(sButtonId+"-r",sPopupId,sapPopupPositionBehavior.MENULEFT,e);
	}
  e.cancelBubble=false;
	if ((e.type=="contextmenu")) {
    e.returnValue=false;
  } else {
    e.returnValue=true;
  }
}
function sapUrMapi_ToolbarButton_setFunctionFromMenuItem(sMenuItemId) {
  if (ur_replace_function) {
  	var clickedItem = ur_get(sMenuItemId);
    var sImgSrc=""
    if (clickedItem.getElementsByTagName("img").length>0) {
      sImgSrc=clickedItem.getElementsByTagName("img").item(0).src;
    }
    var sText=clickedItem.getElementsByTagName("nobr").item(0).innerText;
    var effectedButtonId=ur_replace_function_button_id;
    ur_replace_function_button_id="";
    ur_replace_function=false;
    sapUrMapi_ToolbarButton_applyFunction( effectedButtonId, sText, sImgSrc, clickedItem.onclick)
  }
}
function sapUrMapi_ToolbarButton_applyFunction( sButtonId, sNewText, sNewImageSrc, fNewClickHandler){
  var effectedButton=ur_get(sButtonId);
  effectedButton.onclick=fNewClickHandler;
  effectedButton.onkeydown=fNewClickHandler;
  var sButtonContent=effectedButton.getElementsByTagName("nobr").item(0).innerHTML;
  if (effectedButton.getElementsByTagName("nobr").item(0).getElementsByTagName("img").length>0) {
    if (sNewImageSrc=="") {
      effectedButton.getElementsByTagName("nobr").item(0).innerHTML="<img height=\"12\" width=\"1\" border=\"0\" align=\"absmiddle\" src=\""+ur_system.mimepath+"1x1.gif\">"+sNewText
    } else {
      effectedButton.getElementsByTagName("nobr").item(0).innerHTML="<img border=\"0\" align=\"absmiddle\" src=\""+sNewImageSrc+"\">&nbsp;"+sNewText;
  }
  } else {
    effectedButton.getElementsByTagName("nobr").item(0).innerHTML=sNewText;
  }
 }

