ur_type={ActiveXContainer:"AX",ActiveXContainer_End:"AX_END",AppletContainer:"AP",AppletContainer_End:"AP_END",Button:"B",Button_Menu:"B_MNU",Button_MenuSection:"B_MNUSEC",Button_Toggle:"B_TG",BreadCrumb:"BRC",BreadCrumb_Item:"BRC_I",BreadCrumb_SingleLink:"BRC_SL",CheckBox:"C",ComboBox:"CB",ComboBox_DropDownListBox:"CB_DD",CheckBoxGroup:"CG",CheckBoxGroup_End:"CG_END",Caption:"CP",ContextualPanel:"CXP",ContextualPanel_Help:"CXP_H",ContextualPanel_Personalize:"CXP_P",ContextualPanel_End:"CXP_END",DateNavigator:"DN",DateNavigator_Month:"DN_MONTH",DateNavigator_Day:"DN_DAY",DateNavigator_Week:"DN_WEEK",DateNavigator_End:"DN_END",FileUpload:"FU",FreeArea:"FRA",FreeArea_Personalize:"FRA_P",FreeArea_End:"FRA_END",GeoMap:"GM",GeoMap_Button:"GM_BTN",GeoMap_Image:"GM_IMG",GeoMap_End:"GM_END",GeoMap_ZoomIn:"GM_ZIN",GeoMap_ZoomOut:"GM_ZOUT",Group:"G",Group_End:"G_END",InputField:"I",Iframe:"IF",Iframe_End:"IF_END",ItemList:"IL",ItemListBoxSingle:"ILBS",ItemListBoxSingle_Item:"ILBS_I",ItemListBoxMultiple:"ILBM",ItemListBoxMultiple_Item:"ILBM_I",Image:"IMG",Invisible:"INV",InputTokenizer:"IT",InputTokenList:"ITL",Label:"L",Legend:"LEG",LegendDateNavigatorItem:"LEGDI",LegendTableItem:"LEGTI",Link:"LN",ListBox:"LB",LoadingAnimation:"LA",MatrixLayout:"ML",MenuBar:"MNB",MenuBar_Item:"MNB_I",MessageBar:"MB",MessageBar_Link:"MB_LNK",NavigationList:"NL",NavigationList_Item:"NL_I",NavigationList_Group:"NL_G",NavigationList_Personalize:"NL_P",NavigationList_End:"NL_END",PageHeader:"PH",PageHeaderEnd:"PH_END",Paginator:"PG",Paginator_Button:"PG_B",Paginator_InputField:"PG_I",Paginator_Menu:"PG_MNU",PatternContainerContentItem:"PC",PatternContainerIconButton:"PCI",PatternContainerIconButton_Collapse:"PCI_C",PatternContainerIconButton_Expand:"PCI_E",PatternContainerIconButton_Min:"PCI_M",PatternContainerTab:"PCTAB",PatternContainerTab_Item:"PCTAB_I",PatternContainerTab_End:"PCTAB_END",PatternContainerTab_Menu:"PCTAB_MNU",PatternContainerTitle:"PCTIT",PatternContainerTitle_End:"PCTIT_END",PatternContainerTitle_Menu:"PCTIT_MNU",PatternContainerSequence:"PCSEQ",PatternContainerSequence_Item:"PCSEQ_I",PatternContainerSequence_End:"PCSEQ_END",PatternContainerSequence_Menu:"PCSEQ_MNU",PhaseIndicator:"PHI",PhaseIndicator_Step:"PHI_STN",PopIn:"PI",PopIn_CloseButton:"PI_CLB",PopIn_End:"PI_END",PopupMenu_Item:"POMN_I",PopupMenu_SubMenu:"POMN_ISMNU",PopupTrigger:"POTRG",ProgressIndicator:"PRI",RadioButton:"R",RadioButtonGroup:"RG",RadioButtonGroup_End:"RG_END",RasterLayout:"RL",RatingIndicator:"RI",RoadMap:"RM",RoadMap_RoundTripStep:"RM_SUB",RoadMap_Step:"RM_STN",RoadMap_RoundtripClosed:"RM_RTCLO",RoadMap_RoundtripStart:"RM_RTSTR",RoadMap_RoundtripEnd:"RM_RTEND",ScrollContainer:"SC",ScrollContainer_End:"SC_END",SapTable:"ST",SapTable_Header1:"ST_HDR1",SapTable_Header2:"ST_HDR2",SapTable_Header3:"ST_HDR3",SapTable_SortButtonAsc:"ST_SRTBTNA",SapTable_SortButtonDesc:"ST_SRTBTND",SapTable_SelectionCell:"ST_SC",SapTable_SelectionColumn:"ST_SCOL",SapTable_SelectionMenu:"ST_SMNU",SapTable_FilterButton:"ST_FBTN",SapTable_End:"ST_END",SapTable_Cell:"ST_C",SapTable_EmptyRowCell:"ST_ER",SelectableLinkBar:"SLB",SingleColumnLayout:"SL",TableView:"TBV",TabStrip:"TS",TabstripItem:"TSITM",TextBar:"TXB",TextEdit:"TE",TextView:"TV",ToggleLink:"TGL",Toolbar:"T",Toolbar_ToggleButton:"T_BTN",Toolbar_End:"T_END",ToolbarInputField:"TI",ToolbarLink:"TLN",Tray:"TY",Tray_Button:"TY_BTN",Tray_Menu:"TY_MNU",Tray_End:"TY_END",Tree:"TR",Tree_Folder:"TR_F",Tree_Leaf:"TR_L",TriStateCheckBox:"TRI",ValueComparison:"VC",ViewSwitch:"VS"};

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_checkKey
//* parameter   : e - event object
//*             : eType   - event type to check against i.e. "keydown","keypress","keyup"
//*							: arrKeys - array of strings with the numbers of keycodes i.e. new Array("9") checks the tab key
//* return      : true if one of the given keys of arrKeys was pressed, else false
//*	description	: checks keyboard events for keys given in arrKeys
//* ------------------------------------------------------------------------
function sapUrMapi_checkKey(e,eType,arrKeys) {
	if (e.type==eType) {
		for (var i=0;i<arrKeys.length;i++) {
			if (e.which==parseInt(arrKeys[i])) {
				e.returnValue=false;
				return true;
			}
		}
	}
	return false;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_suppressFocus
//* ------------------------------------------------------------------------
var ur_context={suppressFocus:false};
function sapUrMapi_suppressFocus(){
	ur_context.suppressFocus=true;
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_triggerFocus
//* ------------------------------------------------------------------------
function sapUrMapi_triggerFocus(sId) {
  ur_callDelayed("sapUrMapi_focusElement('" + sId.replace(/\\/g, "\\\\").replace(/\'/g, "\\'") + "', true)", 0);
}

function sapUrMapi_findFirstFocus(o,bLast) {
  if (o && o.style && (o.style.display == "none" || o.style.visibility == "hidden")) return null;
  var oChild=o;
  if (o==null) return null;
  if (sapUrMapi_Focus_canFocus(o)) {
		return o;
  }
  // focus the leftmost child that is focussable
  if (ur_system.direction=="rtl" || bLast) {
   	for (var i=oChild.childNodes.length-1;i>=0;i--) {
      var oTmp=oChild.childNodes.item(i);
      if (oTmp && oTmp.style && (oTmp.style.display=="none" || oTmp.style.visibility=="hidden")) continue;
	  if (sapUrMapi_Focus_canFocus(oTmp)) {
	    return oTmp;
      }
      var oTmp=sapUrMapi_findFirstFocus(oTmp,bLast);
      if (oTmp!=null) {
        return oTmp;
      }
    }  
  } else {    
    for (var i=0;i<oChild.childNodes.length;i++) {
      var oTmp=oChild.childNodes.item(i);
      if (oTmp && oTmp.style && (oTmp.style.display=="none" || oTmp.style.visibility=="hidden")) continue;
	  if (sapUrMapi_Focus_canFocus(oTmp)) {
	    return oTmp;
      }
      var oTmp=sapUrMapi_findFirstFocus(oTmp);
      if (oTmp!=null) {
        return oTmp;
      }
    }  
  }
  return null;
}

//calls the focus fuction of the browser and avoids js error if o is currently disabled or in a disabled container.
function ur_focus(o) {
	if (!ur_context.suppressFocus) {
		try {
			o.focus();
		} 
		catch (ex){
		}
	} else {
		ur_context.suppressFocus=false;
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_focusElement
//* parameter   : sId - string Id of the element to focus
//* return      : true if the focus was set, else false
//*	description	: focuses an element with sId if possible
//* ------------------------------------------------------------------------
function sapUrMapi_focusElement(sId, bTriggered) {
  var bErr=false;
  if (ur_context.suppressFocus) {
    window.addEventListener("onfocus",sapUrMapi_focusElement,true);
    ur_context.setfocusto = sId;
    ur_context.triggered = bTriggered;
    ur_context.suppressFocus = false;
    return;
  } 
  if (ur_context.setfocusto != null) {
    sId = ur_context.setfocusto;
    bTriggered = ur_context.triggered;
    window.removeEventListener("onfocus",sapUrMapi_focusElement,true);
    ur_context.setfocusto = null;
    ur_context.triggered = false;
  }
  //there is a timing problem in the smart client that causes a problem with detaching from focus
  //see: 4116073 2008
  if(ur_context.setfocusto == null && typeof(sId)=="object" && sId.type=="focus"){
      window.removeEventListener("focus",sapUrMapi_focusElement);
      return;
  }


	if(sId == "") return;
	
		if( typeof(sId)=="string" && sapUrMapi_SapTable_bIsMatrixId(sId)){
			sapUrMapi_SapTable_focusMatrixItem(sId);
			return;
		}
	
	  var o;
	  if (typeof(sId)=="string") {
	    o=ur_get(sId);
	  } else {
	    o=sId;
	  }
	  if(o == null) return;
	     var sType=sapUrMapi_getControlTypeFromObject(o);
	  
		if (sType=="I" && o.tagName=="INPUT" && bTriggered && ( o.getAttribute('type') == "text" || o.getAttribute('type') == "password" )) {
			if(_ur_cursorInfo && _ur_cursorInfo.id == sId ) {
				var htmlRef = document.getElementById(_ur_cursorInfo.id);
				if(htmlRef) ur_setCursorPos(htmlRef, _ur_cursorInfo.pos);
				  else {
				  	ur_focus(o);
					o.select();
					}
				
			 }
			 else{
			o.select(); ur_focus(o); // What if the _ur_cursorInfo is not set, least the Inputfield would be focused ?
			_ur_cursorInfo = null; //reset the cursor element
			}
		}
		if (sType=="TE" && bTriggered) {
			if(_ur_cursorInfo && _ur_cursorInfo.id == sId ) {
				var htmlRef = document.getElementById(_ur_cursorInfo.id);
				if(htmlRef) ur_setCursorPos(htmlRef, _ur_cursorInfo.pos);
			  else ur_setCursorPos(htmlRef,o.value.length);
			 }
			 else{
			   ur_setCursorPos(o,o.value.length); // What if the _ur_cursorInfo is not set, least the Inputfield would be focused ?
			  _ur_cursorInfo = null; //reset the cursor element
			}
		}
		if ((sType=="TR")&&((o.className.indexOf("urTreN")>-1)||(o.className.indexOf("urTreExp")>-1))) {
		  sapUrMapi_Tree_focusNode(sapUrMapi_getRootControl(o).id,o.id.split("-")[0],true);
		} else if ((sType=="TS")&&
	            (((o.className.indexOf("urTbsTxt")>-1) || ((o.firstChild!=null)&&(o.firstChild.className.indexOf("urTbsTxt")>-1))))){
		  	sapUrMapi_TabStrip_focusItem(sapUrMapi_getRootControl(o).id,parseInt(o.id.split("-")[2]));
		} else if (sType=="I" || sType=="TE") { 
		   //for inptfield and textarea the set of the focus is right. do nothing here also do not try to focus the root control then
		} else if (sType=="SLB") {
		    if (o.id.indexOf("-itm-")>-1) {
			    sapUrMapi_SelectableLinkBar_scroll(sapUrMapi_getRootControl(o).id,o.id);
			    sapUrMapi_setTabIndex(o,0);
			  }
			  try {
			   ur_focus(o);
			  } catch (ex){bErr=true};
		} else if ((sType=="PHI")&&(o.id.indexOf("-itm-")>-1)) {
		    sapUrMapi_PhaseIndicator_focusItem(sapUrMapi_getRootControl(o).id,"-itm-0",o.id.substring(o.id.indexOf("-")));
		} else if ((sType=="RM")&&(o.id.indexOf("-itm-")>-1)) {
		    sapUrMapi_RoadMap_setFocus(sapUrMapi_getRootControl(o).id,"-itm-0",o.id.substring(o.id.indexOf("-itm-")+5));
		} else if (sType=="ST") {
		  var oOrgFocusObj = o;
		  
		  if ((o.firstChild!=null) && (o.firstChild.tagName=="BUTTON") && (o.firstChild.className.indexOf("Ico")>-1)) {
		    o=o.firstChild;
		  }
		  o=sapUrMapi_findFirstFocus(o);
		  
		  if(!o && oOrgFocusObj) {
		  	var oElemToFocus = null;
		  	
		  	//Check StdCell and HieraricalCell
		  	if(!oElemToFocus && oOrgFocusObj.getAttribute("tp") == "HIC" || oOrgFocusObj.getAttribute("tp") == "C") {
		  		oElemToFocus = oOrgFocusObj.firstChild;
		  	}
		  	
		  	//Check if HeaderCell
		  	if(!oElemToFocus && oOrgFocusObj.tagName == "TH" && oOrgFocusObj.id ) {
		  		var oContentContainer = document.getElementById(oOrgFocusObj.id + "-content");
		  		if(oContentContainer && oContentContainer.getAttribute("tp") &&  oContentContainer.getAttribute("tp").indexOf("HDR") == 0) {
		  			oElemToFocus = oContentContainer;
		  		}
		  		
		  	}
		  	
		  	if(oElemToFocus) {
					sapUrMapi_setTabIndex(oElemToFocus,"0");
					sapUrMapi_setTabIndexAutoReset(oElemToFocus);
					ur_focus(oElemToFocus);
					return;
		  	}
		  }
		    
		  try {
		   ur_focus(o);
		  } catch (ex){bErr=true};

		  
		} else if (sType=="CB") {
		  o=ur_get(sapUrMapi_getRootControl(o).id);
			if (o.disabled==true) { o.disabled=false;ur_focus(o);o.disabled=true;}
			else ur_focus(o);
		} else if (sType=="C") {
			o=ur_get(o.id.split("-")[0]);
			if (o.disabled==true) {o=ur_get(o.id.split("-")[0]+"-img");}
			ur_focus(o);
		} else if (sType=="R") {
			o=ur_get(o.id.split("-")[0]);
		  if (!o.checked) {
				var oInputGrp  = document.getElementsByName(o.name);
				for (var i=0;i<oInputGrp.length;i++){
				  if (oInputGrp[i].checked) {
				    o=oInputGrp[i];
						break;
				  } 
				}
		  }
		  try {
			 if (o.disabled==true) {o=ur_get(o.id.split("-")[0]+"-img");}
		   ur_focus(o);
		  } catch (ex){bErr=true};
		} else if (sType=="RG" && o.id.indexOf("skipend")<-1) {
		  o=sapUrMapi_findFirstFocus(o);
			if (o!=null && !o.checked) {
				var oInputGrp  = document.getElementsByName(o.name);
				for (var i=0;i<oInputGrp.length;i++){
				  if (oInputGrp[i].checked) {
				    o=oInputGrp[i];
				  } 
				}
		  }
		  o=ur_get(o.id.split("-")[0]);
		  try {
		   ur_focus(o);
		  } catch (ex){bErr=true};
		} else {
			if (typeof(sId)=="string") {
				if (ur_get(sId+"-r")!=null) {
					sapUrMapi_focusElement(sId+"-r");
				}
			}
			o=sapUrMapi_findFirstFocus(o);
			if (o==null) return;
		  try {
		   ur_focus(o);
		  } catch (ex){bErr=true};
	  }
	  if (!b508Refocus) {
	   if (bErr) {
	     sapUrMapi_Focus_hideFocusRect();
	   } else {
	     sapUrMapi_Focus_showFocusRect(o);
	   }
	  }
	  return true;
	//} catch (ex) {return false};
}

var b508Refocus=false;

function sapUrMapi_refocusElement(sId){
if (ur_system.is508) {
	  oSpan=ur_get("ur-accfocus");
	  if (oSpan==null) {
	    oSpan=document.createElement("span");
	    oSpan.setAttribute("id","ur-accfocus");
	    oSpan.style.position="absolute";
	    document.getElementsByTagName("BODY").item(0).appendChild(oSpan);
	    oSpan=ur_get("ur-accfocus");
	  }
	  oSpan.tabIndex="2";
	  b508Refocus=true;
	  oSpan.focus();
	  if(typeof(sId)=="object") sId.focus();
	  else ur_get(sId).focus();
	  b508Refocus=false;
	  oSpan.tabIndex="-1";
	}
};

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_getAbsolutePosition
//* parameter   : obj - DOM object
//* return      : position={top, left, right}
//*	description	: sets the absolute position of obj in the document
//*				  right is set only in an RTL environment
//* ------------------------------------------------------------------------
function sapUrMapi_getAbsolutePosition (obj) {
  var position = { top: 0, left: 0, right: 0};  
	var obj2=obj;
	while (obj && obj.tagName!="BODY") {
	  try { 
	    var s=document.defaultView.getComputedStyle(obj,"");
			if (s.getPropertyValue("overflow")!="visible") {
				position.left-=obj.scrollLeft;
				position.top-=obj.scrollTop;
			}
	  } catch(ex) {}
	  if (obj==obj2) {
	    position.left += obj.offsetLeft;
	    position.top  += obj.offsetTop;
		  obj2=obj.offsetParent;
	  }
	  obj = obj.parentNode;
	}
  return position;
}

/* get the root of the control, object where you  find the ct attribute */
function sapUrMapi_getRootControl(o) {
	var oR=o;
	try {
		/* get object where you find the id, for the most of the control you also
		   find the ct attribute there */
	  if (oR.id.indexOf("-")>-1) {
	    oR=ur_get(o.id.split("-")[0]);
	  }
	  if(oR.getAttribute("ct")!=null) return oR;
	  /* if you do not find the ct attribute on the same level as the id
	     look at each parent starting with the passed object */
	  oR=o;
	  while (oR.getAttribute("ct")==null) {
	    if (oR.tagName=="BODY") return "";
	    oR=oR.parentNode;
	  }
	  return oR;
	} catch (ex) {return ""};
}

function sapUrMapi_isChildOfControl(oObj,sControlType) {
  while (oObj.tagName!="BODY") {
    if (sapUrMapi_getControlTypeFromObject(oObj)==sControlType) return oObj;
    oObj=oObj.parentNode;
  }
  return null;
}

function sapUrMapi_getControlTypeFromObject(o) {
	try {
	  var sControlType="";
	  while (o.getAttribute("ct")==null) {
	    if (o.tagName=="BODY") return "";
	    o=o.parentNode;
	  }
	  return o.getAttribute("ct");
	} catch (ex) {return ""};
}

function sapUrMapi_getControlType(sId) {
	try {
	  aId=sId.split("-");
	  var sCt=ur_get(aId[0]).getAttribute("ct");
	  if(sCt==null) sCt=ur_get(aId[0]+"-r").getAttribute("ct");
	  return sCt;
	} catch (ex) {return ""};
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_triggerClick
//* parameter   : e - event object
//*             : arrKeys - array of keycodes that trigger an click on an element
//* return      :
//*	description	: triggers an click event on a events source object if any by given key code(s)
//* ------------------------------------------------------------------------

function sapUrMapi_triggerClick(e,arrKeys, o)
{
  if(sapUrMapi_checkKey(e,"keydown",arrKeys) || sapUrMapi_checkKey(e,"keypress",arrKeys)){
    try{
      if (o) {
      	o.click(e); 
      } else {
      	e.target.click(); //old coding without an given object.
      }
    }
    catch(ex){};
  }
}


function ur_cancelBubble(oEvt){
	oEvt.stopPropagation();
}

function getLanguageText(sMain,arrChildTxt) {
	 var s;
	 try {
	 	s= ur_txt[ur_language][sMain];
	 	if (!arrChildTxt) return s;
	 	for (var i=0;i<arrChildTxt.length;i++) {
	 		 if (ur_txt[ur_language][arrChildTxt[i]]) {
	 	  	 s= s.replace("{"+i+"}",ur_txt[ur_language][arrChildTxt[i]]);
	 	 	} else {
	 	  	 s= s.replace("{"+i+"}",arrChildTxt[i]);
	 	 	}
	 	}
	} catch(e) {
		s="";
	}
	 return s;
}

function ur_get(sId) {
  return document.getElementById(sId);
}

//retruns an attribute value if it was set otherwise it returns the given default value
//it does not initialize the attribute in the html though
//o=object where to look for the attribute
//sAtt=attribute name
//def=default value
function ur_getAttD(o,sAtt,def) {
  if (!o) return def;
  var s=o.getAttribute(sAtt);
  if (s!=null && s!="") return s;
  else return def;
}

//* ************************************************************************
//* Frame Management Functions
//* ************************************************************************
//Get all the contained iFrames of an element
var ur_arr_FrameCollector = new Array();

function sapUrMapi_toggleIframes(inElement,bShow) {
  var arr = sapUrMapi_collectIFrames(inElement);
  for (var i=0;i<arr.length;i++) {
  	if (!bShow) {
  		if ((arr[i].getAttribute("oldheight")=="")||(!arr[i].getAttribute("oldheight"))) {
  			arr[i].setAttribute("oldheight",arr[i].offsetHeight);
  		}
  		if ((arr[i].getAttribute("hidelevel")=="")||(!arr[i].getAttribute("hidelevel"))) {
  		  arr[i].setAttribute("hidelevel",0);
  		}
  		arr[i].setAttribute("hidelevel",parseInt(arr[i].getAttribute("hidelevel"))+1);
 		  arr[i].style.height="0";
    } else {
  		if ((arr[i].getAttribute("hidelevel")=="")||(!arr[i].getAttribute("hidelevel"))) {
  		  arr[i].setAttribute("hidelevel",1);
  		}
  		arr[i].setAttribute("hidelevel",parseInt(arr[i].getAttribute("hidelevel"))-1);
  		if (arr[i].getAttribute("hidelevel")==0) {
	  		if ((arr[i].getAttribute("oldheight")!="")||(arr[i].getAttribute("oldheight"))) {
	  		  arr[i].style.height=arr[i].getAttribute("oldheight");
	  		}
	  	}
    }
  }
}

function sapUrMapi_collectIFrames(el) {
  ur_arr_FrameCollector = new Array();
  if (el.innerHTML.indexOf("iframe")>-1) {
    sapUrMapi_collectIFramesRec(el);
  }
  return ur_arr_FrameCollector;
}

function sapUrMapi_collectIFramesRec(el) {
	  if (el.childNodes) {
	    var i=0;
	    while ( i<el.childNodes.length ) {
	      var o=el.childNodes.item(i)
	      if (o.childNodes) sapUrMapi_collectIFramesRec(o);
	      if (o.tagName=="IFRAME") ur_arr_FrameCollector[ur_arr_FrameCollector.length]=o;
	      i++;
	    }
	  }
}

//* ************************************************************************
//* functions for position calculation in rtl
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_scrollRight
//* parameter   : elem - element
//* return      : int
//*	description	: calculates the amount of elem that is scrolled to the right
//* warning     : correct for elem=document.body,
//*				  appearantly not correct in other cases due to wrong elem.clientWidth
//* ------------------------------------------------------------------------
function sapUrMapi_scrollRight(elem)
{
//  return elem.scrollWidth-elem.scrollLeft-elem.clientWidth;
  return 0;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_clientRight
//* parameter   : elem - element
//* return      : int
//*	description	: calculates the distance between outer and inner border
//*				  of elem of the right
//* ------------------------------------------------------------------------
function sapUrMapi_clientRight(elem)
{
//  return elem.offsetWidth-elem.clientWidth-elem.clientLeft;
  return 0;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_scrollBarWidth
//* parameter   : elem - element
//* return      : int
//*	description	: calculates the width of the scrollbar in elem
//* ------------------------------------------------------------------------
function sapUrMapi_scrollBarWidth(elem)
{
//  clientRight=sapUrMapi_clientRight(elem);
//  if (elem.clientLeft>clientRight) return elem.clientLeft-clientRight;
//    else return clientRight-elem.clientLeft;
  return 0;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_offsetRight
//* parameter   : elem - element
//* return      : int
//*	description	: calculates the distance of outer border of elem
//*				  to inner border of parent to the right
//* ------------------------------------------------------------------------
function sapUrMapi_offsetRight(elem)
{
//  if (elem.offsetParent)
//    return elem.offsetParent.clientWidth-elem.offsetLeft-elem.offsetWidth;
//  else return 0;
  return 0;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_clientXtoRight
//* parameter   : docBody - document body
//*				: e - event
//* return      : int
//*	description	: calculates the distance of event to outer border of
//*				  document to the right
//* ------------------------------------------------------------------------
function sapUrMapi_clientXtoRight(docBody, e)
{
//  return docBody.offsetWidth-e.clientX;
  return 0;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_posLeftCorrectionForRTL
//* parameter   : elem - element
//* return      : int
//*	description	: amount of positioning error in MSIE
//*				  a child of elem is placed too far to the right in RTL mode
//*				  substract this correction value before setting style.left
//*				  to achieve correct placement
//* but			: better use positioning from the right
//* note		: in the sapUrMapi function for nn this value is different
//* Modified @ Author: Sri
//* ------------------------------------------------------------------------
function sapUrMapi_posLeftCorrectionForRTL(elem)
{
//  return elem.scrollWidth - elem.clientWidth + 16; // for IE due to a bug
  return 0;
}

function sapUr_Scroll_scrollToPosition(sId,x,y) {
	var ct = sapUrMapi_getControlType(sId);
	try{
	if(ct!="")
	{
		if(ct=="G" || ct=="TY")
			sapUrMapi_scrollToPosition(ur_get(sId+"-bd"),x,y);
		else
		if(ct =="TS")
		{
			var iSelIdx = ur_get(sId).getAttribute('sidx'); // Scrl pos for the selected TabItem
			var oCont = ur_get(sId+"-tbar-cnt-"+iSelIdx); // If Toolbar is present
			if(!oCont) 
			{
				oCont = ur_get(sId+"-bd-"+iSelIdx); // No Toolbar, normal handling
			}
			sapUrMapi_scrollToPosition(oCont,x,y);

		}
		else
		{
		    sapUrMapi_scrollToPosition(ur_get(sId),x,y);
		}
	}
	}catch(ex) {};
	
}

function sapUrMapi_scrollToPosition(o,x,y) {
	o.scrollTop=y;
    o.scrollLeft=x;
}
function sapUrMapi_getScrollLeft(o) {
  return o.scrollLeft;
}
function sapUrMapi_getScrollTop(o) {
  return o.scrollTop;
}


function sapUr_Scroll_scrollLeft(sId) {
	
	var ct = sapUrMapi_getControlType(sId);
	try{
	if(ct!="")
	{
		if(ct=="G" || ct=="TY")
			return ur_get(sId+"-bd").scrollLeft;
		else
		if(ct =="TS")
		{
			var iSelIdx = ur_get(sId).getAttribute('sidx'); // Scrl pos for the selected TabItem
			var oCont = ur_get(sId+"-tbar-cnt-"+iSelIdx); // If Toolbar is present
			if(!oCont) 
			{
				oCont = ur_get(sId+"-bd-"+iSelIdx); // No Toolbar, normal handling
			}
			return oCont.scrollLeft;

		}
		else
		{
		  return ur_get(sId).scrollLeft;
		}
	}
	}catch(ex) {};
	
 
}
function sapUr_Scroll_scrollRight(sId) {
	var o = ur_get(sId);
	return sapUrMapi_scrollRight(o);

}
function sapUr_Scroll_scrollTop(sId) {
	
	var ct = sapUrMapi_getControlType(sId);
	try{
	if(ct!="")
	{
		if(ct=="G" || ct=="TY")
			return ur_get(sId+"-bd").scrollTop;
		else
		if(ct =="TS")
		{
			var iSelIdx = ur_get(sId).getAttribute('sidx'); // Scrl pos for the selected TabItem
			var oCont = ur_get(sId+"-tbar-cnt-"+iSelIdx); // If Toolbar is present
			if(!oCont) 
			{
				oCont = ur_get(sId+"-bd-"+iSelIdx); // No Toolbar, normal handling
			}
			return oCont.scrollTop;

		}
		else
		{
		  return ur_get(sId).scrollTop;
		}
	}
	}catch(ex) {};

}

/* Helper function
 * oPos is an object which contains the x and y co-ordinate offset.
 */
function ur_Scrl_setScrlPosById(sId,oPos)
{
	sapUr_Scroll_scrollToPosition(sId,oPos.x,oPos.y);
}

/* Helper function
 * returns an object containg the current x & y offset.
 */
function ur_Scrl_getScrlPosById(sId)
{
	var oPos = new Object();
	oPos.x = sapUr_Scroll_scrollLeft(sId);
	oPos.y = sapUr_Scroll_scrollTop(sId);
	return oPos;

}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_initLinkStatus
//* return      : none
//* description	: adds the onmouseover and onfocus events to erase status "javascript:void(0)"
//* ------------------------------------------------------------------------
function sapUrMapi_initLinkStatus() {
  var oNodes = document.getElementsByTagName("A");
  for (var n=0;n<oNodes.length;n++) {
    if (oNodes[n].href.indexOf("javascript:void")>-1) {
      oNodes[n].onmouseover=sapUrMapi_resetStatus;
      oNodes[n].onfocus=sapUrMapi_resetStatus;
    }
  }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_resetStatus
//* return      : none
//* description	: resets the status to empty string
//* ------------------------------------------------------------------------
function sapUrMapi_resetStatus() {
  window.status="";
  //event.returnValue=true;
}







//* ------------------------------------------------------------------------
//* function:			sapUrMapi_Resize_Handler
//* parameter:			sId : the Id of the control to target
//*						sHandler : a string of the function and parameters to call when
//*						resizing is finished
//* return:				none
//* description:		resizes all controls as needed from resize event
//* ------------------------------------------------------------------------
function sapUrMapi_Resize_Handler(sId, sHandler) {
	this.sId = sId;
	this.sHandler = sHandler;
}

//* ------------------------------------------------------------------------
//* Global Hash Table of all controls needing to adjust based on the resize
//* event.  This registry is walked after the resizing has taken place and
//* all controls are resized at that point.
//* ------------------------------------------------------------------------
var sapUrMapi_Resize_Registry = new Array();
var sapUrMapi_Resize_Width = null;
var sapUrMapi_Resize_Timeout = null;
var sapUrMapi_Resize_Set = false;

//* ------------------------------------------------------------------------
//* function:			sapUrMapi_Resize_Capture
//* parameter:			none
//* return:				none
//* description:		sets the window.resize event to call the CheckSize function
//* ------------------------------------------------------------------------
function sapUrMapi_Resize_Capture() {
	if (sapUrMapi_Resize_Set == false) {
		window.addEventListener("resize", sapUrMapi_Resize_CheckSize, false);
		sapUrMapi_Resize_Set = true;
	}
}

//* ------------------------------------------------------------------------
//* function:			sapUrMapi_Resize_AddItem
//* parameter:			sId : the Id of the control to add to the registry
//*						sHandler : a string of the function and parameters to call when
//*						resizing is finished
//* return:				none
//* description:		resizes all controls as needed from resize event
//* ------------------------------------------------------------------------
function sapUrMapi_Resize_AddItem(sId, sHandler) {
	//set our window to capture the event
	sapUrMapi_Resize_Capture();
	//register our control
	if (!sapUrMapi_Resize_Registry[sId] || sapUrMapi_Resize_Registry[sId]) {
		sapUrMapi_Resize_Registry[sId] = new sapUrMapi_Resize_Handler(sId, sHandler);
	}
}

//* ------------------------------------------------------------------------
//* function:			sapUrMapi_Resize_CheckSize
//* parameter:			none
//* return:				none
//* description:		watches the browser window size, checking to see if
//*						the resize event is over and we can call our handlers
//* ------------------------------------------------------------------------
function sapUrMapi_Resize_CheckSize() {
	if (sapUrMapi_Resize_Timeout == null && sapUrMapi_Resize_Width == null) {
		sapUrMapi_Resize_Width = document.body.offsetWidth;
		sapUrMapi_Resize_Timeout = window.ur_callDelayed("sapUrMapi_Resize_CheckSize()", 50);
		return;
	}
	if (sapUrMapi_Resize_Width != document.body.offsetWidth) {
		sapUrMapi_Resize_Width = document.body.offsetWidth;
		sapUrMapi_Resize_Timeout = window.ur_callDelayed("sapUrMapi_Resize_CheckSize()", 50);
	}
	else {
	    window.clearTimeout(sapUrMapi_Resize_Timeout);
		sapUrMapi_Resize_Timeout = null;
		sapUrMapi_Resize_Resize();
		sapUrMapi_Resize_Width = null;
	}
}

//* ------------------------------------------------------------------------
//* function:			sapUrMapi_Resize_Resize
//* parameter:			none
//* return:				none
//* description:		loops all resizable controls in the registry and calls
//*						their resize handlers
//* ------------------------------------------------------------------------
function sapUrMapi_Resize_Resize() {
	for (var ctl in sapUrMapi_Resize_Registry) {
		if (ctl.indexOf("_") == 0) {continue;}
		if (sapUrMapi_Resize_Registry[ctl] != null) {
			eval(sapUrMapi_Resize_Registry[ctl].sHandler);
		}
	}
}

//* ------------------------------------------------------------------------
//* function:			sapUrMapi_Create_Handler
//* parameter:			sId : the Id of the control to target
//*						sHandler : a string of the function and parameters to call when
//*						onload is finished
//* return:				none
//* description:		creates all controls as needed from create event
//* ------------------------------------------------------------------------
function sapUrMapi_Create_Handler(sId, sHandler) {
	this.sId = sId;
	this.sHandler = sHandler;
}

//* ------------------------------------------------------------------------
//* Global Hash Table of all controls needing to have initialization scripts
//* called when the document has finished loading.  Also boolean switch which
//* reflects whether or not the timer for the create event is set.
//* ------------------------------------------------------------------------
var sapUrMapi_Create_Registry = new Array();
var sapUrMapi_Create_Apply = new Array();
var sapUrMapi_Create_Set = false;
var sapUrMapi_Create_Timeout = null;
var sapUrMapi_Create_Doc = "";

//* ------------------------------------------------------------------------
//* function:			sapUrMapi_Create_Capture
//* parameter:			none
//* return:				none
//* description:		sets the window.resize event to call the CheckSize function
//* ------------------------------------------------------------------------
function sapUrMapi_Create_Capture() {
	if (sapUrMapi_Create_Set == false) {
		//document.body.addEventListener("load", sapUrMapi_Create_CreateItems, false);
		sapUrMapi_Create_Doc = document.body.innerHTML;
		sapUrMapi_Create_Timeout = window.setTimeout("sapUrMapi_Create_CreateItems()", 150);
		sapUrMapi_Create_Set = true;
	}

}
//* ------------------------------------------------------------------------
//* function:			sapUrMapi_Create_AddItem
//* parameter:		sId : the Id of the control to add to the registry
//*								sHandler : a string of the function and parameters to call when
//*													 resizing is finished
//*								bApply: register function after all the others to apply values
//*												calculated before
//* return:				none
//* description:		resizes all controls as needed from resize event
//* ------------------------------------------------------------------------
function sapUrMapi_Create_AddItem(sId, sHandler,bApply) {
	//set our window to capture the event
	sapUrMapi_Create_Capture();
	//register our control
	if(bApply)
		sapUrMapi_Create_Apply[sId] = new sapUrMapi_Create_Handler(sId, sHandler);
	else	
		sapUrMapi_Create_Registry[sId] = new sapUrMapi_Create_Handler(sId, sHandler);
}

//* ------------------------------------------------------------------------
//* function:			sapUrMapi_Create_CreateItems
//* parameter:			none
//* return:				none
//* description:		loops all resizable controls in the registry and calls
//*						their resize handlers
//* ------------------------------------------------------------------------
function sapUrMapi_Create_CreateItems() {
	//document.body.removeEventListener("load", sapUrMapi_Create_CreateItems, true);
	var doc = document.body.innerHTML;
	if (doc != sapUrMapi_Create_Doc) {
		sapUrMapi_Create_Doc = doc;
		sapUrMapi_Create_Timeout = window.setTimeout("sapUrMapi_Create_CreateItems()", 150);
	}
	else {
		window.clearTimeout(sapUrMapi_Create_Timeout);
		sapUrMapi_Create_Timeout = null;
		for (var ctl in sapUrMapi_Create_Registry) {
			if (ctl.indexOf("_") == 0) {continue;}
			if (sapUrMapi_Create_Registry[ctl] != null) {
				eval(sapUrMapi_Create_Registry[ctl].sHandler);
			}
		}
		sapUrMapi_Create_Registry = new Array();
		/* apply values calculated before */
		for (var ctl in sapUrMapi_Create_Apply) {
			if (ctl.indexOf("_") == 0) {continue;}
			if (sapUrMapi_Create_Apply[ctl] != null) {
				eval(sapUrMapi_Create_Apply[ctl].sHandler);
			}
		}
		sapUrMapi_Create_Apply = new Array();				
	}
}



//* ------------------------------------------------------------------------
//* function    : sapUrMapi_init
//* description	: initializes global variables when page content was changed by framework
//* ------------------------------------------------------------------------
function sapUrMapi_init() {
	if (ur_system.mimepath == null) ur_system.mimepath = ur_system.stylepath.substring(0,ur_system.stylepath.indexOf("/ur"))+"/common/";
	if (ur_system.emptyhoverurl == null || ur_system.emptyhoverurl == "") ur_system.emptyhoverurl = ur_system.mimepath+"emptyhover.html";
	if (ur_language==null || ur_language=="") {
		var oScript=ur_get("ur_lang_js");
		if (!oScript) {
			var scripts=document.getElementsByTagName("SCRIPT");
			for (var i=0;i<scripts.length;i++) 
				if (scripts[i].src.indexOf("urMessageBundle_")>-1) {
					oScript=scripts[i];
					break;
				}
		}
		if (oScript) {
			var url = oScript.src,
			    beginPos = url.indexOf("urMessageBundle_"),
			    endPos = url.indexOf(".js", beginPos);
			var oParent = oScript.parentNode;
			oParent.removeChild(oScript);
			oScript = document.createElement("script"); 
			oScript.src = url.substring(0,beginPos) + "urMessageBundle" + url.substring(endPos);
			oParent.appendChild(oScript);
      }
	}

  oPopup=null;
  oDatePicker=null;
  sapUrMapi_Resize_Registry=new Array();
  sapUrMapi_PcTabSeq_Registry = new Array();
  _ur_POMN = {all:new Array(),menus:new Array(),level:0};
  _ur_tables=new Array();
  ur_Scrollbar_EnvironmentInit();
}

function ur_evtSrc(e){return e.target;}

function sapUrMapi_cleanUp() {
  //IE memory leak
}

//* ************************************************************************
//* Method getCurrentStyle
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : getCurrentStyle
//* parameter   : o - object it should refere to
//*             : sStAt   - string, defines the style attribute. Here, with Mozilla, NN and
//*				Firefox, the CSS property has to be passed. For example, "border-right-width"!
//* return      : string value of the desired style attribute
//* description	: distinguishes the dom reference and browser specific method of asking
//* 			  for style attributs of objects.
//* ------------------------------------------------------------------------
function sapUrMapi_getCurrentStyle(o,sStAt){
	var s=document.defaultView.getComputedStyle(o,"").getPropertyValue(sStAt);
	return s;
}
	
function ur_checkFocussedUiElement(htmlRef, browserEvent) {

}

//* ------------------------------------------------------------------------
//* function    : ur_setEditCellColor
//* parameter   : o - object that got the focus
//* description	: checks if an object is inside a table cell and if it should changes the background-color of the cell
//* ------------------------------------------------------------------------
var _ur_tableInputFoc;
function ur_setEditCellColor(o) {
  ur_removeEditCellColor();
  var sCt=sapUrMapi_getControlTypeFromObject(o);
  if (sCt=="I" || sCt=="CB") { 
		if (ur_getAttD(o,"st","").indexOf("r")==-1 && 
		    ur_getAttD(o,"st","").indexOf("d")==-1 && 
				sapUrMapi_isChildOfControl(o,"ST")) {
			var oCell=o;
			while (oCell.tagName!="TD" || oCell.className.indexOf("urSTTD")==-1) {
				oCell=oCell.parentNode;
				//leave the loop if we reach a tr that is not the inputfields tr
				if (oCell.tagName=="TR" && oCell.firstChild.firstChild!=o) { oCell=null;break;}
			}
			if (oCell!=null && oCell!=o) {
				oCell.className=oCell.className+" urSTFoc";
				_ur_tableInputFoc=oCell;
			}
		}
	}
}
//* ------------------------------------------------------------------------
//* function    : ur_removeEditCellColor
//* description	: removes the edit cell color from the cell
//* ------------------------------------------------------------------------
function ur_removeEditCellColor() {
	if (_ur_tableInputFoc!=null) {
	  try {
	    _ur_tableInputFoc.className=_ur_tableInputFoc.className.replace(" urSTFoc","");
	  } catch (ex) {}
	  _ur_tableInputFoc=null;
	}  
}

//Timeout
function ur_callDelayed(sFunc,ms) {
  return setTimeout("try{"+sFunc+"}catch(ex){}",ms);
}


//* ------------------------------------------------------------------------
//* function    : ur_getPrevItm
//* parameter   : o - focused object
//*				: sAt - string attribute in html
//* return      : returns object that has the defined attribute
//*	description	: used to find the previous item in a horizontally 
//*				  rendered collection of items
//* ------------------------------------------------------------------------

function ur_getPrevItm(o,sAt){
		if(!o || !sAt) return null;
		while(ur_getAttD(o,sAt,"")==""){ 
			o=o.previousSibling;
			if (!o) return null;
		}
	return o;
}
//* ------------------------------------------------------------------------
//* function    : ur_getNxtItm
//* parameter   : o - focused object
//*				: sAt - string attribute in html
//* return      : returns object that has the defined attribute
//*	description	: used to find the next item in a horizontally 
//*				  rendered collection of items
//* ------------------------------------------------------------------------
function ur_getNxtItm(o,sAt){
	if(!o || !sAt) return null;
	while(ur_getAttD(o,sAt,"")==""){ 
			o=o.nextSibling;
			if (!o ) return null;
		}
	return o;
}
//* ------------------------------------------------------------------------
//* function    : ur_focus_Itm
//* parameter   : oNew - next item to recieve tabindex
//*				: oOld - old item to loose tab index
//* return      : -
//* ------------------------------------------------------------------------
function ur_focus_Itm(oNew,oOld){
		sapUrMapi_setTabIndex(oOld,-1);
		sapUrMapi_setTabIndex(oNew,0);
		ur_focus(oNew);
}
//* -----------------------------------------------------------------------------
//* function    : sapUrMapi_relaxDomain([integrated[, standalone[, maxrelax]]])
//*
//* parameters  : 
//*   integrated: domain relaxation used, when application is started inside of
//*               an iframe, a frameset or a popup window
//*   standalone: domain relaxation used, when application runs standalone
//*   maxrelax:   maximal relaxation, for "auto" and "maximal"
//*
//* return      : true, if relaxation was successful or not necessary
//*               false, if an error occured, while doing relaxation
//*
//* Possible values for integrated/standalone:
//*   "none"    : No domain relaxation will be done
//*   "auto"    : Domain relaxation will automatically adapt to the parent window.
//*               If no matching relaxation can be found, domain relaxation is 
//*               "maximal". When running standalone this defaults to "minimal". 
//*   "minimal" : Only the first part (hostname) of the domain will be removed
//*   "maximal" : Remove as much as possible, without relaxing to TLD
//*
//* Possible value for maxrelax:
//*   Integer, that determines the number of domain parts, that have to be kept.
//*   E.g. 2 means "sap.com", 3 means "sub.sap.com" 
//*
//* There is a bug in Internet Explorer, that causes domain relaxation
//* to fail intermittently, when the domain, where content is loaded from is
//* the same as the relaxed domain of the parent
//* (e.g. relaxed to wdf.sap.corp, iframe url http://wdf.sap.corp/....)
//* -----------------------------------------------------------------------------

function sapUrMapi_relaxDomain(integrated, standalone, maxrelax) {
  var hostname = location.hostname,
      nameparts = hostname.split("."),
      partslength = nameparts.length,
      reference = "parent";
  
  // if hostname is an ip address don't try to relax
  if (/^(\d|\.)+$/.test(hostname)) return true;

  // if hostname has no domain part don't relax
  if (partslength == 1) return true;
  
  // check and set defaults for parameters
  if (standalone == null) standalone = "minimal";
  if (integrated == null) integrated = "auto";
  if (maxrelax == null) {
    // determine maximal possible relaxation (e.g. domain.co.uk)
    if (nameparts[partslength - 1].length == 2 &&
        nameparts[partslength - 2].length == 2) {
      maxrelax = 3;
    } else {
      maxrelax = 2;
    }
  }

  // check if already reached maxrelax
  if (partslength <= maxrelax) return true;

  // determine method 
  if (standalone == "auto") standalone = "minimal";
  if (window[reference] == window) reference = "opener";
  if (window[reference] == null) method = standalone;
  else method = integrated;

  // apply method
  switch (method) {

    case "none": // no domain relaxing
      return true;
      break;
    
    case "auto": // try until correct one is found or maximal relaxation reached
      try {
        window[reference].location.href;
        return true;
      }
      catch (e) {};
      var testdomain;
      for (var i = 0; i <= partslength - maxrelax; i++) {
        testdomain = nameparts.slice(i).join(".");
        try {
          document.domain = testdomain;
          window[reference].location.href;
          return true;
        }
        catch (e) {};
      }
      return false;
      break;

    case "minimal": // only remove first (hostname) part of the domain
      try {
        document.domain = nameparts.slice(1).join(".");
        return true;
      }
      catch (e) {
        return false;
      }
      break;

    case "maximal": // relax as maximal possible/allowed
      try {
        document.domain = nameparts.slice(partslength - maxrelax).join(".");
        return true;
      }
      catch (e) {
        return false;
      }
      break;

    default:
      alert("Unknown relaxation method: " + method);
  }

  return false;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_setTabIndex
//* parameter   : oElem - DOM element
//*             : iVal  - Value
//* return      : none
//*	description	: sets the tabindex on an element
//* ------------------------------------------------------------------------
function sapUrMapi_setTabIndex(oElem,sVal) {
	if(oElem.getAttribute("ti")) {
		oElem.setAttribute("orgTi",oElem.getAttribute("ti"));
	}	
  oElem.tabIndex=sVal;
  oElem.setAttribute("ti",sVal);
}

function sapUrMapi_resetTabIndex(oElem) {
	if (oElem.type == "blur") oElem = this;
	if(!oElem) oElem=this;
	
	if(oElem.getAttribute("orgTi")) {
		var sVal = oElem.getAttribute("orgTi");
		oElem.tabIndex=sVal;
		oElem.setAttribute("ti",sVal);
		if(oElem.onblur == sapUrMapi_resetTabIndex)
			oElem.onblur = null;
		oElem.setAttribute("orgTi",null);
	}	else {
  	oElem.tabIndex="-1";
  	oElem.setAttribute("ti",null);
	}
}
function sapUrMapi_setTabIndexAutoReset(oElem) {
	if(!oElem.onblur)
		oElem.onblur = sapUrMapi_resetTabIndex;
}

function sapUrMapi_DOM_bContains(oDomRefContainer, oDomRefChild) {
	var oDomRef = oDomRefChild;
	
	if(oDomRefContainer == oDomRefChild) return true;
	
	while(oDomRef != null) {
		if(oDomRef == oDomRefContainer) return true;
		oDomRef = oDomRef.parentNode;
	}
	
	return false;
};

function sapUrMapi_triggerDefaultButton(sId,oEvt)
{
	var oR=ur_get(sId);
	var dbId = oR.getAttribute("dbid");
	var dbtn = ur_get(dbId);
	if(dbId!=null && ur_get(dbId).parentNode!=null)
	{
		
		var currentFocus = ur_EVT_src(oEvt)
		var sCt=sapUrMapi_getControlTypeFromObject(currentFocus);
		switch (sCt) 
		{
			case "": 
			case "B":
			case "TB":
			case "TE":
			case "TGL":
			case "LN":
			    sapUrMapi_DBTN_hideDBtn(); 
				break;
			case "TY":
				var sTp = currentFocus.getAttribute("tp");
			    if (sTp != null)
			    {
					if(sTp=="BTN" || sTp=="MNU")
					sapUrMapi_DBTN_hideDBtn(); 
			    }
				else
			    {
					sapUrMapi_defaultButtonClick(dbtn);
				}
				break;
			case "T":
				var sTp = currentFocus.getAttribute("tp");
			    if (sTp != null)
			    {
					if(sTp=="BTN")
					sapUrMapi_DBTN_hideDBtn(); 
			    }
				else
				{
					sapUrMapi_defaultButtonClick(dbtn);
				}
				break;
			case "I":
			case "TI":
				if(currentFocus.onkeypress!=null)
					sapUrMapi_DBTN_hideDBtn(); 
				else
				{
					sapUrMapi_defaultButtonClick(dbtn);
				}
				break;
			default :
			{
				sapUrMapi_defaultButtonClick(dbtn);
			}
				
		}
	}
	else 
	{
		sapUrMapi_DBTN_hideDBtn();
	}
		
}
function sapUrMapi_defaultButtonClick(dbtn)
{
	ur_EVT_fire(dbtn,"ocl",{type:"click",target:dbtn});
}

var ur_logIdx = 0;
function ur_logEvent(a,b,c) {
	var oLog = ur_get("ur-log");
	if (!oLog) {
		var oLog = document.createElement("DIV");
		oLog.id="ur-log";
		document.body.appendChild(oLog);
		oLog.style.position="absolute";
		oLog.style.top="0";
		oLog.style.left="0";
		oLog.style.backgroundColor="#fff";
		oLog.style.padding="5px";
	} 
	var o = document.createElement("DIV");
	o.innerHTML = (ur_logIdx++) + "  -  (" + a + "," + b + "," + c + ")";
	oLog.appendChild(o);
}

function ur_findPreviousFocusableElement(o) {
	var oR=o;
	var oN=null;
	var oF=null;

	while(oR!=null && oF==null){
		while(oR!=null && oR.previousSibling==null)
			oR=oR.parentNode;
		if(oR==null)
			break;
		oN=oR.previousSibling;
		while(oN!=null && oF==null){
			oF=sapUrMapi_findFirstFocus(oN,true);
			if(oF==null)
				oN=oN.previousSibling;
		}
		if(oF==null)
			oR=oR.parentNode;
		else
			break;
	}
	return oF;
}

function ur_findNextFocusableElement(o) {
	var oR=o;
	var oN=null;
	var oF=null;
	while(oR!=null && oF==null){
		while(oR!=null && oR.nextSibling==null)
			oR=oR.parentNode;
		if(oR==null)
			break;				
		oN=oR.nextSibling;
		while(oN!=null && oF==null){
			oF=sapUrMapi_findFirstFocus(oN);
			if(oF==null)
				oN=oN.nextSibling;
		}
		if(oF==null)
			oR=oR.parentNode;
		else
			break;
	}
	return oF;
}

function ur_getNextHtmlParentByAttribute(oDomRef, sAttributeName){
	if (oDomRef) {
		var oCurDomRef = oDomRef;
		for(var i=10; i>0; i--) {
			if(oCurDomRef.tagName == "BODY") return null;
			
			if(oCurDomRef.getAttribute(sAttributeName)) return oCurDomRef;
		
			if(oCurDomRef.parentNode) oCurDomRef=oCurDomRef.parentNode;
			else return null;
		}
	}
	return null;
};


function ur_getNextHtmlParentByTagName(oDomRef, sTagName){
	if (oDomRef) {
		var oCurDomRef = oDomRef;
		for(var i=10; i>0; i--) {
			if(oCurDomRef.tagName == "BODY") return null;
			
			if(oCurDomRef.tagName == sTagName) return oCurDomRef;
		
			if(oCurDomRef.parentNode) oCurDomRef=oCurDomRef.parentNode;
			else return null;
		}
	}
	return null;
};

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_bCtrl
//* parameter   : oEvent - event object
//* return      : true if ctrl or apple command on MAC is pressed
//*	description	: Checks whether the ctrl is pressed
//* ------------------------------------------------------------------------
function sapUrMapi_bCtrl( oEvent ) {
	return sapUrMapi_bIsMacOs() ? oEvent.metaKey : oEvent.ctrlKey;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_bIsMacOs
//* return      : true if browser is running on a MAC
//*	description	: checks whether the browser is running on a MAC Platform
//* ------------------------------------------------------------------------
function sapUrMapi_bIsMacOs( ) {
	
	try {
		return window.navigator.userAgent.indexOf("Mac OS")>-1;
	} catch( e ) { 
		return false; 
	}
}