//* ************************************************************************
//* Tray
//* ************************************************************************
//* function    : sapUrMapi_Tray_handle
//handles click and keyboard events on the whole tray
function sapUrMapi_Tray_handle(oEvt) {
	var oSrc= ur_EVT_src(oEvt);
	var oTray = sapUrMapi_getRootControl(oSrc);
	var sType = sapUrMapi_getControlTypeFromObject(oTray);
	if (sType != "TY") return; //not a tray
	var sId = oTray.id;
	var sCommand = "";
	if (oEvt.type == "focus") {
		var oOptionMenu = ur_get(sId + "-menu");
		oOptionMenu.tabIndex="-1";
		oTray.focus();
	} else if (oEvt.type == "click") {
		//check option menu click
		if (oSrc && oSrc.id && oSrc.id.indexOf("-menu")>0) sCommand = "openMenu";
		else sCommand = "toggle" //this was a header click
	} else if (oEvt.type == "keydown") {
		var iKey = oEvt.keyCode || oEvt.which;  
		if ((iKey == ur_KY.DOWN && oEvt.altKey) || iKey == 115) {
			var oOptionMenu = ur_get(sId + "-menu");
			if (oOptionMenu) sCommand = "openMenu";
			oOptionMenu.tabIndex="0"; // set the tab index to recieve a focus event after the menu is closed
		} else if (iKey == 107 && !ur_isSt(oTray,ur_st.DISABLED) && ur_isSt(oTray,ur_st.COLLAPSED)){
			sCommand = "toggle";
		} else if (iKey == 109 && !ur_isSt(oTray,ur_st.DISABLED) && ur_isSt(oTray,ur_st.EXPANDED)) {
			sCommand = "toggle";
		} else if (iKey == 13 && !ur_isSt(oTray,ur_st.COLLAPSED)) {
			sapUrMapi_triggerDefaultButton(sId,oEvt);
			return;
		} else {
			return sapUrMapi_skip(sId,oEvt);
		}
	}
	
	if (sCommand == "openMenu") {
		ur_EVT_fire(oTray,"oopt",oEvt);
			ur_EVT_cancel(oEvt);
	} else if (sCommand == "toggle") {
		ur_EVT_fire(oTray,"oexp",oEvt);
		ur_EVT_cancel(oEvt);
	}
};

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_RegisterCreate
//* parameter   : sId - string - Id of the Tray
//*				: bScroll - boolean - indicates whether the tray is scrollable
//*				: bCollapsed - boolean - indicates whether the tray is collapsed
//* description : Registers the tray with the create item registry to be
//*				  initialized when the page loads
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_RegisterCreate(sId, bScroll, bCollapsed) {
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_Tray_create('" + sId + "',"+bScroll+","+bCollapsed+")");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_create
//* parameter   : sId  - string - Id of the Tray
//* 			: bScroll - boolean - indicates weather the Tray is scrollable
//*  			: bCollapsed - boolean - indicates weather the Tray is collapsed
//* description : This is a dummy function to be implemented in the future.
//*               It is used in Netscape though
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_create(sId,bScroll,bCollapsed) {

 	var oTray = ur_get(sId);
 
 	if (oTray == null) return;
 
	var sStatus = oTray.getAttribute("st"); 
 	var bCollapsible =  sStatus == "+" || sStatus == "-" || sStatus == "+d" || sStatus == "-d";
 	
  	if (bCollapsible && bCollapsed==true) {
    	sapUrMapi_Tray_toggle(sId);
  	}
  
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_showOptionMenu
//* parameter   : sTrayId    - string - Id of the Tray
//  							sTriggerId - string - The Id of the DOM Objects that
//                                      is the trigger for the menu
//  							sMenuContentId - string- The Id of the DOM Objects that
//                                         contains the menu
//  							enumPositionBehavior - string- Defines at which position the PopupMenu
//																			 will appear. Default is Right
//							  e - EventObject - the events object
//* description : Opens the Menu that is applied as option menu to that tray.
//								There is an icon shown if a menu is connected to the tray
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_showOptionMenu2(sTrayId,sMenuContentId,oEvt) {
 	if (ur_system.direction=="rtl")
	  sapUrMapi_Tray_showOptionMenu(sTrayId,sTrayId+"-menu",sMenuContentId,sapPopupPositionBehavior.MENULEFT,oEvt) 
	else
	  sapUrMapi_Tray_showOptionMenu(sTrayId,sTrayId+"-menu",sMenuContentId,sapPopupPositionBehavior.MENURIGHT,oEvt) 
}
function sapUrMapi_Tray_showOptionMenu(idTray,idTrigger,idContent,pos,e) {
	sapUrMapi_PopupMenu_showMenu(idTrigger,idContent,pos,e);
}

//* ------------------------------------------------------------------------
//* function : sapUrMapi_Tray_toggle
//* parameter : sTrayId - string - Id of the Tray
// e - EventObject - the events object
//* description : Expand / Collapses the tray
//* return : none
//* sample :
//* Docu: Special Handling only for Mozilla, coz if we add a iframe inside a Tray and
//*		  try to do the expand collapse, The iframe still remained.
//* ------------------------------------------------------------------------

ur_trayBody=new Array();
ur_trayValues = new Array();
var tywd = -1;
var tyht = -1;

function sapUrMapi_Tray_toggle( idTray,e)
{
	sCtlType="SAPUR_TRAY";
	if(typeof(e)!="undefined")
	{
		if ((e.type!="click") && (!sapUrMapi_checkKey(e,"keydown",new Array("32","30","107","109")))) return false;
		ur_EVT_cancelBubble(e);
	}
	var elBody = ur_get(idTray+"-tbd");
	var sTitle = ur_get(idTray+"-hd");
	var elExpander = ur_get(idTray+"-exp");
	var elHeader = ur_get(idTray+"-hd");
	var oSkip=ur_get(idTray);
	var elExpandState = ur_get(idTray+"-es");
	if (elBody && elBody.getAttribute("col") == 1)
	{

		elBody.removeAttribute('style');
		elBody.style.visibility="static";
		elBody.style.height=tyht;
		elBody.style.width=tywd;
		elBody.setAttribute("col","0");
		ur_get(idTray+"-bd").style.display ="block"; 
		ur_trayBody[idTray]=null;

		if ( elExpander && elExpander.className.indexOf("Closed") != -1)

		{

			var re = /Closed/gi;
			var clsNm = elExpander.className;
			elExpander.className = clsNm.replace(re, "Open");
			ur_setSt(oSkip,ur_st.COLLAPSED,false);
			ur_setSt(oSkip,ur_st.EXPANDED,true);

		}
		if ( elHeader && elHeader.className == "urTrcHdBgClosedIco" )
			elHeader.className = "urTrcHdBgOpenIco";
		if ( elExpandState )
			elExpandState.value = "1";
		if (ur_system.is508)
		{
			if (elExpander)
				elExpander.title=getLanguageText("SAPUR_TY_BTNE");
		} 
		else
		{
			if (elExpander)
				elExpander.title=getLanguageText("SAPUR_TY_BTNE");		
		}

	}
	else
	{

		ur_trayBody[idTray]=elBody.innerHTML;
		ur_Tray_CollectValues(elBody);
		// Try to get the width and height offset of the content inside. and reset it when you expand the Tray.
		if(tywd == -1)
		tywd =elBody.offsetWidth;
		if(tyht == -1)
		tyht = elBody.offsetHeight;
		elBody.style.position ="absolute";
		elBody.style.overflow="hidden";
		ur_get(idTray+"-bd")
		elBody.style.visibility="hidden";
	
		elBody.style.height= "0px"; //the old value of -2000px causes issues in firefox. To be save add top and left -9000
		elBody.style.width= "0px";
		elBody.style.top= "-9000px";
		elBody.style.left= "-9000px";			
		
		elBody.setAttribute("col","1");
		ur_get(idTray+"-bd").style.display ="none";

		if ( elExpander && elExpander.className.indexOf("Open") != -1)
		{
			var re = /Open/gi;
			var clsNm = elExpander.className;
			elExpander.className = clsNm.replace(re, "Closed");
			ur_setSt(oSkip,ur_st.COLLAPSED,true);
			ur_setSt(oSkip,ur_st.EXPANDED,false);
		}
			if ( elHeader && elHeader.className == "urTrcHdBgOpenIco" )
				elHeader.className = "urTrcHdBgClosedIco";
			if ( elExpandState )
				elExpandState.value = "0";
			if (ur_system.is508)
			{
				if (elExpander)
					elExpander.title=getLanguageText("SAPUR_TY_BTNC");
			}
			else
			{
				if (elExpander)
					elExpander.title=getLanguageText("SAPUR_TY_BTNC");		
			}
	  }
          return true;
}

function ur_Tray_restoreValues(obj)
{
	
	var oInpColl = obj.getElementsByTagName("INPUT");
	var oTaColl = obj.getElementsByTagName("textarea");
	 for(i=0 ; i<oInpColl.length;i++)
    {	
		if(oInpColl[i].getAttribute("id"))
		oInpColl[i].value = ur_trayValues[oInpColl[i].getAttribute("id")] ;
		
    }
    for(i=0 ; i<oTaColl.length;i++)
    {
		if(oTaColl[i].getAttribute("id")){
		var sId = oTaColl[i].getAttribute("id");
		oTaColl[i].value = ur_trayValues[sId]  ;
		}
    }
}
function ur_Tray_CollectValues(obj)
{
	var oInpColl = obj.getElementsByTagName("INPUT");
	var oTaColl = obj.getElementsByTagName("textarea");
	
    for(i=0 ; i<oInpColl.length;i++)
    {	
		if(oInpColl[i].getAttribute("id"))
		ur_trayValues[oInpColl[i].getAttribute("id")] = oInpColl[i].value;
		
    }
    
    for(i=0 ; i<oTaColl.length;i++)
    {
		if(oTaColl[i].getAttribute("id")){
		var sId = oTaColl[i].getAttribute("id");
		ur_trayValues[sId] = oTaColl[i].value;
		}
    }
    
}
