//* ************************************************************************
//* Toolbar
//* ************************************************************************
function sapUrMapi_Toolbar_toggleItems(sControlId,e) {
  if((e.type == "keydown" && e.keyCode==32) || e.type == "click") {
	  var oToggleButton = ur_get(sControlId+"-tgl");
	  var oToolbar = ur_get(sControlId);
	  var colItems = oToolbar.childNodes;
	  var bShowAllState = oToggleButton.getAttribute("showall")=="true";
	  for (var n=0;n<colItems.length;n++) {
		var oItem=colItems.item(n);
		if (oItem.getAttribute("cancollapse")=="true") {
		  if (bShowAllState) {
			  oItem.style.display="none";
			  oItem.setAttribute("show","false");
	      } else {
		  oItem.style.display="inline";
			  oItem.setAttribute("show","true");
		}
	    }
	    if (oItem==oToggleButton) break;
	  }
	  if (bShowAllState) {
	    oToggleButton.setAttribute("showall","false");
	    oToggleButton.className="urBtnStd urTBtnCol";

	  } else {
	    oToggleButton.setAttribute("showall","true");
	    oToggleButton.className="urBtnStd urTBtnExp";
	  }
  }
  else {
  	return;
  }
}
