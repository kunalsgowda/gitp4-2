//** InputTokenizer.nn6 **
//* ************************************************************************
//* InputTokenizer
//* ************************************************************************
//* ------------------------------------------------------------------------
//* global variables
//* oLastSelTextRange - a pointer to a valid text range object
//* ------------------------------------------------------------------------
var oLastSelTextRange = null;

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_MouseUp
//* parameter   : none
//* return      : none
//*	description	: this sets a global variable equal to a generic document 
//*								text range object
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_MouseUp() {
	//non-functional for nn6
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_Click
//* parameter   : sId - the id of the HTML element we are seaching for tokens in
//*               oEv - window event object
//* return      : none
//*	description	: this selects a text range surrounding a given token based on 
//*								where the user clicked their mouse
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_Click(sId, oEv) {	  	  
	//non-functional for nn6
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_KeyDown
//* parameter   : sId - id of the HTML element whose innerText needs to be  
//*								validated against a token list
//*               oEv - window event object
//* return      : modifies the innerHTML of the HTML element, creating a visual
//*								representation of the valid/invalid tokens contained therein
//*	description	: this checks for valid tokens in the HTML element's innerText
//*								and marks those elements as valid or invalid
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_KeyDown(sId, oEv) {
	//in NN6 this only looks for the keyCode and triggers the validation action
	//if ctrl+enter was pressed
	// ignore <enter> unless ctrl+enter was pressed
	if (oEv.which == 13) {	
		//if the user presses ctrl+enter, fire the validation code
		if (sapUrMapi_bCtrl(oEv)) {
		  var inp = ur_get(sId);
			var btn = ur_get(inp.getAttribute("validatebtn"));
			if (btn != null) {
				btn.onclick();
			}
		}
		oEv.stopPropagation();
		return false;
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_selectToken
//* parameter   : oInput - pointer to HTML element containing needed values
//*               oSelRange - pointer to valid TextRange object
//* return      : string - either the value of the token's text or an empty string
//*	description	: this searches a given text range for valid tokens and selects
//*								them into the text range, the function then returns the text
//*								value of the token to the caller
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_selectToken(oInput, oSelRange) {
	//non-functional for nn6
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_markValidTokens
//* parameter   : sId - id of the HTML element whose innerText needs to be  
//*								validated against a token list
//* return      : modifies the innerHTML of the HTML element, creating a visual
//*								representation of the valid/invalid tokens contained therein
//*	description	: this checks for valid tokens in the HTML element's innerText
//*								and marks those elements as valid or invalid
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_markValidTokens(sId) {
	var oInput = ur_get(sId);
	var val = oInput.value;
	if (val == "") { return; }
	var tokenlist = sapUrMapi_InputTokenizer_getTokenList(oInput);
	var usecase = oInput.getAttribute("casesensitive");
	var delim = oInput.getAttribute("delimiter");
	var newValue = "";
	
	var inputtokens = sapUrMapi_InputTokenizer_splitTokens(oInput);
	for (i = 0; i < inputtokens.length; i++) {
	  if (sapUrMapi_InputTokenizer_matchToken(inputtokens[i], tokenlist, usecase)) {
			inputtokens[i] = "[" + inputtokens[i] + "]" + delim + " ";
	  }
		else {
		  inputtokens[i] = "{" + inputtokens[i] + "}" + delim + " ";
		}
		newValue += inputtokens[i];
	}

	//replace the inner HTML with the new values
	oInput.value=newValue;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_getTokenList
//* parameter   : oInput - pointer to an HTML element that has an attribute 
//*								named "listid" set to a non-empty string
//* return      : a string of delimited token values to use as the validation set
//*								for the InputTokenizer's current data
//*	description	: this method accesses a global variable found through the Input's
//*								listid attribute.  The values in this array are concatenated into
//*								a string delimited by |-|.
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_getTokenList(oInput){
//	var list = window[oInput.getAttribute("listid")]; diese zeile durch die folgende ersetzt
	var listdiv = ur_get(oInput.getAttribute("listid"));
	if (listdiv != null) {
		var tokendelim = listdiv.getAttribute("tokendelim");
		var keydelim = listdiv.getAttribute("keydelim");
  		var list = listdiv.innerHTML.split(tokendelim);
		var retstr = "|-|";
		for (i = 0; i < list.length; i++) {
			var tkn = list[i].split(keydelim);
			retstr += tkn[0] +  "|-|" ;
		}
		return retstr;
	}
}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_splitTokens
//* parameter   : oInput - pointer to an HTML element that has an attribute 
//*								named "delimiter" set to a non-empty string
//* return      : an array of the tokens split by the delimiter
//*	description	: this method accesses a delimiter token from the HTML element's
//*								delimiter attribute and creates a regular expression which 
//*								splits the innerText of the element into an array of token strings
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_splitTokens(oInput) {
	var delim = oInput.getAttribute("delimiter");
	var re = new RegExp("\\s*" + delim + "\\s*", "gi");
	var txt = oInput.value;
	
	//trim leading whitespaces for the entire input field
	while (txt.substr(0,1) == " ") {
		txt = txt.substr(1,txt.length-1);
	}

	//trim trailing whitespaces for the entire input field and trim the last delimiter
	//to keep from adding an extra index into the array
	while (txt.substr(txt.length-1, 1) == " " || txt.substr(txt.length-1, 1) == delim) {
		txt = txt.substr(0, txt.length-1);
	}

	//now replace our marker characters with nothign [,],{,}
	txt = txt.replace(/\[/gi,"");
	txt = txt.replace(/\]/gi,"");
	txt = txt.replace(/\{/gi,"");
	txt = txt.replace(/\}/gi,"");

	//if they didn't put in any delimiters, treat the entire
	//innerText value as a single token
	if (txt.indexOf(delim) == -1) {
	  return new Array(txt);
	}
	else {
		return txt.split(re);
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_matchToken
//* parameter   : sTkn - string value of the token to try and match
//*								sTknList - formated list of tokens to match the token value from
//*								bUseCase - whether or not to use case sensitivity during match
//* return      : boolean true if matched, false if not
//*	description	: this method takes a token string, a list of token values generated
//*								by the sapUrMapi_InputTokenizer_getTokenList function and a boolean
//*								switch for whether or not to use case-sensitivity during the test
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_matchToken(sTkn, sTknList, bUseCase) {
	//switch the comparison based on case-sensitivity
	if (bUseCase) {
	  if (sTknList.indexOf("|-|" + sTkn + "|-|") != -1) {
	    return true;
	  }
	}
	else {
	  if (sTknList.toLowerCase().indexOf("|-|" + sTkn.toLowerCase() + "|-|") != -1) {
	    return true;
	  }
	}
	//we fell through so return false match
	return false;
}
