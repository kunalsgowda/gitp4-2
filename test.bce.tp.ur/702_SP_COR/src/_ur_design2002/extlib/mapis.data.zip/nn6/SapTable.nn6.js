//* ************************************************************************
//* SapTable
//* ************************************************************************
function sapUrMapi_SapTable_getClickedRowIndex(e)
{
   if (typeof(e)=='undefined') {
     oSrc = window.event.target;
   } else {
     oSrc = e.target;
   }
   var obj = oSrc;
   while ( (obj!=null) && (obj.getAttribute("rr")==null) )
      obj = obj.parentElement;
   if(obj==null) return;
   try {
     var rowindex = obj.rr;
     var nr=parseInt(rowindex);
     if (isNaN(nr)) return null;
     else return nr;
   } catch (e) {
     return null;
   }
}

function sapUrMapi_SapTable_getClickedColIndex(e)
{
   if (typeof(e)=='undefined') {
     oSrc = window.event.target;
   } else {
     oSrc = e.target;
   }
   var obj=oSrc;
   while ( (obj!=null) && (obj.getAttribute("cc")==null) )
      obj = obj.parentNode;
   if(obj==null) return;
   try {
     var colindex = obj.cc;
     var nr=parseInt(colindex);
     if (isNaN(nr)) return null;
     else return nr;
   } catch (e) {
     return null;
   }
}
function sapUrMapi_SapTable_getClickedCellId(e)
{
   if (typeof(e)=='undefined') {
     oSrc = window.event.target;
   } else {
     oSrc = e.target;
   }
   var obj=oSrc;
   while ( (obj!=null) && (obj.getAttribute("cc")==null) )
      obj = obj.parentNode;
   if(obj==null) return;
   try {
     var col=obj.cc;
     var thisid = obj.id;
     return thisid;
   } catch (e) {
     return null;
   }
}
function sapUrMapi_SapTable_getClickedRow(sTableId,e) {
   if (typeof(e)=='undefined') {
     oSrc = window.event.target;
   } else {
     oSrc = e.target;
   }
   var obj=oSrc;
   while ( (obj!=null) && (obj.getAttribute("rr")==null) )
      obj = obj.parentElement;
   if(obj==null) return;
     return sapUrMapi_SapTable_getRow(sTableId,parseInt(obj.rr))
 }

function sapUrMapi_SapTable_getRow(sTableId, iRowIdx) {
	var oTable=ur_Table_create(sTableId),
		aRows = oTable.rows,
		iRowIndex = -1,
		sRowIndex = null;

	for (var i=0;i<aRows.length;i++) {
		sRowIndex = aRows[i].ref.getAttribute("rr");
		iRowIndex = -1;

		if(sRowIndex) {
			iRowIndex = parseInt(sRowIndex);
			if(isNaN(iRowIndex)) continue;
		} else continue;

		if (iRowIndex==iRowIdx) return aRows[i].ref;
	}
	return null;
}

function sapUrMapi_SapTable_correctSelectionBorder(oRow) {
}

function sapUrMapi_SapTable_isSecondarySelected(oButton) {
  return oButton.className=="urSTRowSelSecIcon";
}

function sapUrMapi_SapTable_isPrimarySelected(oButton) {
  return oButton.className=="urSTRowSelIcon";
}

function sapUrMapi_SapTable_toggleSecondarySelection(oRow) {
  var oButton = oRow.getElementsByTagName("DIV").item(0);
  sapUrMapi_SapTable_selectRowByObject(oRow, !sapUrMapi_SapTable_isSecondarySelected(oButton), true);
}

var UR_SELECTION_STATE = {
  NOT_SELECTED:0,
  PRIMARY:1,
  SECONDARY:2
}

function sapUrMapi_SapTable_setSelection(oRow, eState) {
  if(eState == UR_SELECTION_STATE.NOT_SELECTED) {
    sapUrMapi_SapTable_selectRowByObject(oRow, false, false);
  } else if(eState == UR_SELECTION_STATE.PRIMARY) {
    sapUrMapi_SapTable_selectRowByObject(oRow, true, false);
  } else if(eState == UR_SELECTION_STATE.SECONDARY) {
    sapUrMapi_SapTable_selectRowByObject(oRow, true, true);
  }
}


function sapUrMapi_SapTable_selectRowByObject(oRow,bSelect,bSecondary) {
  var oButton = oRow.getElementsByTagName("DIV").item(0);
  if(!oButton.getAttribute("rr")||oButton.getAttribute("rr")=="") return;
  var bEdit = false;
  
  //selection mandatory?
  if(!bSelect && oButton.getAttribute("selMust")) return;
  
  if(!bSelect)
    oButton.className="urSTRowUnSelIcon";
  else if(bSecondary)
    oButton.className="urSTRowSelSecIcon";
  else
    oButton.className="urSTRowSelIcon";
  for (var n=0;n<oRow.childNodes.length;n++) {
    oItem=oRow.childNodes[n];
    sapUrMapi_SapTableSelectCell(oItem,false,bSelect,bSecondary);
  }
}


function sapUrMapi_SapTable_selectRow(sTableId, sRowIdx,iCol, iGroup, e) {
  if (typeof(bSecondary)=="undefined") bSecondary=false;
  var oRow = ur_EVT_src(e).parentNode.parentNode;
  while (oRow.tagName!="TR") oRow=oRow.parentNode;
  var oButton = oRow.getElementsByTagName("DIV").item(0);
  if (oButton.className.indexOf("Dsbl")>-1) return oRow;
  var bSelect = oButton.className=="urSTRowSelIcon"||oButton.className=="urSTRowSelSecIcon"?false:true;
  sapUrMapi_SapTable_selectRowByObject(oRow,bSelect,bSecondary);
  return oRow;
}

function sapUrMapi_SapTableSelectCell(oCell,bEdit,bSelect,bSecondary)
{
  var bEdit=false;
  
  if (oCell.getAttribute("urRowSpan") &&  parseInt(oCell.getAttribute("urRowSpan")) > 1) return;
  if (typeof(bSelect)=="undefined") bSelect=true;
  if (typeof(bSecondary)=="undefined") bSecondary=false;
  if (oCell.className.indexOf("Ico")>-1) return;
  
  var bIsReadOnly = oCell.className.indexOf("urSTTDRo2") >= 0;
  
  if (bSelect) {
    if (bSecondary)
      oCell.className = oCell.className + " urST4Sel2" + (bIsReadOnly? "Ro": "");
    else
      oCell.className = oCell.className + " urST4Sel" + (bIsReadOnly? "Ro": "");
  } else {
  	if(bIsReadOnly) {
  		oCell.className=oCell.className.replace(" urST4Sel2Ro","");
	    oCell.className=oCell.className.replace(" urST4SelRo","");
  	} else {
  		oCell.className=oCell.className.replace(" urST4Sel2","");
	    oCell.className=oCell.className.replace(" urST4Sel","");
  	}
  }
}

function sapUrMapi_SapTable_isSelectable(oRow){
	var sButtons = oRow.getElementsByTagName("DIV");
	for(var i=0;i<sButtons.length;i++)
		if(sButtons[i].className=="urSTRowUnSelIcon" || sButtons[i].className=="urSTRowSelIcon") return true;
	return false;
}

function sapUrMapi_SapTable_clickSelButton(oRow,oEvt){
	while(oRow.tagName!="TR") oRow = oRow.parentNode;
	if(oRow.tagName!="TR")return;
	var sButtons = oRow.getElementsByTagName("DIV");
	for(var i=0;i<sButtons.length;i++){
		if(sButtons[i].className=="urSTRowUnSelIcon" || sButtons[i].className=="urSTRowSelIcon" || sButtons[i].className=="urSTRowSelSecIcon"){
			sButtons[i].click();
			return;
		}
	}
}



function sapUrMapi_SapTable_sGenerateMatrixId(sRootId, iRowIndex, iColIndex){ //Changed
  return sRootId + "-mtx_" + iRowIndex + "_" + iColIndex + "_mtx-";
}


function sapUrMapi_SapTable_bIsMatrixId(sId){
	return sId && sId.indexOf("-mtx_") > 0 && sId.indexOf("_mtx-") == sId.length-5;
}


function sapUrMapi_SapTable_focusMatrixItem(sMatrixId){
	var iPosBeginIndex = sMatrixId.indexOf("-mtx_"),
		sRootId = sMatrixId.substring(0, iPosBeginIndex),
		sPos = sMatrixId.substring(iPosBeginIndex+5, sMatrixId.length - 5),
		aPos = sPos.split("_"),
		iRowIndex = parseInt(aPos[0]),
		iColIndex = parseInt(aPos[1]);

	sapUrMapi_SapTable_focusTableCellByPos(sRootId, iRowIndex, iColIndex);
}


function sapUrMapi_SapTable_focusTableCellByPos(sTableId, iRowIndex, iColIndex){
	return false; // FF does not handle focus
}


function sapUrMapi_SapTable_sGetMatrixIdByContentDomRef(sTableId, oContentDomRef){ 
	var oDomRefTable=ur_get(sTableId),
		oTableInfo = (oDomRefTable.ct == "ST")? ur_Table_create(sTableId): null,
		oCurrDomRef = oContentDomRef;
	
	if(oTableInfo) {
		while(oCurrDomRef != null && oCurrDomRef != oDomRefTable && oCurrDomRef.tagName!="BODY") {
			if(oCurrDomRef.parentNode && oCurrDomRef.parentNode.rr && oCurrDomRef.id){
				var oCellInfo = oTableInfo.lookup[oCurrDomRef.id];
				if(oCellInfo) return sapUrMapi_SapTable_sGenerateMatrixId(sTableId, oCellInfo.rowIdx, oCellInfo.colIdx);
			}
			oCurrDomRef = oCurrDomRef.parentNode;
		}
	}
	return "";
}


function sapUrMapi_SapTable_bIsTableId(sTableId){
  var oDomRefTable=ur_get(sTableId);
	return oDomRefTable && oDomRefTable.ct == "ST";
}




// New Table Model
var _ur_tables=new Array();
function ur_Table_create(sId) {
	if (_ur_tables[sId]==null) { 
		//create a table object if not already stored in _ur_tables collection.
		var oRows = new Array();
		var oRefCells = new Array();
		var oBdy = null;
		var iR=0;
		var oTab=ur_get(sId);
		while(oBdy==null){
		  if (oTab.rows[iR].cells[0]==null){iR++;continue;}
		  var oTmp=oTab.rows[iR].cells[0].firstChild;
		  if (oTmp==null) {iR++;continue;}
		  if (oTmp.tagName=="TABLE") {
		    if (oTmp.getAttribute("bd")=="1") {
					oBdy=oTmp;
					break;
		    }	  
		    if (oTmp.firstChild.firstChild.firstChild.getAttribute("ct")=="T") {
					oTb=oTmp.firstChild.firstChild.firstChild;
					bHasTb=true;
		    }	  
		  }
		  iR++;
		}
		var oTRows = oBdy.rows;
		var oDCells = null;
		var oRowSpanedCells = new Array();
		//analyze all rows
		var iMax=0;
		for (var iRowCount=0;iRowCount<oTRows.length;iRowCount++)  {
			var oCells = new Array();
			var iColCount=0;
			oDCells=oTRows[iRowCount].cells;
			var iLength=iMax;
			if (oDCells.length>iMax) iLength=oDCells.length; //find the right length to loop. there might be less cells in a row. therefore we loop to the maximum of cells we found before
			for (var iCol=0;iCol<iLength;iCol++) {
				if (oRowSpanedCells!=null) { //the oRowSpanedCells array passes in cells with rowspans
					for (var k=0;k<oRowSpanedCells.length;k++) {
						if (oRowSpanedCells[k].pos==iCol && oRowSpanedCells[k].rspan>1) { //.pos is the actual column position for the cell.   .rspan is the actual rowspan number, check if its gt 1
							iColCount++;
							oCells.push({ref:oRowSpanedCells[k].o,rspan:true}); //create and add the cell to the cell collection
							for (t=1;t<oRowSpanedCells[k].cspan;t++) { //.cspan loop if the rowspan cell has also a colspan
								iColCount++;
								oCells.push({ref:oRowSpanedCells[k].o,cspan:true,rspan:true}); //create and add the cell to the cell collection
							}
							oRowSpanedCells[k].rspan--; //decrease rspan number ->to be finished in the next row
						}
					}
				}
				if (iCol<oDCells.length) {
					iColCount++;
					oCells.push({ref:oDCells[iCol]});	 //create and add the new cell
					var iColSpan=parseInt(oDCells[iCol].colSpan); //colspan
					if (isNaN(iColSpan)) iColSpan=1;
					var iRowSpan=parseInt(oDCells[iCol].rowSpan); //rowspan
					if (isNaN(iRowSpan)) iRowSpan=1;
					if (iColSpan>1) {
						for (var x=1;x<iColSpan;x++) {
							//append the cells that are colspanned
							oCells.push({ref:oDCells[iCol],cspan:true});
							iColCount++;
						}
					}
					if (iRowSpan>1) oRowSpanedCells.push({rspan:iRowSpan,cspan:iColSpan,o:oDCells[iCol],pos:iCol}); //append the rowspaned cells to oRowSpanedCells array
				}	
			}
			oRows.push({irowidx:oRows.length,ref:oTRows[iRowCount],cells:oCells}); //create and add a row object with cells and a reference
			iMax=iColCount>iMax?iColCount:iMax; //find the row with most columns
		}
		
		//there might be missing cells in some rows. therefore we could add references
		//this section can be used to manipulate existing cell references or add some stuff to cell objects
		//we could also do some width interpreting and setting if needed
		//Build col object
		var oCols=new Array();
		for (var i=0;i<oRows.length;i++){
			for (var j=0;j<iMax;j++) {
				if (oRows[i].cells[j]==null) {
					oRows[i].cells[j]={ref:oRows[i].cells[j-1].ref,empty:true};
					oRows[i].cells[j-1].last=true; //last
				} else {
					oRows[i].cells[j].empty=false;
					oRows[i].cells[j].last=j==iMax-1?true:false; //first cell in row
				}
				if (i>0) oRows[i].previousRow=oRows[i-1];
				if (i<oRows.length-1) oRows[i].nextRow=oRows[i+1];
				oRows[i].irowidx=i;
				var oCell=oRows[i].cells[j]; 
				//add attributes to the row
				oRows[i].sel=-1;

				//add missing attributes to the cell
				oCell.foc=false;
				oCell.sel=-1; //-1 not selected 0 lead selection 1 secondary selection 
				oCell.type="te"; //set of "te,ed,se,hi
				oCell.parentRow=oRows[i]; //remember the own row reference in each cell to get information if in column mode
				oCell.headers=ur_table_getCellHeaders(oCell.ref.getAttribute("headers"));
				oCell.first=j==0?true:false; //first cell in row
				oCell.isTH=oCell.ref.tagName=="TH"; //is it a th tag
				oCell.rowIdx=i;
				oCell.colIdx=j;
				
				//build the columns model
				if (i==0) {
					oCols.push({icolidx:j,cells:new Array()}); //create and add the col to cols collection
				}
				oCell.parentCol=oCols[j];	//remember a col reference for fast access from cell to column
				oCols[j].cells.push(oCell); //push the cell to the column
				
				oCols[j].sel=-1;
				if (oCell.ref.id==null || oCell.ref.id=="") {
					oCell.ref.setAttribute("id",sId+"-cell-"+i+"-"+j);
				}
				if (oRefCells[oCell.ref.id]==null) {
				  oRefCells[oCell.ref.id] = new Array();
				  oRefCells[oCell.ref.id].push=oCell;
				} else {
				  oRefCells[oCell.ref.id].push=oCell;
				}
			}
		}
		// add the new table object to the table collection. the code above is only run once if nothing changes
		_ur_tables[sId]={rows:oRows,cols:oCols,lookup:oRefCells};
	}
  
	return _ur_tables[sId];
}



/* Apply the scrolling from the scrollbar*/
function sapUrMapi_SapTable_Scrollbar_scroll(sId,oEvt) {
  var o=document.getElementById(sId.split("-")[0]);
  if (!o) return;

  if (oEvt.ur_param && oEvt.ur_param["dir"]) {
    var dir=oEvt.ur_param["dir"];
    if (dir=="v") {
      if (ur_getAttD(o,"o"+dir+"scrl","")!="") ur_EVT_fire(o,"o"+dir+"scrl",oEvt);
    } else if (dir=="h") {
      if (ur_getAttD(o,"o"+dir+"scrl","")!="") ur_EVT_fire(o,"o"+dir+"scrl",oEvt);
    }
  }
}


function ur_table_getCellHeaders(s) {
	var result=null;
	if (s!=null && s!="") {
		result=new Array();
		var arrHdr=s.split(",");
		for (var iH=0;iH<arrHdr.length;iH++) {
			var oHdr=ur_get(arrHdr[iH]);
			result.push({ref:oHdr,text:""});
			// TODO: get the text representation of a header object
		}
	}
	return result;
}






function ur_contains(oDomRefContainer, oDomRefChild) {
	var oDomRef = oDomRefChild;
	
	if(oDomRefContainer == oDomRefChild) return true;
	
	while(oDomRef != null) {
		if(oDomRef == oDomRefContainer) return true;
		oDomRef = oDomRef.parentNode;
	}
	
	return false;
};



function sapUrMapi_SapTable_keydown(sId,e){}




function sapUrMapi_SapTable_activate(sId,e){}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SapTable_deactivate
//* parameter   : oEvt   - event object         
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function sapUrMapi_SapTable_deactivate(oEvt){}

function ur_SapTable_getCell(o){
	var oCell=o;
	while(oCell.getAttribute("tp")!="HIC"){
		if(oCell.getAttribute("ct")=="ST") return null;
		oCell=oCell.parentNode;
	}
	return oCell;
}

//Hierarchical Cell Handling
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SapTable_HiCell_cl
//* parameter   : o - cell object
//*               oEvt  - event object of the browser
//* return      : none
//*	description	: handles click events and keydowns on the hierarchical cell
//*               triggers expand,collapse or click event
//* ------------------------------------------------------------------------
function sapUrMapi_SapTable_HiCell_he(o,oEvt) {
	var o=ur_evtSrc(oEvt);
	var oCell=ur_SapTable_getCell(o);
	var sCt=sapUrMapi_getControlTypeFromObject(o);
	var sFunc="";
	var oFunc=null;

	/* check if you clicked on an object within a SapTable cell */
	if(o==null || oCell==null) return;
	
	/* check if you clicked on a control which handles the click or spacebar on its own */
	if(sCt=="I" || sCt=="CB" || sCt=="TE" || sCt=="LN")
		return;
		
	/* handle only click, sapcebar, numpad + or numpad - */
	if( oEvt.type!="click" && !(oEvt.type=="keydown" && (oEvt.keyCode==32 || oEvt.keyCode==107 || oEvt.keyCode==109)))
		return;
		
	/* expand */	
	if(o.className.indexOf("urSTExpOp")>-1 || (oEvt.type=="keydown" && oEvt.keyCode==107))
		sFunc=oCell.getAttribute("oco");
	/* collapse */
	else if(o.className.indexOf("urSTExpClo")>-1 || (oEvt.type=="keydown" && oEvt.keyCode==109))
		sFunc=oCell.getAttribute("oex");
	/* cell click */
	else{
		sFunc=oCell.getAttribute("oc");
		if(sFunc==null && ur_isSt(oCell,ur_st.EXPANDED))
			sFunc=oCell.getAttribute("oco");
		else if(sFunc==null && ur_isSt(oCell,ur_st.COLLAPSED))
			sFunc=oCell.getAttribute("oex");
  }
	
	/* fire event */
	if(sFunc==null) return;
	oFunc=new Function("event",sFunc);
	oFunc(oEvt);
	
	return ur_EVT_cancel(oEvt);
}

/*Handling of the column resize functionality*/
function sapUrMapi_SapTable_resizehandler(oEvt) {
  //check the source element to be on a resize handle
}

/*Handling of drag eventing*/
function ur_SapTable_Drag_mousedown(sTableId,oEvt) {
}

/*Handle the drag start events*/
function ur_SapTable_Drag_start(sTableId,oEvt) {
}


/* Replaces classes an sets the style for the given tag oTag*/
function ur_classNameToStyle(oTag) {
  with (oTag) {
    if (className && currentStyle) {
      style.backgroundColor = currentStyle.backgroundColor;
      style.fontFamily      = currentStyle.fontFamily;
      style.borderStyle     = currentStyle.borderStyle;
      style.borderColor     = currentStyle.borderColor;
      style.borderWidth     = currentStyle.borderWidth;
      style.padding         = currentStyle.padding;
      style.fontSize        = currentStyle.fontSize;
      style.textAlign       = currentStyle.textAlign;
      style.borderCollapse  = currentStyle.borderCollapse;
      className = ""; //erase the classname
    }
    if (childNodes) {
      for (var n = 0;n<childNodes.length;n++) {
        ur_SapTable_modifyDragTable(childNodes[n]);
      }
    }
  }
}

function ur_SapTable_applySortCursor(oEvt) {
  var o=ur_evtSrc(oEvt);
  o = ur_getNextHtmlParentByAttribute(o, "stasc");
  o.style.cursor="url(" + ur_system.mimepath + "saptable/sort.cur)";
  o.onmouseover=null;
  return false;
}
