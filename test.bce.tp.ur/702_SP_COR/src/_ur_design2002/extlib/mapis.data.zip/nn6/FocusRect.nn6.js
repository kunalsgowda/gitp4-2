function sapUrMapi_Focus_getFocusOffset(object){}
function sapUrMapi_Focus_canFocus(o){
	if (o==null) return;
	if (!o.tagName) return;
	var tag=","+o.tagName+",";
  //if (tag==",IFRAME,") return true; who added this. this produces bug in iframe control -->where is this needed?
	if((tag==",INPUT,")&&(o.type=="hidden"||o.disabled)){ 
		return false;
	}
	var search=",A,BODY,BUTTON,FRAME,IFRAME,INPUT,ISINDEX,OBJECT,SELECT,TEXTAREA,";
	if (search.indexOf(tag)>-1){
	   if (!ur_system.is508 && o.tabIndex<0)
	       return (o.ti>=0);
	   else
	      return (o.tabIndex>=0);
	}
	if (!o.getAttribute) return;
	if (o.getAttribute("ti")!=null) return (parseInt(o.getAttribute("ti"))>=0);
}
function sapUrMapi_Focus_getNextFocusableElement(o){
	while (o!=null) {
		if (sapUrMapi_Focus_canFocus(o)) return o;
		o=o.parentNode;
	}
	return null;
}
function sapUrMapi_Focus_showFocusRect(sId){}
function sapUrMapi_Focus_RegisterCreate(sId){}
function sapUrMapi_Focus_getCurrentId(){}
function sapUrMapi_Focus_reset(){}
function sapUrMapi_Focus_remove(){}
function sapUrMapi_Focus_getFocusRectHeight() {return 0;}
function sapUrMapi_Focus_calcFocusRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom){}
function sapUrMapi_Focus_DeflBtn_hideFocusRect(IsDeflBtn){};
