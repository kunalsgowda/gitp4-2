//* ************************************************************************
//* Input Field
//* ************************************************************************
//Datepicker init
var aMonthNames=null;
var aDayNames=null;
var aDayNameAbbrevs=null;
var aDayCount=null;

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_setInvalid
//* parameter   :	sId      - id of an inputfield
//*             : bSet     - true to set the inputfield invalid, false to set it valid
//*							: sTooltip - string - tooltip to be set
//* description : sets an input field valid or invalid
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_setInvalid(sId,bSet,sTooltip) {
	var oIn=ur_get(sId);
	if (oIn.disabled || oIn.readonly || (ur_isSt(sId,ur_st.INVALID)&&bSet) || (!ur_isSt(sId,ur_st.INVALID)&&!bSet)) return;
  var oLbl=sapUrMapi_Label_getInputLabel(sId);
	sapUrMapi_Label_setInvalid(oLbl,bSet);
	if(sTooltip!="") oIn.setAttribute("tt",sTooltip);
	ur_setSt(sId,ur_st.INVALID,bSet);
	if(bSet)
		oIn.className=oIn.className+" urEdf2TxtInv";
	else
    oIn.className=oIn.className.replace(" urEdf2TxtInv","");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_setDisabled
//* parameter   :	sId - string - id of a inputfield
//*             : bSet - bool - true to set the inputfield to disabeled, false to unset
//* description : sets the disabled status of an input field
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_setDisabled(sId,bSet) {
	var oIn=ur_get(sId);
  var oLbl=sapUrMapi_Label_getInputLabel(sId);
  var oBtn=ur_get(sId+"-btn");
  
	if (bSet && !ur_isSt(sId,ur_st.DISABLED)) {
		sapUrMapi_Label_setDisabled(oLbl);
	  oIn.readOnly=true;
		oIn.className+=" urEdf2TxtDsbl";
		if(oBtn!=null) 
			oBtn.className=oBtn.className+"Dsbl";
		ur_setSt(sId,ur_st.DISABLED,bSet);	
	} 
	else if(!bSet && ur_isSt(sId,ur_st.DISABLED)){
		sapUrMapi_Label_setEnabled(oLbl);
	  oIn.readOnly=false;
    oIn.className=oIn.className.replace(" urEdf2TxtDsbl","");
		if(oBtn!=null)
			oBtn.className=oBtn.className.substring(0,oBtn.className.length-4);
	  ur_setSt(sId,ur_st.DISABLED,bSet);
  }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_setReadonly
//* parameter   :	sId - string - id of a inputfield
//*             : bSet - bool - true to set the inputfield to readonly, false to unset
//* description : sets the readonly status of an input field
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_setReadonly(sId,bSet) {
	var oIn=ur_get(sId);
  var oLbl=sapUrMapi_Label_getInputLabel(sId);
  var oBtn=ur_get(sId+"-btn");
  
	if (bSet && !ur_isSt(sId,ur_st.READONLY)) {
		sapUrMapi_Label_setDisabled(oLbl);
	  oIn.readOnly=true;
		oIn.className+=" urEdf2TxtRo";
		ur_setSt(sId,ur_st.READONLY,bSet);
	} 
	else if(!bSet && ur_isSt(sId,ur_st.READONLY)){
		sapUrMapi_Label_setEnabled(oLbl);
	  oIn.readOnly=false;
		oIn.className=oIn.className.replace(" urEdf2TxtRo","");
	  ur_setSt(sId,ur_st.READONLY,bSet);
  }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_keydown
//* parameter   :	sId - string - id of a inputfield
//*             : e   - event
//* description : handle keyboard navigation for the input field
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_keydown(sId,e){
	var o=ur_get(sId);
	var iKeyCode=e.keyCode;
	// show value help when you press f4
	if((e.altKey && (e.keyCode==40||e.keyCode==38)) || e.keyCode==115){
		var oBtn = ur_get(sId+"-btn") 
		if(oBtn)
			oBtn.onclick(e);
		return ur_EVT_cancel(e);
	}
	/* show data tip when you press ctrl+shift+i (old key ctrl+q)*/
	if( (e.keyCode==73) && e.shiftKey && sapUrMapi_bCtrl(e)  && !e.altKey ){
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
		return ur_EVT_cancel(e);
	}
	if(e.which == 27){
		sapUrMapi_DataTip_hide(sId);
		return ur_EVT_cancel(e);
	}
	// If the value is a default value from the server, do not allow editing the value.
	// It is only allowed to enter a new value.
	var sDefaultValue=o.getAttribute("defval");
	if(sDefaultValue && o.value == sDefaultValue){
		var sNavigationKeys="|"+ur_KEYS.UP+"|"+ur_KEYS.DOWN+"|"+ur_KEYS.LEFT+"|"+ur_KEYS.RIGHT+"|"+ur_KEYS.POS1+"|"+ur_KEYS.END+"|"+ur_KEYS.PAGE_UP+"|"+ur_KEYS.PAGE_DOWN+"|";
		if(sNavigationKeys.indexOf("|"+iKeyCode+"|") >=0) {
			return ur_EVT_cancel(e);		
		}				
	}	

}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_changeLabel
//* parameter   :	sId       - string - id of a inputfield
//*             : sNewLabel - string - new labeltext of the input field
//* description : changes the label text of the input field used in the tooltip
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_changeLabel(sId,sNewLabel){
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_focus
//* parameter   :	sId  - string - id of an inputfield
//*               oEvt - event object
//* description : sets the focus to an input field
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_focus(sId,oEvt) {
	var o=ur_get(sId);
  sapUrMapi_focusElement(sId);
  if (o.getAttribute("st").indexOf("d")>-1) o.disabled=true;
  sapUrMapi_DataTip_show(sId,"focus");
  ur_setEditCellColor(o);
  sapUrMapi_InputField_showButton(o,oEvt);
  // if you are not allowed to change the value, only to enter a new value, select the value
  var sDefaultValue=o.getAttribute("defval");
  if(sDefaultValue && o.value == sDefaultValue){
       o.select();
	    o.onclick=ur_InputField_click;
  }

}

//* ------------------------------------------------------------------------
//* function    : ur_InputField_click
//* description : called when you click on an input field
//* return      : none
//* ------------------------------------------------------------------------
function ur_InputField_click(oEvt) {
	var o=ur_evtSrc(oEvt);
	
	// if you are not allowed to change the value, only to enter a new value, select the value
	var sDefaultValue=o.getAttribute("defval");
	if(sDefaultValue && o.value == sDefaultValue){
		o.select();
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_focusWithFormat
//* parameter   :	sId  - string - id of an inputfield
//*							:	sFormat  - dateFormatString to be used for the inputfield
//*               oEvt - event object
//* description : sets the focus to an input field
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_focusWithFormat(sId,sFormat,oEvt) {
	var o=ur_get(sId);
	sapUrMapi_InputField_focus(sId,oEvt);
	if (ur_getAttD(o,"tp","")=="DATE") {
	   o.setAttribute("df",sFormat);
	}
}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_triggerOnChange
//* parameter   :	sId - string - id of an inputfield
//*               sOldValue - string - old value of the input field
//*               sNewValue - string - new value of the input field
//* description : triggers the on change event on an input field if new differs from oldvalue
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_triggerOnChange(sId,sOldValue,sNewValue) {
  var oInp = ur_get(sId);
  if (sOldValue!=sNewValue) {
    if (oInp.onchange!=null) return oInp.onchange();
  }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_setValue
//* parameter   :	sId - string - id of an inputfield
//*               sValue - string - value of the input field
//* description : sets the value of an input field
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_setValue(sId,sValue) {
  ur_get(sId).value=sValue;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_getValue
//* parameter   :	sId - string - id of an inputfield
//* description : returns the value of an input field
//* return      : string value of the input field
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_getValue(sId) {
  return ur_get(sId).value;
}

//* ************************************************************************
//* DatePicker
//* ************************************************************************
var oDatePicker;
var dActDate;

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Date_getArray
//* parameter   :	sFormat - string - Format string for a sDate string
//*             : sDate - string - Date to format
//* description : formats the datestring and splits it into parts
//* return      : date array
//* ------------------------------------------------------------------------
function sapUrMapi_Date_getArray(sFormat,sDate) {
  var q;
  if ( sFormat == 1 || sFormat == 4 )
    q=sDate.split(".");
  if ( sFormat == 2 || sFormat == 5 || sFormat == 7)
    q=sDate.split("/" );
  if ( sFormat == 3 || sFormat == 6 || sFormat == 8)
    q=sDate.split("-");
  for (var i=0;i<q.length;i++) {
  	var str=q[i];
		if(str.length==2 && str.charAt(0)=='0'){
		  str=str.charAt(1);
		}
		q[i]=parseInt(str);
  }

  return q;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Date_normalize
//* parameter   :	sFormat - string - Format string for a sDate string
//*             : arrDate - string - Date to format
//* description : normalizes a date array depending on the sFormat
//* return      : normalized date array where year is [0], month is [1], day [2]
//* ------------------------------------------------------------------------
function sapUrMapi_Date_normalize(sFormat,arrDate) {
  // returns datearray where year is [0], month is [1], day [2]
	var Day=1;
	var Month=0;
	var Year=0;
	if(sFormat==1 || sFormat==7 || sFormat==8){
		Day=arrDate[0];
		Month=arrDate[1];
		Year=arrDate[2];
	}
	else if(sFormat==2 || sFormat==3){
		Day=arrDate[1];
		Month=arrDate[0];
		Year=arrDate[2];
        }
	else if(sFormat==4 || sFormat==5 || sFormat== 6){
		Day=arrDate[2];
		Month=arrDate[1];
		Year=arrDate[0];
	}
	var arrRet=new Array(3);
	arrRet[0]=Year;
	arrRet[1]=Month-1;
	arrRet[2]=Day;
	return arrRet;
}

function sapUrMapi_Date_make(sFormat,vYear,vMonth,vDay)
{
  var dateString;
  if ( sFormat == 1 )
    dateString=sapUrMapi_Date_setZero(parseInt(vDay)) + "." + sapUrMapi_Date_setZero(parseInt(vMonth)) + "." + vYear;
  if ( sFormat == 2 )
    dateString=sapUrMapi_Date_setZero(parseInt(vMonth)) + "/" + sapUrMapi_Date_setZero(parseInt(vDay)) + "/" + vYear;
  if ( sFormat == 3 )
    dateString=sapUrMapi_Date_setZero(parseInt(vMonth)) + "-" + sapUrMapi_Date_setZero(parseInt(vDay)) + "-" + vYear;
  if ( sFormat == 4 )
    dateString="" + vYear + "." + sapUrMapi_Date_setZero(parseInt(vMonth)) + "." + sapUrMapi_Date_setZero(parseInt(vDay));
  if ( sFormat == 5 )
    dateString="" + vYear + "/" + sapUrMapi_Date_setZero(parseInt(vMonth)) + "/" + sapUrMapi_Date_setZero(parseInt(vDay));
  if ( sFormat == 6 )
    dateString="" + vYear + "-" + sapUrMapi_Date_setZero(parseInt(vMonth)) + "-" + sapUrMapi_Date_setZero(parseInt(vDay));
  if ( sFormat == 7 )
    dateString=sapUrMapi_Date_setZero(parseInt(vDay)) + "/" + sapUrMapi_Date_setZero(parseInt(vMonth)) + "/" + vYear;
  if ( sFormat == 8 )
    dateString=sapUrMapi_Date_setZero(parseInt(vDay)) + "-" + sapUrMapi_Date_setZero(parseInt(vMonth)) + "-" + vYear;
  return dateString;
}

function sapUrMapi_InputField_showActualDatePicker(sId, oEvt) {
	  var dt=sapUrMapi_DateField_getDate(sId);
    sapUrMapi_InputField_showDatePicker(sId,dt.year,dt.month-1,dt.day,ur_system.firstdayofweek, oEvt);
}
function sapUrMapi_InputField_showDatePicker(sId,iYear,iMonth,iDay,iFirstDayOfWeek, oEvt) {
	oInput=ur_get(sId);
	if (ur_getAttD(oInput,"st","").indexOf("d")>-1) return;
	ur_focus(oInput);
  if (typeof(iFirstDayOfWeek)=="undefined") {
  	iFirstDayOfWeek=ur_system.firstdayofweek;
  }
  if (isNaN(iYear) || isNaN(iMonth) || isNaN(iDay)) {
	  var dt=sapUrMapi_DateField_getDate(sId);
	  iYear=dt.year;
	  iMonth=dt.month;
	  iDay=dt.day;
	  if (isNaN(iYear) || isNaN(iMonth) || isNaN(iDay)) {
			var dt=new Date();
			iYear  = dt.getFullYear();
			iMonth = dt.getMonth();
			iDay   = dt.getDate();
		} 
  }

	if (oInput.getAttribute("dsbl")=="true") return;
	var arrUrls;
	arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
	if (oDatePicker) {
	    var oCal = sapUrMapi_DatePicker_make(sId,iYear,iMonth,iDay,iFirstDayOfWeek);
	  	try {
	  	  oDatePicker.frame.window.document.getElementsByTagName("BODY")[0].innerHTML=oCal.innerHTML;
	  	} catch(ex) {}
	  } else {
	    dActDate  = new Date(iYear,iMonth,iDay);
	    var oCal = sapUrMapi_DatePicker_make(sId,iYear,iMonth,iDay,iFirstDayOfWeek);
	    oDatePicker = new sapPopup(window,arrUrls,oCal,ur_get(sId+"-btn"),oEvt,0);
		oDatePicker.positionbehavior = sapPopupPositionBehavior.MENURIGHT;
		//oDatePicker.onblur = sapUrMapi_hideDatePicker;
		if (ur_system.direction=="rtl") {
		  oDatePicker.position.right=oDatePicker.position.right-1;
		} else {
		  oDatePicker.position.left=oDatePicker.position.left-1;
		}
		oDatePicker.inputId=sId;
		oDatePicker.position.top=oDatePicker.position.top-1;
	  	oDatePicker.show();
	  	oDatePicker.frame.window.focus();
	  	
	  	var focusedDateCell=oDatePicker.frame.window.document.getElementById(iYear + "-"+ (iMonth+1)+ "-"+iDay);
	  	if (focusedDateCell) {
	  		focusedDateCell.tabIndex = "0";
	  		focusedDateCell.focus()
	  	} else {
	  		oDatePicker.frame.window.document.getElementById("dp").focus();
	  	}
	  	window.onfocus = sapUrMapi_hideDatePicker;
		
		//cancel the event and prevent default actions
		//event.preventDefault();
	}
	var focusedDateCell=oDatePicker.frame.window.document.getElementById(iYear + "-"+ (iMonth+1)+ "-"+iDay);
	if (focusedDateCell) {
		focusedDateCell.tabIndex = "0";
		focusedDateCell.focus()
	} else {
		oDatePicker.frame.window.document.getElementById("dp").focus();
	}
  oEvt.stopPropagation();
}


function sapUrMapi_hideDatePicker() {
	try {
  		window.focus(); //needed for safari because it does not set the focus correctly if the window does not have the focus.
	    ur_focus(oPopup.source.object);
	} catch(e) {}
	
 	if (oDatePicker) {
		oDatePicker.hide();
		oDatePicker.onblur=null;
 	  if (oDatePicker.inputId) document.getElementById(oDatePicker.inputId).focus();
		oDatePicker=null;
		oPopup=null;
	}
}
function sapUrMapi_DatePicker_keydown(hWnd,sId,iFirstDayOfWeek,oEvt) {
	var iKey = oEvt.keyCode,
		oCell = ur_EVT_src(oEvt);
		iOneDay = 1000*60*60*24;
	if (oCell.tagName == "TD") {
		var oFocusCell = null;
		var sDay = oCell.id;
		var aDate = sDay.split("-");
		var dDate = new Date(aDate[0],aDate[1]-1,aDate[2],15);
		var iDays = 0;
		
		if (iKey==ur_KY.PREV) {
			dDate.setTime(dDate.getTime() - iOneDay);
		} else if(iKey==ur_KY.NEXT) {
			dDate.setTime(dDate.getTime() + iOneDay);
		} else if(iKey==ur_KY.UP) {
			dDate.setTime(dDate.getTime() - (7*iOneDay));
		} else if(iKey==ur_KY.DOWN) {
			dDate.setTime(dDate.getTime() + (7*iOneDay));
		} else if((iKey==ur_KY.PGUP || iKey==ur_KY.PGDOWN)) {
			//Page Up and Down
			var iYear = dDate.getFullYear();
			var iMonth = dDate.getMonth();
			var iDays= dDate.getDate();
			if (oEvt.shiftKey)
				iYear = iKey==ur_KY.PGUP ? iYear-1 : iYear+1;
			else
				iMonth = iKey==ur_KY.PGUP ? iMonth-1 : iMonth+1;
		
			dDate.setFullYear(iYear);
			if (iMonth<0) {
				dDate.setFullYear(dDate.getFullYear()-1);
				iMonth=11;
			}
			if (iMonth>11) {
				dDate.setFullYear(dDate.getFullYear()+1);
				iMonth=0;
			}
			dDate.setMonth(iMonth);
			dDate.setDate(iDays);
		
			//we need to correct if we did not reach the right month because the day does not exist (like 30 Feb)
			if (dDate.getMonth()>iMonth) {
				sapUrMapi_Date_setDayCount(iMonth,iYear);
				iDays = aDayCount[iMonth];
				dDate.setDate(iDays);
				dDate.setMonth(iMonth);
			}
		} else if(iKey==ur_KY.HOME && oEvt.shiftKey) {
			dDate.setDate(1);
		} else if(iKey==ur_KY.END  && oEvt.shiftKey) {
			sapUrMapi_Date_setDayCount(dDate.getMonth(),dDate.getFullYear());
			dDate.setDate(aDayCount[dDate.getMonth()]);
		} else if(iKey==ur_KY.HOME) {
			var iDays = dDate.getDay() - iFirstDayOfWeek;
			if (iFirstDayOfWeek>0 && dDate.getDay() < iFirstDayOfWeek) iDays = dDate.getDay()+ 7 - iFirstDayOfWeek;
			dDate.setTime(dDate.getTime() - (iDays * iOneDay));
		} else if(iKey==ur_KY.END) {
			var iDays = 6 - dDate.getDay() + iFirstDayOfWeek;
			if (iDays==7) iDays=0;
			dDate.setTime(dDate.getTime() + (iDays * iOneDay));
		} else if(iKey==ur_KY.TAB || iKey == 27 || iKey == 115 ) {
			sapUrMapi_hideDatePicker();
			window.focus();
			if (iKey == 27 || iKey == 115) ur_EVT_cancel(oEvt);
			return;
		} else if(iKey==ur_KY.RETURN || iKey==ur_KY.SPACE) {
			sapUrMapi_DatePicker_select(sId,oEvt);
			window.focus();
			return;
		}
		var sDayId = dDate.getFullYear()+"-"+(dDate.getMonth()+1)+"-"+dDate.getDate();
		var oFocusCell = hWnd.document.getElementById(sDayId);
		if (oFocusCell && oFocusCell.className!="urCalIna") {
			oFocusCell.tabIndex = "0";
			oCell.tabIndex = "-1";
			oFocusCell.focus();
		} else {
			if (dDate.getFullYear()==10000) {
				oCell.focus();
			} else {
				sapUrMapi_InputField_showDatePicker(sId,dDate.getFullYear(),dDate.getMonth(),dDate.getDate(),iFirstDayOfWeek,oEvt,true)
			}
		}
	}	
	ur_EVT_cancel(oEvt);
	return false;
}

function sapUrMapi_DatePicker_select(sId,e) {
  var o = e.target;
  var oInput=ur_get(sId);
  if(ur_isSt(sId,ur_st.READONLY))
	  return;
  while (o.tagName!="TD") {
  	o = o.parentNode;
  	if (o==null) return;
  }
	sDay = o.getAttribute("id");
	if (sDay==null || sDay=="") return;
  if (sDay) {
    var aDate = sDay.split("-");
    var arrValue=new Array();
    arrValue[0]=parseInt(aDate[2]);
    arrValue[1]=parseInt(aDate[1]);
    arrValue[2]=parseInt(aDate[0]);
    sapUrMapi_DateField_setDate(sId,arrValue[0],arrValue[1],arrValue[2]);
		  sapUrMapi_hideDatePicker();
		  ur_focus(oInput);
    
  }
}

function sapUrMapi_Date_setZero(iInt) {
	return iInt<10?"0"+iInt:iInt;
}

function sapUrMapi_DatePicker_make(sId,iYear,iMonth,iDay,iFirstDayOfWeek) {
  var arrTmp = ur_txt[ur_language];
  if (aMonthNames==null) aMonthNames = new Array (arrTmp["SAPUR_JANUARY"],arrTmp["SAPUR_FEBRUARY"],arrTmp["SAPUR_MARCH"],arrTmp["SAPUR_APRIL"],arrTmp["SAPUR_MAY"],arrTmp["SAPUR_JUNE"],arrTmp["SAPUR_JULY"],arrTmp["SAPUR_AUGUST"],arrTmp["SAPUR_SEPTEMBER"],arrTmp["SAPUR_OCTOBER"],arrTmp["SAPUR_NOVEMBER"],arrTmp["SAPUR_DECEMBER"]);
  if (aDayNameAbbrevs==null)   aDayNameAbbrevs   = new Array (arrTmp["SAPUR_SUNDAY_ABBREV"],arrTmp["SAPUR_MONDAY_ABBREV"],arrTmp["SAPUR_TUESDAY_ABBREV"],arrTmp["SAPUR_WEDNESDAY_ABBREV"],arrTmp["SAPUR_THURSDAY_ABBREV"],arrTmp["SAPUR_FRIDAY_ABBREV"],arrTmp["SAPUR_SATURDAY_ABBREV"]);
  if (aDayCount==null)  aDayCount = new Array (31,28,31,30,31,30,31,31,30,31,30,31);

  sapUrMapi_Date_setDayCount(iMonth,iYear);
  if (typeof(iFirstDayOfWeek)=="undefined") {
  	iFirstDayOfWeek=ur_system.firstdayofweek;
  }
  var oCal = ur_get("ur-date-picker");
  if (!oCal) {
	  var oBody = document.getElementsByTagName("BODY")[0];
	  var oCal = document.createElement("SPAN");
	  oCal.id="ur-date-picker";
	  oCal.style.position="absolute";
	  if (ur_system.direction=="rtl") {
	    oCal.style.right="0";
	  } else {
	    oCal.style.left="0";
	  }
	  oCal.style.top="-1999px";
	  oBody.appendChild(oCal);
  }
  var o=ur_get(sId);
  var bRO=o.readOnly;
  var sCalHtml = "<div onkeydown=\"return me.sapUrMapi_DatePicker_keydown(window,'"+sId+"',"+iFirstDayOfWeek+",event)\" onclick=\"me.sapUrMapi_DatePicker_select('"+sId+"',event);return false;\"><table class='urCalPicWhl' cellpaddding='0' cellspacing='0' border='0' viscnt='0'><tbody><tr>";
  var pm = iMonth-1;
  var nm = iMonth+1;
  var dy = iDay;
  var py = iYear;
  var ny = iYear;
  if (pm==-1) {pm = 11;py--;}
  if (nm==12) {nm = 0;ny++;}
  if (dy>28) {dy=25}
 if (py<0 && pm==11) {
		sCalHtml    += "<td class=\"urCalArrPrevDsbl\">&nbsp;</td>";
	} else {
		sCalHtml    += "<td id=\"prev\" class=\"urCalArrPrev\" onclick=\"me.sapUrMapi_InputField_showDatePicker('"+sId+"',"+py+","+pm+","+dy+","+iFirstDayOfWeek+",event,true);\">&nbsp;</td>";
	}
  sCalHtml    += "<td colspan=6 class=urCalHdr nowrap align=center>"+aMonthNames[iMonth]+" "+iYear+"</td>";
  sCalHtml    += "<td ";
  if(ny>9999 && nm==0) {
    sCalHtml  += " class=\"urCalArrNextDsbl\">";
  } else {
    sCalHtml  += "id=\"next\" class=\"urCalArrNext\" onclick=\"me.sapUrMapi_InputField_showDatePicker('"+sId+"',"+ny+","+nm+","+dy+","+iFirstDayOfWeek+",event,true);\">";
  }
  sCalHtml    += "&nbsp;";
  sCalHtml    += "</td>";
  sCalHtml    += "</tr>";
  sCalHtml    += "<tr>";
  iLastDayOfWeek = iFirstDayOfWeek-1;
  if (iLastDayOfWeek==-1) iLastDayOfWeek=6;
  
  if (ur_system.direction=="rtl") {
    sCalHtml    += "<td class=urCalName style=\"border-left:0px none\">&nbsp;</td>";
  } else {
    sCalHtml    += "<td class=urCalName style=\"border-right:0px none\">&nbsp;</td>";
  }
  for (var i=iFirstDayOfWeek;i<aDayNameAbbrevs.length;i++) {
    if (aDayNameAbbrevs.length>3) {
      aDayNameAbbrevs[i]=aDayNameAbbrevs[i].substring(0,3);
    }
    sCalHtml    += "<td class=urCalName>"+aDayNameAbbrevs[i]+"</td>";
  }
  for (var i=0;i<iFirstDayOfWeek;i++) {
    sCalHtml    += "<td class=urCalName>"+aDayNameAbbrevs[i]+"</td>";
  }
  var dDate  = new Date(iYear,iMonth,1,12);
  dDate.setFullYear(iYear);
  var dStart=dDate;
  dStart = new Date(dStart.getTime()-((dStart.getDay()-iFirstDayOfWeek)*1000*60*60*24));
  if (dStart.getDate() >= 1 && dStart.getDate() <= 7) dStart = new Date(dStart.getTime()-(7*1000*60*60*24));

  var iFirstWeekCode=30;                                                   
  //the framework should give us the variables for minimalDaysInFirstWeek because it depends of the locale
 
  var iMinimalDaysInFirstWeek=ur_system.minimalDaysInFirstWeek;
  if (!iMinimalDaysInFirstWeek) iMinimalDaysInFirstWeek=4;
		
	for (var i=0;i<6;i++) {
   
    var oDateObj=new Date();
    var weekNum=ur_getWeek(dStart,iMinimalDaysInFirstWeek);
    
    sCalHtml    += "<tr class=urCalRow";
    if (!bRO) sCalHtml    += " style=\"cursor:pointer;\"";
		sCalHtml    += ">";
		
		sCalHtml    +=                                                           
		"<th class=urCalName style='border-style:none" +                         
		((i<5)?" none solid none":"")+" !important;'>" +                         
		weekNum+"</th>";                                       
    for (var n=0;n<7;n++) {
			var sClass="",
				sId=dStart.getFullYear()+"-"+(dStart.getMonth()+1)+"-"+dStart.getDate();
			if (dStart.getFullYear()<0 || dStart.getFullYear()>9999) {
				sId="";
			}
	  		if (dStart.getMonth()!=iMonth) {
	  			sClass="urCalIna";
	  		} else {
	  			sClass="";
	  		}
	  		if ((dStart.getFullYear()==dActDate.getFullYear()) && (dStart.getMonth()==dActDate.getMonth()) && (dStart.getDate()==dActDate.getDate())) {
	  			sClass+=" urCalDaySelEmp";
	  		}
	  		sCalHtml+="<td";
				if (n==0) {
	  		  sCalHtml+=" style=\"border-left-style:solid\"";
	  		}
	  		var dToday = new Date();
	  		var sCellContent = dStart.getDate();
	  		var bToday = false;
	  		if ((dStart.getFullYear()==dToday.getFullYear()) && (dStart.getMonth()==dToday.getMonth()) && (dStart.getDate()==dToday.getDate())) {
	  			sCellContent = "<div style=\"margin:-1;cursor:hand;background-color:transparent\" class=urCalTod>"+dStart.getDate()+"</div>"
	  			bToday = true;
	  		}
			if (sClass!="") {
        		sCalHtml+=" class="+sClass+" id=\""+sId+"\">"+sCellContent+"</td>";
	      	} else {
	        	sCalHtml+=" id=\""+sId+"\">"+sCellContent+"</td>";
	      	}
	  		var oldStart = dStart;
	  		dStart = new Date(dStart.getTime()+(1000*60*60*24));
	  		if (dStart.getDate()==oldStart.getDate()) {
	  		  //js bug width daylightsaving time
	  		  dStart = new Date(dStart.getTime()+(1000*60*60*1));
	  		}
	  		if (dStart.getHours()==1) {
	  		  dStart = new Date(dStart.getTime()-(1000*60*60*1));
	  		}
  	}
    sCalHtml    += "</tr>";
  }
  sCalHtml += "</tr></tbody></table></div>";
  oCal.innerHTML=sCalHtml;

  return oCal;

}

function sapUrMapi_Date_setDayCount(iMonth, iYear) {
	if ((iMonth == 1) && ((iYear % 400 == 0)) || ((iYear % 4 == 0) && (iYear % 100 != 0))) aDayCount[1] = 29;
	else aDayCount[1] = 28;
}

//* ************************************************************************
//* MaskedInputField
//* ************************************************************************
var urSizeDiv = null;
var urInpSizes = new Array();
var urInpWidths = new Array();
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_KeyUp
//* parameter   : id - the id of the input field
//*				  event - the event object
//* return      : none
//*	description	: this resizes the input field's mask effect after a key has
//*				  been entered into the input field
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_KeyUp(id, event) {
	return false;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_Blur
//* parameter   : id - the id of the input field
//*				  event - the event object
//* return      : none
//*	description	: this turns off the mask effect on the input field when the
//*				  loses the focus
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_Blur(id, event) {
	var o=ur_get(id);
	sapUrMapi_DataTip_hide(id);
	if (ur_getAttD(o,"tp","")=="DATE") {
	  sapUrMapi_DateField_checkDate(id);
	}
	ur_removeEditCellColor();
	sapUrMapi_InputField_hideButton(o,event);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_change
//* parameter   : sId  - control id
//*								oEvt - event object
//* return      :
//* description	: 
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_change(sId,oEvt) {}

//*-------------------------------------------------------------------------
//* function	: sapUrMapi_InputFieldHelpClick
//*-------------------------------------------------------------------------
function sapUrMapi_InputFieldHelpClick(sId,oEvt) {
	//disabled button has no picker.
	if (ur_getAttD(ur_get(sId),"st","").indexOf("d")>-1) return;
        var o=ur_get(sId);	
	if (o.getAttribute("dp")!="1") {
            o.onfocus();
            sapUrMapi_InputField_showActualDatePicker(sId,oEvt);
	} else {
	    sapUrMapi_hideDatePicker();
	}
}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_showButton
//* parameter   : o    - input field object
//*								oEvt - event object
//* return      :
//* description	: show the value help button
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_showButton(o,oEvt){
	var oBtn=ur_get(o.id+"-btn");
	// if there is no button or the button is already at the correct position, do nothing
	if(oBtn==null || oBtn.parentNode.offsetTop>=0) return;
	
	// get top position
	var iTop=o.offsetTop;
	var oParent=o.offsetParent;
	while(oParent!=document.body){
		if(oParent.style.position=="absolute") 
			break;	
		iTop+=oParent.offsetTop;
		iTop-=oParent.scrollTop;
		oParent=oParent.offsetParent;
	}
	// subtract scrolling except body scrolling
		oParent=o.parentNode;
		while(oParent!=document.body){
			iTop-=oParent.scrollTop;
			oParent=oParent.parentNode;
	}
	oBtn.parentNode.style.top=iTop;
	oBtn.style.zIndex=101;  
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputField_hideButton
//* parameter   : o    - input field object
//*								oEvt - event object
//* return      :
//* description	: hide the value help button
//* ------------------------------------------------------------------------
function sapUrMapi_InputField_hideButton(o,oEvt){
	var oBtn=ur_get(o.id+"-btn");
	if(oBtn==null || oBtn.parentNode.style.position!="absolute")return;
	ur_callDelayed("ur_get('"+oBtn.id+"').parentNode.style.top='-900px'",500);
}
/*
function sapUrMapi_DateField_keypress(oEvt) {
  return;
  if (!oEvt) oEvt=window.event;
  var sPattern=ur_DateField_getDatePattern();
  var sChars=sPattern;
  while (sChars.indexOf("M")>-1) sChars=sChars.replace("M","");
  while (sChars.indexOf("y")>-1) sChars=sChars.replace("y","");
  while (sChars.indexOf("d")>-1) sChars=sChars.replace("d","");
  sChar=String.fromCharCode(oEvt.keyCode);
  var sReplaced="'";
  var sOldPattern=sPattern;
  sNewPattern=sPattern;
  for (var i=0;i<sChars.length;i++) {
		if (sReplaced.indexOf(sChars.charAt(i))>-1) continue;
		var sNewPattern="";
		for (var j=0;j<sOldPattern.length;j++) {
			if (sPattern.charAt(j)==sChars.charAt(i)) {
				sNewPattern=sNewPattern+"["+sOldPattern.charAt(j)+"]";
			} else {
				sNewPattern+=sOldPattern.charAt(j);
			}
		}
		sOldPattern=sNewPattern;
		sReplaced+=sChars.charAt(i);
  }
  sPattern=sNewPattern;
  if ((oEvt.keyCode>=48 && oEvt.keyCode<=57) || (sChars.indexOf(sChar)>-1)) {
    oEvt.returnValue=true
  } else {
    oEvt.returnValue=false
  }
}
*/

function sapUrMapi_DateField_checkDate(sId) {
  //var dt=sapUrMapi_DateField_getDate(sId);
  //if (isNaN(dt.day) || isNaN(dt.month) || isNaN(dt.year)) return;
  //sapUrMapi_DateField_setDate(sId,dt.day,dt.month,dt.year);
}
function sapUrMapi_DateField_getDate(sId) {
  var dToday=new Date();
  var sValue=sapUrMapi_InputField_getValue(sId);
  if (sValue=="") return {day:iDay,month:iMonth,year:iYear};
  var sPattern=ur_DateField_getDatePattern(sId);
  var sLongPattern=sPattern;
  var dgtsYr=0;
  //format the value a bit better
  var sFindNumber="0123456789";
  var sFindPattern="dMy";
  var iDay,iMonth,iYear;
  var iErrors=0;
	while(sFindNumber.indexOf(sValue.charAt(0))==-1) {
		sValue=sValue.substring(1);
		iErrors++;
	}
	while(sFindNumber.indexOf(sValue.charAt(sValue.length-1))==-1) {
	  sValue=sValue.substring(0,sValue.length-1);
		iErrors++;
	}
  //allow some standard formats for inputs 
  var sRegPattern="([^0-9])";
  var reg=new RegExp(sRegPattern,"ig");
  var arr=reg.exec(sValue);
  var xValue=sValue;
	var sCh=RegExp.$1;
	var sCh1;
	var twodelimiters=false;
	//Fix to handle the special char problem
	 try{
	xValue=sValue.split(sCh);

  if (xValue.length != 3)
  {
	var reg1=new RegExp(sRegPattern,"ig");
	var stempval=xValue[1];
	if(stempval!=null)
	while(reg1.exec(stempval))
	{
		var arr1= reg1.exec(stempval);
		sCh1=RegExp.$1;
		xValue=stempval.split(sCh1);
		stempval=xValue[1];
	}
	}
 
	
	if(sCh1!=null) {
	twodelimiters=true;
	if (sValue.indexOf(sCh) > sValue.indexOf(sCh1))
	{
		var tmp=sCh1;
		sCh1=sCh;
		sCh=tmp;
		
	}
	}
	}catch(Exp){}
    reg=new RegExp(sRegPattern,"ig");
    arr=reg.exec(sValue);

	if (reg.lastIndex>0) {
    if (sValue.indexOf(sCh)==4 || sValue.indexOf(sCh)==3) {
		  xValue=sPattern.replace("yyyy",sValue.substring(0,sValue.indexOf(sCh)));
				  if(twodelimiters)
			{
			  xValue=xValue.replace("MM",sValue.substring(sValue.indexOf(sCh)+1,sValue.lastIndexOf(sCh1)));
			  xValue=xValue.replace("M",sValue.substring(sValue.indexOf(sCh)+1,sValue.lastIndexOf(sCh1)));
			  xValue=xValue.replace("dd",sValue.substring(sValue.lastIndexOf(sCh1)+1));
			  xValue=xValue.replace("d",sValue.substring(sValue.lastIndexOf(sCh1)+1));
			}
	      else
			{
		  xValue=xValue.replace("MM",sValue.substring(sValue.indexOf(sCh)+1,sValue.lastIndexOf(sCh)));
		  xValue=xValue.replace("M",sValue.substring(sValue.indexOf(sCh)+1,sValue.lastIndexOf(sCh)));
		  xValue=xValue.replace("dd",sValue.substring(sValue.lastIndexOf(sCh)+1));
		  xValue=xValue.replace("d",sValue.substring(sValue.lastIndexOf(sCh)+1));
			}
		  sValue=xValue;
    }
  } 
	while(sFindPattern.indexOf(sPattern.charAt(sPattern.length-1))==-1) sPattern=sPattern.substring(0,sPattern.length-1);
  while (sPattern.indexOf(" ")>-1) sPattern=sPattern.replace(" ","");
  while (sValue.indexOf(" ")>-1) {
		//iErrors++;
    sValue=sValue.replace(" ","");
  }
  if (iErrors>3) return {day:iDay,month:iMonth,year:iYear};
  
  //now handle the given format
  var reg=ur_DateField_getRegExpTest(sValue,sPattern);
  if (reg.lastIndex>0) {
    //correct some stuff if possible.
    //find the order of month day and year
    var iDayPos=sPattern.indexOf("d");
    var iMonthPos=sPattern.indexOf("M");
    var iYearPos=sPattern.indexOf("y");
    var sDay,sMonth,sYear="";
    if(iDayPos != -1)
    {    
		if (iDayPos<iMonthPos && iDayPos<iYearPos) sDay=RegExp.$1;
    if (iDayPos>iMonthPos && iDayPos<iYearPos) sDay=RegExp.$2;
    if (iDayPos<iMonthPos && iDayPos>iYearPos) sDay=RegExp.$2;
    if (iDayPos>iMonthPos && iDayPos>iYearPos) sDay=RegExp.$3;
    if (iMonthPos==-1)
		{
		if( iDayPos<iYearPos) sDay=RegExp.$1;
		else
		if(iDayPos>iYearPos) sDay=RegExp.$2;
		}
	if (iYearPos==-1)
		{
		if( iDayPos<iMonthPos) sDay=RegExp.$1;
		else
		if(iDayPos>iMonthPos) sDay=RegExp.$2;
		}
    if(iMonthPos==-1 && iYearPos==-1)
		sDay=RegExp.$1;
		
		while (sDay.indexOf("0")==0 && sDay.length>1) sDay=sDay.substring(1);
		iDay=parseInt(sDay);
		if (iDay==0) iDay=1;
	}
	else
	{iDay=-1;}
	if (iMonthPos != -1	)
	{
    if (iMonthPos<iDayPos && iMonthPos<iYearPos) sMonth=RegExp.$1;
    if (iMonthPos>iDayPos && iMonthPos<iYearPos) sMonth=RegExp.$2;
    if (iMonthPos<iDayPos && iMonthPos>iYearPos) sMonth=RegExp.$2;
    if (iMonthPos>iDayPos && iMonthPos>iYearPos) sMonth=RegExp.$3;
    //finally
    if (iDayPos==-1)
		{
		if( iMonthPos<iYearPos) sMonth=RegExp.$1;
		else
		if(iMonthPos>iYearPos) sMonth=RegExp.$2;
		}
	if (iYearPos==-1)
		{
		if( iMonthPos<iDayPos) sMonth=RegExp.$2;
		else
		if(iMonthPos>iDayPos) sMonth=RegExp.$1;
		}
	if(iDayPos==-1 && iYearPos==-1)
		sMonth=RegExp.$1;
		
   // if( iDayPos==-1 && iMonthPos<iYearPos) sMonth=RegExp.$1;
    while (sMonth.indexOf("0")==0 && sMonth.length>1) sMonth=sMonth.substring(1);
		iMonth=parseInt(sMonth);
	}
	else
		iMonth=-1;
	if(iYearPos != -1)
	{
    if (iYearPos<iMonthPos && iYearPos<iDayPos) sYear=RegExp.$1;
    if (iYearPos>iMonthPos && iYearPos<iDayPos) sYear=RegExp.$2;
    if (iYearPos<iMonthPos && iYearPos>iDayPos) sYear=RegExp.$2;
    if (iYearPos>iMonthPos && iYearPos>iDayPos) sYear=RegExp.$3;
    //finally
    if (iDayPos==-1)
		{
		if(iMonthPos<iYearPos) sYear=RegExp.$2;
		else
		if(iMonthPos>iYearPos) sYear=RegExp.$1;
		}
	if (iMonthPos==-1)
		{
		if(iYearPos<iDayPos) sYear=RegExp.$1;
		else
		if(iYearPos>iDayPos) sYear=RegExp.$2;
		}
	if(iDayPos==-1 && iMonthPos==-1)
		sYear=RegExp.$1;    
	dgtsYr=sYear.length;
    while (sYear.indexOf("0")==0 && sYear.length>1) sYear=sYear.substring(1);
		iYear=parseInt(sYear);
	}
	else
	iYear =-1;
		var arrMonth=new Array(0,31,29,31,30,31,30,31,31,30,31,30,31);
  	if (isNaN(iYear) && isNaN(iMonth) && isNaN(iDay)) return {day:iDay,month:iMonth,year:iYear};
		if (isNaN(iYear)) iYear=dToday.getFullYear();
		if (isNaN(iMonth)) iMonth=dToday.getMonth()+1;
		if (isNaN(iDay) && iMonth==dToday.getMonth()+1) iDay=dToday.getDate();
		if (isNaN(iDay) && iMonth!=dToday.getMonth()+1) iDay=1;
		if (isNaN(iYear) || isNaN(iMonth) || isNaN(iDay)) return {day:iDay,month:iMonth,year:iYear};
		if (iMonth>12) iMonth=12;
		if (iMonth<1) iMonth=1;
		if (iDay>arrMonth[iMonth]) iDay=arrMonth[iMonth];
		if ( dgtsYr != 4 && dgtsYr !=0)
		{
		if (iYear<=20) iYear+=	2000;
		else if (iYear>20 && iYear<=99) iYear+=1900;
		}
		if (iMonth==2 && iDay==29 && (!ur_DateField_isLeapYear(iYear))) iDay=28;
    return {day:iDay,month:iMonth,year:iYear};
  } else {
  	/*if (isNaN(iYear) && isNaN(iMonth) && isNaN(iDay)) return {day:iDay,month:iMonth,year:iYear};
		if (isNaN(iYear)) iYear=dToday.getFullYear();
		if (isNaN(iMonth)) iMonth=dToday.getMonth()+1;
		if (isNaN(iDay) && iMonth==dToday.getMonth()+1) iDay=dToday.getDate();
		if (isNaN(iDay) && iMonth!=dToday.getMonth()+1) iDay=1;
		if (isNaN(iYear) || isNaN(iMonth) || isNaN(iDay)) return {day:iDay,month:iMonth,year:iYear};
    */
    return {day:iDay,month:iMonth,year:iYear};
  }
  oEvt.returnValue=false;
  
}
function ur_DateField_getRegExpTest(sValue,sPattern) {
  var sPatternNew="";
  var sEscapeChars="()*$[]\/^{}|. -";
  var sFindNumberPattern="dMy";
  var bFoundNumber=false;
  for (var j=0;j<sPattern.length;j++) {
    if (!bFoundNumber && sFindNumberPattern.indexOf(sPattern.charAt(j))>-1) bFoundNumber=true;
    if (bFoundNumber) {
			if (sEscapeChars.indexOf(sPattern.charAt(j))>-1) sPatternNew=sPatternNew+"[^0-9]{0,1}";
			else sPatternNew+=sPattern.charAt(j);
		}
  }
  sRegPattern=sPatternNew.replace("dd","([0-9]{1,2})");
  sRegPattern=sRegPattern.replace("MM","([0-9]{1,2})");
  sRegPattern=sRegPattern.replace("d","([0-9]{1,2})");
  sRegPattern=sRegPattern.replace("M","([0-9]{1,2})");
  sRegPattern=sRegPattern.replace("yyyy","([0-9]{1,4})");
  sRegPattern=sRegPattern.replace("yy","([0-9]{1,4})");
  var reg=new RegExp(sRegPattern,"ig");
  var arr=reg.exec(sValue);
	if (reg.lastIndex==0) {
		sRegPattern=sPatternNew.replace("dd","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("MM","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("d","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("M","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("yyyy","([0-9]{1,4})");
		sRegPattern=sRegPattern.replace("yy","([0-9]{1,4})");
		var reg=new RegExp(sRegPattern,"ig");
		var arr=reg.exec(sValue);
  }
  if (reg.lastIndex==0 && sValue.length>2) {
		sRegPattern=sPatternNew.replace("dd","([0-9]{2,2})");
		sRegPattern=sRegPattern.replace("MM","([0-9]{2,2})");
		sRegPattern=sRegPattern.replace("d","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("M","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("yyyy","");
		sRegPattern=sRegPattern.replace("yy","");
		if (sRegPattern.indexOf("\\(")==-1 && sRegPattern.indexOf("\\)")==-1) {
		  sRegPattern=sRegPattern.substring(sRegPattern.indexOf("("),sRegPattern.lastIndexOf(")")+1);
		}
		var reg=new RegExp(sRegPattern,"ig");
	  var arr=reg.exec(sValue);
	}
  if (reg.lastIndex==0 && sValue.length>2) {
		sRegPattern=sPatternNew.replace("dd","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("MM","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("d","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("M","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("yyyy","");
		sRegPattern=sRegPattern.replace("yy","");
		if (sRegPattern.indexOf("\\(")==-1 && sRegPattern.indexOf("\\)")==-1) {
		  sRegPattern=sRegPattern.substring(sRegPattern.indexOf("("),sRegPattern.lastIndexOf(")")+1);
		}
		var reg=new RegExp(sRegPattern,"ig");
	  var arr=reg.exec(sValue);
	}
  if (reg.lastIndex==0) {
		sRegPattern=sPatternNew.replace("dd","([0-9]{2,2})");
		sRegPattern=sRegPattern.replace("MM","");
		sRegPattern=sRegPattern.replace("d","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("M","");
		sRegPattern=sRegPattern.replace("yyyy","");
		sRegPattern=sRegPattern.replace("yy","");
		if (sRegPattern.indexOf("\\(")==-1 && sRegPattern.indexOf("\\)")==-1) {
		  sRegPattern=sRegPattern.substring(sRegPattern.indexOf("("),sRegPattern.lastIndexOf(")")+1);
		}
		var reg=new RegExp(sRegPattern,"ig");
	  var arr=reg.exec(sValue);
	}
	return reg;
}

function ur_DateField_isLeapYear(iYear) {
  return ((iYear % 400 == 0) || ((iYear % 4 == 0) && (iYear % 100 != 0)));
}

function sapUrMapi_DateField_setDate(sId,iDay,iMonth,iYear) {
  var sPattern=ur_DateField_getDatePattern(sId);
  if (iYear<10) iYear = "000"+iYear;
  else if (iYear<100) iYear = "00"+iYear;
  else if (iYear<1000) iYear = "0"+iYear;
  var sFormat=sPattern;
  var s=sPattern.replace("dd",ur_DateField_addZero(iDay));
  s=s.replace("MM",ur_DateField_addZero(iMonth));
  s=s.replace("yyyy",iYear+"");
  if (iYear<1950) {
    s=s.replace("yy",iYear+"");
  } else {
    s=s.replace("yy",(iYear+"").substring(2));
  }
  s=s.replace("d",iDay+"");
  s=s.replace("M",iMonth+"");
	sapUrMapi_InputField_setInvalid(sId,false,"");
	var oldValue=sapUrMapi_InputField_getValue(sId);
	sapUrMapi_InputField_setValue(sId,s)
	sapUrMapi_InputField_triggerOnChange(sId,oldValue,s);
}

function ur_DateField_getDatePattern(sId) {
	var o=ur_get(sId);
	var sFormatString="";
	if (ur_getAttD(o,"tp","")=="DATE") {
	  sFormatString=ur_getAttD(o,"df","");
	}
	if (sFormatString=="") {
	  sFormatString=ur_system.dateformatstring;
	}
	if (sFormatString!=null && sFormatString!="") 
		{//Stripping the extra "'" in Chinese locales.
		while(sFormatString.indexOf("'")>-1) {sFormatString=sFormatString.replace("'","");}
		return sFormatString;
		}
	var iFormat=ur_system.dateformat;
	if (iFormat==1) return "dd.MM.yyyy";
	if (iFormat==2) return "MM/dd/yyyy";
	if (iFormat==3) return "MM-dd-yyyy";
	if (iFormat==4) return "yyyy.MM.dd";
	if (iFormat==5) return "yyyy/MM/dd";
	if (iFormat==6) return "yyyy-MM-dd";
	if (iFormat==7) return "dd/MM/yyyy";
	if (iFormat==8) return "dd-MM-yyyy";
}

function ur_DateField_addZero(i) {
  return i<10&&i>0?"0"+i:""+i;
}

function ur_getFirstDayOfFirstWeek(iFullYear, minDays) {
    var oFirstDay = new Date(iFullYear, 0, minDays, 12, 0, 0),
        iFirstDay = oFirstDay.getDay(),
        iDiff = iFirstDay - ur_system.firstdayofweek,
        DAY = 86400000;
    if (iDiff < 0)
        iDiff += 7;
    var ilFirstDayOfFirstWeek = oFirstDay.getTime() - (iDiff) * DAY;
    return ilFirstDayOfFirstWeek;
};

function ur_getWeek(oDate, minDays) {
    var iFirstDayOfFirstWeekYear = oDate.getFullYear(),
        iFirstDayOfFirstWeek = ur_getFirstDayOfFirstWeek(iFirstDayOfFirstWeekYear, minDays),
        WEEK = 86400000 * 7,
        iWeekNum = Math.floor((oDate.getTime() - iFirstDayOfFirstWeek) / WEEK + .5) + 1;
    if (iWeekNum >= 53) {
        var itFirstDayOfFirstYear = ur_getFirstDayOfFirstWeek(oDate.getFullYear() + 1, minDays);
        if (itFirstDayOfFirstYear - oDate.getTime() < WEEK)
            iWeekNum = 1;
    }
    return iWeekNum;

}