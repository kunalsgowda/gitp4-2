function sapUrMapi_SapTable_getClickedRowIndex(e)
{
}

function sapUrMapi_SapTable_getClickedColIndex(e)
{
}
function sapUrMapi_SapTable_getClickedCellId(e)
{
}
function sapUrMapi_SapTable_getClickedRow(sTableId,e) {
}

function sapUrMapi_SapTable_getRow(sTableId, iRowIdx) {
}

function sapUrMapi_SapTable_correctSelectionBorder(oRow)
{
}

function sapUrMapi_SapTable_correctSelectionBorder4Table(id)
{
}

function sapUrMapi_SapTable_selectRowByObject(oRow,bSelect,bSecondary)
{
}

function sapUrMapi_SapTable_selectRow(sTableId,sRowIdx,iCol,iGroup,e,bSecondary)
{
}

function sapUrMapi_SapTableSelectCell(oCell,bEdit,bSelect,bSecondary)
{
}
