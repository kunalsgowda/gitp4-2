function sapUrMapi_Table_selectRow(sTableId,iRow,e) {
}
function sapUrMapi_Table_getClickedRowIndex(sId) {
}
function sapUrMapi_Table_getClickedColIndex(sId) {
}
function sapUrMapi_Table_getClickedCellId(sId) {
}
function sapUrMapi_Table_clickSelButton(o){
}
function sapUrMapi_Table_getCellIndex(oCell){
}
function sapUrMapi_Table_getCell(oRow,iIdx){
}
function sapUrMapi_Table_focusUp(sId,o){
}
function sapUrMapi_Table_focusDown(sId,o){
}
function sapUrMapi_Table_focusPrevious(sId,o){
}
function sapUrMapi_Table_focusNext(sId,o){
}
function sapUrMapi_Table_tabBack(sId,o){
	return false;
}
function sapUrMapi_Table_keydown(sId,e){
}
function sapUrMapi_Table_activate(sId,e){
}