function sapUrMapi_Tree_collapseAll(sTreeId) {
}
function sapUrMapi_Tree_expandAll(sTreeId) {
}
function sapUrMapi_Tree_toggle( sTreeId, sNodeId, bClose, bKey) {
}
function sapUrMapi_Tree_focusNode(sTreeId,sNodeId,bInit,bNoFocus) {
}
function sapUrMapi_TreeNode_keyDown(sTreeId,sNodeId,e) {
}
function sapUrMapi_TreeNode_hover(sTreeId,sNodeId,bIn,e) {
}
function sapUrMapi_TreeNode_mouseover(sTreeId,sNodeId,e) {
}
function sapUrMapi_TreeNode_mouseout(sTreeId,sNodeId,e) {
}
function sapUrMapi_Tree_enter (sTreeId,e) {
}
function sapUrMapi_Tree_expandNode(sTreeId,sFocusedNode,sMainContainerNode) {
}
function sapUrMapi_Tree_collapseNode(sTreeId,sFocusedNode, sMainContainerNode) {
}
function sapUrMapi_Tree_keyDown(sTreeId,e) {
}
function sapUrMapi_Tree_controlExit(sTreeId, sNodeId,e) {
}
function sapUrMapi_Tree_ignoreControlEvents() {
}
function sapUrMapi_Tree_controlEnter(sTreeId, sNodeId,e) {
	return false;
}
function sapUrMapi_Tree_getNodeId(sId) {
	return "";
}
function sapUrMapi_Tree_selectNode(sTreeId, sNodeId, iSelLevel) {
}
function sapUrMapi_Tree_deselectAll(sTreeId) {
}