function sapUrMapi_Link_activate(sLinkId,e) {
}
