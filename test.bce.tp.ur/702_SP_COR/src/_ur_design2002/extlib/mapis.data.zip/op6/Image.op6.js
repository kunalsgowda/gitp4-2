function sapUrMapi_Image_menuActivate(sImageId,e) {
}
function sapUrMapi_Image_checkClick(sId, e) {
}
