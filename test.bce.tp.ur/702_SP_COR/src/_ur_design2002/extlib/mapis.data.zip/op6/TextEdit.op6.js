function sapUrMapi_TextEdit_focus(sId,oEvt){
}
function sapUrMapi_TextEdit_blur(sId,oEvt) {
}
function sapUrMapi_TextEdit_keydown(sId,oEvt) {
}