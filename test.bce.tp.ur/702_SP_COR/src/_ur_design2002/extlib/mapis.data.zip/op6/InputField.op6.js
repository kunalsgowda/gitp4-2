//* ************************************************************************
//* Input Field
//* ************************************************************************
//Datepicker init
var aMonthNames=null;
var aDayNames=null;
var aDayNameAbbrevs=null;
var aDayCount=null;
function sapUrMapi_InputField_setInvalid(sId,bSet,sTooltip) {
}
function sapUrMapi_InputField_setDisabled(sId,bSet) {
}

function sapUrMapi_InputField_setReadonly(sId,bSet) {
}
function sapUrMapi_InputField_keydown(sId,e){
}
function sapUrMapi_InputField_changeLabel(sId,sNewLabel){
}
function sapUrMapi_InputField_focus(sId,oEvt) {
}
function sapUrMapi_InputField_showLength(o,oEvt) {
}
function sapUrMapi_InputField_triggerOnChange(sId,sOldValue,sNewValue) {
  var oInp = ur_get(sId);
  if (sOldValue!=sNewValue) {
    if (oInp.onchange!=null) return oInp.onchange();
  }
}
function sapUrMapi_InputField_setValue(sId,sValue) {
  ur_get(sId).value=sValue;
}
function sapUrMapi_InputField_getValue(sId) {
  return ur_get(sId).value;
}
var oDatePicker;
var dActDate;

function sapUrMapi_Date_getArray(sFormat,sDate) {
}
function sapUrMapi_Date_normalize(sFormat,arrDate) {
}

function sapUrMapi_Date_make(sFormat,vYear,vMonth,vDay)
{
}

function sapUrMapi_InputField_showActualDatePicker(sId, oEvt) {
}
function sapUrMapi_InputField_showDatePicker(sId,iYear,iMonth,iDay,iFirstDayOfWeek, oEvt) {
}

function sapUrMapi_hideDatePicker() {
}
function sapUrMapi_DatePicker_select(sId,e) {
}

function sapUrMapi_Date_setZero(iInt) {
}

function sapUrMapi_DatePicker_make(sId,iYear,iMonth,iDay,iFirstDayOfWeek) {
}

function sapUrMapi_Date_setDayCount(iMonth, iYear) {
}

//* ************************************************************************
//* MaskedInputField
//* ************************************************************************
var urSizeDiv = null;
var urInpSizes = new Array();
var urInpWidths = new Array();
function sapUrMapi_InputField_KeyUp(id, event) {
}
function sapUrMapi_InputField_Blur(id, event) {
}
function sapUrMapi_InputField_initMask() {
}
function sapUrMapi_InputField_change(sId,oEvt) {
}
function sapUrMapi_InputFieldHelpClick(id,e) {
}
function sapUrMapi_InputField_showButton(o,oEvt){
}
function sapUrMapi_InputField_hideButton(o,oEvt){
}
