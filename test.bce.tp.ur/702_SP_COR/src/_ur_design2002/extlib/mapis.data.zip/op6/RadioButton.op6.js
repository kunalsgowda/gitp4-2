function sapUrMapi_RadioButton_registerCreate(sId) {
}
function sapUrMapi_RadioButton_create(sId) {
}
function sapUrMapi_RadioButton_toggle(sId,e) {
  return true;
}
function sapUrMapi_RadioButton_setDisabled(sId) {
}
function sapUrMapi_RadioButton_setEnabled(sId) {
}
function sapUrMapi_RadioButton_setReadonly(sId,bSet){
}
function sapUrMapi_RadioButton_focus(sId,oEvt) {
}
function sapUrMapi_RadioButton_blur(sId,oEvt) {
}
function sapUrMapi_RadioButton_keydown(sId,oEvt) {
}

