var sapUrDomainRelaxing = {NONE:"NONE",MINIMAL:"MINIMAL",MAXIMAL:"MAXIMAL"};
try {ur_language==null;} catch(e) {ur_language="en"};
ur_txt=new Array();
ur_KEYS = {TAB:9,ESCAPE:27,
           UP:38,DOWN:40,LEFT:37,RIGHT:39,
           BEGIN:36,END:35,PAGE_UP:33,PAGE_DOWN:34,POS1:36,
           BACKSPACE:8,DELETE:46,ENTER:13,SPACE:32,INSERT:45,
           F4:115}