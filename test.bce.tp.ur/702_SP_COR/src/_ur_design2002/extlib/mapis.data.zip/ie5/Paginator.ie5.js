//* ************************************************************************
//* Paginator
//* ************************************************************************
UR_PAGINATOR_BUTTON = {BEGIN:0, PREVIOUS_PAGE:1, PREVIOUS_ITEM:2,NEXT_ITEM:3,NEXT_PAGE:4,END:5};

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Paginator_setStates
//* parameter   : sId - string id of the Paginator
//*               arrBtns   - Array of Paginator Buttons
//*               arrStates - Array of Paginator Buttons  State (Enabled, Disabled)
//* return      : none
//* description	: sets the state of the paging buttons in a given paginator control (sId)
//*               use the UR_PAGINATOR_BUTTON constants to build the array.
//* ------------------------------------------------------------------------
function sapUrMapi_Paginator_setStates(sId, arrBtns, arrStates) {
	var oPaginator  = ur_get(sId);
	var oButton;
	var bHorizontal = oPaginator.getAttribute("ur_direction")=="horizontal";
	for (var n=0;n<arrBtns.length;n++) {
		try {
		  oButton= ur_get(sId+"-btn-"+arrBtns[n]);
		  if (oButton==null) continue;
		} catch (e) {
		  continue;
		}
		if (arrStates[n]) {
		  if (ur_isSt(oButton,ur_st.DISABLED)) {
		  	var arrClass=oButton.className.split(" ");
		  	arrClass[0]=arrClass[0].replace("Dsbl","");
		  	arrClass[2]=arrClass[2].replace("Dsbl","");
		  	oButton.className=arrClass.join(" ");
		  	ur_setSt(oButton,ur_st.DISABLED,false);
		  	oButton.setAttribute("href","javascript:void(0)");
		  }
		} else {
		  if (!ur_isSt(oButton,ur_st.DISABLED)) {
		  	var arrClass=oButton.className.split(" ");
		  	arrClass[0]=arrClass[0]+"Dsbl";
		  	arrClass[2]=arrClass[2]+"Dsbl";
		  	oButton.className=arrClass.join(" ");
		  	oButton.href=null;
		  	ur_setSt(oButton,ur_st.DISABLED,true);
		  	oButton.removeAttribute("href");
		  }
		}
	}
  sapUrMapi_Focus_showFocusRect();
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Paginator_buttonDisabled
//* parameter   : e - event object
//* return      : none
//* description	: Checks whether a pressed paginator button is disabled
//* ------------------------------------------------------------------------
function sapUrMapi_Paginator_buttonDisabled(o) {
  if (o.ct=="PG") return true;
  return ur_isSt(o,ur_st.DISABLED);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Paginator_getInputValue
//* parameter   : sId - string id of the Paginator
//* return      : integer
//* description	: Retrieves the value(page/item number) of the paginators inputfield
//* ------------------------------------------------------------------------
function sapUrMapi_Paginator_getInputValue(sId) {
  var oInp=ur_get(sId+"-inp");
  if (oInp!=null) return parseInt(oInp.value);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Paginator_setInputValue
//* parameter   : sId - string id of the Paginator
//* return      : none
//* description	: Sets the value(page/item number) of the paginators inputfield
//* ------------------------------------------------------------------------
function sapUrMapi_Paginator_setInputValue(sId,iNewValue) {
  var oInp=ur_get(sId+"-inp");
  if (oInp!=null) oInp.value=iNewValue;
}

function sapUrMapi_Paginator_click(sId,sConId,oEvt) {
  var o=ur_EVT_src(oEvt);
  if (o.id.indexOf("-btn")==-1) return;
  if (!sapUrMapi_Paginator_buttonDisabled(o)) {
    ur_EVT_fire(o,"ocl",oEvt);
  }
}
function sapUrMapi_Paginator_keydown(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
  if (o.id.indexOf("-btn")==-1) return;
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
    sapUrMapi_triggerClick(oEvt,new Array("32"),o.parentNode); //for FF we need the o.parentNode as there is the onClick handler defined. In IE the click bubbles.
  }
  if ((o.id.indexOf("-menu")>-1) && ((oEvt.keyCode==40) || (oEvt.keyCode==13)|| (oEvt.keyCode==32))) {
    return ur_EVT_cancel(oEvt);
  }
  if (oEvt.keyCode>36 && oEvt.keyCode<41) {
	  return ur_EVT_cancel(oEvt);
  }
  if (oEvt.keyCode==32) {
	  return ur_EVT_cancel(oEvt);
  }
  if (oEvt.keyCode>=33 && oEvt.keyCode<=36) {
    var oBtn=null;
		if (oEvt.keyCode==33) { //PageUp
			oBtn=ur_get(sId+"-btn-1");
		}
		if (oEvt.keyCode==34) { //PageDown
			oBtn=ur_get(sId+"-btn-4");
		}
		if (oEvt.keyCode==36) { //Pos1
			oBtn=ur_get(sId+"-btn-0");
		}
		if (oEvt.keyCode==35) { //End
			oBtn=ur_get(sId+"-btn-5");
		}
    if (oBtn!=null) { 
      sapUrMapi_focusElement(oBtn.id);
      if (!sapUrMapi_Paginator_buttonDisabled(oBtn)) {
        ur_EVT_fire(oBtn,"ocl",oEvt);
      }
    }
	}
}


function sapUrMapi_Paginator_navBegin(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
		var arrButtonArray = new Array();
		arrButtonArray[0]=UR_PAGINATOR_BUTTON.PREVIOUS_PAGE;
		arrButtonArray[1]=UR_PAGINATOR_BUTTON.PREVIOUS_ITEM;
		arrButtonArray[2]=UR_PAGINATOR_BUTTON.BEGIN;
		arrButtonArray[3]=UR_PAGINATOR_BUTTON.NEXT_PAGE;
		arrButtonArray[4]=UR_PAGINATOR_BUTTON.NEXT_ITEM;
		arrButtonArray[5]=UR_PAGINATOR_BUTTON.END;
		var arrStateArray = new Array();
		arrStateArray[0]=false;
		arrStateArray[1]=false;
		arrStateArray[2]=false;
		arrStateArray[3]=true;
		arrStateArray[4]=true;
		arrStateArray[5]=true;
		sapUrMapi_Paginator_setStates(sId,arrButtonArray,arrStateArray);
		try {
	    if (sapUrMapi_getControlType(sConId)=="PCSEQ") 
	      sapUrMapi_bounceItem(sConId,-1,"PCSEQ");
			if (sapUrMapi_getControlType(sConId)=="PCTAB") 
				sapUrMapi_bounceItem(sConId,-1,"PCTAB");
	  } catch (ex) {}  
		return true;
  }
  return false
}
function sapUrMapi_Paginator_navEnd(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
		var arrButtonArray = new Array();
		arrButtonArray[0]=UR_PAGINATOR_BUTTON.NEXT_PAGE;
		arrButtonArray[1]=UR_PAGINATOR_BUTTON.NEXT_ITEM;
		arrButtonArray[2]=UR_PAGINATOR_BUTTON.END;
		arrButtonArray[3]=UR_PAGINATOR_BUTTON.PREVIOUS_PAGE;
		arrButtonArray[4]=UR_PAGINATOR_BUTTON.PREVIOUS_ITEM;
		arrButtonArray[5]=UR_PAGINATOR_BUTTON.BEGIN;
		var arrStateArray = new Array();
		arrStateArray[0]=false;
		arrStateArray[1]=false;
		arrStateArray[2]=false;
		arrStateArray[3]=true;
		arrStateArray[4]=true;
		arrStateArray[5]=true;
		sapUrMapi_Paginator_setStates(sId,arrButtonArray,arrStateArray);
		try {
	    if (sapUrMapi_getControlType(sConId)=="PCSEQ") 
	      sapUrMapi_bounceItem(sConId,1,"PCSEQ");
			if (sapUrMapi_getControlType(sConId)=="PCTAB") 
				sapUrMapi_bounceItem(sConId,1,"PCTAB");
	  } catch (ex) {}  
		return true;
  }
  return false;
}
function sapUrMapi_Paginator_navPrevPage(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
		try {
	    if (sapUrMapi_getControlType(sConId)=="PCSEQ") 
	      ur_PcSeq_pageItem(sConId,-1,"PCSEQ");
			if (sapUrMapi_getControlType(sConId)=="PCTAB") 
				sapUrMapi_pageItem(sConId,-1,"PCTAB");				
	  } catch (ex) {}  
		return true;
  }
  return false;
}
function	sapUrMapi_Paginator_navNextPage(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
		try {
	    if (sapUrMapi_getControlType(sConId)=="PCSEQ") 
	      ur_PcSeq_pageItem(sConId,1,"PCSEQ");
	        if (sapUrMapi_getControlType(sConId)=="PCTAB") 
				sapUrMapi_pageItem(sConId,1,"PCTAB");
			
	  } catch (ex) {}  
		return true;
  }
  return false;
}
function sapUrMapi_Paginator_navPrev(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
		try {
	    if (sapUrMapi_getControlType(sConId)=="PHI") 
	        sapUrMapi_PhaseIndicator_paging(sConId,"BACK");
	    if (sapUrMapi_getControlType(sConId)=="PCSEQ") 
	      ur_PcSeq_scrollItem(sConId,-1,"PCSEQ");
			if (sapUrMapi_getControlType(sConId)=="PCTAB") 
				sapUrMapi_scrollItem(sConId,-1,"PCTAB");
			if(sapUrMapi_getControlType(sConId)=="TS")
			{
				ur_IScr_toPrevItem(sConId);
				var oCon = ur_get(sConId);
				var ifocIdx = parseInt(oCon.getAttribute('fidx'));
				if(ifocIdx > 0)
					ur_TS_setTabIdx(sConId,ifocIdx,-1);
			    ur_EVT_addParam(oEvt,"FirstVisibleItemIdx",ur_IScr[sConId].first);
			}
	    } catch (ex) {}  
		return true;
  }
  return false;
}
function sapUrMapi_Paginator_navNext(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
    try {
	    if (sapUrMapi_getControlType(sConId)=="PHI") 
	      sapUrMapi_PhaseIndicator_paging(sConId,"FURTHER");
	    if (sapUrMapi_getControlType(sConId)=="PCSEQ") 
	      ur_PcSeq_scrollItem(sConId,1,"PCSEQ");
	    if (sapUrMapi_getControlType(sConId)=="PCTAB") 
	      sapUrMapi_scrollItem(sConId,1,"PCTAB");
		if(sapUrMapi_getControlType(sConId)=="TS")
		{
		  ur_IScr_toNextItem(sConId);	      	      
		  var oCon = ur_get(sConId);
		  var ifocIdx = parseInt(oCon.getAttribute('fidx'));
		  var iCount = parseInt(oCon.getAttribute('ic'));
		  if(ifocIdx < iCount )
			ur_TS_setTabIdx(sConId,ifocIdx,-1);
		  ur_EVT_addParam(oEvt,"FirstVisibleItemIdx",ur_IScr[sConId].first);
		}
	  } catch (ex) {}  
		return true;
  }
  return false;
}

function sapUrMapi_Paginator_showMenu(sId,sMenuId,sConId,oEvt) {
  if (oEvt.type=="click" || (oEvt.keyCode==40) || (oEvt.keyCode==13)|| (oEvt.keyCode==32)) {
    if (sapUrMapi_getControlType(sConId)=="TS") {
      sId=sConId+"-pg";
    }
    sapUrMapi_PopupMenu_showMenu(sId+"-menu",sMenuId,sapPopupPositionBehavior.MENURIGHT,oEvt);
  }
  return false;
}

function ur_Paginator_triggerClick(sId,enumButton) {
  var oBtn=null;
	oBtn=ur_get(sId+"-btn-"+enumButton);
  if (oBtn!=null) { 
    if (!sapUrMapi_Paginator_buttonDisabled(oBtn)) {
      oBtn.click();
      return true;
    }
  }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Paginator_enrichParameters
//* parameter   : sConId - string id of the connected control
//* return      : can be used to return various data. I.e. the id of the
//*				  first visible phaseindicator item
//* ------------------------------------------------------------------------

function sapUrMapi_Paginator_enrichParameters(sConId) {
	try {
		if (sapUrMapi_getControlType(sConId)=="PHI") {
	  	return sapUrMapi_PhaseIndicator_getFirstVisible(ur_get(sConId));
	   }
	} catch (ex) {}  
	return "";
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Paginator_removeFromTabChain
//* parameter   : sConId - string id of the connected control
//* return      : can be used to return various data. I.e. the id of the
//*				  first visible phaseindicator item
//* ------------------------------------------------------------------------
function sapUrMapi_Paginator_removeFromTabChain(sId) {
  var o=ur_get(sId);
  if (!o.hasChildNodes) return;
  var oC=o.childNodes;
  for (var i=0;i<oC.length;i++) sapUrMapi_setTabIndex(oC[i],-1);
}
