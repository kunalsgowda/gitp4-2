//* ************************************************************************
//* NavigationList
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : ur_NL_getItem
//* parameter   : oEvt   - Event Object
//* return      : none
//*	description	: returns the item object of the source object (tr)
//* ------------------------------------------------------------------------
function ur_NL_getItem(oEvt){
	var oItm=ur_EVT_src(oEvt);
	while(ur_getAttD(oItm,"idx","")==""){ 
		oItm=oItm.parentNode;
		if (!oItm || oItm.tagName=="BODY") return null;
	}
	return oItm;
}

//* ------------------------------------------------------------------------
//* function    : ur_NL_getGroup
//* parameter   : oEvt   - Event Object
//* return      : none
//*	description	: returns the group object of the source object (tr)
//* ------------------------------------------------------------------------
function ur_NL_getGroup(oEvt){
	var oItm=ur_EVT_src(oEvt);
	while(ur_getAttD(oItm,"gidx","")==""){ 
		oItm=oItm.parentNode;
		if (!oItm || oItm.tagName=="BODY") return null;
	}
	return oItm;
}

//* ------------------------------------------------------------------------
//* function    : ur_NL_cl
//* parameter   : oEvt   - Event Object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function ur_NL_cl(oEvt){
	var oSrcElement = ur_EVT_src(oEvt);
	var oNL = sapUrMapi_getRootControl(oSrcElement);
	var sId = oNL.getAttribute("id");	
	var o = ur_NL_getObj(sId);
	
	for(i=0; i<o.items.length; i++){
		if(oSrcElement.id==o.items[i].id){
			o.ref.setAttribute("iFidx",i);
			break;
		}
	}

  if (ur_FRA_cl(oEvt)) return;
	var oItm=ur_NL_getItem(oEvt);
	
	if (oItm==null) {
	  oItm=ur_NL_getGroup(oEvt);
	  if (oItm!=null) {
		  ur_EVT_fire(oItm,"ogc",oEvt);
	  } else {
	  	if (oSrcElement.className.indexOf("MnuIco") > -1) {
			
			if (oSrcElement.tagName == "IMG") {
				oItm = oSrcElement.parentNode.previousSibling;
			}
		}
	  }
	}

	if(oItm==null) return;
	if (ur_getAttD(oItm,"st","").indexOf("d")>-1) return;
	var sMenuId=oItm.parentNode.getAttribute("pop");
	var sChildId=oItm.getAttribute("id");
	
	if(sMenuId!=null && sMenuId!=""){
		if (ur_system.direction=="rtl")
		  sapUrMapi_PopupMenu_showMenu(sChildId,sMenuId,sapPopupPositionBehavior.MENULEFT,oEvt);
		else
	 	  sapUrMapi_PopupMenu_showMenu(sChildId,sMenuId,sapPopupPositionBehavior.MENURIGHT,oEvt);
	}
	else{
	  ur_EVT_fire(oItm,"oic",oEvt);
	}
}


//* ------------------------------------------------------------------------
//* function    : ur_NL_keyNav
//*             : oEvt   - Event Object
//*	description	: hanedles keyboard navigation
//* ------------------------------------------------------------------------

function ur_NL_keyNav(oEvt){
	var oSrcElement=ur_EVT_src(oEvt);
	var oNL = sapUrMapi_getRootControl(oSrcElement);
	var sId = oNL.getAttribute("id");	
	var o = ur_NL_getObj(sId);
	 
	var iKey = oEvt.keyCode;
	var oItem = null;
	var iFidx=o.ref.getAttribute("iFidx");
	if (iFidx!=null) iFidx = parseInt(iFidx);
	if(iFidx==null)
		iFidx=o.items.selidx;
	if(iFidx==null && o.items.length>1) {
		iFidx=0;
		//there was no selected index
		sapUrMapi_setTabIndex(o.items[0],"0");
	}
	var iOldIndex = iFidx;
			
	if(iKey==40 && oSrcElement!=o.end){
		if(oSrcElement!=o.ref && oSrcElement!=o.ref.pers)
			if (iFidx<=o.items.length ){
				iFidx=iFidx+1;
				oItem=o.items[iFidx];
			} else return;
			
		}	
	else if(iKey==38 && oSrcElement!=o.end && oSrcElement!=o.ref && oSrcElement!=o.pers){
		iFidx=iFidx-1;
		if(iFidx>=0){	
		   oItem=o.items[iFidx];
		}else
			return;
		}
	else if(iKey==9){
		 if(oEvt.shiftKey){ 
		 	if(oSrcElement!=o.ref && oSrcElement!=o.end && o.ref.pers==null){
			   oItem=o.ref;
			   if(o.items.selected==null)
			  		iFidx=0;
			   else
			     	iFidx=o.items.selidx;
			}
			else if(oSrcElement!=o.ref && oSrcElement!=o.end && o.ref.pers!=null && oSrcElement!=o.ref.pers ){
			   oItem=o.ref.pers;
			   iFidx=0;
			} else if (oSrcElement==o.end){
				if(o.items.selected==null){
					oItem=o.items[o.items.length-1];
					iFidx=o.items.length-1;
						}else{
				   oItem=o.items[o.items.selidx];
				   iFidx=o.items.selidx;
				}
			}
			else if(oSrcElement==o.ref.pers)
				oItem=o.ref;
		} else if (!oEvt.shiftKey){
		 	if(oSrcElement!=o.ref && oSrcElement!=o.end && oSrcElement!=o.ref.pers){
	 			oItem=o.end;
	 			iFidx=o.items.length-1;
			}	else if((oSrcElement==o.ref && o.ref.pers==null) || oSrcElement==o.ref.pers){
				if(o.items.selected==null){
					oItem=o.items[0];
					iFidx=0;
				}
				else {
					oItem=o.items[o.items.selidx];
					iFidx=o.items.selidx;
				}
			}
		}
	}
	
	if(iFidx<o.items.length) {
	    o.ref.setAttribute("iFidx",iFidx);
	    //remove the old tabindex
	    sapUrMapi_setTabIndex(o.items[iOldIndex],"-1");
	}
	
	if(oItem!=null){
		try{
			sapUrMapi_setTabIndex(oItem,0);
			ur_focus(oItem);
		} catch(err){}
		return ur_EVT_cancel(oEvt);
		}

				}
//* ------------------------------------------------------------------------
//* function    : ur_NL_getObj
//*             : sId   - id of navigation list
//*	description	: gets the whole content of the navigation list and returns it as an object
//* ------------------------------------------------------------------------
function ur_NL_getObj(sId){
		var oNL=ur_get(sId);
		var oCnt=ur_get(sId+"-cnt");
		var o = {
			ref:oNL,
			items:new Array(),
			end:ur_get(sId+"-end")
			};
	o.ref.pers = ur_get(sId+"-pers");

	var oItems=oCnt.getElementsByTagName("TD");

	for(i=0; i<oItems.length; i++){
		if(oItems[i].getAttribute("idx")!=null || oItems[i].getAttribute("gidx")!=null){
			//check disabled items
			if (oItems[i].getAttribute("st") && oItems[i].getAttribute("st").indexOf("d")>-1 && !ur_system.is508) continue;
			o.items.push(oItems[i]);
		}
				
			}
	for(i=0; i<o.items.length; i++){
		if(o.items[i].getAttribute("sel")!=null){
		   o.items["selected"]=o.items[i].getAttribute("sel");
		}		
		if(o.items[i].id==o.items.selected){
		   o.items["selidx"]=i;
		   break; 
	         }
	}
		return o;
}

//* ------------------------------------------------------------------------
//* function    : ur_NL_kd
//*             : oEvt   - Event Object
//* return      : none
//*	description	: hanedles keyboard events
//* ------------------------------------------------------------------------

function ur_NL_kd(oEvt){
	var o = ur_EVT_src(oEvt);
	 o = sapUrMapi_getRootControl(o);
	var sId = o.getAttribute("id");	
	var oSrcElement=ur_EVT_src(oEvt);
	
  if(oEvt.keyCode==38 || oEvt.keyCode==40 || oEvt.keyCode==9){
	ur_NL_keyNav(oEvt);
   }
   else if(oEvt.keyCode==107 && ur_isSt(o,ur_st.COLLAPSED) && oSrcElement.getAttribute("ct")=="NL")
	 {
		if (ur_isSt(o,ur_st.COLLAPSED))
		{
			mf_FRA_exp(sId);
		}
		return ur_EVT_cancel(oEvt);
	 }
	 
	 else if(oEvt.keyCode==109 && oSrcElement.getAttribute("ct")=="NL")
	 {
		 if (ur_isSt(o,ur_st.EXPANDED))
		 {
			 mf_FRA_col(sId);
		 }
		 return ur_EVT_cancel(oEvt);
	 }
	
	else if(oEvt.keyCode==32 || oEvt.keyCode==13){
		ur_EVT_src(oEvt).click();
		return ur_EVT_cancel(oEvt);
	}	
	
	else if(oEvt.keyCode==39 || oEvt.keyCode==115){
		var oMnuNode=ur_NL_getPrevObj(ur_NL_getItem(oEvt),"pop");
		var sSt = oSrcElement.getAttribute("st");
		
		if(oMnuNode==null || sSt=="d" || sSt==null)return ur_EVT_cancel(oEvt);
		else {
			sChildId=oSrcElement.getAttribute("id");
			sMenuId=oMnuNode.getAttribute("pop");
				if (ur_system.direction=="rtl")
				  sapUrMapi_PopupMenu_showMenu(sChildId,sMenuId,sapPopupPositionBehavior.MENULEFT,oEvt);
				else
			 	  sapUrMapi_PopupMenu_showMenu(sChildId,sMenuId,sapPopupPositionBehavior.MENURIGHT,oEvt);
			return ur_EVT_cancel(oEvt);
		}
	}
	else
		return sapUrMapi_skip(sId,oEvt);
}

//* ------------------------------------------------------------------------
//* function    : ur_NL_getPrevObj
//* parameter   : o - item object from where the function starts searching
//*             : tag  - html object to be found
//* return      : returns HTML object
//*	description	: searches for a HTML object that is placed above the passed item (tag)
//* ------------------------------------------------------------------------

function ur_NL_getPrevObj(o,sAt){
		if(!o || !sAt) return null;
		while(ur_getAttD(o,sAt,"")==""){ 
			o=o.parentNode;
			if (!o || o.getAttribute("ct")=="NL") return null;
		}
	return o;
}
