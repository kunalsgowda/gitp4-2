function sapUrMapi_ToolbarButton_setFunctionFromMenuItem(sMenuItemId) {
  if (ur_replace_function) {
  	var clickedItem = ur_get(sMenuItemId);
	
	/*
	CSN 557703 2010:
	global var ur_replace_function stays on TRUE.
	subsequent instructions use wrong HTML and cause JS error
	*/
	if (clickedItem.getElementsByTagName("nobr").length == 0) {
		ur_replace_function = false;
		return;
	}
	/*
	CSN 557703 2010
	*/
	
    var sImgSrc=""
    if (clickedItem.getElementsByTagName("img").length>0) {
      sImgSrc=clickedItem.getElementsByTagName("img").item(0).src;
    }
    var sText=clickedItem.getElementsByTagName("nobr").item(0).innerText;
    var effectedButtonId=ur_replace_function_button_id;
    ur_replace_function_button_id="";
    ur_replace_function=false;
    sapUrMapi_ToolbarButton_applyFunction( effectedButtonId, sText, sImgSrc, clickedItem.onclick)
  }
}
function sapUrMapi_ToolbarButton_applyFunction( sButtonId, sNewText, sNewImageSrc, fNewClickHandler){
  var effectedButton=ur_get(sButtonId);
  var bNoText=(ur_get(sButtonId+"-r").getAttribute("notext")=="true");
  effectedButton.onclick=fNewClickHandler;
  effectedButton.onkeydown=fNewClickHandler;
  var sButtonContent=effectedButton.getElementsByTagName("nobr").item(0).innerHTML;
  var oButtonContent = effectedButton.getElementsByTagName("nobr").item(0);
  if (oButtonContent.getElementsByTagName("img").length>0) {
    if (sNewImageSrc=="") {
    	if (!bNoText) { //button has text
      effectedButton.getElementsByTagName("nobr").item(0).innerHTML="<img height=\"12\" width=\"1\" border=\"0\" align=\"absmiddle\" src=\""+ur_system.mimepath+"1x1.gif\">"+sNewText
    } else {
	      effectedButton.getElementsByTagName("nobr").item(0).innerHTML="<img height=\"12\" width=\"12\" border=\"0\" align=\"absmiddle\" src=\""+ur_system.mimepath+"1x1.gif\">";
    	}
    } else {
    	if (!bNoText) { //button has text
      effectedButton.getElementsByTagName("nobr").item(0).innerHTML="<img border=\"0\" align=\"absmiddle\" src=\""+sNewImageSrc+"\">&nbsp;"+sNewText;
      } else {
        effectedButton.getElementsByTagName("nobr").item(0).innerHTML="<img border=\"0\" align=\"absmiddle\" src=\""+sNewImageSrc+"\">";
      }
    }
  } else {
    effectedButton.getElementsByTagName("nobr").item(0).innerHTML=sNewText;
  }
 }

function sapUrMapi_ToolbarButton_openMenu( sButtonId, e){
	var sPopupId=document.getElementById(sButtonId).getAttribute("popup");
	if (document.getElementById(sPopupId)==null) return;
	if (document.getElementById(sButtonId+"-r").getAttribute("replaceable")=="true") {
	  ur_replace_function=true;
	  ur_replace_function_button_id=sButtonId;

	}
	if (ur_system.direction=="rtl")
 	  sapUrMapi_PopupMenu_showMenu(sButtonId,sPopupId,sapPopupPositionBehavior.MENULEFT,e);
 	else
 	  sapUrMapi_PopupMenu_showMenu(sButtonId,sPopupId,sapPopupPositionBehavior.MENURIGHT,e);
  e.cancelBubble=false;
	if ((e.type=="contextmenu")) {
    e.returnValue=false;
  } else {
    e.returnValue=true;
  }
}

function sapUrMapi_ToolbarButton_keydown(sButtonId,e)
{
	var o=ur_get(sButtonId);
	while (o.getAttribute("ct")!="TB") {
	  o=o.parentNode;
	} 
	 if (ur_isSt(o,ur_st.DISABLED)) return;
	var attr_tp=o.getAttribute("tp");	
	if((attr_tp=="MNUSEC") || (attr_tp=="MNU"))
	{
		if(e.altKey && e.keyCode==40)
		{
		  sapUrMapi_ToolbarButton_openMenu(o.id,e);
		}
	}
	if ((e.type!="click")&&(e.type!="contextmenu")) {
		if (!sapUrMapi_checkKey(e,"keypress",new Array("32","40"))) {
	    e.cancelBubble=true;
	    e.returnValue=true;
		  return false;
		}
	}
	if (e.keyCode==32) return ur_EVT_fire(o,"ocl",e);
}
