//* ************************************************************************
//* HCNP
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : ur_Hcnp_RegisterCreate
//* parameter   : sId - string - Id of the HCNP
//*				  count - No of HCNP Tabs
//*				  SelIndex - current Selected Index
//* description : Registers the HCNP with the create item registry to be
//*				  initialized when the page loads
//* return      : none
//* ------------------------------------------------------------------------

function ur_Hcnp_RegisterCreate(sId,iCount,iSel,iMenuIdx)
{
	if(!sId || iCount==0 || iSel<0) return;
	sapUrMapi_Create_AddItem(sId, "ur_Hcnp_create('" + sId + "','" + iCount + "','" + iSel + "')");

}
//* ------------------------------------------------------------------------
//* function    : ur_Hcnp_create
//* parameter   : sId - string - Id of the HCNP
//*				  count - No of HCNP Tabs
//*				  SelIndex - current Selected Index
//* description : Some init oeprations
//*				  
//* return      : none
//* ------------------------------------------------------------------------

function ur_Hcnp_create(sId,Count,SelIndex)
{
	var oHcnp = ur_get(sId);
	if(SelIndex >0 )
	{
		var iPrevSel = parseInt(SelIndex) -1;
		ur_get(sId+"-itm-"+iPrevSel+"-b").style.display="none";
	}
}
//* ------------------------------------------------------------------------
//* function    : ur_Hcnp_create
//* parameter   : sId - string - Id of the HCNP
//*				  count - No of HCNP Tabs
//*				  SelIndex - current Selected Index
//* description : Some init oeprations
//*				  
//* return      : none
//* ------------------------------------------------------------------------
function ur_Hcnp_setActiveItem(sId,iSel,iPrevSel,evt)
{
	//alert("function invoked with... "+sId+"  "+iSel);
	var oTbl = ur_get(sId);	
	var iOldSel = oTbl.getAttribute("sidx");
	
	if(iSel == iOldSel) return;
	
	if(iOldSel !=0)
	{
		var iPrevSel = parseInt(iOldSel) -1;
		ur_get(sId+"-itm-"+iPrevSel+"-b").style.display="";
	}

	
	//Change Tabs
	var curTabBeg = ur_get(sId+"-itm-"+iSel+"-a");
	var curTabEnd = ur_get(sId+"-itm-"+iSel+"-b");
	var curTabTxt = ur_get(sId+"-itm-"+iSel);

	var oldTabBeg = ur_get(sId+"-itm-"+iOldSel+"-a");
	var oldTabEnd = ur_get(sId+"-itm-"+iOldSel+"-b");
	var oldTabTxt = ur_get(sId+"-itm-"+iOldSel);

	if(iOldSel ==0 )
	{
		oldTabBeg.className = "urHcnpfirstAngOff urHcnpTopUndBdr";
		oldTabEnd.className = "urHcnpUnSelTabEnd urHcnpTopUndBdr";
		oldTabTxt.className = "urHcnpUnSelTabText urHcnpTopUndBdr";
	}
	else
	{
		oldTabBeg.className = "urHcnpUnSelTabStart urHcnpTopUndBdr";
		oldTabEnd.className = "urHcnpUnSelTabEnd urHcnpTopUndBdr"; 
		oldTabTxt.className = "urHcnpUnSelTabText urHcnpTopUndBdr";
		oldTabBeg.childNodes[0].className = "urHcnpBetwAng";

	}

	if(iSel == 0)
	{
		curTabBeg.className = "urHcnpfirstAngOn";
		curTabEnd.className = "urHcnpSelTabEnd";
		curTabTxt.className = "urHcnpSelTabText";
	}
	else
	{
		curTabBeg.className = "urHcnpSelTabStart";
		curTabEnd.className = "urHcnpSelTabEnd";
		curTabTxt.className = "urHcnpSelTabText";
		curTabBeg.childNodes[0].className = "urHcnpBetSelAng";			
	}

	oTbl.setAttribute("sidx",iSel);

//Change status
	if (ur_system.is508) {
		ur_setSt(oldTabTxt,ur_st.NOTSELECTED,true);
		ur_setSt(oldTabTxt,ur_st.SELECTED,false);
		ur_setSt(curTabTxt,ur_st.NOTSELECTED,false);
		ur_setSt(curTabTxt,ur_st.SELECTED,true);
	
		sapUrMapi_refocusElement(curTabTxt.id);
	}

	if(iSel !=0)
	{
		var iPrevSel = parseInt(iSel) -1;
		ur_get(sId+"-itm-"+iPrevSel+"-b").style.display="none";
	}
	
	//Change SubMenuArea Content

	var oOldCont = ur_get(sId+"-cnt-"+iOldSel);
	var oNewCont = ur_get(sId+"-cnt-"+iSel);

	oOldCont.style.display= "none";
	oNewCont.style.display ="block";

}


function ur_HcnpMnu_Select(sId,tabIdx,mnuIdx,oEvt)
{
	var iMenuSel = parseInt(ur_get(sId+"-cnt-"+tabIdx).getAttribute('sidx'));
	var oNewSelMenuItm = ur_get(sId+"-cnt-"+tabIdx+"-mnu-"+mnuIdx);
	
	var oPrevSelMenuItm =  ur_get(sId+"-cnt-"+tabIdx+"-mnu-"+iMenuSel);
	
	if(mnuIdx == iMenuSel) return;
	
	if(iMenuSel == -1)
	{
		oNewSelMenuItm.className = "urHcnpMenuSel";
		ur_get(sId+"-cnt-"+tabIdx).setAttribute('sidx',mnuIdx);
	}
	else if(iMenuSel >= 0)
	{
		oNewSelMenuItm.className = "urHcnpMenuSel";
		oPrevSelMenuItm.className = "urHcnpMenuUnSel";
		ur_get(sId+"-cnt-"+tabIdx).setAttribute('sidx',mnuIdx);
		if (ur_system.is508){
			ur_setSt(oPrevSelMenuItm,ur_st.NOTSELECTED,true);
			ur_setSt(oPrevSelMenuItm,ur_st.SELECTED,false);
			ur_setSt(oNewSelMenuItm,ur_st.NOTSELECTED,false);
			ur_setSt(oNewSelMenuItm,ur_st.SELECTED,true);
		
			sapUrMapi_refocusElement(oNewSelMenuItm.id);
	        }	
	}	
		
}

//* ------------------------------------------------------------------------
//* function    : ur_Hcnp_keyDown
//* parameter   : sId - string - Id of the HCNP
//*				  e - event object
//* description : handles keyboard
//* return      : none
//* ------------------------------------------------------------------------

function ur_Hcnp_keySelect(sId,oEvt){
	var o = ur_get(sId);
	var oItm = ur_EVT_src(oEvt);
	var sItmId=oItm.id;
	var sItm="-itm-";
	
	if(sItmId.indexOf("mnu")>-1){
		var tabIdx=sItmId.split("-")[2];
		sItm="-cnt-"+tabIdx+"-mnu-";
		o=ur_EVT_src(oEvt).parentNode;
	}
	if(ur_system.direction!="rtl"){
		oPrev=ur_getPrevItm(oItm.previousSibling,"idx");
		oNext = ur_getNxtItm(oItm.nextSibling,"idx");
	}else{
	     oNext=ur_getPrevItm(oItm.previousSibling,"idx");
	   oPrev = ur_getNxtItm(oItm.nextSibling,"idx");
	}
	if((oEvt.keyCode == 39 || oEvt.keyCode == 40) && oNext!=null) {
		 ur_focus_Itm(oNext,oItm);
		 ur_EVT_cancel(oEvt);
	}
	else if((oEvt.keyCode == 37 || oEvt.keyCode == 38) && oPrev!=null){
		ur_focus_Itm(oPrev,oItm);
		ur_EVT_cancel(oEvt);
	}
	else if(oEvt.keyCode==9){
		var iSel=o.getAttribute("sidx");
		var oSel = ur_get(sId+sItm+iSel);
		ur_focus_Itm(oSel,oItm);
	}
	else if(oEvt.keyCode==32 || oEvt.keyCode==13){
		oItm.click();
		 ur_EVT_cancelBubble(oEvt);
	}else
		sapUrMapi_skip(sId,oEvt);
}
