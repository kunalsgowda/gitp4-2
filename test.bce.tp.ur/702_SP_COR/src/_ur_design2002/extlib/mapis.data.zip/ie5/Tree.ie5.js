
//* ************************************************************************
//* Tree
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_collapseAll
//* parameter   : sTreeId  - Id of the Tree
//* description : Collapses all Nodes of the tree
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_collapseAll(sTreeId) {
    var eRootNode = ur_get(sTreeId + "-r");
    var eNodes = eRootNode.getElementsByTagName("DIV");

    //now loop through all the child nodes
    for (var i =  eNodes.length-1; i >-1; i--){
      if (ur_getAttD(eNodes[i],"tp","").indexOf("F")>-1) {
        sapUrMapi_Tree_toggle( sTreeId, eNodes[i].id, true, true)
      }
    }
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_expandAll
//* parameter   : sTreeId  - Id of the Tree
//* description : Expands all Nodes of the tree
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_expandAll(sTreeId) {
    var eRootNode = ur_get(sTreeId + "-r");
    var eNodes = eRootNode.getElementsByTagName("DIV");

    //now loop through all the child nodes
    for (var i =  eNodes.length-1; i >-1; i--){
      if (ur_getAttD(eNodes[i],"tp","").indexOf("F")>-1) {
        sapUrMapi_Tree_toggle( sTreeId, eNodes[i].id, false, true)
      }
    }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_toggle
//* parameter   : sTreeId  - string  - Id of the Tree
//						  : sNodeId  - string  - Id of the TreeNode
//              : bClose   - boolean - optional true if the node should be
//								                     closed use only with bKey=true
//              : bKey     - boolean - optional true if explicit open
//																		 or close is used (bClose)
//* description : Toggles a tree node and focus it using bKey you can
//                explicit close oropen a node specified by sNodeId
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_toggle( sTreeId, sNodeId, bClose, bKey) {
	var nodeDiv = ur_get(sNodeId);
  var oMainContainerNode = ur_get(sTreeId+"-r");
  var oEvt = window.event;
  if (oEvt) ur_EVT_cancelBubble(oEvt);
  if (ur_isSt(nodeDiv,ur_st.DISABLED)) return;
  if (!bKey) {
    oMainContainerNode.setAttribute("focuced_id",sNodeId);
    try { sapUrMapi_Tree_focusNode(sTreeId,sNodeId); } catch (e) {};
	}
  var childrenDiv = ur_get( nodeDiv.id + "-child" );
  if (!childrenDiv) return;
	var expander = ur_get( nodeDiv.id + "-exp" );

	if ((ur_isSt(nodeDiv,ur_st.COLLAPSED) && !bKey)||(bKey && !bClose && ur_isSt(nodeDiv,ur_st.COLLAPSED)))
	{
	  nodeDiv.className = nodeDiv.className+" urTreNlExp";
		childrenDiv.style.display="block";
		//show the maximum of the opened folder is a bit too much
		//childrenDiv.scrollIntoView();
		eLength = expander.className.length;
		expander.className = expander.className.substr(0,eLength-3) + "Op";
    nodeDiv.setAttribute("st",nodeDiv.getAttribute("st").replace("-","+"));
    try { sapUrMapi_Tree_focusNode(sTreeId,sNodeId); } catch (e) {};
    return;
	}
	if ((ur_isSt(nodeDiv,ur_st.EXPANDED)&&!bKey)||(bKey && bClose && ur_isSt(nodeDiv,ur_st.EXPANDED)))
	{
		if (nodeDiv.className.lastIndexOf(" ")>-1) {
		  nodeDiv.className = nodeDiv.className.substring(0,nodeDiv.className.lastIndexOf(" "));
		}
		childrenDiv.style.display="none";
		eLength = expander.className.length;
		expander.className = expander.className.substr(0,eLength-2) + "Clo";
    nodeDiv.setAttribute("st",nodeDiv.getAttribute("st").replace("+","-"));
    try { sapUrMapi_Tree_focusNode(sTreeId,sNodeId); } catch (e) {};
		return;
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_focusNode
//* parameter   : sTreeId  - string  - Id of the Tree
//						  : sNodeId  - string  - Id of the TreeNode to focus
//* description : sets the focus to a TreeNode specified by sNodeId,
//								sets 508 descriptions for the nodes if the flag is used
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_focusNode(sTreeId,sNodeId,bInit,bNoFocus) {
	var oMainContainerNode = ur_get(sTreeId+"-r");
	var oR=ur_get(sTreeId+"-skipstart");
	if (sNodeId=="") return;
	if (sNodeId.indexOf("-skipstart")>0) return;

	var oNode = ur_get(sNodeId);
	if (bInit) oMainContainerNode.setAttribute("focuced_id",null);
	var sOldNode = oMainContainerNode.getAttribute("focuced_id");
	try {
		if (sOldNode) {
		  sapUrMapi_setTabIndex(ur_get(sOldNode),-1);
		}
  } catch (ex) {
  }
	oMainContainerNode.setAttribute("focuced_id",oNode.id);
	if(ur_system.is508) {
		var sTtTree=oMainContainerNode.getAttribute("tt");
		var sTt=oNode.getAttribute("tt");	
		var sAccTt="";
		}
	sapUrMapi_setTabIndex(oNode,0);
  try {
    if (!bNoFocus) ur_focus(oNode);
  } catch (ex) {}
  sapUrMapi_Focus_showFocusRect();
}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TreeNode_keyDown
//* parameter   : sTreeId  - string  - Id of the Tree
//						  : sNodeId  - string  - Id of the TreeNode on which a keydown
//								                     event was fired
//						    e - EventObject 	 - the event itself
//* description : raises events on the TreeNode specified by sNodeId
//								Spacebar - will raise the onclick event of the Node
//								Shift+Control+F10 - will raise the oncontextmenu event of the Node
//								Tab and Arrow Keys will be handled in sapUrMapi_Tree_keyDown
//* return      : none, cancels bubbling if the events are not handled in the node
//* ------------------------------------------------------------------------
function sapUrMapi_TreeNode_keyDown(sTreeId,sNodeId,e) {
	if (sapUrMapi_checkKey(e,"keydown",new Array("32"))) {
		 //select this node with spacebar
		 if (ur_isSt(ur_get(sNodeId),ur_st.DISABLED)) return;
		 oNodeEvents = ur_get(sNodeId);
		 if (oNodeEvents.onclick) {
		 	  oNodeEvents.onclick(e);
		 	  return true;
		 } else {
		 	//reset events and bubbling
		 	ur_EVT_cancel(e);
		 }
	}
	if (sapUrMapi_checkKey(e,"keydown",new Array("121")) && e.shiftKey) { //F10 + shift for Context Menu
		oNodeEvents = ur_get(sNodeId);
		 if (oNodeEvents.oncontextmenu) {
		 	  oNodeEvents.oncontextmenu(e);
		 	  return true;
		 } else {
		 	//reset events and bubbling
		 	ur_EVT_cancel(e);
		 }
	}
	if (sapUrMapi_checkKey(e,"keydown",new Array("38","39","40","37","9","107","109","106"))) {
		sapUrMapi_Tree_keyDown(sTreeId,e)
  }
}
function sapUrMapi_TreeNode_hover(sTreeId,sNodeId,bIn,e) {
	if ((ur_EVT_src(e).getAttribute("level")) && (!ur_EVT_src(e).getAttribute("container"))) {
	  var sClass="urTreNoEnbl";
	  if (ur_EVT_src(e).getAttribute("clickable")=="true") {
	    sClass+="Clk";
	  }
    if (bIn) ur_EVT_src(e).className=sClass+" urTreNoEnblClkHover"
    else ur_EVT_src(e).className=sClass;
  }
}
function sapUrMapi_TreeNode_mouseover(sTreeId,sNodeId,e) {
	sapUrMapi_TreeNode_hover(sTreeId, sNodeId, true, e);
}
function sapUrMapi_TreeNode_mouseout(sTreeId,sNodeId,e) {
	sapUrMapi_TreeNode_hover(sTreeId, sNodeId, false, e);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_enter
//* parameter   : sTreeId  - string  - Id of the Tree
//						    e - EventObject 	 - the event itself
//* description : this functiion should be called while entering the tree
//                with the keyboard.
//								this will lead the focus to the last focused Node
//								a hidden field that triggeres that function
//								while getting the focus will cause screenreader to
//								read the title of the tree AND its focused node
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_enter (sTreeId,e) {
	//for 508 this will read the outline item text and then automatically lead to
	//the next node
	var oFocusedNode=null;
	if (ur_EVT_src(e).id==sTreeId+"-skipstart") {
	  var oMainContainerNode = ur_get(sTreeId+"-r");
		//while this is used with shift tab the exit flag is set and we will erase tabstops
		//in the tree
		if (ur_get(sTreeId+"-skipstart").getAttribute("exit")=="true") {
			ur_get(sTreeId+"-skipstart").setAttribute("exit","false");
			var sFocusedNode= oMainContainerNode.getAttribute("focuced_id");
		  if (sFocusedNode!="") {
		  	 oFocusedNode=ur_get(sFocusedNode);
			   sapUrMapi_setTabIndex(oFocusedNode.lastChild,-1);
		  }
		} else {
			//focus the first treenode or the selected (Selection=WDTreeNodeSelection.PRIMARYSELECTION) node or the previous selected node
		  var sFocusedNode= oMainContainerNode.getAttribute("focuced_id");
		  if (sFocusedNode) {
				 oFocusedNode=ur_get(sFocusedNode);
		  } else {
		  	 var nodelist= oMainContainerNode.getElementsByTagName("DIV");
		  	 for (var nlc=0;nlc<nodelist.length;nlc++) {
		  	   if (nodelist.item(nlc).getAttribute("sellevel")=="1") {
		  	     oFocusedNode=nodelist.item(nlc);
		  	     break;
		  	   }
		  	 }
		     if (oFocusedNode==null) {
		       var nodelist=oMainContainerNode.getElementsByTagName("DIV");
		  	   oFocusedNode=nodelist.item(0);
		  	   if (oFocusedNode.id.indexOf("-")>0) {
		  	     oFocusedNode=oFocusedNode.childNodes.item(0);
		  	   }
			}
			}
			sapUrMapi_Tree_focusNode(sTreeId,oFocusedNode.id,true);
	  }
	} else {
		//entering the tree from below
		var oLastElement=ur_get(sTreeId+"-skipend")
		if (oLastElement.getAttribute("exit")=="true") {
			//while this is used with shift tab the exit flag is set and we will erase tabstops
			//in the tree
			oLastElement.setAttribute("exit","false");
		} else {
			ur_focus(ur_get(sTreeId+"-skipstart"));
	  }
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_expandNode
//* parameter   : sTreeId  - string  - Id of the Tree
//				  sFocusedNode - element - the focused node
//* description : expands the focused node
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_expandNode(sTreeId,o,sMainContainerNode) {
	if (o && ur_getAttD(o,"tp","").indexOf("F")>-1 && ur_isSt(o,ur_st.COLLAPSED) && !ur_isSt(o,ur_st.DISABLED)) {
		sapUrMapi_Tree_toggle(sTreeId,o.id,false,true);
  }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_collapseNode
//* parameter   : sTreeId  - string  - Id of the Tree
//*				  sFocusedNode - element - the focused node
//*				  sMainContainerNode
//* description : collapses the focused node
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_collapseNode(sTreeId,o, sMainContainerNode) {
	if (o && ur_getAttD(o,"tp","").indexOf("F")>-1 && !ur_isSt(o,ur_st.COLLAPSED) && !ur_isSt(o,ur_st.DISABLED)) {
		sapUrMapi_Tree_toggle(sTreeId,o.id,true,true);
  }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_keyDown
//* parameter   : sTreeId  - string  - Id of the Tree
//						    e - EventObject 	 - the event
//* description : Handles arrow and tab keys in the tree specified by sTreeId
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_keyDown(sTreeId,e) {
  var oFocusedNode=null;
  var oMainContainerNode = ur_get(sTreeId+"-r");
  var sFocusedNode= oMainContainerNode.getAttribute("focuced_id");
  if (sFocusedNode!="") {
  	 oFocusedNode=ur_get(sFocusedNode);
  }
  if (sapUrMapi_checkKey(e,"keydown",new Array("38","39","40","37","9","32","107","109","106"))) {
  	if (e.keyCode==9) { // tab
  		if (!e.shiftKey) {
  			oLastElement = ur_get(sTreeId+"-skipend");
  			oLastElement.setAttribute("exit","true");
  			ur_focus(oLastElement);
	  		ur_EVT_cancel(e);
	  		return;
  		} else {
  			oFirstElement = ur_get(sTreeId+"-skipstart");
  			oFirstElement.setAttribute("exit","true");
  			ur_focus(oFirstElement);
	  		ur_EVT_cancel(e);
	  		return;
  		}
  	}
  	if (e.keyCode==40) { // down 
		  if (!oFocusedNode) {
	  	  oFocusedNode=oMainContainerNode.childNodes.item(0);
		  } else {
		  	if (ur_isSt(oFocusedNode,ur_st.EXPANDED) || ur_getAttD(oFocusedNode,"tp","").indexOf("L")>-1) { 
		  	  oNextContainer = ur_get(oFocusedNode.id+"-child");
		  	  if (oNextContainer && oFocusedNode.nextSibling.firstChild) oFocusedNode=oFocusedNode.nextSibling.childNodes.item(0);
          else if (oNextContainer && oFocusedNode.nextSibling.nextSibling) oFocusedNode=oFocusedNode.nextSibling.nextSibling; 
          else if (!oNextContainer && oFocusedNode.nextSibling) oFocusedNode=oFocusedNode.nextSibling; 
          else if (oFocusedNode.parentNode !=oMainContainerNode)
			  	     { 
				  	     	oParent = oFocusedNode.parentNode.previousSibling;
				  	     	while ((!oParent.nextSibling.nextSibling) && (oParent.parentNode!=oMainContainerNode)) {
				  	     		 oParent=oParent.parentNode.previousSibling;
				  	     	}
				  	     	if (oParent.nextSibling.nextSibling) {
				  	     		oFocusedNode=oParent.nextSibling.nextSibling;
				  	     	}
			  	     }
			  } else {
		  		if (ur_isSt(oFocusedNode,ur_st.COLLAPSED) || ur_getAttD(oFocusedNode,"tp","").indexOf("L")) {
			  		if (oFocusedNode.nextSibling.nextSibling) {
				  	  oFocusedNode=oFocusedNode.nextSibling.nextSibling;
			  		} else { 
		  	     	oParent = oFocusedNode;
		  	     	while ((!oParent.nextSibling.nextSibling) && (oParent.parentNode!=oMainContainerNode)) {
		  	     		 oParent=oParent.parentNode.previousSibling;
		  	     	}
		  	     	if (oParent.nextSibling.nextSibling) {
		  	     		oFocusedNode=oParent.nextSibling.nextSibling;
		  	     	}
			  		}
		  		}
		  	}
		  }
		}
		if (e.keyCode==39) { // right
		  if (ur_system.direction=="rtl") {
		    sapUrMapi_Tree_collapseNode(sTreeId,oFocusedNode,oMainContainerNode);
		  } else {
		    sapUrMapi_Tree_expandNode(sTreeId,oFocusedNode,oMainContainerNode)
		  }
		}
		if (e.keyCode==37) { // left
		  if (ur_system.direction=="rtl") {
		    sapUrMapi_Tree_expandNode(sTreeId,oFocusedNode,oMainContainerNode)
		  } else {
		    sapUrMapi_Tree_collapseNode(sTreeId,oFocusedNode,oMainContainerNode);
		  }
		}
		if (e.keyCode==109) { // numpad -
		  sapUrMapi_Tree_collapseNode(sTreeId,oFocusedNode,oMainContainerNode);
		}
		if (e.keyCode==107) { // numpad +
		  sapUrMapi_Tree_expandNode(sTreeId,oFocusedNode,oMainContainerNode);
		}
		if (e.keyCode==106) { // numpad *
			sapUrMapi_Tree_collapseAll(sTreeId);
			return;
		}
		if (e.keyCode==38) { // up
		  if (!oFocusedNode) {
			  oFocusedNode=oMainContainerNode.childNodes.item(0);
		  } else {
			  oParent = oFocusedNode.parentNode;
	    	if (oFocusedNode != oMainContainerNode.childNodes.item(0)) {
		    	if (oFocusedNode==oParent.childNodes[0]) {
		    		if (oParent==oMainContainerNode) {
		    			oFocusedNode=oParent.lastChild;
				  		while ((oFocusedNode.id.indexOf("-child")>-1)&&(ur_isSt(oFocusedNode.previousSibling,ur_st.COLLAPSED)||ur_getAttD(oFocusedNode.previousSibling,"tp","").indexOf("L")>-1)) {
				  		  oFocusedNode=oFocusedNode.previousSibling;
				  		}
				  		while ((oFocusedNode.id.indexOf("-child")>-1)&&(ur_isSt(oFocusedNode.previousSibling,ur_st.EXPANDED)||ur_getAttD(oFocusedNode.previousSibling,"tp","").indexOf("L")>-1)) {
				  		  oFocusedNode=oFocusedNode.lastChild;
				  		}
		    		} else {
			  		  oFocusedNode=oParent.previousSibling;
						}
					} else {
							oFocusedNode=oFocusedNode.previousSibling;
							while ((oFocusedNode.id.indexOf("-child")>-1)&&(ur_isSt(oFocusedNode.previousSibling,ur_st.COLLAPSED) || !oFocusedNode.lastChild)) {
								oFocusedNode=oFocusedNode.previousSibling;
							}
							while ((oFocusedNode.id.indexOf("-child")>-1)&&(ur_isSt(oFocusedNode.previousSibling,ur_st.EXPANDED)) && oFocusedNode.lastChild) {
								oFocusedNode=oFocusedNode.lastChild;
							}
					}
				}
			}
	  }
		ur_EVT_cancel(e);
  		
	  	if (sTreeId && oFocusedNode) {
			sapUrMapi_Tree_focusNode(sTreeId,oFocusedNode.id);
		}
		
		if (ur_system.is508 && oFocusedNode) {
			  sapUrMapi_refocusElement(oFocusedNode.id);
		}
  }
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_controlExit
//* parameter   : sTreeId  - string  - Id of the Tree
//                sNodeId  - string  - the Node that contains a control and
//							  exited now
//						    e - EventObject 	 - the event
//* description : If a Node contains other controls this function is called
//						    after all other controls where tabbed to and the
//								tree node has to take back the focus
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_controlExit(sTreeId, sNodeId,e) {
	var oContainer = ur_get(sNodeId+"-cnt-start");
  sapUrMapi_setTabIndex(oContainer,-1); //release the tabstop on the container so cannot be focused again
  oContainer.onkeydown=null;  //reset sapUrMapi_Tree_ignoreControlEvents from keydown
  														//keyboard event will now be able to get through
  oContainer.title = ""
  var oNode=ur_get(sNodeId);  														
	sapUrMapi_setTabIndex(oNode.lastChild,0);
	sapUrMapi_setTabIndex(ur_get(sNodeId+"-cnt-end"),-1);
	ur_get(sNodeId+"-cnt-end").title="";
	sapUrMapi_Tree_focusNode(sTreeId,sNodeId)
	ur_EVT_cancel(e);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_ignoreControlEvents
//* parameter   :
//* description : This function is added to the container if inner Node Controls
//                to ensure that events will not raise functions in the tree
//* return      : true and cancels all bubbling
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_ignoreControlEvents() {
	ur_EVT_cancel(event);
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_controlEnter
//* parameter   : sTreeId  - string  - Id of the Tree
//                sNodeId  - string  - the Node that contains a control and
//							  entered now
//						    e - EventObject 	 - the event
//* description : If a Node contains other controls this function is called
//						    before the first control will get the focus
//
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_controlEnter(sTreeId, sNodeId,e) {
	var oControlExitPoint = ur_get(sNodeId+"-cnt-end");
	var oControlEventer   = ur_get(sNodeId+"-cnt-start");
	var sAllowTag=",INPUT,SELECT,TEXTAREA,";
	var sEvType = ur_EVT_src(e).type;
	if (sAllowTag.indexOf(","+ur_EVT_src(e).tagName+",")>-1) {
	  //simulation of navigation to the nodes content
		sapUrMapi_Tree_focusNode(sTreeId,sNodeId,true,true);
		sapUrMapi_setTabIndex(oControlExitPoint,0);
		sapUrMapi_setTabIndex(oControlEventer,0);
		if(sEvType.indexOf("select")>-1){
			ur_focus(ur_EVT_src(e).options[0]);
		}else{
			ur_focus(ur_EVT_src(e));
		}
		oControlEventer.onkeydown=sapUrMapi_Tree_ignoreControlEvents; 
		return true;
	}
	if (oControlExitPoint) {
		sapUrMapi_setTabIndex(oControlExitPoint,0);
		sapUrMapi_setTabIndex(oControlEventer,0);
		oControlExitPoint.title = getLanguageText("SAPUR_TREE_ITEM_CONTAINER_END");
		oControlEventer.title   = getLanguageText("SAPUR_TREE_ITEM_CONT_SELECTED");
		ur_focus(oControlEventer);
		oControlEventer.onkeydown=sapUrMapi_Tree_ignoreControlEvents; //ignore keyboard events from now until the node will be left
		ur_EVT_cancelBubble(e);
		//e.returnValue=false;
		return true;
	}
	return false;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_getNodeId
//* parameter   :	sId - string - id of a control contained in a TreeNode
//* description : finds the node id of a tree node starting with a control inside
//*               the treenode
//* return      : id of the node
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_getNodeId(sId) {
	var o=ur_get(sId);
	while (o.tagName!="BODY") {
		if (o.tagName=="DIV" && ((String(o.getAttribute("tp")).indexOf("F")>-1) || (String(o.getAttribute("tp")).indexOf("L")>-1))) return o.id;
		o=o.parentNode;
	}
	return "";
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_selectNode
//* parameter   :	sTreeId - string - id of a tree control
//*             :	sNodeId - string - id of a tree node to be selected
//*						  :	iSelLelel - int - level of selection (1=primary or 2=secondary)
//* description : selects a treenode with a specified level
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_selectNode(sTreeId, sNodeId, iSelLevel) {
	var oNode   = ur_get(sNodeId);
	var bExp    = oNode.className.indexOf("urTreNlExp")>0;
	var sClass = oNode.className.substring(0,oNode.className.indexOf(" "));
	if (sClass=="") var sClass = oNode.className;
	oNode.setAttribute("sellevel",""+iSelLevel);
	ur_get(sNodeId+"-cnt-start").setAttribute("sellevel",""+iSelLevel);
	if (iSelLevel==1) sClass+=" urTreNSel";
	if (iSelLevel==2) sClass+=" urTreNSel2";
	if (bExp) sClass+=" urTreNlExp";
	oNode.className=sClass;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tree_deselectAll
//* parameter   :	sTreeId - string - id of a tree control
//* description : deselects all treenodes within a tree
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tree_deselectAll(sTreeId) {
	var colNodes   = document.getElementsByTagName("DIV");
	for (var n=0;n<colNodes.length;n++) {
		if (colNodes.item(n).sellevel) sapUrMapi_Tree_selectNode(sTreeId,colNodes.item(n).id,0);
	}
}

function sapUrMapi_Tree_showMenu(sTreeId,sNodeId,sPopupMenuId,oEvt) {
	sapUrMapi_Tree_focusNode(sTreeId,sNodeId);
	o=ur_get(sNodeId);
   
  if (oEvt.type=="keydown") {
	  sapUrMapi_PopupMenu_showMenu(sNodeId,sPopupMenuId,sapPopupPositionBehavior.MENULEFT,oEvt);
	  if (oPopup) {
	    oPopup.frame.object.style.top=parseInt(oPopup.frame.object.style.top)-7+"px";
	    oPopup.frame.object.style.left=parseInt(oPopup.frame.object.style.left)+o.firstChild.offsetLeft+14+"px";
	    
	  }
  } else { 
	sapUrMapi_PopupMenu_showMenu(sNodeId,sPopupMenuId,sapPopupPositionBehavior.EVENT,oEvt);
	}
	ur_EVT_cancel(oEvt);
}
