//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ActiveXContainer_RegisterCreate
//* parameter   : sId - string - Id of the ActiveXContainer
//* description : Registers the activex control for activation
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_ActiveXContainer_RegisterCreate(sId) {
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_ActiveXContainer_create('" + sId + "')");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ActiveXContainer_create
//* parameter   : sId - the ID of the Applet/ActiceX Container to activate
//* return      : -
//* ------------------------------------------------------------------------
function sapUrMapi_ActiveXContainer_create(sId){
	var o = ur_get(sId + "-obj");
	if (!o) return;
	o.parentNode.innerHTML = o.innerHTML;	
}
