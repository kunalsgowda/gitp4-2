//* ************************************************************************
//* Tray
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_handle
//handles click and keyboard events on the whole tray
function sapUrMapi_Tray_handle(oEvt) {
	var oSrc= ur_EVT_src(oEvt);
	var oTray = sapUrMapi_getRootControl(oSrc);
	var sType = sapUrMapi_getControlTypeFromObject(oTray);
	if (sType != "TY") return; //not a tray
	var sId = oTray.id;
	var sCommand = "";
	if (oEvt.type == "focus") {
		oTray.focus();
	} else if (oEvt.type == "click") {
		//check option menu click
		if (oSrc && oSrc.id && oSrc.id.indexOf("-menu")>0) sCommand = "openMenu";
		else if (oSrc && oSrc.id && oSrc.id.indexOf("-exp")>0) sCommand = "toggle" //this was a header click
	} else if (oEvt.type == "keydown") {
		var iKey = oEvt.keyCode || oEvt.which;  
		if ((iKey == ur_KY.DOWN && oEvt.altKey) || iKey == 115) {
			var oOptionMenu = ur_get(sId + "-menu");
			if (oOptionMenu) sCommand = "openMenu";
		} else if (iKey == 107 && !ur_isSt(oTray,ur_st.DISABLED) && ur_isSt(oTray,ur_st.COLLAPSED)){
			sCommand = "toggle";
		} else if (iKey == 109 && !ur_isSt(oTray,ur_st.DISABLED) && ur_isSt(oTray,ur_st.EXPANDED)) {
			sCommand = "toggle";
		} else if (iKey == 13 && !ur_isSt(oTray,ur_st.COLLAPSED)) {
			sapUrMapi_triggerDefaultButton(sId,oEvt);
			return;
		} else {
			return sapUrMapi_skip(sId,oEvt);
		}
	}
	
	if (sCommand == "openMenu") {
		ur_EVT_fire(oTray,"oopt",oEvt);
		ur_EVT_cancel(oEvt);
	} else if (sCommand == "toggle") {
		ur_EVT_fire(oTray,"oexp",oEvt);
		ur_EVT_cancel(oEvt);
	}
};



//* function    : sapUrMapi_Tray_RegisterCreate
//* parameter   : sId - string - Id of the Tray
//*				: bScroll - boolean - indicates whether the tray is scrollable
//*				: bCollapsed - boolean - indicates whether the tray is collapsed
//* description : Registers the tray with the create item registry to be
//*				  initialized when the page loads
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_RegisterCreate(sId, bScroll, bCollapsed) {
	//this is only executed from the FF renderer
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_Tray_create('" + sId + "',"+bScroll+","+bCollapsed+")");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_create
//* parameter   : sId  - string - Id of the Tray
//* 			: bScroll - boolean - indicates weather the Tray is scrollable
//*  			: bCollapsed - boolean - indicates weather the Tray is collapsed
//* description : This is a dummy function to be implemented in the future.
//*               It is used in Netscape though
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_create(sId,bScroll,bCollapsed) {
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_showOptionMenu
//* parameter   : sTrayId    - string - Id of the Tray
//  							sTriggerId - string - The Id of the DOM Objects that
//                                      is the trigger for the menu
//  							sMenuContentId - string- The Id of the DOM Objects that
//                                         contains the menu
//  							enumPositionBehavior - string- Defines at which position the PopupMenu
//																			 will appear. Default is Right for ltr.
//							  e - EventObject - the events object
//* description : Opens the Menu that is applied as option menu to that tray.
//								There is an icon shown if a menu is connected to the tray
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_showOptionMenu2(sTrayId,sMenuContentId,oEvt) {

	var oMenu = ur_get(sTrayId+"-menu");
	if (oMenu && oMenu.st && oMenu.st.indexOf("d") > -1) return;
	
 	if (ur_system.direction=="rtl")
	  sapUrMapi_Tray_showOptionMenu(sTrayId,sTrayId+"-menu",sMenuContentId,sapPopupPositionBehavior.MENULEFT,oEvt) 
	else
	  sapUrMapi_Tray_showOptionMenu(sTrayId,sTrayId+"-menu",sMenuContentId,sapPopupPositionBehavior.MENURIGHT,oEvt) 
}

function sapUrMapi_Tray_showOptionMenu(sTrayId,sTriggerId,sMenuContentId,enumPositionBehavior,e) {

	var oMenu = ur_get(sTrayId+"-menu");
	if (oMenu && oMenu.st && oMenu.st.indexOf("d") > -1) return;
	
	sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_toggle
//* parameter   : sTrayId    - string - Id of the Tray
//							  e - EventObject - the events object
//* description : Expand / Collapses the tray
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------

function sapUrMapi_Tray_toggle(sTrayId,e)
{

	var elExp = ur_get(sTrayId+"-exp");
	if (elExp && elExp.st && elExp.st.indexOf("d") > -1) return;
	
	ur_EVT_cancelBubble(e);
	var elBody = ur_get(sTrayId+"-bd"); 
	var elHeader = ur_get(sTrayId+"-hd");
	var oTray = ur_get(sTrayId);

	if ( elBody != null && elExp != null )
	{
		var sScrollMode = elBody.getAttribute("scrlMode"),
			iHeight = elBody.getAttribute("cntHeight"),
			oTbar = ur_get(sTrayId+"-tbar"),
			oTbody = ur_get(sTrayId+"-height");
		if ( elBody.style.visibility == "hidden" )
		{
			if (oTbar != null) oTbar.style.display = "block";
			elBody.style.visibility = "inherit";
			elBody.style.overflow = sScrollMode;
			elBody.style.height = "100%";
			oTbody.parentNode.className = oTbody.parentNode.className.replace(" urTryCTransBody", "");
			oTbody.style.height = iHeight;
			
			ur_setSt(oTray,ur_st.COLLAPSED,false);
			ur_setSt(oTray,ur_st.EXPANDED,true);
			sapUrMapi_Focus_showFocusRect();
			if (elExp.className.indexOf("Closed") != -1)
			{
				var re = /Closed/gi;
				var clsNm = elExp.className;
				
				elExp.className = clsNm.replace(re, "Open");
			}
			if (elHeader.className == "urTrcHdBgClosedIco" )	elHeader.className = "urTrcHdBgOpenIco";
			elExp.title=getLanguageText("SAPUR_TY_BTNE");
			sapUrMapi_refocusElement(oTray);
			sapUrMapi_DBTN_showDBtn();
		} 
		else
		{
			if (oTbar != null) oTbar.style.display = "none";
			elBody.style.overflow = "hidden";
			elBody.style.height = "1px";
			oTbody.style.height = "1px";
			oTbody.parentNode.className = oTbody.parentNode.className + " urTryCTransBody";
			elBody.style.visibility = "hidden";
			//elBody.style.width = "1px";
			
			ur_setSt(oTray,ur_st.COLLAPSED,true);
			ur_setSt(oTray,ur_st.EXPANDED,false);
			sapUrMapi_Focus_showFocusRect();
			if (elExp.className.indexOf("Open") != -1)
			{
				var re = /Open/gi;
				var clsNm = elExp.className;
				
				elExp.className = clsNm.replace(re, "Closed");
				
			}
			if (elHeader.className == "urTrcHdBgOpenIco" ) elHeader.className = "urTrcHdBgClosedIco";
			elExp.title=getLanguageText("SAPUR_TY_BTNC");
			sapUrMapi_refocusElement(oTray);
			sapUrMapi_DBTN_hideDBtn();
			
		}
	}
	return true;
}
