//* ------------------------------------------------------------------------
//* function    : sapUr_TextView_menuActivate
//* parameter   : sTextViewId - string - Id of the text view
//*             : e - event object
//* description : triggers the menu open functions if there is a menu assigned to the textview
//* return      :
//* ------------------------------------------------------------------------
function sapUrMapi_TextView_menuActivate(sTextViewId,e) {
	var o=ur_get(sTextViewId);
	if (sapUrMapi_checkKey(e,"keydown",new Array("32","40"))) {
		if(o.onclick) {o.onclick();return false;} //trigger click
		if(o.oncontextmenu) {o.oncontextmenu();return false;} //trigger contextmenu
		if(o.onmouseover) {o.onmouseover();return false;} //trigger onmouseover (hover)
	}
  return false;
}