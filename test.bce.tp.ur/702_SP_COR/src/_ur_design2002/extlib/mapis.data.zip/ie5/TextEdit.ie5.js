//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TextEdit_focus
//* parameter   :	sId  - id of the control
//*							: oEvt - event object
//* description : set the tooltip in accessibility mode, show data tip if 
//*								available
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_TextEdit_focus(sId,oEvt){
	sapUrMapi_DataTip_show(sId,"focus");

}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TextEdit_blur
//* parameter   :	sId  - id of the control
//*							: oEvt - event object
//* description : hide data tip if data tip is open
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_TextEdit_blur(sId,oEvt) {

	if(ur_get(sId).getAttribute("chgFire") == "1")
	{
		ur_EVT_fire(ur_get(sId),'notifyChange',oEvt);
		ur_get(sId).setAttribute("chgFire","0");
	}

	sapUrMapi_DataTip_hide(sId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TextEdit_keydown
//* parameter   :	sId  - id of the control
//*							: oEvt - event object
//* description : handle keydown
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_TextEdit_keydown(sId,oEvt) {

	// show data tip when you press ctrl+shift+i (old key ctrl+q) 
	if( oEvt.keyCode==73 && oEvt.shiftKey && sapUrMapi_bCtrl(oEvt) && !oEvt.altKey ){
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
		ur_EVT_cancel(oEvt);
	}
	if( (ur_get(sId).getAttribute('rc')) == '1') 
	{
		var iMaxLength = parseInt(ur_get(sId).getAttribute('cc'));
		
		if(ur_TE_getCorrectLength(ur_get(sId).value) == iMaxLength)
		{
			// Handling for Ctrl+A, Backspace, cut, paste etc..
			if(oEvt.keyCode == 8 
			|| (oEvt.keyCode==86 && sapUrMapi_bCtrl(oEvt)) 
			|| (oEvt.keyCode==88 && sapUrMapi_bCtrl(oEvt)) 
			|| (oEvt.keyCode==89 && sapUrMapi_bCtrl(oEvt)) 
			|| (oEvt.keyCode==90 && sapUrMapi_bCtrl(oEvt))
			|| (oEvt.keyCode==65 && sapUrMapi_bCtrl(oEvt))
			|| (document.selection && document.selection.createRange().text.length>0)
			) {
  		
				if (oEvt.keyCode==90 && sapUrMapi_bCtrl(oEvt)) { //ctrl+z -> undo check the maxlength again CSN E-0000576574 2010
					ur_callDelayed("ur_TE_restrictChar('"+sId+"')",0);
				}
			return true;
		        }
		}
		
		// enter = two characters
		if(oEvt.keyCode==13){
		  iMaxLength = iMaxLength -1;
		}		
		
		if(ur_TE_getCorrectLength(ur_get(sId).value) >= iMaxLength && ur_TE_checkValidKey(oEvt))
		{
				ur_EVT_cancel(oEvt);
		}
		
	}
// handle esc key
	if(oEvt.keyCode == "27"){
		sapUrMapi_DataTip_hide(sId);
		ur_EVT_cancel(oEvt);
	}
}
//* ------------------------------------------------------------------------
//* function    : ur_TE_checkValidKey
//* parameter   :	oEvt - DOM Event
//*					
//* description : Check for Valid key Code.
//* return      : none
//* ------------------------------------------------------------------------

function ur_TE_checkValidKey(oEvt)
{
	switch(oEvt.keyCode)
	{
		case 37: //Left arrow
		case 39: // Right arrow
		case 38: // Up arrow
		case 40: // Down arrow
		case 46: // Delete Key
		case 45: //Insert /Overwrite key
		case 16: //Shift
		case 17: // Ctrl key
		case 9: 
		case 33:
		case 34:
		case 35:
		case 36:
			return false;
			break;
		default:
			return true;
	}
}

function ur_TE_KeyUp(sId,oEvt)
{
	ur_EVT_fire(ur_get(sId),'notifyKeyUp',oEvt);
}

function ur_TE_Change(sId, oEvt)
{

	ur_EVT_fire(ur_get(sId),'notifyChange',oEvt);
}

function ur_TE_onPaste(sId,oEvt)
{
	
	if( (ur_get(sId).getAttribute('rc')) == '1') 
	{
		ur_callDelayed("ur_TE_restrictChar('"+sId+"')",0);
		ur_get(sId).setAttribute("chgFire","1");
	}

}

//* ------------------------------------------------------------------------
//* function    : ur_TE_getCorrectLength
//* parameter   :	txtValue - String
//*					
//* description : Calculates the correct length of a string with line break. 
//*								Especially FF returns for a line break a length of 1 but it is two ASCII characters. 
//* return      : none
//* ------------------------------------------------------------------------

function ur_TE_getCorrectLength(txtValue)
{
	  if (txtValue.indexOf('\r\n')!=-1)
	    ; // IE on windows do nothing
	  else if (txtValue.indexOf('\r')!=-1)
	    txtValue=txtValue.replace ( /\r/g, "\r\n" ); // IE on MAC uses /r      
	  else if (txtValue.indexOf('\n')!=-1)
	     txtValue=txtValue.replace ( /\n/g, "\r\n" ); // Firefox on all platforms counts line break as one character but transfers two ASCII characters

		return txtValue.length;
}

//* ------------------------------------------------------------------------
//* function    : ur_TE_restrictChars
//* parameter   :	sId  - id of the control
//*					
//* description : Restricts the number of chars
//* return      : none
//* ------------------------------------------------------------------------
function ur_TE_restrictChar( sId )
{
	var oTextEdt = ur_get(sId), 
		txtValue=oTextEdt.value,
		lineBreakCount = 0,
		charCount = parseInt(oTextEdt.getAttribute('cc'));

	if(txtValue != "" && ur_TE_getCorrectLength(txtValue) >= charCount) {
		txtValue = txtValue.substr(0,charCount);

		//on some platforms and browser the newline character just counts as one character even two characters are transfered.
		//Ensure that the correct amount of characters are transfered to the server.
		//CSN E-0000576574 2010
	  if (txtValue.indexOf('\r\n')!=-1)
	    lineBreakCount = 0; // IE on windows do nothing
	  else if (txtValue.indexOf('\r')!=-1)
	    lineBreakCount = (txtValue.split(/\r/g).length - 1); // IE on MAC uses /r      
	  else if (txtValue.indexOf('\n')!=-1)
	    lineBreakCount = (txtValue.split(/\n/g).length - 1); // Firefox on all platforms counts line break as one character but transfers two ASCII characters

		if (lineBreakCount > 0 ) txtValue = txtValue.substr(0,charCount-lineBreakCount);
		oTextEdt.value = txtValue;
	}	
}
