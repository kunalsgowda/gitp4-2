//** LoadingAnimation.ie5 **
var _ur_LoadingAni_delay = 2000;
var _ur_LoadingAni_timerId = null;
var _ur_LoadingPopup = null;
function sapUrMapi_LoadingAnimation_getObject() {
	return ur_get("ur-loading");
}
function sapUrMapi_LoadingAnimation_getText() {
	var oLAText = ur_get("ur-loading");
	oLAText = oLAText.firstChild.lastChild;
	return oLAText.innerHTML;
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_LoadingAnimation_trigger
//* parameter   : loadingDelay  optional parameter to define the delay until 
//*		                loading animation is called. Don't hand over
//*		                a value to get the default UR delay value.  
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_LoadingAnimation_trigger(loadingDelay) {
	if ( loadingDelay>=0 ) 
		_ur_LoadingAni_timerId = ur_callDelayed("sapUrMapi_LoadingAnimation_show('ur-loading')", loadingDelay);
	else 
		_ur_LoadingAni_timerId = ur_callDelayed("sapUrMapi_LoadingAnimation_show('ur-loading')", _ur_LoadingAni_delay);
}
function sapUrMapi_LoadingAnimation_show(sId) {
	if (_ur_LoadingAni_timerId) {
		var arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
		_ur_LoadingPopup = new sapPopup(window,arrUrls,ur_get("ur-loading"),null,e,0);
		_ur_LoadingPopup.positionbehavior=sapPopupPositionBehavior.BROWSERCENTER;
		_ur_LoadingPopup.show(true);
		_ur_LoadingAni_timerId = null;
	}
}
function sapUrMapi_LoadingAnimation_cancel() {
	if (_ur_LoadingAni_timerId) {
		clearTimeout(_ur_LoadingAni_timerId);
	_ur_LoadingAni_timerId = null;
	} else {
		sapUrMapi_LoadingAnimation_hide();
}
}
function sapUrMapi_LoadingAnimation_hide() {
	if (_ur_LoadingPopup!=null) {
	   _ur_LoadingPopup.hide();
	   _ur_LoadingPopup=null;
	}
}
