

//returns the surrounding container element of a dom object o starting with the parent node of o
function ur_Cnt_getContainer(o) {
	o=o.parentNode;
	try {
	  while (o.getAttribute && o.getAttribute("ct")==null) {
	    if (o.tagName=="BODY") return null;
	    o=o.parentNode;
	  }
	  return o;
	} catch (ex) {return null};
}


}