//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SelectableLinkBar_RegisterCreate
//* parameter   : sId - string - Id of the SelectableLinkBar
//* description : Registers the selectablelinkbar with the create item registry to be
//*				  initialized when the page loads
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_SelectableLinkBar_RegisterCreate(sId) {
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_SelectableLinkBar_create('" + sId + "')");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SelectableLinkBar_create
//* parameter   : sId - string id of the SelectableLinkBar
//* return      : none
//* description	:
//* ------------------------------------------------------------------------
function sapUrMapi_SelectableLinkBar_create(sId) {
	
	ur_IScr_getObj(sId);
	ur_IScr_create(sId);
	sapUrMapi_Resize_AddItem(sId, "ur_IScr_resize('"+sId+"')");
	ur_IScr_resize(sId);
	
}

function ur_SLB_oadi(sId)
{

	var oScrl = ur_IScr[sId];
	if(oScrl.first == 0)
		ur_get(sId+'-SrlLt').className= "urLnkBarScrlLeftDsbl";
	else
		ur_get(sId+'-SrlLt').className= "urLnkBarScrlLeft";
	if(oScrl.last == oScrl.items.length -1)
		ur_get(sId+'-SrlRt').className= "urLnkBarScrlRightDsbl";
	else
		ur_get(sId+'-SrlRt').className= "urLnkBarScrlRight";
	
}

function sapUrMapi_SelectableLinkBar_draw(sId) {
  var oLinkBar = ur_get(sId);
  var iWidth = oLinkBar.offsetWidth;
  var iOrgWidth=iWidth;
  var oLinkBarContent = ur_get(sId+"-cnt");
  var oLinkBarScrollPrev = ur_get(sId+"-p");
  var oLinkBarScrollNext = ur_get(sId+"-n");
  iWidth-=oLinkBarScrollPrev.offsetWidth;
  iWidth-=oLinkBarScrollNext.offsetWidth;
  var nWidth=0;
  var xWidth=0;
  var xHeight=oLinkBarScrollNext.offsetHeight;
  var collItems = oLinkBarContent.childNodes;
  var iFirstVisible=sapUrMapi_SelectableLinkBar_getFirstVisibleItem(sId);
  var iLastVisible=parseInt(ur_get(sId).getAttribute("lastitemidx"));
  for (var n=0;n<collItems.length;n++) {
		  collItems.item(n).style.width="50px";
  }
  var ix=0;
  if (iWidth==0) {
  	oLinkBar.style.width="100%";
  	return;
  }
  if (iFirstVisible==-1) {
	  for (var n=0;n<iLastVisible+1;n++) {
		  if (n>=collItems.length) break;
		  collItems.item(n).style.height=xHeight;
	   	collItems.item(n).style.display="block";
	    nWidth+=collItems.item(n).offsetWidth;
	    if (nWidth<iWidth) {
	      xWidth=nWidth;
	    }
 	    if (nWidth>iWidth) {
	      collItems.item(ix).style.display="none";
	      ix++;
	      iFirstVisible=ix;
	    }
    }
    if (nWidth<iWidth) {
		  for (var n=iLastVisible+1;n<collItems.length;n++) {
		   	collItems.item(n).style.display="block";
  	    iLastVisible=n-1;
		    if (nWidth<iWidth) {
		      xWidth=nWidth;
		    }
 	      nWidth+=collItems.item(n).offsetWidth;
	 	    if (nWidth>iWidth) {
	 	    	break;
		    }
	    }
    }

  } else {
    var iLastVisible=-1;
	  for (var n=0;n<collItems.length;n++) {
		   collItems.item(n).style.height=xHeight;
		   if (n<iFirstVisible) {
		   	collItems.item(n).style.display="none";
		    continue;
		   } else {
		   	collItems.item(n).style.display="block";
		   }
		   nWidth+=collItems.item(n).offsetWidth;
		   if (nWidth<iWidth) {
		     xWidth=nWidth;
		   }
		   if (nWidth>iWidth) {
		     collItems.item(n).style.display="none";
		     if (iLastVisible==-1) {
		     	 iLastVisible=n-1;
		     }
		   }
		   if (nWidth<iWidth) {
		     xWidth=nWidth;
		   }
	  }
  }
  if (iLastVisible==-1) {
  	 iLastVisible=collItems.length-1;
  }
  if (iFirstVisible==-1) {
  	 iFirstVisible=0;
  }
  oLinkBar.setAttribute("lastitemidx",iLastVisible);
  oLinkBar.setAttribute("firstitemidx",iFirstVisible);
  // note that in style sheet class names "left" means "start of line
  //  and "right" means "end of line"
	if (oLinkBarScrollNext.onclick!=null) {
    oLinkBarScrollNext.setAttribute("oldonclick",oLinkBarScrollNext.onclick);
	}
  if (iLastVisible>=collItems.length-1) {
    oLinkBarScrollNext.className="urLnkBarScrlRight urLnkBarScrlRightDsbl";
    oLinkBarScrollNext.onclick=null;
  } else {
    oLinkBarScrollNext.className="urLnkBarScrlRight";
    oLinkBarScrollNext.onclick=oLinkBarScrollNext.getAttribute("oldonclick");
  }
	if (oLinkBarScrollPrev.onclick!=null) {
    oLinkBarScrollPrev.setAttribute("oldonclick",oLinkBarScrollPrev.onclick);
	}
  if (iFirstVisible==0) {
    oLinkBarScrollPrev.className="urLnkBarScrlLeft urLnkBarScrlLeftDsbl";
    oLinkBarScrollPrev.onclick=null;
  } else {
    oLinkBarScrollPrev.className="urLnkBarScrlLeft";
    oLinkBarScrollPrev.onclick=oLinkBarScrollPrev.getAttribute("oldonclick");
  }
  var oLinkBarDiv = ur_get(sId+"-div");
  oLinkBarDiv.style.height=xHeight;
  oLinkBarDiv.style.width=xWidth;
}

function sapUrMapi_SelectableLinkBar_getFirstVisibleItem(sLinkBarId) {
	return parseInt(ur_get(sLinkBarId).getAttribute("firstitemidx"));
}
function sapUrMapi_SelectableLinkBar_resize(sLinkBarId,e) {
  sapUrMapi_SelectableLinkBar_create(sLinkBarId);
}

function sapUrMapi_SelectableLinkBar_scroll(sLinkBarId,sDirection) {
  var iFirstVisible=sapUrMapi_SelectableLinkBar_getFirstVisibleItem(sLinkBarId);
  var iLastVisible=ur_get(sLinkBarId).getAttribute("lastitemidx");
  var iPageSize=iLastVisible-iFirstVisible;
  if (sDirection=="PREV") {
		iLastVisible=iFirstVisible-1;
		iFirstVisible=-1;
  } else if (sDirection=="NEXT") {
		iFirstVisible=iLastVisible+1;
		iLastVisible=-1;
	}	else {
	  iFirstVisible=-1;
	  iLastVisible=parseInt(sDirection.split("-")[2]);
	}
	ur_get(sLinkBarId).setAttribute("firstitemidx",iFirstVisible)
	ur_get(sLinkBarId).setAttribute("lastitemidx",iLastVisible)
  sapUrMapi_SelectableLinkBar_draw(sLinkBarId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SelectableLinkBar_goprevious
//* parameter   : sId - - string - Id of the SelectableLinkBar
//*				  o - srcelement
//*				  e - event
//* description :
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_SelectableLinkBar_goprevious(sId,o,e) {
	if(o.tagName == "TABLE"){
			o=o.firstChild.firstChild.firstChild;
		} else {
			while(o.tagName != "TD") o=o.parentNode;
			sapUrMapi_setTabIndex(o.firstChild,-1);
			o=o.previousSibling;
			if(o==null) return;
		}
		if(o.firstChild.className == "urLnkBarLnkDsbl" && ur_system.is508 == false ) o=o.previousSibling;
		if(o==null) return;
		if(o.style.display=="none")
		  sapUrMapi_SelectableLinkBar_scroll(sId,"PREV");
		sapUrMapi_setTabIndex(o.firstChild,0);
		sapUrMapi_focusElement(o.firstChild);
		ur_EVT_cancel(e);
		return true;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SelectableLinkBar_gonext
//* parameter   : sId - - string - Id of the SelectableLinkBar
//*				  o - srcelement
//*				  e - event
//* description :
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_SelectableLinkBar_gonext(sId,o,e) {
	if(o.tagName == "TABLE"){
			o=o.firstChild.firstChild.firstChild;
		}
		else{
			while(o.tagName != "TD") o=o.parentNode;
			sapUrMapi_setTabIndex(o.firstChild,-1);
			o=o.nextSibling;
			if(o==null) return;
		}
		if(o.firstChild.className == "urLnkBarLnkDsbl" && ur_system.is508 == false ) o=o.nextSibling;
		if(o==null) return;
		if(o.style.display=="none")
			sapUrMapi_SelectableLinkBar_scroll(sId,"NEXT");
		sapUrMapi_setTabIndex(o.firstChild,0);
		sapUrMapi_focusElement(o.firstChild);
		ur_EVT_cancel(e);
		return true;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SelectableLinkBar_keydown
//* parameter   : sId - string - Id of the SelectableLinkBar
//* description :
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_SelectableLinkBar_keydown(sId,e) {
	var o=e.srcElement;

	// spacebar
	if(e.keyCode=="32"){
		if(o.tagName=="A")o.click();
		ur_EVT_cancel(e);
	}

	// arrow right
	if(e.keyCode=="39"){
		if (ur_system.direction=="rtl")
			return sapUrMapi_SelectableLinkBar_goprevious(sId,o,e)
		else
			return sapUrMapi_SelectableLinkBar_gonext(sId,o,e)
	}
	// arrow left
	if(e.keyCode=="37"){
		if (ur_system.direction=="rtl")
			return sapUrMapi_SelectableLinkBar_gonext(sId,o,e);
		else
			return sapUrMapi_SelectableLinkBar_goprevious(sId,o,e);
	}

	// tab
	if(e.keyCode=="9"){
		if(o.tagName == "TABLE"){
			o=o.firstChild.firstChild.firstChild;
		} else {
			while(o.tagName != "TD") o=o.parentNode;
			sapUrMapi_setTabIndex(o.firstChild,-1);
			o=o.previousSibling;
			if(o==null) return;
		}
	}
}
