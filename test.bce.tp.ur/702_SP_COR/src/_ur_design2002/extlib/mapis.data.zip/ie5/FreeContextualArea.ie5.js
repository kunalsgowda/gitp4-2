//* ************************************************************************
//* FreeContextualArea
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : mf_FRA_exp
//* parameter   : sId   - Id of the object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function mf_FRA_exp(sId)
{
  var o=ur_get(sId);
  var oImg=o.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild;
  oImg.className="urFRAExpOp";
  var oCnt=o.firstChild.childNodes[1].firstChild.firstChild;
  oCnt.style.display="block";
  // For Mozilla display block only on div, which is td(above).firstChild
  ur_setSt(o,ur_st.COLLAPSED,false);
  ur_setSt(o,ur_st.EXPANDED,true);
  sapUrMapi_DBTN_showDBtn();
  sapUrMapi_refocusElement(sId);
}
//* ------------------------------------------------------------------------
//* function    : mf_FRA_col
//* parameter   : sId   - Id of the object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function mf_FRA_col(sId)
{
  var o=ur_get(sId);
  var oImg=o.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild;
  oImg.className="urFRAExpClo";
  var oCnt=o.firstChild.childNodes[1].firstChild.firstChild;
  oCnt.style.display="none";
  ur_setSt(o,ur_st.COLLAPSED,true);
  ur_setSt(o,ur_st.EXPANDED,false);
  sapUrMapi_DBTN_hideDBtn(); 
  sapUrMapi_refocusElement(sId);
}



//* ------------------------------------------------------------------------
//* function    : ur_FRA_cl
//* parameter   : oEvt   - Event Object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function ur_FRA_cl(oEvt)
{
  if (ur_FRA_tgl(oEvt)) return true;
  var oCl=ur_EVT_src(oEvt);
  var o=ur_getRootObj(oCl);
  if (oCl.className=="urFRAPers")
  {
    ur_EVT_fire(o,"opers",oEvt);
    return true;	
  }
}

//* ------------------------------------------------------------------------
//* function    : ur_FRA_kd
//* parameter   : oEvt   - Event Object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function ur_FRA_kd(sId,oEvt)
{
	// numpad +: expand tray
	var o=ur_get(sId);
	if(oEvt.keyCode==107)
	{
		if (ur_isSt(o,ur_st.COLLAPSED))
		{
			mf_FRA_exp(sId);
		 	ur_EVT_cancel(oEvt);
		 
		}
		return true;
	 }
	 // numpad -: collapse tray
	 else  if(oEvt.keyCode==109)
	 {
		 if (ur_isSt(o,ur_st.EXPANDED))
		 {
			 mf_FRA_col(sId);
			 sapUrMapi_DBTN_hideDBtn(); 
			 ur_EVT_cancel(oEvt);
			// o.fireEvent("onactivate");
		 }
		 return true;
	 }
     else if(oEvt.keyCode== 13)
	 {
		oSrc = ur_EVT_src(oEvt);
		if (oSrc && oSrc.id && oSrc.id.indexOf("-pers")>0) {
			ur_EVT_fire(o,"opers",oEvt);
			ur_EVT_cancel(oEvt);
		} else {
			sapUrMapi_triggerDefaultButton(sId,oEvt);
		}
	 }	 
	 else
		return sapUrMapi_skip(sId,oEvt);
}

function ur_FRA_tgl(oEvt)
{
  var oCl=ur_EVT_src(oEvt);
  var o=ur_getRootObj(oCl);
  if (oCl.className=="urFRAExpOp") 
  {
    ur_EVT_fire(o,"ocol",o.id);
    return true;
  } else if (oCl.className=="urFRAExpClo")
  {
    ur_EVT_fire(o,"oexp",oEvt);
    return true;
  }
}
