//* ************************************************************************
//* FileUpload
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_FileUpload_change
//* parameter   : sId  - Id of the FileUpload control
//*             : oEvt - Event Object
//* return      : none
//*	description	: update 508 tooltip
//* ------------------------------------------------------------------------
function sapUrMapi_FileUpload_change(sId,oEvt){
	// not used any more
}

