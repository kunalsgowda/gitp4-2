//* ************************************************************************
//* PatternContainerTabs
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function:			sapUrMapi_PcTab_Resize
//* parameter:			sId : the Id of the control to target
//* return      : none
//* description:		Handles the onresize event from the controls and delegates
//*						it to the resize registry
//* ------------------------------------------------------------------------
function ur_PcSeq_Resize(sId) {
	sapUrMapi_Resize_AddItem(sId, "ur_PcSeq_Draw('" + sId + "')");
}

function ur_PcSeq_RegisterCreate(sId) {
	ur_PcSeq_Create(sId);
	sapUrMapi_Create_AddItem(sId, "ur_PcSeq_Draw('" + sId + "')");
}

var ur_PcSeq_Registry = new Array();
//* ------------------------------------------------------------------------
//* function:			sapUrMapi_PcTabSeq_Create
//* parameter:			sId : the Id of the control to target
//* return      : none
//* description:		Based on the scroll type parameter, resizes the control and sets the overflow
//*						property to allow for the correct horizontal scrolling mode.
//* ------------------------------------------------------------------------
function ur_PcSeq_Create(sId) {
	ur_PcSeq_Registry[sId] = false;

	//if this control is collapsed, we will need to initialize it again.
	var bCollapsed = ur_get(sId).getAttribute("collapsed");
	var tbl = ur_get(sId + "-tbd").parentElement;
	if (bCollapsed == "true"){
		tbl.setAttribute("sized", "false");
	}
	else{
		tbl.setAttribute("sized", "true");
	}

	//register with the resize handler
	sapUrMapi_Resize_AddItem(sId, "ur_PcSeq_Draw('" + sId + "')");
	ur_PcSeq_Registry[sId] = true;
}

//* ------------------------------------------------------------------------
//* function:			sapUrMapi_PcTabSeq_Draw
//* parameter:			none
//* return:				none
//* description:		This loops all the PatternContainerTab controls and
//*						resizes them
//* ------------------------------------------------------------------------
function ur_PcSeq_Draw() {
	var divlist = new Array();
	var tbdylist = new Array();
	var iIdx = "null";

	for (var ctls in ur_PcSeq_Registry) {
		if (ctls.indexOf("_") == 0) {continue;}
		var tbdy = ur_get(ctls + "-tbd");
    if(tbdy==null) continue;
		tbdylist[ctls] = tbdy;
		divlist[ctls] = null;
		if (tbdy.style.display == "none") {
			continue;
		}
		iIdx = ur_get(ctls + "-tbl").getAttribute("selectedtab");
		if (iIdx == -9999) {
			iIdx = "Title";
		}
		var div = ur_get(ctls + "-cnt-" + iIdx);
		if (div==null) return;
		divlist[ctls] = div;
		/*
		for (i = 0; i < div.childNodes.length; i++) {
			if (div.childNodes[i].nodeType == 1) {div.childNodes[i].style.width = "1px";}
		}	*/
}

	for (var ctls in ur_PcSeq_Registry) {
		if ((ctls.indexOf("_") == 0) || (tbdylist[ctls].style.display == "none")) {
			continue;
		}
		var div = divlist[ctls];
		var maxWidth = parseInt(div.clientWidth);
		/*for (var i = 0; i < div.childNodes.length; i++) {
			if (div.childNodes[i].nodeType == 1) {div.childNodes[i].style.width = (maxWidth - 1) + "px";}
		}	*/
	}

	for (var ctls in ur_PcSeq_Registry) {
		if ((ctls.indexOf("_") == 0) || (tbdylist[ctls].style.display == "none")) {
			continue;
		}
		var div = divlist[ctls];
		for (var i = 0; i < div.childNodes.length; i++) {
			if (div.childNodes[i].nodeType == 1) {
				if (div.childNodes[i].style.display == "none") {
					div.childNodes[i].style.display = "";
				}
			}
		}
	}
}
//* ************************************************************************
//* PatternContainerSequence
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PcSeq_setActiveItem
//* parameter   : sId  - Id of the TabStrip
//  							iIdx - Index of the Item to activate (select)
//* description : selects an item of the tabstrip with the id sId
//* return      : true if the item was selected, else false
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_PcSeq_setActiveItem(sId, iIdx, iOldIdx, bIsTitle) {
	with(document) {
		var maxwidth = 0;
		var oTbl = getElementById(sId+"-tbl");
		var tbdy = getElementById(sId+"-tbd");
		var iOldIdx = parseInt(oTbl.getAttribute("selectedtab"));
		var iTabLength = parseInt(oTbl.getAttribute("tabcount"));
		var iNewIdx = parseInt(oTbl.getAttribute("starttab"));
		var iVisTabs = parseInt(oTbl.getAttribute("vistabs"));

		/* TEST FOR QUICK FUNCTION EXITS */
		// either the new index is not a number or it's the same as the currently selected index
		if (isNaN(iIdx)){return;}
		if ((iTabLength==1) || (iOldIdx==iIdx)){ return true; }

		//if we are not the title item, see if we can escape this function
		//the title item is always chosen with the value of -1
		if (iIdx != -9999){
			//get the label td and see if it is disabled or a terminating item
			var oClkCell = getElementById(sId + "-itm-" + iIdx);
			if (oClkCell.getAttribute("dsbl")=="true" || oClkCell.className.indexOf("Term") != -1){ return false; }
		}

		/* TURN OFF THE CURRENT ITEM, IF IT'S THE TITLE THIS IS EASIER THAN OTHER ITEMS */
		if (iOldIdx == -9999){
			// get the needed HTML elements and change their styles
			// title label span, connector cell, content container
			var oCurTxt = getElementById(sId + "-tit-txt");
			var oCurCon = getElementById(sId + "-itm-tit-cn");
			var oCurContent  = getElementById(sId+"-cnt-tit");
			maxwidth = parseInt(oCurContent.clientWidth);

			//keep the title's text selected
			if (oCurTxt != null){
				oCurTxt.className = "urPcTitTxt";
				}

			//unselect connector cell
				if (oCurCon != null){
				oCurCon.className = "urPcConOff";
				}

			// hide the old content container
			oCurContent.className = "urPcSeqDsp";
		}
		else if (iOldIdx >=0 && iOldIdx < iTabLength){
			// get the needed html elements
			// label span, label td, connector cell, step cell, step txt, content container
			var oCurTxt = getElementById(sId + "-itm-" + iOldIdx + "-txt");
			var oCurCell = getElementById(sId + "-itm-" + iOldIdx);
			var oCurCon = getElementById(sId + "-itm-" + iOldIdx + "-c");
			var oCurStpCell = getElementById(sId + "-itm-" + iOldIdx + "-n");
			var oCurStpTxt = getElementById(sId + "-itm-" + iOldIdx + "-na");
			var oCurContent  = getElementById(sId+"-cnt-"+iOldIdx);
			maxwidth = parseInt(oCurContent.clientWidth);

			if (oCurCell != null){
				//unselect label td and label span
				oCurCell.className="urPcSeqLabelOff";
				oCurTxt.className = "urPcSeqTxtOff";

				if (oCurStpCell != null){
					var re = /On/gi;
					var clsNm = oCurStpCell.className;
					//unselect step cell and it's text
					oCurStpCell.className = clsNm.replace(re, "Off");
					oCurStpTxt.className = "urPcSeqStpTxtOff";
				}
				//unselect connector cell
				if (oCurCon != null){
					oCurCon.className = "urPcConOff";
				}
			}

			//hide the old content container
			oCurContent.className = "urPcSeqDsp";
		}

		/* TURN ON THE CURRENT ITEM, IF IT'S THE TITLE THIS IS EASIER THAN OTHER ITEMS */
		//global variable to store the height of the new content
		var newHt = 0;
		if (iIdx == -9999){
			//get the needed HTML elements
			// label span, connector td, content container
			var oClkTxt  = getElementById(sId + "-tit-a");
			var oClkCon = getElementById(sId + "-itm-tit-cn");
			var oClkContent  = getElementById(sId+"-cnt-tit");

			//select the content connector
			if (oClkCon != null){
				oClkCon.className = "urPcConOn";
			}

			//display the content container
			if (tbdy.style.display != "none") {
				for (var i = 0; i < oClkContent.childNodes.length; i++){
					oClkContent.childNodes[i].style.width = (maxwidth - 1) + "px";
					}
				}

			oClkContent.className = "urPcSeqDspSel";
		}
		else{
			//get the needed HTML elements
			//label td, label span, connector cell, step cell, step txt, content container
			var oClkCell = getElementById(sId + "-itm-" + iIdx);
			var oClkTxt  = getElementById(sId + "-itm-" + iIdx + "-txt");
			var oClkCon = getElementById(sId + "-itm-" + iIdx + "-c");
			var oClkStpCell = getElementById(sId + "-itm-" + iIdx + "-n");
			var oClkStpTxt = getElementById(sId + "-itm-" + iIdx + "-na");
			var oClkContent  = getElementById(sId+"-cnt-"+iIdx);

			if (oClkCell != null){
				//select label td and label span
				oClkCell.className="urPcSeqLabelOn";
				oClkTxt.className = "urPcSeqTxtOn";
				if (oClkStpCell != null){
					var re = /Off/gi;
					var clsNm = oClkStpCell.className;
					//unselect step cell and it's text
					oClkStpCell.className = clsNm.replace(re, "On");
					oClkStpTxt.className = "urPcSeqStpTxtOn";
				}
			}

			//select the content connector
			if (oClkCon != null){
				oClkCon.className = "urPcConOn";
			}

			//display the content container
			if (tbdy.style.display != "none") {
				for (var i = 0; i < oClkContent.childNodes.length; i++){
					oClkContent.childNodes[i].style.width = (maxwidth - 1) + "px";
					}
				}


			oClkContent.className = "urPcSeqDspSel";
		}

		/* SET THE SEPARATION IMAGES BETWEEN ITEMS */
		if (iOldIdx != -9999){
			if (iOldIdx == iNewIdx){
				if (getElementById(sId+"-itm-"+(iOldIdx)+"-a") != null) {
				  getElementById(sId+"-itm-"+(iOldIdx)+"-a").className="urPcSeqAngOffOff";
				}
				var td = getElementById(sId+"-itm-"+(iOldIdx+1)+"-a");
				if (td.className.indexOf("Term") == -1){
					td.className="urPcSeqAngOffOff";
				}
				else{
					 td.className="urPcSeqAngOffTerm";
				}
			}
			else if (iOldIdx >=0 && iOldIdx < iTabLength){
				getElementById(sId+"-itm-"+(iOldIdx)+"-a").className="urPcSeqAngOffOff";
				if (iOldIdx < iTabLength){
					var td = getElementById(sId+"-itm-"+(iOldIdx+1)+"-a");
					if (td != null) {
					        if (td.className.indexOf("Term") == -1){
						        td.className="urPcSeqAngOffOff";
					        }
					        else{
						        td.className="urPcSeqAngOffTerm";
						}
					}
				}
			}
		}

		//set the seperation images between the tabs to selectedstates
		if (iIdx==iNewIdx){
				var td = getElementById(sId+"-itm-"+(iIdx+1)+"-a");
				if (getElementById(sId+"-itm-"+(iIdx)+"-a") != null) {
				  getElementById(sId+"-itm-"+(iIdx)+"-a").className="urPcSeqAngOffOn";
				}
				if (td.className.indexOf("Term") == -1){
					td.className="urPcSeqAngOnOff";
				}
				else{
					td.className="urPcSeqAngOnTerm";
				}
		}
		else{
			if (iIdx != -9999){
				getElementById(sId+"-itm-"+(iIdx)+"-a").className="urPcSeqAngOffOn";
			}
			if (iIdx != -9999 && iIdx != iTabLength - 1) {
				var td = getElementById(sId+"-itm-"+(iIdx+1)+"-a");
				if (td.className.indexOf("Term") == -1){
					td.className="urPcSeqAngOnOff";
				}
				else{
					td.className="urPcSeqAngOnTerm";
				}
			}
		}

		/* SET THE PREVIOUS AND NEXT ICONS FOR THE CONTROL */
		var oFirstImage  = getElementById(sId+"-p");
		var oLastImage   = getElementById(sId+"-n");

		// handle prev icons
		if (iNewIdx != 0){
			/*starting image in tab row unselected*/
			if (iIdx!=iNewIdx){oFirstImage.className="urPcSeqFirstAngOffPrevon";}
			/*selected*/
			else{oFirstImage.className="urPcSeqFirstAngOnPrevon";}
		}
		else{
			/*starting image in tab row unselected*/
			if (iIdx!=iNewIdx){oFirstImage.className="urPcSeqFirstAngOffPrevoff";}
			/*selected*/
			else{oFirstImage.className="urPcSeqFirstAngOnPrevoff";}
		}
		//find out what the last visible item is. if it is a terminator
		//oLastImage.style.display="none" else oLastImage.style.display="block"
		var oLastItm=null;
		if (iTabLength-1<iNewIdx+iVisTabs-1) {
		 oLastItm=ur_get(sId+"-itm-"+(iTabLength-1));
		} else {
		  oLastItm=ur_get(sId+"-itm-"+(iNewIdx+iVisTabs-1));
		}
		if (oLastItm.getAttribute("design")=="TERM") oLastImage.style.display="none";
		else oLastImage.style.display="block";

		// handle next icons
		if (iNewIdx + iVisTabs >= iTabLength){
			/* not selected */
			if (iIdx != (iNewIdx + iVisTabs - 1) && iIdx != iTabLength - 1){
				if (oLastImage.className.indexOf("Branch") != -1){
					oLastImage.className="urPcSeqLastOffBranchOn";
				}
				else if (oLastImage.className.indexOf("Term") != -1){
					
					oLastImage.className="urPcSeqAngOffTerm";
				} 
				else if ((iIdx + iVisTabs) < iOldIdx) {
					oLastImage.className="urPcSeqLastOffNextOff";
				} else {
					oLastImage.className="urPcSeqAngOffTerm";
				}
			}
			else{ /*selected*/
				if (oLastImage.className.indexOf("Branch") != -1){
					oLastImage.className="urPcSeqLastOnBranchOn";
				}
				else if (oLastImage.className.indexOf("Term") != -1){
					oLastImage.className="urPcSeqAngOnTerm";
					
				}
				else if (iIdx<iTabLength - 1){
					oLastImage.className="urPcSeqLastOffNextOn";
				}
			}
		}
		else{
			/* we shouldn't have next icons */
			if (iIdx != (iNewIdx + iVisTabs - 1) && iIdx != iTabLength - 1){
				if (oLastImage.className.indexOf("Branch") != -1){
					oLastImage.className="urPcSeqLastOffBranchOn";
				}
				else if (oLastImage.className.indexOf("Term") != -1){
					oLastImage.className="urPcSeqAngOnTerm";
				}
				else{
					oLastImage.className="urPcSeqLastOffNextOn";
				}
			}
			else{
				if (oLastImage.className.indexOf("Branch") != -1){
					oLastImage.className="urPcSeqLastOnBranchOn";
				}
				else if (oLastImage.className.indexOf("Term") != -1){
					oLastImage.className="urPcSeqAngOnTerm";
				}
				else if (iIdx<iVisTabs - 1){
					oLastImage.className="urPcSeqLastOffNextOn";
				} else {

					oLastImage.className="urPcSeqLastOnNextOn";
				}
			}
		}

		//set custom attribute selectedtab to current index
		oTbl.setAttribute("selectedtab",iIdx);

	/* set status for the current cell and the clicked cell */
	ur_setSt(oCurTxt,ur_st.NOTSELECTED,true);
	ur_setSt(oCurTxt,ur_st.SELECTED,false);
	ur_setSt(oClkTxt,ur_st.NOTSELECTED,false);
	ur_setSt(oClkTxt,ur_st.SELECTED,true);

	if (ur_system.is508) {
		sapUrMapi_refocusElement(oClkTxt.id)
	}

		//focus the item
		if (iIdx != -1){
			sapUrMapi_PcSeq_focusItem(sId,iIdx);
		}

		if (ur_system.is508) {
			oClkTxt.title = getLanguageText("SAPUR_PCSEQ_ITEM",new Array(oClkTxt.innerText,"SAPUR_PCSEQ_ITEM_SELECTED"));
			if (oClkStpTxt != null) {
				oClkStpTxt.title = getLanguageText("SAPUR_PCSEQ_ITEM_STEPNUMBER",new Array(oClkStpTxt.innerText,"SAPUR_PCSEQ_ITEM_STEPNR_SELECTED"));
			}
			if (oCurTxt != null) {
				oCurTxt.title = getLanguageText("SAPUR_PCSEQ_ITEM",new Array(oCurTxt.innerText,"SAPUR_PCSEQ_ITEM_ENABLED"));
				if (oCurStpTxt != null) {
					oCurStpTxt.title = getLanguageText("SAPUR_PCSEQ_ITEM_STEPNUMBER",new Array(oCurStpTxt.innerText,"SAPUR_PCSEQ_ITEM_STEPNR_ENABLED"));
				}
			}
		}
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PcSeq_focusItem
//* parameter   : sTabStripId - Id of the TabStrip (required)
//							: iFocusIdx   - Index of the Item to focus (optional),
//														  if not set the selectedItem will be focused
//							: iTabCount - set if you bNext and bPrev use Count of all TabStrips - optional
//							: bNext - if set the next Item gets the focus - optional
//							: bPrev - if set the previous Item gets the focus - optional
//* return      : false
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_PcSeq_focusItem(sSeqId, iIdx, iTabCount, bNext, bPrev) {
	var oTabTable 	= ur_get(sSeqId+"-tbl");
	if (isNaN(iIdx)) {iIdx = parseInt(oTabTable.getAttribute("selectedtab"));}
	if (isNaN(iTabCount)) {iTabCount = parseInt(oTabTable.getAttribute("tabcount"));}
	var ico = ur_get(sSeqId + "-menu");

	//escape if we're the title, no arrow key navigation
	if (iIdx == -9999) {return false;}

	var iNewIndex=iIdx;

	if (ico != null && ico.getAttribute("hasfocus") == "true") {
		if (bNext) {
			iNewIndex = parseInt(oTabTable.getAttribute("starttab"));
		}
		if (bPrev) {
			iNewIndex = parseInt(oTabTable.getAttribute("starttab")) - 1 + parseInt(oTabTable.getAttribute("vistabs"));
			if (ur_get(sSeqId+"-itm-"+iNewIndex+"-txt").getAttribute("design") == "term") {
				iNewIndex--;
			}
		}
	}
	else {
		if (bNext) {
			//Select the next TabStripItem
			if (iIdx<iTabCount-1){ iNewIndex=iIdx+1;}
			else {iNewIndex=0;}
		}
		if (bPrev) {
			if (iIdx>0) {iNewIndex=iIdx-1;}
			else {iNewIndex=iTabCount-1;}
		}
	}
	oFocusedTab = ur_get(sSeqId+"-itm-"+iNewIndex);

	if (oFocusedTab.style.display != "none") {
		var iOldFoc = parseInt(oTabTable.getAttribute("focusedtab"));
		if (!isNaN(iOldFoc)) {
			if (iOldFoc == -9999) {
			  sapUrMapi_setTabIndex(ur_get(sSeqId+"-tit-txt"),-1);
			}
			else {
			  sapUrMapi_setTabIndex(ur_get(sSeqId+"-itm-"+iOldFoc+"-txt"),-1);
			}
		}
		var oFoc = ur_get(sSeqId+"-itm-"+iNewIndex+"-txt");
		if (oFoc.getAttribute("design") != "term") {
			sapUrMapi_setTabIndex(oFoc,0);
			oFoc.focus();
			oTabTable.setAttribute("focusedtab",iNewIndex);
			if (ico != null) {
				ico.setAttribute("hasfocus", "false");
			}
			if ((oFocusedTab.getAttribute("dsbl")=="true")&&(!ur_system.is508)) {
				sapUrMapi_PcSeq_focusItem(sSeqId,iNewIndex,iTabCount,bNext,bPrev);
				return;
			}
		}
		else {
			if (ico != null && ico.getAttribute("hasfocus") != "true") {
				sapUrMapi_setTabIndex(ico,0);
				ico.setAttribute("hasfocus", "true");
				ico.focus();
			}
			else {
				sapUrMapi_PcSeq_focusItem(sSeqId,iNewIndex,iTabCount,bNext,bPrev);
				return;
			}
		}
	}
	else {
	    if (ico != null) {
			sapUrMapi_setTabIndex(ico,0);
			ico.setAttribute("hasfocus", "true");
			ico.focus();
	    }
	}
}


//* ------------------------------------------------------------------------
//* function:			sapUrMapi_PcSeq_keySelect
//* parameter:	  sId : the Id of the control to target
//* return      : none
//* description:		Handles the keyboardevent
//* ------------------------------------------------------------------------
function sapUrMapi_PcSeq_keySelect(sId, iSelectedIdx, iTabCount,e) {
	if (sapUrMapi_checkKey(e,"keydown",new Array("39","37"))){
	  if (ur_system.direction=="rtl") {
	    sapUrMapi_PcSeq_focusItem(sId,iSelectedIdx,iTabCount,e.keyCode==37,e.keyCode==39);
	  } else {
		sapUrMapi_PcSeq_focusItem(sId,iSelectedIdx,iTabCount,e.keyCode==39,e.keyCode==37);
	  }
		ur_EVT_cancel(e);
	  return;
	}
	if (sapUrMapi_checkKey(e,"keydown",new Array("32"))){
		sapUrMapi_PcSeq_setActiveItem(sId,iSelectedIdx,0,false);
		ur_EVT_cancel(e);
		return;
	}
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Pc_toggle
//* parameter   : sId    - string - Id of the Tray
//							  e - EventObject - the events object
//* description : Expand / Collapses the tray
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------
function ur_PcSeq_toggle(sId, sCtlType, e) {
	if ((e.type!="click") && (!sapUrMapi_checkKey(e,"keydown",new Array("32","30")))) return false;
	ur_EVT_cancelBubble(e);
	var tbdy = ur_get(sId+"-tbd");
	var tbl = tbdy.parentElement;
	var tbar = ur_get(sId+"-tbar");
	var thead = ur_get(sId+"-hd");
	var ico = ur_get(sId+"-exp");
	if ( tbdy != null && ico != null ) {
		if ( tbdy.style.display == "none" ) {
			if (tbar) tbar.style.setAttribute("display", "block");
			tbdy.style.setAttribute("display", "block");
			//we have to re-create our object here or things will not work properly
			if (tbl.getAttribute("sized") != "true"){
				sapUrMapi_Pc_Create(sId, tbl.getAttribute("scrolltype"), false );
			}

			if (ico.className.indexOf("urPcExpClosedIco") != -1){ ico.className = ico.className.replace("urPcExpClosedIco", "urPcExpOpenIco");}
			if (thead != null && thead.className == "urPcHdBgClosedIco" ){ thead.className = "urPcHdBgOpenIco";}
			if (ur_system.is508) {
				ico.title=getLanguageText(sCtlType + "_COLLAPSE",new Array(thead.innerText,sCtlType + "_COLLAPSE_KEY"));
			}
		} else {
			if (tbar){ tbar.style.setAttribute("display", "none");}
			var helper = tbdy.parentNode.offsetWidth;
			tbdy.style.setAttribute("display", "none");
			tbdy.parentNode.style.width=helper+"px";

			if (ico.className.indexOf("urPcExpOpenIco") != -1 ){ ico.className = ico.className.replace("urPcExpOpenIco", "urPcExpClosedIco");}
			if (thead != null && thead.className == "urPcHdBgOpenIco" ){ thead.className = "urPcHdBgClosedIco";}
			if (ur_system.is508) {
				ico.title=getLanguageText(sCtlType + "_EXPAND",new Array(thead.innerText, sCtlType + "_EXPAND_KEY"));
			}
	}
		ur_focus(ico);
}
  sapUrMapi_Focus_showFocusRect();
	return true;
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Pc_showOptionMenu
//* parameter   : sTrayId    - string - Id of the Tray
//  							sTriggerId - string - The Id of the DOM Objects that
//                                      is the trigger for the menu
//  							sMenuContentId - string- The Id of the DOM Objects that
//                                         contains the menu
//  							enumPositionBehavior - string- Defines at which position the PopupMenu
//																			 will appear. Default is Right in ltr.
//							  e - EventObject - the events object
//* description : Opens the Menu that is applied as option menu to that tray.
//								There is an icon shown if a menu is connected to the tray
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------
function ur_PcSeq_showOptionMenu(sId,e) {
  var sTrayId=sId;
  var sTriggerId=sId+"-menu";
  var sMenuContentId=ur_get(sTriggerId).getAttribute("mid");
 	if (ur_system.direction=="rtl")
	  var enumPositionBehavior=sapPopupPositionBehavior.MENULEFT;
	else
	  var enumPositionBehavior=sapPopupPositionBehavior.MENURIGHT;
  var sControlType=sapUrMapi_getControlTypeFromObject(ur_get(sId));
	if(sControlType == "PCSEQ") 
	{
		if (e.type!="click") {
			if (sapUrMapi_checkKey(e,"keydown",new Array("32","40","13"))){
				sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
			}
			else if (sapUrMapi_checkKey(e,"keydown",new Array("39","37"))) {
				var intTabCount = parseInt(ur_get(sTrayId + "-tbl").getAttribute("tabcount"));
				if (ur_system.direction=="rtl") {
					sapUrMapi_PcSeq_focusItem(sTrayId,null,null,e.keyCode==37,e.keyCode==39);
				} else {
					sapUrMapi_PcSeq_focusItem(sTrayId,null,null,e.keyCode==39,e.keyCode==37);
				}
				return;
			}
			else {
				return false;
			}
		}
		else {
			sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
		}
	}
}
//* ************************************************************************
//* PatternContainerScrollable Functions
//* ************************************************************************
/**
 * This handles scrolling single tabs through either direction.  It delegates
 * the actual transformation of HTML elements to other functions.
 *
 * @declare public
 * @param sId Sting The id of the control to check
 * @param iDir int The direction for the scrolling
 * @param sCtlType String One of the constants available in the system as a scrolling control type.
 */
function ur_PcSeq_scrollItem( sId, iDir, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	if (iDir != -1 && iDir != 1){
		return false;
	}
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
	var diff = vistabs;

	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs - 1;}
	}

	if (lasttab != firsttab + vistabs - 1){
		diff = lasttab - firsttab;
	}

	if (iDir == 1){
		//scroll up
		if (lasttab == tabcount - 1){return false;}
		//first shift off the firsttab
		showItem(sId, firsttab, false, true, false);
		//reset our first tab and show it
		firsttab += 1;
		showItem(sId, firsttab, true, true, false);
		if (diff > 2) {
			//shift down or current last tab
			showItem(sId, lasttab, true, false, false);
		}
		if (diff != 1) {
		//reset our last tab and show it
		lasttab += 1;
		showItem(sId, lasttab, true, false, true);
	}
	else{
		//reset the last tab equal to the first tab
		lasttab = firsttab;
		showItem(sId, lasttab, true, true, true);
		}

	}
	else{
		//scroll down
		if (firsttab == 0){return false;}
		//to handle odd tab groupings don't turn off the last tab unless we
		//have a full visible set
		if (diff >= vistabs - 1){
			//shift off the last tab
			showItem(sId, lasttab, false, false, true);
			//reset our last tab and show it
			lasttab -= 1;
			showItem(sId, lasttab, true, false, true);
		}
		if (diff >= 1) {
			if (vistabs > 1) {
				//move our old first tab
		showItem(sId, firsttab, true, false, false);
		//shift up our current tab
		firsttab -= 1;
		showItem(sId, firsttab, true, true, false);
	}
		else {
			  //hide the old first tab
				showItem(sId, firsttab, false, false, false);
		//shift up our current tab
		firsttab -= 1;
				showItem(sId, firsttab, true, true, false);
			}
		}
		else {
		//shift up our current tab
    showItem(sId, firsttab, true, false, true);
		firsttab -= 1;
		showItem(sId, firsttab, true, true, true);
		}

	}
	//call the function to set the icons
	setSeqIcons( sId, firsttab, lasttab, tabcount );

	//now we have to reset the page information
	var newtabpage = Math.floor(firsttab / vistabs);
	oTabs.setAttribute("starttab", firsttab);
	oTabs.setAttribute("lasttab", lasttab);
	oTabs.setAttribute("tabpage", newtabpage);
	ur_PcSeq_togglePager(sId,e)
}

/**
 * Scrolls the tabset by a "page" of items.
 *
 * @declare public
 * @param sId String The Id of the control to change.
 * @param iDir Int The direction of the page scroll, either -1/1.
 */
function ur_PcSeq_pageItem( sId, iDir, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	if (iDir != 1 && iDir != -1){
		return false;
	}
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));

	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs-1;}
	}
	//see if we have any pages in the desired direction, if not return false
	if ((iDir == -1 && firsttab == 0) || ( iDir == 1 && lasttab == tabcount -1)){
		return false;
	}

	//change our current tabpage
	if (((iDir == 1) && ((tabpage + iDir) * vistabs) < (tabcount)) ||
		((iDir == -1) && (tabpage + iDir >= 0) )){
		tabpage = tabpage + iDir;
	}

	//get the upper and lower bounds of our visible page
	var lbound = Math.floor(tabpage * vistabs);
	var ubound = lbound + vistabs - 1;
	//if our ubound is greater than the tabcount, reset the ubound
	if (ubound > tabcount - 1){
		ubound = tabcount -1;
	}

	//loop over the tabs and turn off items outside of our visible range
	for (var i = 0; i < tabcount; i++){
		//turn off tabs outside of our bounds
		if (i < lbound || i > ubound){
			if (i == firsttab){
				showItem(sId, i, false, true, false);
			}
			else if (i == lasttab){
				showItem(sId, i, false, false, true);
			}
			else{
			   showItem(sId, i, false, false, false);
			}
		}
		else{
		   if (i == lbound){
				showItem(sId, i, true, true, false);
		   }
		   else if (i == tabcount -1 || i == ubound){
				showItem(sId, i, true, false, true);
		   }
		   else{
				showItem(sId, i, true, false, false);
		   }
		}
	}
	//call the function to set the icons
	setSeqIcons( sId, lbound, ubound, tabcount );

	//re-assign our attributes
	oTabs.setAttribute("starttab", lbound);
	oTabs.setAttribute("lasttab", ubound);
	oTabs.setAttribute("tabpage", tabpage);
	ur_PcSeq_togglePager(sId,e)
}

/**
 * This will show/hide a given tab element.
 *
 * @declare public
 * @param iIdx int The index of the tab to show or hide
 * @param bShow bool True to show, false to hide
 * @param bIsFirst bool True if the current tab is the first visible tab.
 * @param bIsLast bool True if the current tab is the last visible tab.
 */
function showItem( sId, iIdx, bShow, bIsFirst, bIsLast ){
	//get our HTML elements
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var seltab = parseInt(oTabs.getAttribute("selectedtab"));

	var tabimg = ur_get(sId + "-itm-" + iIdx + "-a");
	var tabstat = ur_get(sId + "-itm-" + iIdx + "-n");
	var tabcell = ur_get(sId + "-itm-" + iIdx);
	//get connector row if there is one
	var conimg = ur_get(sId + "-itm-" + iIdx + "-ca");
	var constat = ur_get(sId + "-itm-" + iIdx + "-cn");
	var concell = ur_get(sId + "-itm-" + iIdx + "-c");

	if (bShow){
		//show the tab
		var statdisp = "";
		if (tabcell.getAttribute("design") == "INT" || tabcell.getAttribute("design") == "TERM"){
			statdisp = "none";
		}

		if (!bIsFirst && !bIsLast){
			tabimg.style.display = "";
			tabcell.style.display = "";
			tabstat.style.display = statdisp;

			if (concell != null){
				concell.style.display = "";
				conimg.style.display = "";
				constat.style.display = statdisp;
			}
		}
		else if (bIsFirst){
			tabimg.style.display = "none";
			tabcell.style.display = "";
			tabstat.style.display = statdisp;
			if (concell != null){
				concell.style.display = "";
				conimg.style.display = "none";
				constat.style.display = statdisp;
			}
		}
		else if (bIsLast){
			tabimg.style.display = "";
			tabcell.style.display = "";
			tabstat.style.display = statdisp;
			if (concell != null){
				concell.style.display = "";
				conimg.style.display = "";
				constat.style.display = statdisp;
			}
		}
	}
	else{
		//hide the tab
		tabimg.style.display = "none";
		tabcell.style.display = "none";
		tabstat.style.display = "none";
		if (concell != null){
			concell.style.display = "none";
			conimg.style.display = "none";
			constat.style.display = "none";
		}
	}
}

/**
 * This will manage control specific prev/next icons.
 *
 * @declare public
 * @param variable type description
 */
function setSeqIcons( sId, firsttab, lasttab, tabcount ){
	var prev = ur_get(sId + "-p");
	var next = ur_get(sId + "-n");
	var c_prev = ur_get(sId + "-p-c");
	var c_next = ur_get(sId + "-n-c");
	var first = ur_get(sId + "-itm-" + firsttab);
	var last = ur_get(sId + "-itm-" + lasttab);

	var prevtmp = prev.className;
	var nexttmp = next.className
	//change the prev tab first
	if (firsttab == 0){
		if (first.className == "urPcSeqLabelOn"){
			prev.className = "urPcSeqFirstAngOnPrevOff";
		}
		else{
			prev.className = "urPcSeqFirstAngOffPrevOff";

		}
		if (c_prev != null) {
		  c_prev.style.display = "none";
		}
	}
	else{
		if (first.className == "urPcSeqLabelOn"){
			prev.className = "urPcSeqFirstAngOnPrevOn";
		}
		else{
			prev.className = "urPcSeqFirstAngOffPrevOn";
		}
		if (c_prev != null) {
		  c_prev.style.display = "";
		}
	}
	//change the next tab
	if (lasttab == tabcount - 1){
		var lastdesign = last.getAttribute("design").toUpperCase();
		//test for term item first
		//if (last.className.indexOf("Term") != -1){
		if (lastdesign == "TERM") {
			next.className = "urPcSeqLastTerm";
			if (c_next != null) {
			  c_next.style.display = "none";
			}
		}
		//else if (last.className.indexOf("Branch") != -1){
		else if (lastdesign == "BRANCH") {
			if (last.className == "urPcSeqLabelOn"){
				next.className = "urPcSeqLastOnBranchOn";
			}
			else{
				next.className = "urPcSeqLastOffBranchOn";
			}
			if (c_next != null) {
			  c_next.style.display = "none";
			}
		}
		else {
		    if (last.className == "urPcSeqLabelOn") {
				next.className = "urPcSeqLastOnNextOff";
			}
			else {
			    next.className = "urPcSeqLastOffNextOff";
			}
			if (c_next != null) {
			  c_next.style.display = "none";
			}
		}
	}
	else{
		next.style.display="block";
		if (last.className == "urPcSeqLabelOn"){
			next.className = "urPcSeqLastOnNextOn";
		}
		else{
			next.className = "urPcSeqLastOffNextOn";
		}
		if (c_next != null) {
		  c_next.style.display = "";
		}
	}

	//set the previous indicator class
	prev.childNodes(0).className = "urPcSeqPreFirstAng";

	//change the class for the image in the next indicator
	if (next.className.indexOf("Term") != -1){
		next.childNodes(0).className = "urPcSeqAfterLastAng";
	}
	else if (next.className.indexOf("Branch") != -1){
		next.childNodes(0).className = "urPcSeqBranchAng";
	}
	else{
		next.childNodes(0).className = "urPcSeqAfterLastAng";
	}
}
/**
 * Scrolls the tabs by jumping to a particular tab and selecting that tab.
 *
 * @declare public
 * @param sId String The Id of the control to scroll.
 * @param iTab int The index of the tab to jump to.
 * @param sCtlType String The type of control being acted upon.
 */
function ur_PcSeq_jumpItem( sId, iTab, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
  sapUrMapi_PopupMenu_hideAll();
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
	var seltab = parseInt(oTabs.getAttribute("selectedtab"));

	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs-1;}
	}

	//prevent unavailable values.
	if (iTab >= tabcount || iTab < 0){
		return false;
	}

	//get our new tab page
	var tabpage = Math.floor(iTab / vistabs);
	//get the upper and lower bounds of our visible page
	var lbound = Math.floor(tabpage * vistabs);
	var ubound = lbound + vistabs - 1;
	//if our ubound is greater than the tabcount, reset the ubound
	if (ubound > tabcount - 1){
		ubound = tabcount -1;
	}

	//loop over the tabs and turn off items outside of our visible range
	for (var i = 0; i < tabcount; i++){
		//turn off tabs outside of our bounds
		if (i < lbound || i > ubound){
			if (i == firsttab){
				showItem(sId, i, false, true, false);
			}
			else if (i == lasttab){
				showItem(sId, i, false, false, true);
			}
			else{
			   showItem(sId, i, false, false, false);
			}
		}
		else{
		   if (i == lbound){
				showItem(sId, i, true, true, false);
		   }
		   else if (i == tabcount -1 || i == ubound){
				showItem(sId, i, true, false, true);
		   }
		   else{
				showItem(sId, i, true, false, false);
		   }
		}
	}

	//re-assign our attributes
	oTabs.setAttribute("starttab", lbound);
	oTabs.setAttribute("lasttab", ubound);
	oTabs.setAttribute("tabpage", tabpage);
	ur_PcSeq_togglePager(sId,e)

	//TODO:  now select our item by calling the appropriate function
	//the signature for the methods needs to be the same all the time...
	sapUrMapi_PcSeq_setActiveItem(sId, iTab, seltab, false);

	//call the function to set the icons
	setSeqIcons( sId, lbound, ubound, tabcount );
}

function ur_PcSeq_togglePager(sId,e) {
  if (ur_get(sId+"-pag")!=null) {
    var sPagerId=ur_get(sId+"-pag").firstChild.id;
  } else {
    return;
  }
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
  var arrButtonArray = new Array();
	var arrStateArray = new Array();
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.BEGIN;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.PREVIOUS_PAGE;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.PREVIOUS_ITEM;
	if (firsttab!=0) {
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	} else {
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	}
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.END;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.NEXT_PAGE;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.NEXT_ITEM;
	if (lasttab!=tabcount-1) {
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	} else {
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	}
  sapUrMapi_Paginator_setStates(sPagerId,arrButtonArray,arrStateArray);
}