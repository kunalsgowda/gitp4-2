//* ************************************************************************
//* DateNavigator
//* ************************************************************************
//* PRIVATE FUNCTIONS
//* ------------------------------------------------------------------------
//* function    : ur_DateNavigator_getMonthHdr
//* parameter   : o  - month (cell containing the month table)
//* return      :	month header object
//* description	: get header object of a month
//* ------------------------------------------------------------------------
function ur_DateNavigator_getMonthHdr(o){
  try {
	return o.firstChild.firstChild.firstChild.cells[1].firstChild;
	} catch (ex) {
	  return null;
  } 
} 

//* ------------------------------------------------------------------------
//* function    : ur_DateNavigator_getMonth
//* parameter   : o  - object within a month
//* return      :	month object  (cell containing the month table)
//* description	: get month object
//* ------------------------------------------------------------------------
function ur_DateNavigator_getMonth(o){
	while(o.tagName!="TABLE")
		o=o.parentNode;
	return o.parentNode;  
      }

//* ------------------------------------------------------------------------
//* function    : ur_DateNavigator_focusNextMonth
//* parameter   : o - object within a month
//* return      :
//* description	: focus header of the next month or click next arrow to
//*								get more month
//* ------------------------------------------------------------------------
function ur_DateNavigator_focusNextMonth(o){
	var oThis=ur_DateNavigator_getMonth(o);
	var oThisHdr=ur_DateNavigator_getMonthHdr(oThis);
	if (!oThisHdr) return false;
	var oPrev=null;
	var oPrevHdr=null;
	if(oThisHdr && oThisHdr.parentNode.nextSibling && oThisHdr.parentNode.nextSibling.className.indexOf("ArrNext")>-1 && oThisHdr.parentNode.nextSibling.className.indexOf("Dsbl")==-1) { // if month is last month click next arrow
		oThisHdr.parentNode.nextSibling.click();
  } else{		
		oNext=oThis.nextSibling; // next month in the row
		if(oNext==null&&oThis.parentNode.nextSibling!=null)	// first month in the next row
			oNext=oThis.parentNode.nextSibling.firstChild;
		if(oNext==null) return false;
		oNextHdr=ur_DateNavigator_getMonthHdr(oNext);
		if(oNextHdr!=null)
			ur_focus(oNextHdr);
			return true;
  }
}

//* ------------------------------------------------------------------------
//* function    : ur_DateNavigator_focusUpMonth
//* parameter   : o - object within a month
//* return      :
//* description	: focus header of the upper month
//* ------------------------------------------------------------------------
function ur_DateNavigator_focusUpMonth(o){
	var oThis=ur_DateNavigator_getMonth(o);
	var oPrevRow=oThis.parentNode.previousSibling;
	if(oPrevRow==null) return;
	ur_DateNavigator_getMonthHdr(oPrevRow.childNodes[oThis.cellIndex]).focus();
  }

//* ------------------------------------------------------------------------
//* function    : ur_DateNavigator_focusDownMonth
//* parameter   : o - object within a month
//* return      :
//* description	: focus header of the month	below
//* ------------------------------------------------------------------------
function ur_DateNavigator_focusDownMonth(o){
	var oThis=ur_DateNavigator_getMonth(o);
	var oNextRow=oThis.parentNode.nextSibling;
	if(oNextRow==null) return;
	ur_DateNavigator_getMonthHdr(oNextRow.childNodes[oThis.cellIndex]).focus();
			    }

//* ------------------------------------------------------------------------
//* function    : ur_DateNavigator_focusPrevMonth
//* parameter   : o - object within a month
//* return      :
//* description	: focus header of the previous month or click previous arrow to
//*								get more month
//* ------------------------------------------------------------------------
function ur_DateNavigator_focusPrevMonth(o){
	var oThis=ur_DateNavigator_getMonth(o);
	var oThisHdr=ur_DateNavigator_getMonthHdr(oThis);
	var oPrev=null;
	var oPrevHdr=null;
  if(oThisHdr.parentNode.previousSibling.className.indexOf("urCalArrPrev")>-1) {
		oThisHdr.parentNode.previousSibling.click();
        }
  else{		
		oPrev=oThis.previousSibling;	// previous month in the row
		if(oPrev==null&&oThis.parentNode.previousSibling!=null)	// last month in the previous row
			oPrev=oThis.parentNode.previousSibling.lastChild;
		if(oPrev==null) return;
		oPrevHdr=ur_DateNavigator_getMonthHdr(oPrev);
		if(oPrevHdr!=null)
			oPrevHdr.focus();
      }
    }

//* ------------------------------------------------------------------------
//* function    : ur_DateNavigator_focusThisMonth
//* parameter   : o  - object within a month
//* return      :
//* description	: focus header of the current month 
//* ------------------------------------------------------------------------
function ur_DateNavigator_focusThisMonth(o){
	var oThis=ur_DateNavigator_getMonth(o);
	var oThisHdr=ur_DateNavigator_getMonthHdr(oThis);
	if(oThisHdr!=null)
		oThisHdr.focus();
  } 

//* ------------------------------------------------------------------------
//* function    : ur_DateNavigator_focusNextDay
//* parameter   : o  - day object
//* return      :
//* description	: focus next day
//* ------------------------------------------------------------------------
function ur_DateNavigator_focusNextDay(o){
	var oNext=o.nextSibling;
	while(oNext!=null && ur_isSt(oNext.id,ur_st.DISABLED)) 
			oNext=oNext.nextSibling;
	if(oNext!=null && o.className.indexOf("urCalNum")==-1) oNext.setAttribute("sameWeek","true");
	if(oNext==null&&o.parentNode.nextSibling!=null)
	{
		oNext=o.parentNode.nextSibling.firstChild;
		oNext.setAttribute("sameWeek","false");
	}
	if(oNext==null) return;
	if(oNext.getAttribute("ti")=="0")
		oNext.focus();
	else
		ur_DateNavigator_focusNextDay(oNext);
   }

//* ------------------------------------------------------------------------
//* function    : ur_DateNavigator_focusPrevDay
//* parameter   : o  - day object
//* return      :
//* description	: focus previous day 
//* ------------------------------------------------------------------------
function ur_DateNavigator_focusPrevDay(o){
	var oPrev=o.previousSibling;
	while(oPrev!=null && ur_isSt(oPrev.id,ur_st.DISABLED)) 
			oPrev=oPrev.previousSibling;
	if(oPrev!=null && o.className.indexOf("urCalNum")==-1) oPrev.setAttribute("sameWeek","true");
	if(oPrev==null&&o.parentNode.previousSibling!=null)
	{
		oPrev=o.parentNode.previousSibling.lastChild;
		oPrev.setAttribute("sameWeek","false");
	}
	if(oPrev==null||oPrev.className.indexOf("urCalName")>=0) return;
	if(oPrev.getAttribute("ti")=="0")
		oPrev.focus();
	else
		ur_DateNavigator_focusPrevDay(oPrev);
		 }

//* ------------------------------------------------------------------------
//* function    : ur_DateNavigator_focusNextWeek
//* parameter   : o  - day object
//* return      :
//* description	: focus next week
//* ------------------------------------------------------------------------
function ur_DateNavigator_focusNextWeek(o){
	var oNext=o.parentNode.nextSibling;
	if(oNext==null) return;
	oNext=oNext.cells[o.cellIndex];
	if(oNext.getAttribute("ti")=="0")
		oNext.focus();
	else
		ur_DateNavigator_focusNextWeek(oNext);
  }

//* ------------------------------------------------------------------------
//* function    : ur_DateNavigator_focusPevWeek
//* parameter   : o  - day object
//* return      :
//* description	: focus previous week
//* ------------------------------------------------------------------------
function ur_DateNavigator_focusPrevWeek(o){
	var oPrev=o.parentNode.previousSibling;
	if(oPrev==null) return;
	oPrev=oPrev.cells[o.cellIndex];
	if(oPrev.className.indexOf("urCalName")>=0) return;
	if(oPrev.getAttribute("ti")=="0")
		oPrev.focus();
	else
		ur_DateNavigator_focusPrevWeek(oPrev);
}

//* PUBLIC FUNCTIONS
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_DateNavigator_keydown
//* parameter   : sId  - Id of the DateNavigator control
//*								oEvt - event object
//* return      :
//* description	: 
//* ------------------------------------------------------------------------
function sapUrMapi_DateNavigator_keydown(sId,oEvt) {
  var o=ur_evtSrc(oEvt);
  var iKey=oEvt.keyCode;

	/* rtl left and right arrow key mapping */
  if(iKey==37)
		iKey=ur_system.direction!="rtl"?37:39;
	else if(iKey==39)
		iKey=ur_system.direction!="rtl"?39:37;
		
	/* F6 = skip to end */
	if(iKey==117)
		return sapUrMapi_skip(sId,oEvt);
	
	/* spacebar = click	*/
	if(iKey==32){
		o.click();
    return ur_EVT_cancel(oEvt);
  }
			
	/* arrow right = next day, month */	
	if(iKey==39){
		if(o.className.indexOf("Whl")>=0) return;
		if (o.parentNode.className.indexOf("urCalHdr")>-1)
			ur_DateNavigator_focusNextMonth(o);
		else
			ur_DateNavigator_focusNextDay(o);
		return ur_EVT_cancel(oEvt);
				}
	
	/* arrow left = previous day, month */	
	if(iKey==37){
		if(o.className.indexOf("Whl")>=0) return;
		if (o.parentNode.className.indexOf("urCalHdr")>-1)
			ur_DateNavigator_focusPrevMonth(o);
		else
			ur_DateNavigator_focusPrevDay(o);
		return ur_EVT_cancel(oEvt);
			}
	
	/* arrow up = previous week */
	if(iKey==38){
		if(o.className.indexOf("Whl")>=0) return;
		if(o.getAttribute("tp")=="DAY")
		{
			o.setAttribute("sameWeek","false");
		}
		
		if(o.parentNode.className.indexOf("urCalHdr")>=0)
			ur_DateNavigator_focusUpMonth(o);
		else
			ur_DateNavigator_focusPrevWeek(o);
		return ur_EVT_cancel(oEvt);
				}

	/* arrow down = next week */
	if(iKey==40){
		if(o.className.indexOf("Whl")>=0) return;
		if(o.getAttribute("tp")=="DAY")
		{
			o.setAttribute("sameWeek","false");
		}
		if(o.parentNode.className.indexOf("urCalHdr")>=0)
			ur_DateNavigator_focusDownMonth(o);
		else		
			ur_DateNavigator_focusNextWeek(o);
		return ur_EVT_cancel(oEvt);
			}
	
	/* tab = go to next month if you are within a month
	   shift+tab = got to header of the current month	*/
	if(iKey==9&&o.id!=sId&&o.id!=sId+"-skipend"){
		if(o.className.indexOf("Whl")>=0||o.parentNode.className.indexOf("urCalHdr")>-1) return;
		if(oEvt.shiftKey)
			ur_DateNavigator_focusThisMonth(o);
		else{
			var oThis=ur_DateNavigator_getMonth(o);
			var oThisHdr=ur_DateNavigator_getMonthHdr(oThis);
      if (!ur_DateNavigator_focusNextMonth(oThisHdr)) {
			  if (ur_get(sId+"-skipend")) {
				ur_get(sId+"-skipend").focus();
      		return ur_EVT_cancel(oEvt);
			  } else {
			    //focus he last day and dont cancel for non 508 case
			    var tds = o.parentNode.parentNode.parentNode.getElementsByTagName("TD");
			    var td = tds[tds.length-1];
			    ur_focus(td);
    }
			} else {
    return ur_EVT_cancel(oEvt);
  }
    }
  }
  
	/* shift+tab at skipend = go to last month */
	if(iKey==9&&oEvt.shiftKey&&o.id==sId+"-skipend"){
		o.previousSibling.firstChild.firstChild.lastChild.lastChild.firstChild.firstChild.firstChild.childNodes[1].firstChild.focus();
		return ur_EVT_cancel(oEvt);
	}	  
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_DateNavigator_mousemove
//* parameter   : sId  - Id of the DateNavigator control
//*								oEvt - event object
//* return      :
//* description	: 
//* ------------------------------------------------------------------------
function sapUrMapi_DateNavigator_mousemove(sId,oEvt) {
 
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_DateNavigator_activate
//* parameter   : sId  - Id of the DateNavigator control
//*								oEvt - event object
//* return      :
//* description	: sets the 508 tooltip for days	and month
//* ------------------------------------------------------------------------
function sapUrMapi_DateNavigator_activate(sId,oEvt){
	var o=ur_evtSrc(oEvt);
	var sDay=o.getAttribute("day");
	var sSep=" "+getLanguageText("SAPUR_SEPARATOR")+" ";	

	/* day */
	if(sDay!=null){
		var oRow=o.parentNode;
		var oWeekday=oRow.parentNode.rows[1].cells[o.cellIndex];
		var sDesign=o.getAttribute("ds");
		var sTt=o.getAttribute("tt");
		o.title=sDay+sSep+getLanguageText("SAPUR_CALWEEK")+" "+oRow.firstChild.innerText+sSep+oWeekday.title;
		if(sDesign!=null&&sDesign!="")
			o.title+=sSep+sDesign;
		if(sTt!=null&&sTt!="")
			o.title+=sSep+sTt;
		if(o.getAttribute("cl")=="true")
			o.title+=sSep+getLanguageText("SAPUR_CALSEL_TUTOR");
	}
	/* month */
	else if (o.parentNode!=null&&o.parentNode.className.indexOf("urCalHdr")>-1){
		o.title=o.innerText;
		var iIdx=o.getAttribute("idx");
		if(iIdx=="f"){
			o.title+=sSep+getLanguageText("SAPUR_CALFIRSTMONTH");
			if(ur_get(sId).getAttribute("nav")=="true")
				o.title+=sSep+getLanguageText("SAPUR_CALPREVMONTH_TUTOR");
			if(o.getAttribute("cl")=="true")
				o.title+=" "+getLanguageText("SAPUR_CALSEL_TUTOR");													
		}
		else if(iIdx=="l"){
			o.title+=sSep+getLanguageText("SAPUR_CALLASTMONTH");
			if(ur_get(sId).getAttribute("nav")=="true")
				o.title+=sSep+getLanguageText("SAPUR_CALNEXTMONTH_TUTOR");
			if(o.getAttribute("cl")=="true")
				o.title+=" "+getLanguageText("SAPUR_CALSEL_TUTOR");						
}
		else if(o.getAttribute("cl")=="true")
			o.title+=sSep+getLanguageText("SAPUR_CALSEL_TUTOR");
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_DateNavigator_getDateFromId
//* parameter   : sId  - Id of the DateNavigator control
//* return      :
//* description	: 
//* ------------------------------------------------------------------------
function sapUrMapi_DateNavigator_getDateFromId(sId){}
