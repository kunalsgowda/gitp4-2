//** DragSource.ie5 **
var _ur_DragDrop=null;
function ur_Drag_hideCursor() {
	if (_ur_DragDrop) {
   if (_ur_DragDrop.cursor) {
     _ur_DragDrop.cursor.style.display="none";
   }
  }
}
function ur_Drag_showCursor() {
	if (_ur_DragDrop) {
   if (_ur_DragDrop.cursor) {
     _ur_DragDrop.cursor.style.display="block";
   }
  }
}
function ur_Drag_progress(e) {
  if (_ur_DragDrop && _ur_DragDrop.progress) {
    var o=ur_EVT_src(e);
    _ur_DragDrop.isddoperation=true;
    var oChildContainer=sapUrMapi_isChildOfControl(o,"DRT");
    if (oChildContainer) {
	    if (_ur_DragDrop.target!=oChildContainer) {
	      _ur_DragDrop.target=oChildContainer;
	      ur_Drag_enter(_ur_DragDrop.target.id,e);
	    } else {
	      ur_Drag_over(_ur_DragDrop.target.id,e);
	    }
	    if (_ur_DragDrop.cursor!=_ur_DragDrop.drag) {
	      ur_Drag_hideCursor();
	      _ur_DragDrop.cursor=_ur_DragDrop.drag;
	    };
	  } else {
	    if (_ur_DragDrop.target) ur_Drag_leave(_ur_DragDrop.target.id,e);
	    _ur_DragDrop.target=null;
	    if (_ur_DragDrop.cursor!=_ur_DragDrop.nodrag) {
	      ur_Drag_hideCursor();
	      _ur_DragDrop.cursor=_ur_DragDrop.nodrag;
	    };
	  }
	  var oBody=document.getElementsByTagName("BODY")[0];
	  if (e.x>oBody.offsetWidth-26 ||e.y>oBody.offsetHeight-26 || e.x<0 || e.y<0) {
	    ur_Drag_hideCursor();
	  } else {
	  	if (ur_system.direction=="rtl") {
				iHorCorr = oBody.scrollLeft-sapUrMapi_posLeftCorrectionForRTL(oBody);
				_ur_DragDrop.cursor.style.top=e.clientY+14;
				_ur_DragDrop.cursor.style.left=e.clientX-5;
			} else {
				iHorCorr = oBody.scrollLeft;
				_ur_DragDrop.cursor.style.top=e.clientY+14;
				_ur_DragDrop.cursor.style.left=e.clientX+10;
			}
	    ur_Drag_showCursor();
	  }
    ur_EVT_fire(ur_get(_ur_DragDrop.source.id),"odrag",e);
  }
}
function ur_Drag_start(sId,e){
  if (!_ur_DragDrop) {
    _ur_DragDrop={cursor:null,drag:null,nodrag:null,progress:false,isddoperation:false};
    var o=document.createElement("IMG");
    o.src=ur_system.mimepath+"dragdrop/nodrop.gif";
		o.style.position="absolute";
	  o.style.display="none";
	  o.style.zIndex="1000";
	  _ur_DragDrop.nodrag=o;
	  document.body.appendChild(_ur_DragDrop.nodrag);
    var o=document.createElement("IMG");
    o.src=ur_system.mimepath+"dragdrop/drop.gif";
		o.style.position="absolute";
	  o.style.display="none";
	  o.style.zIndex="1000";
	  _ur_DragDrop.drag=o;
	  document.body.appendChild(_ur_DragDrop.drag);
	} 
	_ur_DragDrop.progress=true;
	_ur_DragDrop.source=sapUrMapi_isChildOfControl(ur_get(sId),"DRS");
	ur_get(sId).setCapture();
  ur_EVT_fire(ur_get(sId),"ods",e);
}

function ur_Drag_end(e){
	if (_ur_DragDrop && _ur_DragDrop.progress && _ur_DragDrop.isddoperation) {
    ur_Drag_hideCursor();
    if (_ur_DragDrop.target) ur_Drop(_ur_DragDrop.target.id,e);
	  ur_EVT_fire(_ur_DragDrop.source,"ode",e);
		_ur_DragDrop.source.releaseCapture();
		ur_Drag_hideCursor();
		_ur_DragDrop.source=null;
		_ur_DragDrop.target=null;
		_ur_DragDrop.isddoperation=false;
		_ur_DragDrop.progress=false;
  }
}
function ur_Drop(sId,e) {
	if (_ur_DragDrop && _ur_DragDrop.progress && _ur_DragDrop.isddoperation) {
		ur_EVT_fire(ur_get(sId),"odrop",e);
	}
}
function ur_Drag_enter(sId,e) {
	if (_ur_DragDrop && _ur_DragDrop.progress && _ur_DragDrop.isddoperation) {
	  ur_EVT_fire(ur_get(sId),"odenter",e);
	}
}
function ur_Drag_over(sId,e) {
	if (_ur_DragDrop && _ur_DragDrop.progress && _ur_DragDrop.isddoperation) {
	  ur_EVT_fire(ur_get(sId),"odo",e);
	}
}
function ur_Drag_leave(sId,e) {
	if (_ur_DragDrop && _ur_DragDrop.progress && _ur_DragDrop.isddoperation) {
  	ur_EVT_fire(ur_get(sId),"odl",e);
  }
}
