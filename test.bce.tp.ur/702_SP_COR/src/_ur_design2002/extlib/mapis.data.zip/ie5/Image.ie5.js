//* ************************************************************************
//* Image
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUr_Image_menuActivate
//* parameter   : sImageId - string - Id of the image
//*             : e - event object
//* description : triggers the menu open functions if there is a menu assigned to the image
//* return      :
//* ------------------------------------------------------------------------
function sapUrMapi_Image_menuActivate(sImageId,e) {
	oImage = ur_get(sImageId);
	if (sapUrMapi_checkKey(e,"keydown",new Array("32","40"))) {
		if (oImage.onclick) {oImage.onclick();ur_EVT_cancel(e);return false;} //trigger click
		if (oImage.oncontextmenu) {oImage.oncontextmenu();ur_EVT_cancel(e);return false;} //trigger contextmenu
		if (oImage.onmouseover) {oImage.onmouseover();return false;} //trigger onmouseover (hover)
	}
	return false;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Image_checkClick
//* parameter   : sId - string id of the image
//*             : e   - Event Object
//* return      : none
//* description	: checks if a button was triggered with keyboard or mouseclick
//* ------------------------------------------------------------------------
function sapUrMapi_Image_checkClick(sId, e) {
	if (e.type=="click") return true;
	return sapUrMapi_checkKey(e,"keydown",new Array("32"));
}

function sapUrMapi_Image_registerCreate(sId,MaxWidth,MaxHeight){
	if( MaxWidth =="" && MaxHeight =="") {
		return;
	}
	else {
		ur_Image_Create(sId,MaxWidth,MaxHeight);
	}
}
		
/*
* 
*/
function ur_Image_Create(sId, TargetWidth, TargetHeight) {

	TargetWidth = parseInt(TargetWidth);
	TargetHeight = parseInt(TargetHeight);
	
	if(isNaN(TargetWidth) || TargetWidth < 0) TargetWidth = 0;
	if(isNaN(TargetHeight) || TargetHeight < 0) TargetHeight = 0;
	
	var oLoadedImage = ur_get(sId);
	
	if (oLoadedImage == null) return;
	
	if (TargetWidth <= 0 && TargetHeight <= 0){ 
		ur_Image_showImg(oLoadedImage);
		  return;
		}		
	
	if (oLoadedImage.tagName == "SPAN") oLoadedImage = oLoadedImage.firstChild;
	
    var ActWidth = oLoadedImage.offsetWidth,
  		ActHeight = oLoadedImage.offsetHeight,
		PropHeight = ur_Image_getProportionlaSize(TargetWidth, ActWidth, ActHeight);
	
	
	if (PropHeight > TargetHeight) {
	  	oLoadedImage.style.height = TargetHeight;
	}
	
	else {
		oLoadedImage.style.width = TargetWidth;
		}
	
	ur_Image_showImg(oLoadedImage);
    }

/**
* 
TargetSize: The first dimension as width or height we know in pixels and that we want to apply
			  to the object as a change of its size. 

ActualSizeA: The actual first dimension as width or height. We get this dimension from the HTML. The known TargetSize is directly
			applied to this dimension
			
ActualSizeB: The actual second dimension as width or height. We get this dimension from the HTML. The function calculates the proportional 
			size of this second dimension on basis of the other three values.
*/

function ur_Image_getProportionlaSize(TargetSize, ActualSizeA, ActualSizeB ){
	return Math.floor( ActualSizeB * ( TargetSize / ActualSizeA ) );
}

//* ------------------------------------------------------------------------
//* function    : ur_Image_showImg
//* parameter   : obj - Image root Object
//*             : bVsbl - Boolean , if Visible or not
//* return      : none
//* description	: Util function. To prevent fliker during loading of image, the Image 
//*				  visibility is set to Hidden during rendering, only when AdjustImage is true
//*				  and after calculation of Width and Height, the Visibility is restored.	
//* ------------------------------------------------------------------------

function ur_Image_showImg(img) {

	var sVisibility = img.getAttribute("visibility");
	
	if (img == null || sVisibility == "BLANK") return;
	
	img.style.visibility ="visible";
	img.parentNode.style.overflow = "";
	img.parentNode.style.display = "inline-block"; 
	
	//avoids flickering rows in FF
	if (ur_system.browser_abbrev.indexOf("ie") > -1) {
		img.parentNode.style.height = "auto";
		img.parentNode.style.width = "auto";
	}
	
}
