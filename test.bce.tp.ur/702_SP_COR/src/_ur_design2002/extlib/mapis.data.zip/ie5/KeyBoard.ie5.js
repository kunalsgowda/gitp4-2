//this file will give generic functions for keyboard navigation

//enum for keycodes
ur_KY={RETURN:13,TAB:9,SPACE:32,DOWN:40,UP:38,PREV:ur_system.direction=="rtl"?39:37,NEXT:ur_system.direction=="rtl"?37:39,PGUP:33,PGDOWN:34,END:35,HOME:36}

//------------------------------------------------------
// keyboard navigation for item lists
//------------------------------------------------------


//------------------------------------------------------
// Structure of an item list
//------------------------------------------------------
//	itemlist object
//				ref			the reference	to the root dom object of the control
//								following attributes need to be stored on this object									
//								1. fidx - number - for the focused index
//								2. kb - string - for keyboard behavior "v" means vertical navigation "h" means horizontal.

//------------------------------------------------------

//* ------------------------------------------------------------------------
//* function    : ur_KY_nav
//* parameter   : oEvt the event object
//*							: o - itemlist where  o.ref is the controls dom and o.items is an array of items you navigating trough
//* return      : 
//*	description	: Generic handler of keyboard navigation on item list objects for non scrolling items
//*               o.ref.kb="v" turns on vertical movement, o.ref.kb="h" the horizontal
//* ------------------------------------------------------------------------
function ur_KY_nav(oEvt,o,resetId) {
  // check if keyboard was turned on for o
  var sMode=o.ref.getAttribute("kb"); 
	if (!sMode) return false;
	
	//check if there are o.items defined use the childnodes of the o.ref
	if (!o.items) o.items=o.ref.childNodes 
	
	//store the keycode
	var iKc=oEvt.keyCode 
	
	//check if the keycode is out of the range from 33 and 40 which are the arrowkeys, page up down and home and end.
	if (iKc<ur_KY.PGUP||iKc>ur_KY.DOWN) return false; 
	
	//get the old focused index (iFOIdx)
	var iFOIdx=parseInt(ur_getAttD(o.ref,"fidx","0")); 

	//calculate the new focused index (iFNIdx)
	var iFNIdx=iFOIdx;
	if (iKc==ur_KY.PGUP   || iKc==ur_KY.HOME) iFNIdx=0;
	else if (iKc==ur_KY.PGDOWN || iKc==ur_KY.END) iFNIdx=o.items.length-1;
	else if (((iKc==ur_KY.PREV && sMode.indexOf("h")>-1) || (iKc==ur_KY.UP && sMode.indexOf("v")>-1)) && iFOIdx>0) iFNIdx--;
	else if (((iKc==ur_KY.NEXT && sMode.indexOf("h")>-1) || (iKc==ur_KY.DOWN && sMode.indexOf("v")>-1)) && iFOIdx<o.items.length-1) iFNIdx++;
	//check if focus moved to a new element.
	if (iFNIdx!=iFOIdx) { 
	  //get the old focused index item
      var oItm=o.items[iFOIdx];
	  if(!(ur_system.is508) && ur_isSt(o.items[iFNIdx],ur_st.DISABLED)) return false; 
	  else
	  {   
		  //take away the focus from the actual element
		  sapUrMapi_setTabIndex(oItm,-1); 
		  var oItm=o.items[iFNIdx];
		  //set the focus item index in the root control
	      o.ref.setAttribute("fidx",iFNIdx);
		  //set the focus from the actual element
	      sapUrMapi_setTabIndex(oItm,0);
		  //set the focus
	      sapUrMapi_focusElement(oItm);
	      if (resetId) {
	    	var oReset = ur_get(resetId);
	      	oItm.setAttribute("resetId",resetId);
	      	if (oItm.attachEvent) {
	      		oItm.attachEvent("onblur",ur_KY_nav_blur);
	      	} else {
	      		oItm.addEventListener("blur",ur_KY_nav_blur,true);
	      	}
	      } 
	  }
	}
	return true;
}
function ur_KY_nav_blur(oEvt) {
	var oItm = ur_EVT_src(oEvt);
	if (oItm) {
	    sapUrMapi_setTabIndex(oItm,-1);
		var sResetId = oItm.getAttribute("resetId");
		var oReset = ur_get(sResetId);
		if (oReset) {
			setTimeout("ur_KY_reset('" + sResetId + "')",10);
		}      
	    if (oItm.detachEvent) {
	    	oItm.detachEvent("onblur",ur_KY_nav_blur);
	    } else {
	    	oItm.removeEventListener("blur",ur_KY_nav_blur,true);
	    }
	} 
}

function ur_KY_reset(resetId) {
	var oReset = ur_get(resetId);
	var oActiveElement = document.activeElement; 
	if (!oActiveElement || !sapUrMapi_DOM_bContains(oReset,oActiveElement)) {
		sapUrMapi_setTabIndex(oReset,0);
	}
}


