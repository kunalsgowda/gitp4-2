//** DataTip.ie5 **
var _ur_DataTip=new Object();
_ur_DataTip.hover=false;
_ur_DataTip.leave=false;
_ur_DataTip.label_leave=false;
_ur_DataTip.time_out=0;
function ur_Dt_mouseover(){
	clearTimeout(_ur_DataTip_timer);
	_ur_DataTip.hover=true;
}
function ur_Dt_mouseleave(){
	clearTimeout(_ur_DataTip_timer);
	_ur_DataTip.leave=true;
	var sId=oPopup.source.object.id.split("-")[0];
	sapUrMapi_DataTip_hide(sId);
}

var _ur_DataTip_timer;
function sapUrMapi_DataTip_getText(sId) {
	var oDTText = ur_get(sId+"-dtip");
	return oDTText.innerText;
}
enumUrDataTipType = {ERROR:"Error",WARNING:"Warning",OK:"Ok",TEXT:"Text"};
function sapUrMapi_DataTip_getType(sId) { 
	var oDTTyp  = ur_get(sId+"-dtip");
	oDTTyp = oDTTyp.firstChild.firstChild;
	if (typeof(oDTTyp.className)=="undefined")return enumUrDataTipType.TEXT;
	if ((oDTTyp.className).indexOf(enumUrDataTipType.ERROR)>-1) return enumUrDataTipType.ERROR;
	if ((oDTTyp.className).indexOf(enumUrDataTipType.WARNING)>-1) return enumUrDataTipType.WARNING;
	if ((oDTTyp.className).indexOf(enumUrDataTipType.OK)>-1) return enumUrDataTipType.OK;
	if ((oDTTyp.className).indexOf("urDataTipTxt")>-1) return enumUrDataTipType.TEXT;
  }
function sapUrMapi_DataTip_isOpen(sId){
	var oDT = ur_get(sId+"-dtip");
	if(oDT!=null)
	return (oDT.getAttribute("op")=="true");
}
function sapUrMapi_DataTip_show(sId,sEvtType) {
	var bShow=false;
	oDataTip = ur_get(sId+"-dtip");
	if (oDataTip==null) return;
	var bAf=((oDataTip.getAttribute("af")!=null) && (oDataTip.getAttribute("af")=="a"));
	var bAff=((oDataTip.getAttribute("af")!=null) && (oDataTip.getAttribute("af")=="f"));
	var iTo=0;
	if ((oDataTip.getAttribute("to")!=null) && (oDataTip.getAttribute("to")!="")) {
	  iTo=parseInt(oDataTip.getAttribute("to"));
	}
	if (typeof(sEvtType)=="undefined" || sEvtType=="") {
	  bShow=true;
	}
	if (sEvtType=="keydown") {
	  bShow=true;
	  iTo=0;
	}
	if (sEvtType=="focus") {
	  if (bAf) bShow=true;
	  if ((bAff) && (oDataTip.getAttribute("first")==null || oDataTip.getAttribute("first")=="")) {
	    bShow=true;
		oDataTip.setAttribute("first","true");
	  } else {
	    if (!bAf) iTo=0;
	  }
	}
	if(sEvtType=="mousemove"){
			bShow=true;
			iTo=0;
		}
	if(sEvtType=="mouseleave"){
			iTo=5;
		}
	if (bShow) {
		var oDT = ur_get(sId+"-dtip");
		oDT.open = oDT.setAttribute("op", "true");
		var arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
		sTriggerId=sId;
		oTrg=ur_get(sId);
		if (oTrg.tagName=="INPUT" && (oTrg.type.toLowerCase()=="radio" || oTrg.type.toLowerCase()=="checkbox")) {
		  oTrg=oTrg.nextSibling;
		}
		oPopup = new sapPopup(window,arrUrls,ur_get(sId+'-dtip'),oTrg,sEvtType,0);
		if (ur_system.direction=="rtl") oPopup.positionbehavior = sapPopupPositionBehavior.MENURIGHT;
		else sapPopupPositionBehavior.MENULEFT;	
		oPopup.show(true);
	}
	if (iTo>0) {
	 _ur_DataTip_timer = ur_callDelayed("sapUrMapi_DataTip_hide(\""+sId+"\")",iTo*1000);
	}
}
function sapUrMapi_DataTip_hide(sId) {
	var oDT = ur_get(sId+"-dtip");
	
	if(oDT==null) return;
	if(oDT.getAttribute("op")!="true") return; 
	clearTimeout(_ur_DataTip_timer);
	if (oPopup!=null) oPopup.hide();
 	oDT.setAttribute("op", "false");
}
