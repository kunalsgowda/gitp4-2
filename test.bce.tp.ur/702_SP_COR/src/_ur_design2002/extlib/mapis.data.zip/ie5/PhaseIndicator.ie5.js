function sapUrMapi_PhInPhaseSelect(sId,sPhaseId,bSelected,e){}

var arrValuesOfPhases = new Array();

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PhaseIndicator_create
//* parameter   : sId - string id of the PhaseIndicator
//* return      : none
//* description	: calls init function after createn of the phase indicator
//* ------------------------------------------------------------------------
function sapUrMapi_PhaseIndicator_create(sId){
	var o = ur_get(sId);
	var iItemSel = parseInt(o.getAttribute('sel'));
	if(document.getElementById(sId+"-itm-0")==null)return;
	if(isNaN(iItemSel))document.getElementById(sId+"-itm-0").tabIndex=0;
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_PhaseIndicator_init('"+sId+"')");
	}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PhaseIndicator_init
//* parameter   : sId - string id of the PhaseIndicator
//* return      : none
//* description	: initializes the PhaseIndicator by calculating widths
//* ------------------------------------------------------------------------
function sapUrMapi_PhaseIndicator_init(sId){
	var oVisblPhases = ur_get(sId);
	var iWidth = oVisblPhases.offsetWidth;
	if (iWidth>0) {
	  sapUrMapi_PhaseIndicator_setAllValues(sId);
	} else {
	 	return;
  }
  sapUrMapi_PhaseIndicator_draw(sId);
	//register with the resize handler
	sapUrMapi_Resize_AddItem(sId, "sapUrMapi_PhaseIndicator_draw('" + sId + "')");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PhaseIndicator_setAllValues
//* parameter   : sId - string id of the PhaseIndicator
//* return      : none
//* description	: initializes an internal array with states of the PhaseIndicator
//* ------------------------------------------------------------------------
function sapUrMapi_PhaseIndicator_setAllValues(sId){
		arrValuesOfPhases[sId] = new Array();
        var iItemCount = parseInt(ur_get(sId).getAttribute('ai'));
		for(var i = 0; i <= iItemCount; i++){
			arrValuesOfPhases[sId][i] = new Array();
			arrValuesOfPhases[sId][i][0] = sId + '-itm-' + i;
			arrValuesOfPhases[sId][i][1] = ur_get(sId + '-itm-' + i).offsetWidth;
		}
		arrValuesOfPhases[sId][iItemCount + 1] = new Array();
		done = true;
	}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PhaseIndicator_draw
//* parameter   : sId - string id of the PhaseIndicator
//* return      : none
//* description	: draws the PhaseIndicator
//* ------------------------------------------------------------------------
function sapUrMapi_PhaseIndicator_draw(sId) {
    var o=ur_get(sId);
	if (o == null) return;
	var iItemCount = parseInt(o.getAttribute('ai'));
	var iFirstIdxOld = parseInt(o.getAttribute('fv'));
	ur_get(sId + '-cnt-scrl').style.width = '1px';
	sapUrMapi_PhaseIndicator_make(sId,iFirstIdxOld,iItemCount);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PhaseIndicator_make
//* parameter   : sId - string id of whole control
//*               iStart - integer - start value for visible items
//*               iEnd - integer - end value for visible items
//*               sDir - string - direction for scrolling FURTHER and BACK
//* return      : none
//* description	: drows the proper amount of items in dependency to the availible space
//* ------------------------------------------------------------------------
function sapUrMapi_PhaseIndicator_make(sId,iStart,iEnd,sDir){
  var o=ur_get(sId);
	var iLastIdxOld = parseInt(o.getAttribute('lv'));
	var iFirstIdxOld = parseInt(o.getAttribute('fv'));
	var iAvailWdth = ur_get(sId + '-cnt').offsetWidth;
	var iItemCount = parseInt(o.getAttribute('ai'));
	var iVisblWdth = 0;
	var iFirstIdx = 0;
	var iLastIdx = 0;
	var ii=0;

	for(var i=0;i<=iItemCount;i++) {
	  arrValuesOfPhases[sId][i][2]=false;
	}
  //start<end dann -> Comp="<=" und Count="++"
  //start>end dann -> Comp=">=" und Count="--"
	if(sDir == 'FURTHER' || typeof(sDir)=="undefined"){
    for (i=iStart;i<=iEnd;i++) {
			if(iAvailWdth > 0 && iAvailWdth >= arrValuesOfPhases[sId][i][1]){
				arrValuesOfPhases[sId][i][2]=true;
				iAvailWdth = iAvailWdth - arrValuesOfPhases[sId][i][1];
				iVisblWdth = iVisblWdth + arrValuesOfPhases[sId][i][1];
			}else{
				break;
			}
		ii=i;
    }
	}
	if(sDir == 'BACK'){
    for (i=iStart;i>=iEnd;i--) {
			if(iAvailWdth > 0 && iAvailWdth >= arrValuesOfPhases[sId][i][1]){
				arrValuesOfPhases[sId][i][2]=true;
				iAvailWdth = iAvailWdth - arrValuesOfPhases[sId][i][1];
				iVisblWdth = iVisblWdth + arrValuesOfPhases[sId][i][1];
			}else{
				break;
			}
		  ii=i;
    }
  }
	if(ii == 0 && iAvailWdth > iVisblWdth && iAvailWdth >= arrValuesOfPhases[sId][iStart + 1][1]){
		iAvailWdth = ur_get(sId + '-cnt').offsetWidth;
		for(i = (iStart + 1); i<= iItemCount; i++){
				iVisblWdth = iVisblWdth + arrValuesOfPhases[sId][i][1];
			if(iAvailWdth >= iVisblWdth && iAvailWdth >= arrValuesOfPhases[sId][i][1]){
				arrValuesOfPhases[sId][i][2]=true;
				iStart = i;
			}else{
				break;
			}
		}
	}
	for(var i=0;i<=iItemCount;i++) {
	  if (arrValuesOfPhases[sId][i][2]==false) {
		  ur_get(arrValuesOfPhases[sId][i][0]).childNodes[0].style.display = "none";
	  } else {
		  ur_get(arrValuesOfPhases[sId][i][0]).childNodes[0].style.display = "block";
	  }
	}

	if(sDir == 'BACK'){
		ur_get(sId).setAttribute('fv',ii);
		ur_get(sId).setAttribute('lv',iStart);
		iFirstIdx = ii;
		iLastIdx = iStart;
	} else {
		ur_get(sId).setAttribute('fv',iStart);
		ur_get(sId).setAttribute('lv',ii);
		iFirstIdx = iStart;
		iLastIdx = ii;
	}
	var oLastIdx = ur_get(sId + '-itm-img-' + iLastIdx);
	if(iFirstIdx == 0 && iLastIdx != iItemCount && oLastIdx != null){
		ur_get(sId + '-cnt-scrl').style.width = iVisblWdth;
		if(!isNaN(iLastIdxOld) && iLastIdxOld != iItemCount){
			ur_get(sId + '-itm-img-' + iLastIdxOld).className = 'urPhInFurtherArrow';
			}
		ur_get(sId + '-p').style.display = 'none';
		ur_get(sId + '-itm-img-' + iLastIdx).className = 'urPhInMoreAfter';
	}
	if(iFirstIdx != 0 && iLastIdx != iItemCount){
		ur_get(sId + '-p').style.display = 'block';
		ur_get(sId + '-cnt-scrl').style.width = iVisblWdth;
		if(iLastIdxOld != iItemCount){
			if(!isNaN(iLastIdxOld)){
				ur_get(sId + '-itm-img-' + iLastIdxOld).className = 'urPhInFurtherArrow';
			}
		}
		if(iLastIdx!=null){
			ur_get(sId + '-itm-img-' + iLastIdx).className = 'urPhInMoreAfter';
		}
	}
	if(iFirstIdx != 0 && iLastIdx == iItemCount){
		ur_get(sId + '-p').style.display = 'block';
		ur_get(sId + '-cnt-scrl').style.width = iVisblWdth;
		if(!isNaN(iLastIdxOld) && iLastIdxOld != iItemCount){
			ur_get(sId + '-itm-img-' + iLastIdxOld).className = 'urPhInFurtherArrow';
		}
	}
	if(iFirstIdx == 0 && iLastIdx == iItemCount){
		ur_get(sId + '-cnt-scrl').style.width = iVisblWdth;
		ur_get(sId + '-p').style.display = 'none';
		if(!isNaN(iLastIdxOld) && iLastIdxOld != iItemCount){
			ur_get(sId + '-itm-img-' + iLastIdxOld).className = 'urPhInFurtherArrow';
		}
	}
	ur_get(sId + '-cnt-scrl').scrollLeft = 0;
	sapUrMapi_PhaseIndicator_setPagingButtons(sId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PhaseIndicator_paging
//* parameter   : sId - string id of the PhaseIndicator
//*             : sDir - string - Direction to be paged to -FURTHER or BACK
//* return      : none
//* description	: Pages the Items of the Phase Indicator
//* ------------------------------------------------------------------------
function sapUrMapi_PhaseIndicator_paging(sId,sDir){
	var iItemCount = parseInt(ur_get(sId).getAttribute('ai'));
	var iFirstIdxOld = parseInt(ur_get(sId).getAttribute('fv'));
	var iLastIdxOld = parseInt(ur_get(sId).getAttribute('lv'));
		if(sDir == 'FURTHER'){
				iFirstIdxOld = iLastIdxOld + 1;
				sapUrMapi_PhaseIndicator_make(sId,iFirstIdxOld,iItemCount,sDir);
		} else if(sDir== 'BACK'){
			iLastIdxOld = iFirstIdxOld - 1;
			if(iLastIdxOld != 0){
				sapUrMapi_PhaseIndicator_make(sId,iLastIdxOld,0,sDir);
				}else{
					ur_get(sId).setAttribute('fv',0);
					sapUrMapi_PhaseIndicator_draw(sId);
				}
		} else {
		  	iLastIdxOld = parseInt(sDir.substring(sDir.lastIndexOf("-")+1));
				ur_get(sId).setAttribute('fv',iLastIdxOld);
				sapUrMapi_PhaseIndicator_draw(sId);
			}
	}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PhaseIndicator_setPagingButtons
//* parameter   : sId - string id of the PhaseIndicator
//*             : sDIr - string - Direction to be paged to -FURTHER or BACK
//* return      : none
//* description	: Pages the Items of the Phase Indicator
//* ------------------------------------------------------------------------
function sapUrMapi_PhaseIndicator_setPagingButtons(sId){
	var iItemCount = parseInt(ur_get(sId).getAttribute('ai'));
	if(ur_get(sId+"-pag").hasChildNodes()){
		sPagerId = ur_get(sId+"-pag").childNodes.item(0).id;
		var arrButtonArray = new Array();
		arrButtonArray[0]=UR_PAGINATOR_BUTTON.PREVIOUS_ITEM;
		arrButtonArray[1]=UR_PAGINATOR_BUTTON.NEXT_ITEM;
		var arrStateArray = new Array();
		arrStateArray[0]=true; //einschalten
		arrStateArray[1]=true; //ausschalten
		var iFirstIdxOld = parseInt(ur_get(sId).getAttribute('fv'));
		var iLastIdxOld = parseInt(ur_get(sId).getAttribute('lv'));
		if(iFirstIdxOld == 0){
				arrStateArray[0]=false; //back ausschalten
		}
		if(iLastIdxOld == iItemCount || isNaN(iLastIdxOld)){
				arrStateArray[1]=false; //further ausschalten
		}
		sapUrMapi_Paginator_setStates(sPagerId,arrButtonArray,arrStateArray);
	} else {
	  return;
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PhaseIndicator_keydownStep
//* parameter   : sId - string Id of the PhaseIndicator
//*             : e   - Event Object
//* return      : none
//*	description	: Navigates over items
//* ------------------------------------------------------------------------
function sapUrMapi_PhaseIndicator_keydownStep(sId,sItemIdx,bSel,e){
	var oItm=ur_get(sId+"-itm-"+sItemIdx);
	var oPrev=null;
	var oNext=null;
	
	if(ur_system.direction!="rtl"){
		oPrev=oItm.previousSibling;
		oNext = oItm.nextSibling;
	  } else {
		oNext=oItm.previousSibling;
		oPrev = oItm.nextSibling;
	  }
	
	if(e.keyCode == 39 && oNext!=null) {
		 ur_PhIn_setFocus(oNext,oItm);
	    }
	else if(e.keyCode == 37 && oPrev!=null){
		ur_PhIn_setFocus(oPrev,oItm);
	  }
	else if(e.keyCode==9){
		var oPhIn = ur_get(sId);
		var iSel = oPhIn.getAttribute("sel");
		if(iSel==null)iSel=0;
		var oSel = ur_get(sId+"-itm-"+iSel);
		ur_PhIn_setFocus(oSel,oItm);
	   }
	else if(e.keyCode==32){
		oItm = oItm.getElementsByTagName("TD")[0];
		if (oItm.id.indexOf("start")>-1) oItm = oItm.nextSibling;
		oItm.click();
	}
	//ur_EVT_cancelBubble(e);
}
function ur_PhIn_setFocus(oNew,oOld){
		sapUrMapi_setTabIndex(oOld,-1);
		sapUrMapi_setTabIndex(oNew,0);
		ur_focus(oNew);
}
//*------------------------------------------------------------------------
//* function    : sapUrMapi_PhaseIndicator_getFirstVisible
//* parameter   : o - called phaseindicator object 
//* return      : id of first visible phase
//* description	: used by enrich parameter function
//* ------------------------------------------------------------------------
function sapUrMapi_PhaseIndicator_getFirstVisible(o){
	return o.getAttribute("fv");
}
