//TOOLBAR
function sapUrMapi_Toolbar_toggleItems(sControlId,e) {
  if((e.type == "keydown" && e.keyCode==32) || e.type == "click") {
	  var oToggleButton = ur_get(sControlId+"-tgl");
	  var oToolbar = ur_get(sControlId);
	  var colItems = oToolbar.childNodes;
		ur_EVT_cancel(e);
	  var bShowAllState = oToggleButton.getAttribute("showall")=="true";
	  for (var n=0;n<colItems.length;n++) {
		var oItem=colItems.item(n);
		if (oItem.nodeType!=3) {
			if (oItem.getAttribute("cancollapse")=="true") {
			  if (bShowAllState) {
				  oItem.style.display="none";
				  oItem.setAttribute("show","false");
		      } else {
			  oItem.style.display="inline";
				  oItem.setAttribute("show","true");
			}
		    }
		  }
	    if (oItem==oToggleButton) break;
		}
	  if (bShowAllState) {
	    oToggleButton.setAttribute("showall","false");
	    oToggleButton.className="urBtnStd urTBtnCol";
	    oToggleButton.title=getLanguageText("SAPUR_T_BTN_E");
	    if(ur_system.is508)
				oToggleButton.setAttribute("t",getLanguageText("SAPUR_T_BTN_E"));
	  } else {
	    oToggleButton.setAttribute("showall","true");
	    oToggleButton.className="urBtnStd urTBtnExp";
	    oToggleButton.title=getLanguageText("SAPUR_T_BTN_C");
	    if(ur_system.is508)
				oToggleButton.setAttribute("t",getLanguageText("SAPUR_T_BTN_C"));

	  }
	  sapUrMapi_Focus_showFocusRect(oToggleButton.id);
	}
	else {
		return;
	}
}

