//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Label_setDisabled
//* parameter   : oLbl - label object
//*	description	: sets a label disabled
//* ------------------------------------------------------------------------
function sapUrMapi_Label_setDisabled(oLbl) {
	if(oLbl==null || oLbl.className.indexOf("Dsbl")>-1) return;
	if(oLbl.className.indexOf("Bar")>-1)
		oLbl.className=oLbl.className.replace("LBar","LBarDsbl");
	else
		oLbl.className=oLbl.className.replace("L","LDsbl");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Label_setEnabled
//* parameter   : oLbl - label object
//*	description	: sets a disabled label enabled
//* ------------------------------------------------------------------------
function sapUrMapi_Label_setEnabled(oLbl) {
	if (oLbl==null) return;
	oLbl.className=oLbl.className.replace("Dsbl","");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Label_setInvalid
//* parameter   : oLbl - label object
//*               bSet - if true set the label invalid else valid
//*	description	: sets a label invalid or valid
//* ------------------------------------------------------------------------
function sapUrMapi_Label_setInvalid(oLbl,bSet) {
	if (oLbl==null) return;
	// reset invalid
	if(!bSet){
		oLbl.className=oLbl.className.replace("Inv","");
		return;
	}
	// set invalid
	if(oLbl.className.indexOf("Inv")>-1) return;
	if (oLbl.className.indexOf("Bar")>-1) 
		oLbl.className=oLbl.className.replace("Bar","BarInv");
	else
		oLbl.className+="Inv";
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Label_getInputLabel
//* parameter   :	sId - id of an input element (checkbox, radiobutton, inputfield, ddlb, ...)
//* description : looks for an associated label for a given input element with sId
//* return      : label element of the input field if any, else null
//* ------------------------------------------------------------------------
function sapUrMapi_Label_getInputLabel(sId) {
	var ur_arrLabels = document.getElementsByTagName("LABEL");
	for (var i=0;i<ur_arrLabels.length;i++) {
		if (ur_arrLabels.item(i).getAttribute("f")==sId) {
			return ur_arrLabels.item(i);
		}
	}
	for (var i=0;i<ur_arrLabels.length;i++) {
		if (ur_arrLabels.item(i).getAttribute("htmlFor")==sId) {
			return ur_arrLabels.item(i);
		}
	}
	return null;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Label_FocusLabeledElement
//* parameter   :	sForId - id of the labeled control
//* description : focus the labeled control
//* return      : -
//* ------------------------------------------------------------------------
function sapUrMapi_Label_FocusLabeledElement(sForId) {
  sapUrMapi_focusElement(sForId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Label_getLabelText
//* parameter   :	sId - string - id of an input element (checkbox, radiobutton, inputfield, ddlb)
//* description : gets the text of the associated label
//* return      : label text
//* ------------------------------------------------------------------------
function sapUrMapi_Label_getLabelText(sId) {
	var oLbl=sapUrMapi_Label_getInputLabel(sId);
	if(oLbl==null) return null;
	var sTxt=oLbl.getAttribute("lbl");
	if(sTxt==null || sTxt=="")
		sTxt=oLbl.innerText;
	if(sTxt.lastIndexOf(" *")>-1 && sTxt.lastIndexOf(" *")==sTxt.length-2)
		sTxt=sTxt.substring(0,sTxt.lastIndexOf(" *"));	
	if(sTxt.lastIndexOf(":")>-1 && sTxt.lastIndexOf(":")==sTxt.length-1)
		sTxt=sTxt.substring(0,sTxt.lastIndexOf(":"));
	return sTxt;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Label_clickLabeledElement
//* parameter   :	sForId - labeled control
//* description : click control the label is associated to
//* return      : -
//* ------------------------------------------------------------------------
function sapUrMapi_Label_clickLabeledElement(sForId) {
	var o=ur_get(sForId);
	try{
	  var sCt=o.getAttribute("ct");
		if(sCt=="C" || sCt=="R" || sCt=="TRI") ur_get(sForId +"-r").click();
		else ur_focus(o);
	} catch(e){}
}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Label_getAssociatedElement
//* parameter   :	sId - id of the label
//* description : focus the labeled control
//* return      : -
//* ------------------------------------------------------------------------
function ur_L_getF(sId){
  sF=ur_get(sId).f;
  return sF;
}
//* ------------------------------------------------------------------------
//* function    : ur_L_mm (Label Mouse Move)
//* parameter   : sId - id of the control the data tip is connected with
//*								oEvt - event object
//* description : Shows help(explanation), when showHelp flag of control is turned on
//* return      : -
//* ------------------------------------------------------------------------
function ur_L_mm(sId,oEvt){
	clearTimeout(_ur_DataTip_timer);
	if(typeof(sId)== "object"){
		oEvt = sId;
		sId = oEvt.srcElement.getAttribute("id");
	}
	var o=ur_get(sId);
	
	if(!o) return;
	
	var sCt=o.getAttribute("ct");
	if(ur_EVT_src(oEvt).className=="urHlpTHFont")
		_ur_DataTip.time_out=70;
	else
		_ur_DataTip.time_out=0;
	if(sCt=="L")sId=ur_L_getF(sId);
	if(sapUrMapi_DataTip_isOpen(sId)==false)
		_ur_DataTip_timer=ur_callDelayed("sapUrMapi_DataTip_show('"+sId+"','mousemove')",500);
}
//* ------------------------------------------------------------------------
//* function    : ur_L_ml (Label Mouse Leave)
//* parameter   :  sId - id of the control the data tip is connected with
//*								oEvt - event object
//* description : Hides help(explanation), when showHelp flag of control is turned on
//* return      : -
//* ------------------------------------------------------------------------
function ur_L_ml(sId,oEvt){
	clearTimeout(_ur_DataTip_timer);
	if(typeof(sId)== "object"){
		oEvt = sId;
		sId = oEvt.srcElement.getAttribute("id");
	}
	var o=ur_get(sId);
	
	if(!o) return;
	
	var oInput = null;
	var sCt=o.getAttribute("ct");
	if(sCt=="L"){
		sId=ur_L_getF(sId);
		oInput = ur_get(sId+"-r");
		
		if(oInput.getAttribute("evt")==null){
		  oInput.attachEvent("onmouseover",ur_L_mm);
		  oInput.attachEvent("onmouseout",ur_L_ml);
		  oInput.setAttribute("evt","true");
		}
	}
	
	if(oPopup){
		_ur_DataTip_timer = ur_callDelayed("sapUrMapi_DataTip_hide(\""+sId+"\")",_ur_DataTip.time_out);
	}
}
