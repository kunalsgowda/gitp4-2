
function sapUrMapi_GeoMap_keydown(sId, oEvt){
	var o=ur_get(sId);
	var oBtn=null;
 	var iKey=oEvt.keyCode;
	
	if(o==null) return;
	
 	if(ur_system.direction=="rtl" && iKey==37) iKey=39;
 	else if(ur_system.direction=="rtl" && iKey==39) iKey=37;

	if(iKey==107)
		oBtn=ur_GeoMap_getImage("ZIN",o);
	else if(iKey==109)
		oBtn=ur_GeoMap_getImage("ZOUT",o);
	else if(iKey==38)
		oBtn=ur_GeoMap_getImage("N",o);
	else if(iKey==39)
		oBtn=ur_GeoMap_getImage("E",o);
	else if(iKey==40)
		oBtn=ur_GeoMap_getImage("S",o);
	else if(iKey==37)
		oBtn=ur_GeoMap_getImage("W",o);
		
	if(oBtn!=null){
		oBtn.click();
		return;
	}
	
	return sapUrMapi_skip(sId,oEvt);
}

function ur_GeoMap_getImage(sType,o){
	var a=o.getElementsByTagName("IMG");

	for(var i=0; i<a.length; i++){
		if(a[i].getAttribute("tp")==sType)
			return a[i];
	}
	a=o.getElementsByTagName("A");
	for(var i=0; i<a.length; i++){
		if(a[i].getAttribute("tp")==sType)
			return a[i];
	}

	return null;
}