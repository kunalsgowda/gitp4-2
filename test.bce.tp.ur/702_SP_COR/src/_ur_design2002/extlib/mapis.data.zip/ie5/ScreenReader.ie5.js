/* attach activate event for screen reader support */
document.attachEvent("onactivate", ur_SCR_activate);

/* control types/sub types for which screen reader support is available */
//ur_type={ActiveXContainer:"AX",ActiveXContainer_End:"AX_END",AppletContainer:"AP",AppletContainer_End:"AP_END",Button:"B",Button_Menu:"B_MNU",Button_MenuSection:"B_MNUSEC",Button_Toggle:"B_TG",BreadCrumb:"BRC",BreadCrumb_Item:"BRC_I",BreadCrumb_SingleLink:"BRC_SL",CheckBox:"C",ComboBox:"CB",ComboBox_DropDownListBox:"CB_DD",CheckBoxGroup:"CG",CheckBoxGroup_End:"CG_END",Caption:"CP",ContextualPanel:"CXP",ContextualPanel_Help:"CXP_H",ContextualPanel_Personalize:"CXP_P",ContextualPanel_End:"CXP_END",DateNavigator:"DN",DateNavigator_Month:"DN_MONTH",DateNavigator_Day:"DN_DAY",DateNavigator_Week:"DN_WEEK",DateNavigator_End:"DN_END",FileUpload:"FU",FreeArea:"FRA",FreeArea_Personalize:"FRA_P",FreeArea_End:"FRA_END",GeoMap:"GM",GeoMap_Button:"GM_BTN",GeoMap_Image:"GM_IMG",GeoMap_End:"GM_END",GeoMap_ZoomIn:"GM_ZIN",GeoMap_ZoomOut:"GM_ZOUT",Group:"G",Group_End:"G_END",InputField:"I",Iframe:"IF",Iframe_End:"IF_END",ItemList:"IL",ItemListBoxSingle:"ILBS",ItemListBoxSingle_Item:"ILBS_I",ItemListBoxMultiple:"ILBM",ItemListBoxMultiple_Item:"ILBM_I",Image:"IMG",Invisible:"INV",InputTokenizer:"IT",InputTokenList:"ITL",Label:"L",Legend:"LEG",LegendDateNavigatorItem:"LEGDI",LegendTableItem:"LEGTI",Link:"LN",ListBox:"LB",LoadingAnimation:"LA",MatrixLayout:"ML",MenuBar:"MNB",MenuBar_Item:"MNB_I",MessageBar:"MB",MessageBar_Link:"MB_LNK",NavigationList:"NL",NavigationList_Item:"NL_I",NavigationList_Group:"NL_G",NavigationList_Personalize:"NL_P",NavigationList_End:"NL_END",PageHeader:"PH",PageHeaderEnd:"PH_END",Paginator:"PG",Paginator_Button:"PG_B",Paginator_InputField:"PG_I",Paginator_Menu:"PG_MNU",PatternContainerContentItem:"PC",PatternContainerIconButton:"PCI",PatternContainerIconButton_Collapse:"PCI_C",PatternContainerIconButton_Expand:"PCI_E",PatternContainerIconButton_Min:"PCI_M",PatternContainerTab:"PCTAB",PatternContainerTab_Item:"PCTAB_I",PatternContainerTab_End:"PCTAB_END",PatternContainerTab_Menu:"PCTAB_MNU",PatternContainerTitle:"PCTIT",PatternContainerTitle_End:"PCTIT_END",PatternContainerTitle_Menu:"PCTIT_MNU",PatternContainerSequence:"PCSEQ",PatternContainerSequence_Item:"PCSEQ_I",PatternContainerSequence_End:"PCSEQ_END",PatternContainerSequence_Menu:"PCSEQ_MNU",PhaseIndicator:"PHI",PhaseIndicator_Step:"PHI_STN",PopIn:"PI",PopIn_CloseButton:"PI_CLB",PopIn_End:"PI_END",PopupMenu_Item:"POMN_I",PopupMenu_SubMenu:"POMN_ISMNU",PopupTrigger:"POTRG",ProgressIndicator:"PRI",RadioButton:"R",RadioButtonGroup:"RG",RadioButtonGroup_End:"RG_END",RasterLayout:"RL",RatingIndicator:"RI",RoadMap:"RM",RoadMap_RoundTripStep:"RM_SUB",RoadMap_Step:"RM_STN",RoadMap_RoundtripClosed:"RM_RTCLO",RoadMap_RoundtripStart:"RM_RTSTR",RoadMap_RoundtripEnd:"RM_RTEND",ScrollContainer:"SC",ScrollContainer_End:"SC_END",SapTable:"ST",SapTable_Header1:"ST_HDR1",SapTable_Header2:"ST_HDR2",SapTable_Header3:"ST_HDR3",SapTable_SortButtonAsc:"ST_SRTBTNA",SapTable_SortButtonDesc:"ST_SRTBTND",SapTable_SelectionCell:"ST_SC",SapTable_SelectionColumn:"ST_SCOL",SapTable_SelectionMenu:"ST_SMNU",SapTable_FilterButton:"ST_FBTN",SapTable_End:"ST_END",SapTable_Cell:"ST_C",SapTable_EmptyRowCell:"ST_ER",SelectableLinkBar:"SLB",SingleColumnLayout:"SL",TableView:"TBV",TabStrip:"TS",TabstripItem:"TSITM",TextBar:"TXB",TextEdit:"TE",TextView:"TV",ToggleLink:"TGL",Toolbar:"T",Toolbar_ToggleButton:"T_BTN",Toolbar_End:"T_END",ToolbarInputField:"TI",ToolbarLink:"TLN",Tray:"TY",Tray_Button:"TY_BTN",Tray_Menu:"TY_MNU",Tray_End:"TY_END",Tree:"TR",Tree_Folder:"TR_F",Tree_Leaf:"TR_L",TriStateCheckBox:"TRI",ValueComparison:"VC",ViewSwitch:"VS"};

/* Containers */
var _ur_cnt=new Array();
_ur_cnt[ur_type.Group]="";
_ur_cnt[ur_type.PopupTrigger]="";
_ur_cnt[ur_type.SapTable]="";
_ur_cnt[ur_type.SapTableCell]="";
_ur_cnt[ur_type.TableView]="";
_ur_cnt[ur_type.TabStrip]="";
_ur_cnt[ur_type.Toolbar]="";
_ur_cnt[ur_type.Tray]="";

/* 
Definition of the use speech output fragments for the supported control types and subtypes.
The following abbreviations are used for the text fragments:
lbl:	Label
rt:		Text or accessibility description of the root control/container
rct:	Control type of the root control/container
rst:	State of the root control/container
rtt:	Tool tip of the root control/container
rtut: Tutor text for the root control container
t:		Text or accessibility description of the focused control
ct:		Control type of the focused control, the control type can be build from the root control type and a sub type
v:		Value of the control
st:		State of the control
s:		semantic information (color or design)
pos:	Position information for an item of a control
lvl:	Level information
tt:		Tool tip of the focused control
tbl:	Table information, if the control is used in a table cell
tut:	Tutor information of the focused control
ctx:	Tutor text how to open a context menu if a context menu is available for an object
dt:		Data tip
*/
var _ur_SCR=new Array();

_ur_SCR[ur_type.ActiveXContainer]					={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.ActiveXContainer_End]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.AppletContainer]					={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.AppletContainer_End]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.Button]										={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:1,ico:0}; 
_ur_SCR[ur_type.Button_MenuSection]				={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_B_MNU",v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:1,ico:0}; 
_ur_SCR[ur_type.Button_Menu]							={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:"SAPUR_MENU_TUT",ctx:0,dt:1,ico:0}; 
_ur_SCR[ur_type.Button_Toggle]						={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_B",v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:1,ico:0}; 

_ur_SCR[ur_type.BreadCrumb_Item]					={lbl:0,rt:0,rct:1,rst:1,rtt:1,rtut:"SAPUR_LRNAV_TUT",t:1,ct:0,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};  
_ur_SCR[ur_type.BreadCrumb_SingleLink]		={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	

_ur_SCR[ur_type.CheckBox]									={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:1,ico:0};

_ur_SCR[ur_type.ComboBox]									={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:1,st:1,s:0,pos:1,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.ComboBox_DropDownListBox]	={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:1,st:1,s:0,pos:1,lvl:0,tt:1,tbl:1,tut:"SAPUR_CB_TUT",ctx:0,dt:0,ico:0};	

_ur_SCR[ur_type.CheckBoxGroup]						={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.CheckBoxGroup_End]				={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.Caption]									={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:0,ctx:0,dt:1,ico:0};	

_ur_SCR[ur_type.ContextualPanel]					  ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.ContextualPanel_Help]				={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_LN",v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_LN_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.ContextualPanel_Personalize]={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_LN",v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_LN_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.ContextualPanel_End]				={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.DateNavigator]						={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};   
_ur_SCR[ur_type.DateNavigator_Month]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};   
_ur_SCR[ur_type.DateNavigator_Week]				={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};  
_ur_SCR[ur_type.DateNavigator_Day]				={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:0,v:0,st:0,s:1,pos:0,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:0,ico:0};   
_ur_SCR[ur_type.DateNavigator_End]				={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};   

_ur_SCR[ur_type.FileUpload]								={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:1,st:1,s:0,pos:1,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.FreeArea]									={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_G",v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.FreeArea_Personalize]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_LN",v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_LN_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.FreeArea_End]							={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:"SAPUR_G_END",v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.FormattedTextView]				={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:0,ctx:0,dt:0,ico:0};	

_ur_SCR[ur_type.GeoMap]										={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.GeoMap_Button]						={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_B",v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_B_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.GeoMap_Image]							={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.GeoMap_End]								={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.GeoMap_ZoomIn]						={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_B",v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_B_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.GeoMap_ZoomOut]						={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_B",v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_B_TUT",ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.Group]										={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.Group_End]								={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};	

_ur_SCR[ur_type.HorizontalContextualPanel]	={lbl:0,rt:0,rct:"SAPUR_TS",rst:0,rtt:1,rtut:"SAPUR_ITEMGROUP_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.HorizontalContextualPanel_MenuItem]	={lbl:0,rt:0,rct:1,rst:0,rtt:0,rtut:"SAPUR_ITEMGROUP_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.InputField]								={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:1,st:1,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:1,ico:0};	

_ur_SCR[ur_type.InputTokenizer]						={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:1,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.Iframe]										={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.Iframe_End]								={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.ItemList]									={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:1,st:1,s:0,pos:1,lvl:0,tt:1,tbl:1,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.ItemListBoxSingle]				={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:1};	
_ur_SCR[ur_type.ItemListBoxSingle_Item]		={lbl:1,rt:0,rct:1,rst:1,rtt:1,rtut:"SAPUR_UDNAV_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:1,ico:1};	
_ur_SCR[ur_type.ItemListBoxMultiple]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:1};	
_ur_SCR[ur_type.ItemListBoxMultiple_Item]	={lbl:1,rt:0,rct:1,rst:1,rtt:1,rtut:"SAPUR_UDNAV_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:1,ico:1};

_ur_SCR[ur_type.Image]										={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:"SAPUR_SELECT_TUT",ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.Label]				={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:0,v:0,st:1,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0}; 

_ur_SCR[ur_type.Link]											={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.MenuBar]									={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.MenuBar_Item]							={lbl:0,rt:0,rct:0,rst:0,rtt:1,rtut:1,t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.MenuBar_End]								={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};	

_ur_SCR[ur_type.MessageBar]								={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:0,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:0,ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.MessageBar_Link]					={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:0,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.NavigationList]		 	={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.NavigationList_Group]	={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.NavigationList_Item]	={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.NavigationList_Personalize]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_LN",v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_LN_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.NavigationList_End]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.PageHeader]								={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.PageHeaderEnd]						={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.Paginator]								={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,dt:0,ico:0};
_ur_SCR[ur_type.Paginator_Button]					={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_B",v:0,st:1,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_B_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.Paginator_InputField]			={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_I",v:1,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:0,dt:0,ico:0};
_ur_SCR[ur_type.Paginator_Menu]						={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_MENUSPACE_TUT",ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.PatternContainerIconButton]					={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.PatternContainerIconButton_Expand]	={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.PatternContainerIconButton_Collapse]={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.PatternContainerIconButton_Min]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	

_ur_SCR[ur_type.PatternContainerTab]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.PatternContainerTab_Item]	={lbl:0,rt:1,rct:1,rst:0,rtt:1,rtut:"SAPUR_ITEMGROUP_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.PatternContainerTab_End]	={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:0,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.PatternContainerTab_Menu]	={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_PCTIT_MNU",ctx:0,dt:0,ico:0};	

_ur_SCR[ur_type.PatternContainerTitle]		={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.PatternContainerTitle_End]={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.PatternContainerTitle_Menu]={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:1,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.PatternContainerSequence]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.PatternContainerSequence_Item]={lbl:0,rt:1,rct:1,rst:0,rtt:1,rtut:"SAPUR_ITEMGROUP_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.PatternContainerSequence_End]	={lbl:0,rt:1,rct:1,rst:0,rtt:0,rtut:1,t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.PatternContainerSequence_Menu]={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:1,ctx:0,dt:0,ico:0};	

_ur_SCR[ur_type.PhaseIndicator]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0}; 
_ur_SCR[ur_type.PhaseIndicator_Step]	={lbl:0,rt:1,rct:1,rst:0,rtt:1,rtut:"SAPUR_LRNAV_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:"SAPUR_SELECT_TUT",ctx:0,dt:0,ico:0};	

_ur_SCR[ur_type.PopIn]										={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.PopIn_CloseButton]				={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_B",v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_B_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.PopIn_End]								={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.PopupTrigger]							={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.PopupMenu_Item]						={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:"SAPUR_NL_I_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:0,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.PopupMenu_SubMenu]				={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:"SAPUR_NL_I_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:0,tbl:0,tut:1,ctx:0,dt:0,ico:0};	

_ur_SCR[ur_type.ProgressIndicator]			={lbl:1,rt:0,rct:1,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:1,pos:0,lvl:0,tt:1,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.RadioButton]							={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:1,ico:0};

_ur_SCR[ur_type.RadioButtonGroup]					={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.RadioButtonGroup_End]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.RichTextEdit] = {lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_TE",v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.RoadMap]									={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0}; 
_ur_SCR[ur_type.RoadMap_Step]							={lbl:0,rt:1,rct:1,rst:0,rtt:1,rtut:"SAPUR_LRNAV_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.RoadMap_RoundtripClosed]	={lbl:0,rt:1,rct:1,rst:0,rtt:1,rtut:"SAPUR_LRNAV_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.RoadMap_RoundtripStart]		={lbl:0,rt:1,rct:1,rst:0,rtt:1,rtut:"SAPUR_LRNAV_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.RoadMap_RoundtripEnd]			={lbl:0,rt:1,rct:1,rst:0,rtt:1,rtut:"SAPUR_LRNAV_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.RoadMap_RoundTripStep]	={lbl:0,rt:1,rct:1,rst:0,rtt:1,rtut:"SAPUR_LRNAV_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	

_ur_SCR[ur_type.ScrollContainer]					={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_G",v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.ScrollContainer_End]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:"SAPUR_G_END",v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.SapTable]									={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.SapTable_SortButtonAsc]		={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_B_TUT",ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.SapTable_SortButtonDesc]	={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_B_TUT",ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.SapTable_SelectionColumn]	={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:0,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.SapTable_SelectionMenu]		={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_MENUSPACE_TUT",ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.SapTable_FilterButton]		={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR[ur_type.SapTable_End]							={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.SapTable_Cell]						={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:1,tut:0,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.SapTable_EmptyRowCell]		={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.SapTable_Header1]					={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.SapTable_Header2]					={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.SapTable_Header3]					={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.SapTable_SelectionCell]		={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:1,ctx:0,dt:0,ico:0};	

_ur_SCR[ur_type.Toolbar]									={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.Toolbar_End]							={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.Toolbar_ToggleButton]			={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_B",v:0,st:1,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:"SAPUR_B_TUT",ctx:0,dt:0,ico:0};

/* table view */
_ur_SCR["TBV"]			 ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:"SAPUR_GROUP_TUT",ctx:0,dt:0,ico:0};
_ur_SCR["TBV_END"]		 ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};
_ur_SCR["TBV_HC"]		 ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR["TBV_SC"]		 ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR["TBV_MNU"]		 ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR["TBV_TOPBTN"]	 ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR["TBV_PRVPG"]	 ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR["TBV_PRVROW"]	 ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR["TBV_NXTROW"]	 ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR["TBV_NXTPG"]	 ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR["TBV_BOTBTN"]	 ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};
_ur_SCR["TBV_INDICATOR"] ={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR["TE"]		={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.ToggleLink]		={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:"SAPUR_LN_TUT",ctx:0,dt:0,ico:0};

_ur_SCR["TI"]		={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.ToolbarLink]		={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_LN",v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_LN_TUT",ctx:0,dt:0,ico:0};

_ur_SCR[ur_type.Tree_Folder]	={lbl:0,rt:1,rct:1,rst:0,rtt:1,rtut:1,t:1,ct:0,v:0,st:1,s:0,pos:1,lvl:1,tt:1,tbl:0,tut:1,ctx:1,dt:0,ico:0};
_ur_SCR[ur_type.Tree_Leaf]		={lbl:0,rt:1,rct:1,rst:0,rtt:1,rtut:1,t:1,ct:0,v:0,st:1,s:0,pos:1,lvl:1,tt:1,tbl:0,tut:1,ctx:1,dt:0,ico:0};

_ur_SCR["TRI"]		={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:0,ico:0};

/* tab strip */
_ur_SCR["TS"]		={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:0,v:0,st:1,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};	
_ur_SCR["TS_END"]	={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};	
_ur_SCR["TS_ITM"]	={lbl:0,rt:1,rct:1,rst:1,rtt:1,rtut:"SAPUR_ITEMGROUP_TUT",t:1,ct:1,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	//Tab

_ur_SCR[ur_type.TextView]		={lbl:1,rt:1,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:0,v:0,st:1,s:1,pos:0,lvl:0,tt:1,tbl:1,tut:1,ctx:0,dt:0,ico:0};

_ur_SCR["TXB"]		={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:0,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:1,tut:0,ctx:0,dt:0,ico:0};


_ur_SCR[ur_type.Tray]				={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.Tray_End]		={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:0,ct:1,v:0,st:0,s:0,pos:0,lvl:0,tt:0,tbl:0,tut:0,ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.Tray_Button]={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:"SAPUR_B",v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_B_TUT",ctx:0,dt:0,ico:0};	
_ur_SCR[ur_type.Tray_Menu]	={lbl:0,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:0,st:1,s:0,pos:0,lvl:0,tt:1,tbl:0,tut:"SAPUR_MENUSPACE_TUT",ctx:0,dt:0,ico:0};	

_ur_SCR["VC"]		={lbl:1,rt:0,rct:0,rst:0,rtt:0,rtut:0,t:1,ct:1,v:1,st:0,s:0,pos:1,lvl:0,tt:1,tbl:1,tut:0,ctx:0,dt:0,ico:0};

_ur_SCR["VS"]		={lbl:0,rt:1,rct:1,rst:1,rtt:0,rtut:0,t:1,ct:0,v:0,st:1,s:0,pos:1,lvl:0,tt:1,tbl:0,tut:1,ctx:0,dt:0,ico:0};



//* ------------------------------------------------------------------------
//* function    : ur_SCR_activate
//* parameter   : 
//* description : The function is called when you focus a control. The function
//*								checks if screen reader support is turned on in general and
//*								if it is implemented for the focused control in JavaScript.
//*								If both is true, the function builds the screen reader tooltip
//*								and sets the title attribute for the focused control.
//* return      : -
//* ------------------------------------------------------------------------
function ur_SCR_activate(oEvt){
	/* check if screen reader support is turned on */
	if(!ur_system.is508) return;

	if (typeof(oEvt)=="undefined") oEvt=event; 
	
	var o=oEvt.srcElement;	 // focused object
	
	/* return if no object has the focus or if the document or body or the span used for refocus is activated */
	if(o==null || o.tagName=="HTML" || o.tagName=="BODY" || o.id=="ur-accfocus") return;
	
	var oL=oEvt.fromElement; // object focused before
	
	/* get control of the focused object, object where you find the ct attribute */
	var oR=sapUrMapi_getRootControl(o);	
	
	/* check if a control has the focus */
	if( oR==null || typeof(oR)!="object" || oR.getAttribute("ct")==null) return;
	
	var sRCt=oR.getAttribute("ct"); // control type of the focused element
	var sLbl=""; // label associated to the control
	var sRTxt=""; // text or title of the control
	var sRCtTxt=""; // control type
	var sRSt=""; // status of the control
	var sRTt=""; // tool tip text of the control
	var sTxt="";				// text or title of the focused object
	var sCtTxt="";			// type of the focused object
	var sVal="";				// value of the focused object
	var sSt="";					// status of the focused object
	var sSem="";				// semantic color of the focused object
	var sPos="";				// position information of the focused object
	var sLvl="";				// level of the focused object
	var sTt="";					// tool tip text of the focused object
	var sTbl="";				// table cell information of the focused object if it is in a table cell
	var sTut="";				// tutor text of the focused object
	var sDt="";					// data tip of the focused object
	var sRTut=""; // tutor text of the control
	var sCtxMenuTut=""; // additional tutor text if an object has a context menu
	var sIco="";                // Has an additional icon that comes from an external source. Attributes stores tooltip of the icon.
	if (sRCt == "HCNP") oL = null;
	/* check if you enter a control or you navigate within a control */
	var bNav=true;
	if( oL == null||((!oR.contains(oL)||oL==oR) && oL.id!="ur-accfocus"))
		bNav=false;
	/* check navigation for the tree control */
	else if(sRCt==ur_type.Tree && oL.id==oR.id+"-skipstart")
		bNav=false;

	/* check if the ScrollContainer's layout property is set (i.e.,TabIndex), then simple return*/
	if(sRCt== ur_type.ScrollContainer && oR.getAttribute("ti") !=0) return;
	
	/* get subtype of a control and concatenate it to the control type */
	var sCt=ur_SCR_getSubtype(sRCt,o,oR);
	
	/* Check if its a TabStrip and the Paginator buttons were pressed, then just return */
	if( (sRCt == "TS" && sCt == "TS_MNU" ) || (sRCt == "TS" && sCt == "TS_B" )) return;

	/* check if screen reader support is available for the focused object */
	if(_ur_SCR[sCt]==null) return;
	
	/* get label text */
	if((_ur_SCR[sCt].lbl==1 && !bNav)||(sCt=="PG_I"&&_ur_SCR[sCt].lbl==1)){
		sLbl=ur_SCR_getLabelText(oR);
		if(sLbl==null)
			sLbl=ur_SCR_getLabelText(o);
	}
		
	/* get information of the control if a subtype is focused */
	if(o!=oR && !bNav)
	{
		/* get text/title */
		if(_ur_SCR[sCt].rt==1) sRTxt=ur_SCR_getText(sRCt,oR,bNav);	
		
		/* get control type */
		if(_ur_SCR[sCt].rct!=0) sRCtTxt=ur_SCR_getCtTxt(sRCt,oR,_ur_SCR[sCt].rct);
		
		/* get status text */
		if(_ur_SCR[sCt].rst==1) sRSt=ur_SCR_getStatusText(oR);
		
		/* get tooltip */
		if(_ur_SCR[sCt].rtt==1) sRTt=ur_SCR_getTooltip(oR);
        
		/* get tutor text */
		if(_ur_SCR[sCt].rtut!=0) sRTut=ur_SCR_getTutorTxt(sRCt,oR,oR,bNav,oEvt,_ur_SCR[sCt].rtut);    
  }
	
	/* get title */
	if(_ur_SCR[sCt].t==1) sTxt=ur_SCR_getText(sCt,o,bNav);
	
	/* get control type text */
	if(_ur_SCR[sCt].ct!=0 && !(bNav && o==oR))
		sCtTxt=ur_SCR_getCtTxt(sCt,o,_ur_SCR[sCt].ct);
		
	/* get value of the control */
	if(_ur_SCR[sCt].v==1) sVal=ur_SCR_getValue(sCt,o);
	
	/* get status text */
	if(_ur_SCR[sCt].st==1) sSt=ur_SCR_getStatusText(o);
		
	/* get semantic */
	if(_ur_SCR[sCt].s==1) sSem=ur_SCR_getSemantic(o);
	
	/* get position if an item of a control is focused */
	if(_ur_SCR[sCt].pos==1) sPos=ur_SCR_getPos(sCt,o,oR);
	
	/* get level */
	if(_ur_SCR[sCt].lvl==1) sLvl=ur_SCR_getLevel(o);
		
	/* get tooltip */
	if(_ur_SCR[sCt].tt==1) sTt=ur_SCR_getTooltip(o);
	
	/* get tutor text */
	if(_ur_SCR[sCt].tut!=0) sTut=ur_SCR_getTutorTxt(sCt,o,oR,bNav,oEvt,_ur_SCR[sCt].tut);
	
	/* get context menu tutor text if a context menu is available for the object */
	if(_ur_SCR[sCt].ctx!=0) sCtxMenuTut=ur_SCR_getContextMenuTutorTxt(o,oR);
	
	/* data tip */
	if(_ur_SCR[sCt].dt==1) sDt=ur_SCR_getDataTip(o,oR);
	
	/*tool tip of icon that comes from external source*/
	if(_ur_SCR[sCt].ico==1) sIco=ur_SCR_getIcon(o,oR);
	
	var sCntCt=null;
	var oCnt=ur_SCR_getContainer(o);
	if(oCnt!=null) sCntCt=oCnt.getAttribute("ct");
	
	/* popup trigger -> menu available */
	if(sCntCt == ur_type.PopupTrigger){
		sRTut=getLanguageText("SAPUR_MENU_TUT");
		sRTt=ur_SCR_getTooltip(oCnt);
		oCnt=ur_SCR_getContainer(oCnt.parentNode);
		if(oCnt!=null) sCntCt=oCnt.getAttribute("ct");
	}
	
	/* get table cell information if control is in a table cell */
	if(sCntCt==ur_type.SapTable && sCt!=sCntCt && sCt!=ur_type.SapTable_End)  {
		if(sTxt == sTt) sTt = ""; // avoid double announcement
		sTbl=ur_SCR_getSapTableInfo(o);
		/* different tutor text for radio buttons in saptable */
		if(sTbl && sCt==ur_type.RadioButton){
			if(ur_isSt(o,ur_st.SELECTED) || ur_isSt(o,ur_st.DISABLED) || ur_isSt(o,ur_st.READONLY)) sTut="";
			else sTut=getLanguageText("SAPUR_SELECT_TUT");
		}		
	}
	else if(sCntCt==ur_type.TableView) {
		if(o.getAttribute("noCntanrAnnouce")) {
			sTut = "";
			sCtTxt = "";
		}
		sTbl=ur_SCR_getTableInfo(o);
	} else if(sCt==ur_type.DateNavigator_Day) sTbl=ur_SCR_getDayWeek(o,oEvt);
		
	/* set tooltip */
	ur_SCR_setTooltip(o,new Array(sIco,sLbl,sRTxt,sRCtTxt,sRSt,sRTt,sTxt,sCtTxt,sVal,sSt,sSem,sPos,sLvl,sTt,sTut,sCtxMenuTut,sRTut,sDt,sTbl));
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getSubtype
//* parameter   : sCt - control type
//*								o		- focused control
//* description : check if the control has a subtype and if yes concatenate  
//*								the subtype to the control type
//* return      :	control type
//* ------------------------------------------------------------------------
function ur_SCR_getSubtype(sCt,o,oR){
  var sSubTp="";

	/* pattern container title, tab, sequence */
	if(sCt=="PCI" || sCt=="PCTAB" || sCt=="PCSEQ"){
		sSubTp=o.getAttribute("tp");
		if(sSubTp!=null && sSubTp!="") sCt+="_"+sSubTp;
		else if(o!=oR && sCt!="PCTIT") sCt+="_I";
	}

	/* all the other controls except input field */
	else if(sCt!="I"){
	if(o.getAttribute("tp")!=null && o.getAttribute("tp")!="")
		sCt+="_"+o.getAttribute("tp");	
	}

	return sCt;
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getLabelText
//* parameter   : 
//* description : Checks if a Label control can be associated to this control.
//*								If yes, the function checks if a Label control is asscociated 
//*								and if yes gets the text of the Label control and returns it.
//* return      :	text of the asscociated Label control
//* ------------------------------------------------------------------------
function ur_SCR_getLabelText(o){
	if(o.id==null || o.id=="") return;
	
	if(o.ct=="SC"){
		if(o.t!=null)return;
	}
	
	// get the text of an associated label
	var sLbl=sapUrMapi_Label_getLabelText(o.id);
	
	// check if a dropdown or combobox is used as label
	if(!sLbl){
		aIn = document.getElementsByTagName("INPUT");
		for(var i=0; i<aIn.length; i++){
			sLabelFor = aIn[i].getAttribute("f");
			if(sLabelFor == o.id)
				sLbl = aIn[i].value;
		}
	}
	
	// check if a label text is set for the control
	if(sLbl==null)
		sLbl=o.getAttribute("lbl");
	return sLbl;
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getText
//* parameter   : 
//* description : get the text or title of the control
//* return      : text/title of the control
//* ------------------------------------------------------------------------
function ur_SCR_getText(sCt,o,bNav){
	var sTxt="";
	
	/* view switch */
	if(sCt=="VS")
	{
		if(o.tagName=="DIV")
			sTxt=o.parentElement.getAttribute("t");
		else
			sTxt=o.getAttribute("t");
	}
	
	/* all the other controls */
	else{
		sTxt=o.getAttribute("t");
		if((sTxt==null || sTxt=="") && (sCt==ur_type.FormattedTextView || sCt==ur_type.Button || sCt==ur_type.Button_Menu || sCt==ur_type.Button_MenuSection || sCt==ur_type.Button_Toggle || sCt==ur_type.BreadCrumb_Item || sCt==ur_type.BreadCrumb_SingleLink || sCt==ur_type.ContextualPanel_Help || sCt==ur_type.ContextualPanel_Personalize  || sCt==ur_type.DateNavigator_Month || sCt==ur_type.SapTable_Header1 || sCt==ur_type.SapTable_Header2 || sCt==ur_type.SapTable_Header3 || sCt==ur_type.TextView || sCt==ur_type.Toolbar_Button || sCt==ur_type.ToolbarLink))
			sTxt=o.innerText;
	}
	return	sTxt;
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getCtTxt
//* parameter   : 
//* description : Gets the text of the control type. If necessary reads
//*								subtype information before to get the right text.
//* return      :	text of the control type
//* ------------------------------------------------------------------------
function ur_SCR_getCtTxt(sCt,o,sMsgId){
	/* control type message id is already defined in the control definition above */
	if(sMsgId!=1)
		return getLanguageText(sMsgId);

	var sMsgId="SAPUR_"+sCt;
	var sType="";
	
	/* input field 	*/
	if(sCt=="I"){
		sType=o.getAttribute("tp");
		if(sType!=null && sType!="" && (sType=="DATE" || sType=="TIME" || sType=="INTEGER"|| sType=="PW"))
			sMsgId+="_"+sType;
		if(o.getAttribute("f4")=="true")
			sMsgId+="_F4";
	} 
	/* item count is added to the control type */
	else if(sCt==ur_type.CheckBoxGroup || sCt=="RG" || sCt=="IT")
		return getLanguageText(sMsgId, new Array(o.getAttribute("ic")));
		
	/* saptable */
	else if(sCt=="ST"){
		var iRows=o.getAttribute("r");
		var iCols=o.getAttribute("c");
		var iVRows=o.getAttribute("vr");
		var iVFRow=o.getAttribute("vfr");
		var iVCols=o.getAttribute("vc");
		 
		if(parseInt(iRows)==0)
			return getLanguageText(sMsgId+"_EMPTY", new Array(iCols));
		else if(parseInt(iVRows)>0 && parseInt(iVRows)<parseInt(iRows)) {
 			if(parseInt(iVCols) < parseInt(iCols)) {
 				return getLanguageText(sMsgId+"_PAGE_HS", new Array(iCols,iVRows,iRows,iVFRow,iVCols));
 			} else {
 				return getLanguageText(sMsgId+"_PAGE", new Array(iCols,iVRows,iRows,iVFRow));
 			}
 		}	else {
 			if(parseInt(iVCols) < parseInt(iCols)) {
 				return getLanguageText(sMsgId+"_HS", new Array(iCols,iRows,iVCols));
 			} else {
 				return getLanguageText(sMsgId, new Array(iCols,iRows));
 			}
 		}
	}		
	/* saptable selection cell */
	else if(sCt=="ST_SC"){
		var sRow=o.getAttribute("rd");
		if(sRow==null || sRow=="" || parseInt(sRow)==0){
			var oRow=o;
			while(oRow.tagName!="TR") oRow=oRow.parentNode;
			sRow=oRow.getAttribute("rr");
		}
		return getLanguageText(sMsgId, new Array(sRow));
	}
	
	else if(sCt=="TBV")
	{
		var iCols=o.getAttribute("colCnt");
		var iVRows=o.getAttribute("visibleRCnt");
		var iRows=o.getAttribute("rowCnt");
		var iVFRow=o.getAttribute("visibleFRow");

		if(iRows == null || iCols === null) return "";	
		
		if(parseInt(iRows)==0)
			return getLanguageText(sMsgId+"_EMPTY", new Array(iCols));
		else if(parseInt(iVRows)>0 && parseInt(iVRows)<parseInt(iRows))
			return getLanguageText(sMsgId+"_PAGEWISE", new Array(iCols,iVRows,iRows,iVFRow));
		else
			return getLanguageText(sMsgId, new Array(iCols,iRows));
	}
	else if(sCt=="TBV_SC"){
		var sRow=o.getAttribute("rd");
		return getLanguageText(sMsgId, new Array(sRow));
	}
	
	else if(sCt=="TBV_INDICATOR") 
	{
		var navi = o.getAttribute("navi");
		var iRows = o.getAttribute("rCnt");
		var iVRows = o.getAttribute("visibleRCnt");
		return getLanguageText(sMsgId, new Array(navi,iVRows,iRows));
	}

	return getLanguageText(sMsgId);
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getValue
//* parameter   : 
//* description : Gets the current value or text of the control and returns it.
//* return      :	value or text of the control
//* ------------------------------------------------------------------------
function ur_SCR_getValue(sCt,o){
	if((sCt==ur_type.InputField && o.getAttribute("tp")=="PW")||sCt=="PG_I")
		return;
	if(sCt==ur_type.ComboBox_DropDownListBox && o.value=="")
		return getLanguageText("SAPUR_CB_NOITEM");
	return o.value;
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getPos
//* parameter   : sCt - control type
//*				  o		- focused item
//*	              oR	- control
//* description : get the position information if an item of a control is
//*								focused
//* return      :	position information
//* ------------------------------------------------------------------------
function ur_SCR_getPos(sCt,o,oR){
	var iIdx=0;
	var iIc=0;
	
	/* the number of items is the number of controls with the same name */
	if((sCt==ur_type.CheckBox || sCt=="R" || sCt=="TRI") && o.name!=""){
		var a=document.getElementsByName(o.name);
		iIc=a.length;
		for(var i=0;i<a.length;i++){
			if(a[i].tagName!="INPUT"){
				iIc=iIc-1;
				continue;
			}	
			iIdx=iIdx+1;		
			if(a[i]==o) break;	
		}
	}
	else if(sCt=="IL"){
		iIdx=o.getAttribute("idx");
		iIc=o.getAttribute("ic");
	}
	/* combo box */
	else if(sCt==ur_type.ComboBox || sCt==ur_type.ComboBox_DropDownListBox){
		lid = o.getAttribute("lid");
		if (lid) {
		iIdx=ur_ItemListBox_getIndex(o.getAttribute("lid"),o.getAttribute("k"));
		iIc=o.getAttribute("ic"); 
		}
	}
	else if(sCt=="ILB"){
		iIdx=o.parentNode.rowIndex+1;
		iIc=oR.firstChild.rows.length;
	}
	else if(sCt=="VS"){
		    if(o.tagName=="DIV")
			{
				iIdx=o.parentNode.parentNode.rowIndex+1;
				iIc=oR.firstChild.rows.length;
			}
			else
			{
				iIdx=o.parentNode.rowIndex+1;
				iIc=oR.firstChild.rows.length;
			}
	}
	else if(sCt=="NL_I")
	{
		iIdx=parseInt(o.getAttribute("idx"))+1;
		var oIc=ur_NL_getPrevObj(o,"ic");
		iIc=oIc.getAttribute("ic");
	}
	else if(sCt=="NL_G")
	{
		iIdx=parseInt(o.getAttribute("gidx"))+1;
		var oIc=ur_NL_getPrevObj(o,"ic");
		iIc=oIc.getAttribute("ic");
	}
	else if(sCt.indexOf("RM")>-1 || sCt.indexOf("PHI")>-1)
	{
		iIdx=parseInt(o.getAttribute("idx"))+1;
		iIc=o.getAttribute("ic");
	}
	/* tab strip item */
	else if(sCt=="TS_ITM")
	{
		iIdx=parseInt(o.getAttribute("idx")) + 1;
		iIc=oR.getAttribute("ic");
		return  getLanguageText("SAPUR_TS_ITM_POS",new Array(iIdx,iIc));
	}
	else if(sCt==ur_type.Tree_Folder || sCt==ur_type.Tree_Leaf){
		iIdx=o.getAttribute("idx");
		iIc=o.getAttribute("ic");
		var iIci=o.getAttribute("ici");
		if(iIci==null || parseInt(iIci)<=0)
			return getLanguageText("SAPUR_ITMPOS",new Array(iIdx,iIc));
		else
			return getLanguageText("SAPUR_ITMPOSCOUNT",new Array(iIdx,iIc,iIci));
	}
	else if(sCt=="HCNP_LNK"){
		iIdx=o.getAttribute("idx");
		iIc=o.getAttribute("ic");
	}
	else if(sCt=="POMN_I") {
		iIdx=o.getAttribute("idx");
		iIc=oR.getAttribute("ic");
		if (iIdx>0 && iIc>0) {
		    return getLanguageText("SAPUR_ITMPOS",new Array(iIdx,iIc));
		}
	    
	}
	else{
		iIdx=o.getAttribute("idx");
		iIc=oR.getAttribute("ic");
	}
	if(iIc==1 || iIc==0) return;
	else if (iIdx!=null) return getLanguageText("SAPUR_ITMPOS",new Array(iIdx,iIc));
	return "";
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getStatusText
//* parameter   : 
//* description : Gets the status text of the control.
//* return      :	status text of the control
//* ------------------------------------------------------------------------
function ur_SCR_getStatusText(o){
	var sSt=ur_getAttD(o,"st","");
	if(sSt=="") return "";
	var arrS=new Array();
	
	//push all status information in an array
	if(sSt.indexOf("s")>-1) arrS.push(getLanguageText("SAPUR_SELECTED"));
	if(sSt.indexOf("p")>-1) arrS.push(getLanguageText("SAPUR_PRESSED"));
  if(sSt.indexOf("n")>-1) arrS.push(getLanguageText("SAPUR_NOTSELECTED"));
	if(sSt.indexOf("a")>-1) arrS.push(getLanguageText("SAPUR_SUCCESS"));
	if(sSt.indexOf("b")>-1) arrS.push(getLanguageText("SAPUR_ERROR"));
	if(sSt.indexOf("c")>-1) arrS.push(getLanguageText("SAPUR_COMPLETED"));
	if(sSt.indexOf("d")>-1) arrS.push(getLanguageText("SAPUR_DISABLED"));
	if(sSt.indexOf("e")>-1) arrS.push(getLanguageText("SAPUR_END"));
	if(sSt.indexOf("i")>-1) arrS.push(getLanguageText("SAPUR_INVALID"));
	if(sSt.indexOf("m")>-1) arrS.push(getLanguageText("SAPUR_REQUIRED"));
	if(sSt.indexOf("o")>-1) arrS.push(getLanguageText("SAPUR_UNCOMPLETED"));
	if(sSt.indexOf("r")>-1) arrS.push(getLanguageText("SAPUR_READONLY"));	
	if(sSt.indexOf("u")>-1) arrS.push(getLanguageText("SAPUR_UNDEFINED"));
	if(sSt.indexOf("x")>-1) arrS.push(getLanguageText("SAPUR_UNCHECKED"));
	if(sSt.indexOf("v")>-1) arrS.push(getLanguageText("SAPUR_VALID"));
	if(sSt.indexOf("w")>-1) arrS.push(getLanguageText("SAPUR_WARNING"));
	if(sSt.indexOf("z")>-1) arrS.push(getLanguageText("SAPUR_MINIMIZED"));
	if(sSt.indexOf("0")>-1) arrS.push(getLanguageText("SAPUR_EMPTY"));
	if(sSt.indexOf("1")>-1) arrS.push(getLanguageText("SAPUR_START"));	
	if(sSt.indexOf("+")>-1) arrS.push(getLanguageText("SAPUR_EXPANDED"));
	if(sSt.indexOf("2")>-1) arrS.push(getLanguageText("SAPUR_SORTED_ASC"));
	if(sSt.indexOf("3")>-1) arrS.push(getLanguageText("SAPUR_SORTED_DESC"));
	if(sSt.indexOf("4")>-1) arrS.push(getLanguageText("SAPUR_SORTED_NOT"));
	if(sSt.indexOf("-")>-1) arrS.push(getLanguageText("SAPUR_COLLAPSED"));
	if(sSt.indexOf("y")>-1) arrS.push(getLanguageText("SAPUR_DYNAMIC"));
	if(sSt.indexOf("l")>-1) arrS.push(getLanguageText("SAPUR_LOADING"));
	if(sSt.indexOf("5")>-1) arrS.push(getLanguageText("SAPUR_STOP"));
	if(sSt.indexOf("t")>-1) arrS.push(getLanguageText("SAPUR_TODAY"));
	if(sSt.indexOf("T")>-1) arrS.push(getLanguageText("SAPUR_TOGGLED"));  //ToggleLink
	if(sSt.indexOf("N")>-1) arrS.push(getLanguageText("SAPUR_NOTTOGGLED")); //ToggleLink
	//join all status information with space+seperator+space
	if (arrS.length==0) return ""; //there was a st="something" but it was not handled in the if block!
	var sStTxt=arrS.join(" "+getLanguageText("SAPUR_SEPARATOR")+" ");
	//replace two and more spaces.		
	sStTxt=sStTxt.replace(/\s+/g," ");
  return sStTxt;
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getTooltip
//* parameter   : 
//* description : Gets the tooltip of a control
//* return      :	tooltip the control
//* ------------------------------------------------------------------------
function ur_SCR_getTooltip(o){
		return o.getAttribute("tt");;
}
//* ------------------------------------------------------------------------
//* function    : ur_SCR_getIcon
//* parameter   : 
//* description : Gets the tooltip of an associated icon
//* return      :tooltip the icon
//* ------------------------------------------------------------------------

function ur_SCR_getIcon(o){
		return o.getAttribute("ico");
}
//* ------------------------------------------------------------------------
//* function    : ur_SCR_getTutorTxt
//* parameter   : 
//* description : Gets the tutor text of the control.
//* return      :	tutor text of the control
//* ------------------------------------------------------------------------
function ur_SCR_getTutorTxt(sCt,o,oR,bNav,oEvt,sTutMsgId){

	if (sCt == "IMG" && o.interactive == "false")
		return;
		
	/* add no tutor text if control is read only or disabled except for radio buttons */
	if(o.ic==1 || (ur_isSt(o,ur_st.DISABLED) || ur_isSt(o,ur_st.READONLY)) && sCt!=ur_type.RadioButton && sCt!=ur_type.BreadCrumb && sCt!=ur_type.Tray) 
		return;
		
	/* add no tutor text if you navigate within the control for some controls */
	if(bNav && (sCt==ur_type.ComboBox || sCt==ur_type.ComboBox_DropDownListBox))
		return;
		
	/* tutor message id is already defined in the control definition above */
	if(sTutMsgId!=1)
		return getLanguageText(sTutMsgId);
		
	var sMsgId="SAPUR_"+sCt+"_TUT";
	
	/* objects which can be selected or deselected */
	if(sCt==ur_type.PopupMenu_Item){
		if(ur_isSt(o,ur_st.SELECTED))
			sMsgId="SAPUR_"+sCt+"_SEL_TUT";
		else if(ur_isSt(o,ur_st.NOTSELECTED))
			sMsgId="SAPUR_"+sCt+"_NSEL_TUT";
	}
	else if(sCt==ur_type.CheckBox || sCt==ur_type.Tree_Folder || sCt==ur_type.Tree_Leaf || sCt==ur_type.DateNavigator_Day){
		if(ur_isSt(o,ur_st.SELECTED))
			sMsgId="SAPUR_DESELECT_TUT";
		else if(ur_isSt(o,ur_st.NOTSELECTED) || ur_isSt(o,ur_st.SELECTABLE))
			sMsgId="SAPUR_SELECT_TUT";	
	}
	/* objects wich can be selected */
	else if(sCt==ur_type.BreadCrumb_Item || sCt==ur_type.BreadCrumb_SingleLink || sCt==ur_type.DateNavigator_Month || sCt==ur_type.DateNavigator_Week ){
		if(ur_isSt(o,ur_st.NOTSELECTED) || sCt==ur_type.BreadCrumb_SingleLink)
			sMsgId="SAPUR_SELECT_TUT";	
		else
			return;
	}
	/* controls which can be expanded or collapsed */
	 else if(sCt==ur_type.Button_Toggle){
		if(ur_isSt(o,ur_st.EXPANDED))
			sMsgId="SAPUR_"+sCt+"_EXP_TUT";
		else if(ur_isSt(o,ur_st.COLLAPSED))
			sMsgId="SAPUR_"+sCt+"_COLL_TUT";
	}

	/* radio button */
	else if(sCt=="R"){
		if(ur_isSt(oR.id,ur_st.DISABLED) || ur_isSt(oR.id,ur_st.READONLY))
			sMsgId="SAPUR_"+sCt+"_DSBL_TUT"	;
	}	
	/* input field */
	else if(sCt=="I"){
		if(ur_isSt(oR.id,ur_st.DISABLED)) return;
		if(o.getAttribute("f4")=="true")
			sMsgId="SAPUR_"+sCt+"_F4_TUT";
	}
	/* tristate checkbox */
	else if(sCt=="TRI"){
		if(ur_isSt(oR.id,ur_st.SELECTED))
			sMsgId="SAPUR_"+sCt+"_SEL_TUT";
		else if(ur_isSt(oR.id,ur_st.NOTSELECTED))
			sMsgId="SAPUR_"+sCt+"_NSEL_TUT";
		else
			sMsgId="SAPUR_"+sCt+"_UNDEF_TUT";
	}
	/* expandable groups */
	else if(sCt==ur_type.FreeArea || sCt==ur_type.NavigationList || sCt==ur_type.Tray)
		{
		//do not announce additional tutor for entering if there is no additional tab stop in the header
		var bEnter="_NO_ENTER";
		if(o.o)bEnter="";
		if (ur_isSt(oR,ur_st.COLLAPSED))sMsgId="SAPUR_GROUPEXP"+bEnter+"_TUT";
		else if(ur_isSt(oR,ur_st.EXPANDED))sMsgId="SAPUR_GROUPCOLL_TUT";
		else sMsgId="SAPUR_GROUP_TUT";
	}
	/* pattern container tab or sequence item */
	else if(sCt=="PCTAB_I" || sCt=="PCSEQ_I" ){
		if(ur_isSt(o,ur_st.NOTSELECTED)&& !ur_isSt(oR,ur_st.DISABLED))
				sMsgId="SAPUR_SELECT_TUT";
		else
			return;
	}
	/* tab strip item */
	else if(sCt=="TS_ITM" || sCt.indexOf("HCNP") > -1){
		if(ur_isSt(o,ur_st.NOTSELECTED)&& !ur_isSt(o,ur_st.DISABLED))
				sMsgId="SAPUR_SELECT_TUT";
		else
			return;
	}
	/* navigation list */
	else if(sCt=="NL")
	{
		if(ur_isSt(oR.id,ur_st.DISABLED)) return;
		if(bNav=false) return;
	}
	/* navigation list item with pop up menu */
	else if(sCt=="NL_I"){
		sPop=o.parentElement.getAttribute("pop");
		if(!ur_isSt(o,ur_st.DISABLED) && sPop)
		return	getLanguageText("SAPUR_NL_I_POP_TUT");
	}
	/* input tokenizer */
	else if (sCt=="IT"){
		var del= o.getAttribute("delimiter");
		if(del==";")del="SAPUR_IT_SC";
		else if(del==",")del="SAPUR_IT_CM";
		else if(del=="-")del="SAPUR_IT_DS";
		return	getLanguageText(sMsgId,new Array(del));
	}
	/* saptable selection cell */
	else if(sCt=="ST_SC"){
		if(ur_isSt(o,ur_st.DISABLED)) return;
		if(ur_isSt(o,ur_st.SELECTED) && ur_isSt(o,ur_st.DESELECTABLE))
			sMsgId="SAPUR_"+sCt+"_S_TUT";
		else if(ur_isSt(o,ur_st.NOTSELECTED))
			sMsgId="SAPUR_"+sCt+"_N_TUT";
	}	
	/* sortable saptable header cell */
	else if(sCt.indexOf("ST_HDR")>=0){
		if(ur_isSt(o,ur_st.SORTEDDESC) || ur_isSt(o,ur_st.NOTSORTED) || ur_isSt(o,ur_st.SORTEDASC))	
			if(o && o.getAttribute("id") && o.getAttribute("stasc") && !document.getElementById(o.getAttribute("id").replace("-content", "-sort")) ) {
				//When no sort button is available
				return	getLanguageText("SAPUR_TBV_HEADER_CHANGE");
			} else {
				return	getLanguageText("SAPUR_ST_HDR_SORT");
			}
	}
	/* table view header cell */
	else if(sCt=="TBV_HC"){
		if(ur_isSt(o,ur_st.SORTEDDESC) || ur_isSt(o,ur_st.NOTSORTED))	
			return	getLanguageText("SAPUR_TBV_HEADER_CHANGE");
		else if(ur_isSt(o,ur_st.SORTEDASC))	
			return	getLanguageText("SAPUR_TBV_HEADER_CHANGE");
	}
	/* table view selection cell */
	else if(sCt=="TBV_SC"){
		if(ur_isSt(o,ur_st.SELECTED))
		{
			if(o.getAttribute("isSingleSel")=="true") return;
			else
			sMsgId="SAPUR_"+sCt+"_SEL_TUT";
		}
		else
			sMsgId="SAPUR_"+sCt+"_NSEL_TUT";
	}
	/* table view paginator */
	else if(sCt=="TBV_TOPBTN" || sCt=="TBV_PRVPG" || sCt=="TBV_PRVROW" || sCt=="TBV_NXTROW" || sCt=="TBV_NXTPG" || sCt=="TBV_BOTBTN" )
	{
		if(ur_isSt(o,ur_st.DISABLED)) return;
		else
		sMsgId="SAPUR_"+sCt+"_TUT";
	}
	/* roadmap step */
	else if(sCt=="RM_STN" || sCt=="RM_RTCLO" || sCt=="RM_RTSTR" || sCt=="RM_RTEND" || sCt=="RM_SUB")
	{
			if(ur_isSt(o,ur_st.DISABLED) || ur_isSt(o,ur_st.SELECTED) || ur_isSt(o,ur_st.DYNAMIC))
				return;
			if(ur_isSt(o,ur_st.SELECTABLE))
				sMsgId="SAPUR_SELECT_TUT";
	}

	/* view switch */
	else if(sCt=="VS" )
	{
		if(bNav)
		{
			if(!ur_isSt(o,ur_st.SELECTED) && !ur_isSt(o,ur_st.DISABLED))
			{
				sMsgId="SAPUR_"+sCt+"_NSEL_TUT";
				return getLanguageText(sMsgId);
			}
			else
			{
				return;
			}
		}
		else
		{
			sMsgId="SAPUR_"+sCt+"_TUT";
			return getLanguageText(sMsgId);
		}
	}
	/* menubar item */
	else if(sCt=="MNB_I"){
		if(o==oR) sMsgId="SAPUR_MNB_TUT";
		else if(ur_isSt(o.id,ur_st.DISABLED)) return;
	}
	
	/* return tutor text */	
	return getLanguageText(sMsgId);
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getContextMenuTutorTxt
//* parameter   : 
//* description : Check if a context menu is available for the focused
//*								object. If yes return a tutor text how to open the context
//*								menu.
//* return      :	context menu tutor text
//* ------------------------------------------------------------------------
function ur_SCR_getContextMenuTutorTxt(o,oR){	
	var sCtx=o.getAttribute("ctx");
	if(sCtx==null || sCtx!=1) return;
	return getLanguageText("SAPUR_CONTEXTMENU_TUT");
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getDataTip
//* parameter   : 
//* description : Checks if a data tip is assigned to the control. If yes
//*								gets the data tip text.
//* return      :	data tip of the control
//* ------------------------------------------------------------------------
function ur_SCR_getDataTip(o,oR){
	var oDataTip=ur_get(o.id+"-dtip");
	if(oDataTip==null) return;
	var	sDtTxt=sapUrMapi_DataTip_getText(o.id);
	var	sDtType=getLanguageText("SAPUR_MSG_"+sapUrMapi_DataTip_getType(o.id).toUpperCase());
	if (sapUrMapi_DataTip_getType(o.id) == "Ok") sDtType = getLanguageText("SAPUR_MSG_SUCCESS");
	if (sapUrMapi_DataTip_getType(o.id) == "Text") sDtType = "";
	sDtTxt=sDtType+" "+sDtTxt;
	return sDtTxt;
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getTableInfo
//* parameter   : 
//* description : Check if the control is within a table. If yes get the
//*								cell information like	row, column header, ...
//* return      :	table cell information
//* ------------------------------------------------------------------------
function ur_SCR_getTableInfo(o){
	if(o.getAttribute("intbl")!="true") return; 
 	return o.getAttribute("tttbl");
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getSapTableInfo
//* parameter   : 
//* description : Check if the control is within a table. If yes get the
//*								cell information like	row, column header, ...
//* return      :	table cell information
//* ------------------------------------------------------------------------
function ur_SCR_getSapTableInfo(o){
	var oCell=o;
	var sCellType="";
	var sTableInfo="";
	var sColor="";
	
	/* get cell */
	var oLoopObject=oCell, sLoopCt=null, sLoopTagName=null, sLoopCellTP = null;
	while(oLoopObject){
		sLoopCt = ur_getAttD(oCell,"ct","");
		sLoopTagName = oLoopObject.tagName;
		
		if (sLoopCt=="PG" || sLoopTagName=="BODY") return;
				
		if(oLoopObject.getAttribute("tp")) sLoopCellTP = oLoopObject.getAttribute("tp");

		if( (sLoopTagName == "TD" || sLoopTagName == "TH") && oLoopObject.className.indexOf("urST") != -1 && sLoopCellTP) {
			var oBodyTable = oLoopObject.parentNode.parentNode.parentNode; // reference of the inner table body of the table
			
			//Check if this is really a table cell
			if( oBodyTable.bd == "1") {
				sCellType = sLoopCellTP;
				oCell = oLoopObject;
				break;
			}
		}
		
		oLoopObject = oLoopObject.parentNode;
	}
	
	/* data cell */
	if(sCellType=="C" || sCellType=="HIC"){
		var oTab=ur_getRootObj(oCell);
		var sHeaders="";
		var sRowHeaders="";
		var oRow=ur_SCR_getRow(oCell);
		var sRow=oRow.getAttribute("rr");
		var sRowAccDescription=oRow.getAttribute("t");
		
		if(sRowAccDescription) {
			sTableInfo = sRowAccDescription;
		} else if(parseInt(oTab.r)>0 && parseInt(sRow)>0){
			sHeaders=ur_SCR_getHeaders(ur_SCR_getCell(oCell),false);
			sRowHeaders=ur_SCR_getHeaders(ur_SCR_getCell(oCell),true);
			
			if (sHeaders==null) {
				var oTmpCell = ur_SCR_getCell(oCell),
					sCollAttribute = oTmpCell.getAttribute("cc");
				
				sHeaders = (sCollAttribute != null)? sCollAttribute: (oTmpCell.cellIndex+1);
			}
			
			if (sRowHeaders==null) 
				sRowHeaders=sRow;					
			sTableInfo=getLanguageText("SAPUR_ST_C",new Array(sRowHeaders,sHeaders));
		}	
		if(sCellType=="HIC"){
			var sLvl=oCell.getAttribute("lv");
			if(sLvl!=null && sLvl!="")
				sTableInfo+=" "+getLanguageText("SAPUR_SEPARATOR")+" "+getLanguageText("SAPUR_LEVEL",new Array(sLvl));
			if(ur_isSt(oCell.id,ur_st.EXPANDED))
				sTableInfo+=" "+getLanguageText("SAPUR_SEPARATOR")+" "+getLanguageText("SAPUR_ST_COL_TUT");
			else if(ur_isSt(oCell.id,ur_st.COLLAPSED))
				sTableInfo+=" "+getLanguageText("SAPUR_SEPARATOR")+" "+getLanguageText("SAPUR_ST_EXP_TUT");			
		}
		
		// When content is empty
		if(oCell && oCell.firstChild && oCell.firstChild.getAttribute("empty")) {
			sTableInfo = getLanguageText("SAPUR_EMPTY") + " " + getLanguageText("SAPUR_SEPARATOR") + " " + sTableInfo;
		}
		
	}
  /* filter cell */
	else if(sCellType=="F"){
		var sHeaders=ur_SCR_getHeaders(ur_SCR_getCell(oCell),false);
		var sSt=oCell.st;
		if(sHeaders!=null && sSt=="")
			sTableInfo=getLanguageText("SAPUR_ST_F",new Array(sHeaders))+" "+getLanguageText("SAPUR_SEPARATOR")+" "+getLanguageText("SAPUR_ST_F_TUT");
		else if(sHeaders!=null && sSt=="ro")
			sTableInfo=getLanguageText("SAPUR_ST_F",new Array(sHeaders));
	}
	/* get sematic color information */
	sColor=ur_SCR_getSemantic(oCell);
	if(sColor!=null && sColor!="")
		sTableInfo=sTableInfo+" "+getLanguageText("SAPUR_SEPARATOR")+" "+sColor;
	
	/* bi cell */
	if(sCellType=="C") {
		var sBiType = ur_getAttD(oCell,"BiTp","");
		if(sBiType) {
			if(sBiType == "h1") sTableInfo = getLanguageText("SAPUR_ST_HDR1") + " - " + sTableInfo;
			else if(sBiType == "h2") sTableInfo = getLanguageText("SAPUR_ST_HDR2") + " - " + sTableInfo;
			else if(sBiType == "h3") sTableInfo = getLanguageText("SAPUR_ST_HDR3") + " - " + sTableInfo;
		}
	}
	
	return sTableInfo;
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getSemantic
//* parameter   : o - fucused object
//* description : gets the semantic color or design of the focused object from
//*								the atrribute s and returns a corresponding text.
//* return      :	text for a semantic color or design
//* ------------------------------------------------------------------------
function ur_SCR_getSemantic(o){
	var sSem=o.getAttribute("s");
	
	/* only a date navigator day can have a semantic text instead of selected1, selected2, ... */
	var sSemTxt=o.getAttribute("sdesc");
	if(sSemTxt!=null && sSemTxt!="") return sSemTxt;
	
	if(sSem==null || sSem=="") return "";
	var arrSem=new Array();
	//push all semantic information in an array
	if(sSem.indexOf("1")!=-1) arrSem.push(getLanguageText("SAPUR_H1"));
	if(sSem.indexOf("2")!=-1) arrSem.push(getLanguageText("SAPUR_H2"));
	if(sSem.indexOf("3")!=-1) arrSem.push(getLanguageText("SAPUR_H3"));
	if(sSem.indexOf("4")!=-1) arrSem.push(getLanguageText("SAPUR_H4"));
	if(sSem.indexOf("b")!=-1) arrSem.push(getLanguageText("SAPUR_BADVALUE"));
	if(sSem.indexOf("c")!=-1) arrSem.push(getLanguageText("SAPUR_CRITICALVALUE"));
	if(sSem.indexOf("e")!=-1) arrSem.push(getLanguageText("SAPUR_EMPHASIZED"));
	if(sSem.indexOf("n")!=-1) arrSem.push(getLanguageText("SAPUR_NEGATIVE"));
	if(sSem.indexOf("p")!=-1) arrSem.push(getLanguageText("SAPUR_POSITIVE"));	
	if(sSem.indexOf("s")!=-1) arrSem.push(getLanguageText("SAPUR_SELECTED"));
	if(sSem.indexOf("t")!=-1) arrSem.push(getLanguageText("SAPUR_TOTAL"));
	if(sSem.indexOf("u")!=-1) arrSem.push(getLanguageText("SAPUR_SUBTOTAL"));
	if(sSem.indexOf("g")!=-1) arrSem.push(getLanguageText("SAPUR_GOODVALUE"));
	if(sSem.indexOf("k")!=-1) arrSem.push(getLanguageText("SAPUR_KEY"));
	if(sSem.indexOf("a")!=-1) arrSem.push(getLanguageText("SAPUR_STANDARD"));
	//join all status information with space+seperator+space
	if (arrSem.length==0) return ""; 
	sSemTxt=arrSem.join(" ");
	//replace two and more spaces.		
	sSemTxt=sSemTxt.replace(/\s+/g," ");
	return sSemTxt;
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getLevel
//* parameter   : 
//* description : 
//* return      :	
//* ------------------------------------------------------------------------
function ur_SCR_getLevel(o,oR){
	var sLv=o.getAttribute("lv");
	if(sLv==null || sLv=="") return;
	return getLanguageText("SAPUR_LEVEL",new Array(sLv));
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_setTooltip
//* parameter   : 
//* description : Get the tooltip.
//* return      :	tooltip
//* ------------------------------------------------------------------------
function	ur_SCR_setTooltip(o,aTxt){
	var sTitle="";
	var sSep=" "+getLanguageText("SAPUR_SEPARATOR")+" ";

	for(var i=0; i<aTxt.length; i++){
		if(aTxt[i]==null || aTxt[i]=="" || typeof(aTxt[i])=="undefined" || aTxt[i].search(/\S/)==-1) 
			continue;
		if(sTitle!="")
			sTitle+=sSep;
		sTitle+=aTxt[i];
	}		
	if(o.getAttribute("hascnt")=="true")
		o.setAttribute("scrtt",sTitle);
	else
	o.title=sTitle;
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getHeaders
//* parameter   : 
//* description : get the header texts of a table cell
//* return      :	header texts
//* ------------------------------------------------------------------------
function ur_SCR_getHeaders(oCell,bRow){
	var aHeaders;
	var sHeaders="";
	var oHeaderRoot, oHeaderContent, sText;
	
	if(bRow==true)
		sHeaders=oCell.getAttribute("rowheaders");
	else
		sHeaders=oCell.getAttribute("headers");
		
	if(sHeaders==null || sHeaders=="") return null;
	aHeaders=sHeaders.split(" ");
	sHeaders="";
	
	for(var i=0;i<aHeaders.length;i++){
		sText = "";

		//Get the accesibilityDescription from the HeaderContentCell
		oHeaderContent=ur_get(aHeaders[i]+"-content");
		if(oHeaderContent && oHeaderContent.getAttribute("t")) {
			sText=oHeaderContent.getAttribute("t");
		} else {
			// If no accDescription exists try to get the printed headerText	
			oHeaderRoot=ur_get(aHeaders[i]);
			if(oHeaderRoot) {
				sText = oHeaderRoot.innerText;
				if(sText && sText.indexOf("*") == 0 && oHeaderRoot.innerHTML && oHeaderRoot.innerHTML.indexOf("urST3HReq") != -1) {
					// cell is mandatory and contains '*' which has to be extracted
					sText = sText.substr(1);
				}

				if((sText.lastIndexOf("*")+1) == sText.length) {
					sText = sText.substring(0, sText.lastIndexOf("*"));
				}
			}
		}
		
		if(sText) {
			sHeaders+=sText + " ";
		}
	}
	
	//Trim sHeaders
	if(sHeaders) {
		sHeaders = sHeaders.replace(/\s+$/,"").replace(/^\s+/,"");
	}

	return sHeaders;
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getRow
//* parameter   : 
//* description : get the table row
//* return      :	table row object
//* ------------------------------------------------------------------------
function ur_SCR_getRow(o){
	while(o.tagName!="TR") o=o.parentNode;
	return o;
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getCell
//* parameter   : 
//* description : get the table cell
//* return      :	table cell object
//* ------------------------------------------------------------------------
function ur_SCR_getCell(o){
	while(o.tagName!="TD") o=o.parentNode;
	return o;
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getContainer
//* parameter   : 
//* description : get container of the focused control
//* return      :	container object
//* ------------------------------------------------------------------------
function ur_SCR_getContainer(o){
	var oCnt=o;
	
	while(oCnt!=null && oCnt.tagName!="BODY"){
		var sCt=oCnt.getAttribute("ct");
		if(_ur_cnt[sCt]!=null)
			return oCnt;
		oCnt=oCnt.parentNode;
	}
	return null; 
}

//* ------------------------------------------------------------------------
//* function    : ur_SCR_getDayWeek
//* parameter   : 
//* description : get headers for a date navigator day (weekday and week)
//* return      :	header text
//* ------------------------------------------------------------------------
function ur_SCR_getDayWeek(o,oEvt){
	var sWeek=o.parentNode.firstChild.getAttribute("t");
	var sDay=o.parentNode.parentNode.rows[1].cells[o.cellIndex].title;
	var sTbl="";
	if(oEvt.fromElement != null) {
		if(oEvt.fromElement.tagName!="TD" || (o.cellIndex!=oEvt.fromElement.cellIndex))
			sTbl=sDay;
		if(oEvt.fromElement.tagName!="TD" || (o.parentNode.rowIndex!=oEvt.fromElement.parentNode.rowIndex)){
			if(sTbl!="") sTbl+=" ";
			sTbl+=sWeek;
		}
	}	
	return sTbl;
}
//#####################################################################################////
//****The following section contains the functions necessary for hierarchical navigation****//
//#####################################################################################////

document.attachEvent("onkeydown", ur_keyHierarchieNav);

//* ------------------------------------------------------------------------
//* function    : ur_keyHierarchieNav
//* parameter   : browser event
//* description : starting point of hierarchical navigation. Destinguishes 
//				   whether the children or the parent was requested. Collects
//				   the according controls and displays them in an alert box.
//* return      : alert(sSpeachout) - an alert box with the speach out.
//* ------------------------------------------------------------------------
function ur_keyHierarchieNav(event) {
	
	if (!ur_system.is508) return;
	
	var oRoot = event.srcElement,
		bFindCildren = (event.altKey && sapUrMapi_bCtrl(event) && event.keyCode == 87),
		bFindParent = (event.altKey && sapUrMapi_bCtrl(event) && event.keyCode == 86);
		aSpeachout = null,
		sSpeachout = null;
	
	//requesting direct children
	if (bFindCildren) {
		//The sSourceType determines whether the focus surrounds the whole container or only an item (tabstrip) or only the title (group)
		var sSourceType = ur_checkContainerType(oRoot);
		
		//In this case we need the parent, in order to get the children
		if (sSourceType == "ITEM" || sSourceType == "TITLE") {
			oRoot = sapUrMapi_getRootControl(oRoot);
		}
		else if (sSourceType == "DATA_TABLE") {
			sSpeachout = getLanguageText("SAPUR_" + oRoot.ct + "_INF0", new Array(oRoot.c, oRoot.r));
		}
		
		if (oRoot != null && sSourceType != "DATA_TABLE") {
		aSpeachout = ur_findDirectChildren(oRoot, new Array());
		} 
		
		if (sSourceType != null && aSpeachout != null && aSpeachout.length != 0) {
			//retrns the control names in alphabetical order
			sSpeachout = ur_sortSpeachout(aSpeachout);
		} 
		
		//concats the final speach output
		if (sSpeachout != null && typeof(sSpeachout) != "undefined" && sSpeachout != "") {
			sSpeachout = ur_getSourceName(oRoot) + getLanguageText("SAPUR_CHILDREN") + "\n" + sSpeachout;
		} else {
		//The stored control types were not acc relevant, i.e. layout controls, text etc.
			sSpeachout = ur_getSourceName(oRoot) + getLanguageText("SAPUR_NO_CHILDREN");
		}
			
	}
	//requesting direct parent
	else if (bFindParent) {
		var sSourceType = ur_checkContainerType(oRoot)
			oSource = oRoot,
			oRoot = ur_findDirectParent(oRoot);
		
		if (oRoot != null)
			sSpeachout = ur_getControlName("SAPUR_" + oRoot.ct);
		
		if (sSpeachout != null && typeof(sSpeachout) != "undefined" && sSourceType != "TITLE" && sSourceType != "ITEM") {
			sSpeachout = ur_getSourceName(oSource) + getLanguageText("SAPUR_PARENT") + " " + sSpeachout;
		} else {
			sSpeachout = ur_getSourceName(oSource) + getLanguageText("SAPUR_NO_PARENT");
		}
	}
	
	if (bFindCildren || bFindParent) {
		alert(sSpeachout);
		event.returnValue=false;
}
}

function ur_getSourceName(oRoot) {
	var sRoot = "";
	if (oRoot != null && oRoot.ct) {
		sRoot = ur_getControlName("SAPUR_" + oRoot.ct);
		if (typeof(sRoot) == "undefined") sRoot = "";
		else sRoot += " " +getLanguageText("SAPUR_SEPARATOR") + " ";
	}
	return sRoot + " ";
}

//* ------------------------------------------------------------------------
//* function    : ur_findDirectChildren
//* parameter   : oNode - node where depth search starts, 
//				  aSpeachout - an empty array that collects all cts
//* description : collects the ct values of all direct children and returns them in an
//				  array. Breaks further deth search as soon as an acc relevant ct was found.
//* return      : aSpeachout an arry with all ct values found.
//* ------------------------------------------------------------------------

function ur_findDirectChildren(oNode, aSpeachout) {
	
	//avoid collecting objects that are hidden or not display
	if (oNode.childNodes == null || oNode.currentStyle.display == "none" || oNode.currentStyle.visibility == "hidden") return;

	var aChildren = oNode.childNodes;

	for (var i = 0; i < aChildren.length; i++) {
		if (aChildren[i] != null && aChildren[i].nodeType == 1) {
			if (aChildren[i].getAttribute("ct") != null) {
				var sCt = aChildren[i].getAttribute("ct")
				//don't collect cts that are not acc relevat, i.e. layout controls
				if (ur_bIsExcludedType("," + sCt + ",") == false) {
					//create the collection and do not search deeper
					aSpeachout.push(sCt);
				 	continue;
				}
			}
			//call yourselve repeatedly until all necessary cts have been collected.
			// concatinate the returned array with the one created in this instance.
			aSpeachout.concat(ur_findDirectChildren(aChildren[i], aSpeachout));
		}
	}
	//return an array.
	return aSpeachout;
}

//* ------------------------------------------------------------------------
//* function    : ur_findDirectParent
//* parameter   : oNode - node where search starts
//* description : finds the container of an element, if there is one and if 
//				  it is acc relevant and returns it.
//* return      : oParent - the acc relevant container.
//* ------------------------------------------------------------------------

function ur_findDirectParent(oNode){
	var oParent = sapUrMapi_getRootControl(oNode.parentNode);
	
	if (oParent == null || oParent == "" || oParent.getAttribute("ct") == null ) {
		return null;
	// if the returned parent is not acc relevant, i.e. it is a layout control, or should not be treated
	//as a parent, call yourselve again.
	} else if (ur_bIsExcludedType("," + oParent.ct + ",") || ur_bIsNoParent("," + oParent.ct + ",")) {
		oParent = ur_findDirectParent(oParent.parentNode);
	}
	return oParent;
}

//* ------------------------------------------------------------------------
//* function    : ur_sortSpeachout
//* parameter   : aSpeachout - the array with all collected cts of the direct children
//* description : finds the control names and counts their occurrences with the container 
//* return      : sSpeachout - a string representing all children
//* ------------------------------------------------------------------------
function ur_sortSpeachout(aSpeachout){
	
	aSpeachout.sort();
	var sSpeachout = "", j = 0;

	for (var i = 0; i < aSpeachout.length; i++) {
		// counts the occurence of a ct value within the array
		j++;
		//if the value of the following index does not equal the value of the current write the
		// value of j together with the control name.
		if (aSpeachout[i + 1] == null || (aSpeachout[i + 1] != null && aSpeachout[i + 1] != aSpeachout[i])) {
			var sControlName = ur_getControlName("SAPUR_" + aSpeachout[i]);
				
			if (typeof(sControlName) != "undefined" && sSpeachout.indexOf(sControlName) < 0) {
				sSpeachout += j + " " + sControlName + "\n";
			}
			
			j = 0;
		}
	}
	return sSpeachout;
}

//* ------------------------------------------------------------------------
//* function    : ur_getControlName
//* parameter   : sCt - the ct value of a control, i.e. 'B' for button
//* description : avoids brakets within the text of controls like table
//* return      : sControlName - the simple name of a control without further information
//* ------------------------------------------------------------------------
function ur_getControlName(sCt){
	var sControlName = getLanguageText(sCt);
	
	if (typeof(sControlName) != "undefined" && sControlName.indexOf("{") > -1)
		sControlName = getLanguageText(sCt + "_SHORTNAME");
					
	return sControlName;
}

//* ------------------------------------------------------------------------
//* function    : ur_bIsNoParent
//* parameter   : sCt - the ct value of a control, i.e. 'PHI' for phase indicator
//* description : these controls may not be treated as parents, however, they must be treated
//				  as children. For example, the direct parent of a popup trigger's contant is not
//				  the popup trigger, but its container.
//* return      : boolean
//* ------------------------------------------------------------------------
function ur_bIsNoParent(sCt){
	var noParent = ",POTRG,PG,PHI,RM,";
	if(noParent.indexOf(sCt) > -1) return true;
	return false;
}

//* ------------------------------------------------------------------------
//* function    : ur_bIsExcludedType
//* parameter   : sCt - the ct value of a control, i.e. 'BR' for button row
//* description : these controls are not acc relevat at all. 
//* return      : boolean
//* ------------------------------------------------------------------------
function ur_bIsExcludedType(sCt){
	var excludedTypes = ",PAG,PCI,FL,SL,GL,HD,ML,SL,BR,FlowLayout,";
	if(excludedTypes.indexOf(sCt) > -1) return true;
	return false;
}

//* ------------------------------------------------------------------------
//* function    : ur_checkContainerType
//* parameter   : oNode - the source element of the event triggering hierarchical
//					navigation
//* description : The depth search needs to know whether the source element is a container or 
//				something else. Depending on this information the source element is treated as root
//				or the actual root has to be found 
//* return      : string - describing the container type
//* ------------------------------------------------------------------------
function ur_checkContainerType(oNode){
	
	if (oNode == null) return null;
	
	var sType = (oNode.getAttribute("ct")) ? oNode.getAttribute("ct") : oNode.id;
	
	if (sType == null) return null;
	
	switch(sType) {
		case "TY":
		case "FRA":
		case "PCTAB":
		case "PCTIT":
		case "SC":
		case "SC":
		case "CXP":
		case "PI":
		case "T":
		case "PCTIT":
		case "PH":
		case "CG":
		case "RG":
		return "CONTAINER";
		case "G":
		return "TITLE";
		case "HCNP":
		//case "PHI":
		//case "RM":
		return "PAGENAVIGATION";
		//todo: we may have fixed root elements like the sap_table, where we only announce the root
		//		without its children
		case "ST":
		return "DATA_TABLE";
	}
	
	if (sType.indexOf("itm") > -1)
		return "ITEM";
	
	if (oNode.className.indexOf("Grp") > -1)
		return "TITLE";
	
	return null;
}

