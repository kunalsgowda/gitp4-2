//* ************************************************************************
//* ContextualPanel
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : ur_Cp_cl
//* parameter   : sId - string Id 
//*             : e   - Event Object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function ur_CXP_cl(sId,oEvt){
}

//* ------------------------------------------------------------------------
//* function    : ur_Cp_kd
//* parameter   : sId  - Id 
//*             : oEvt - Event Object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function ur_CXP_kd(sId,oEvt)
{
	return sapUrMapi_skip(sId,oEvt)
}

//* ------------------------------------------------------------------------
//* function    : ur_CXP_expand
//* parameter   : sId  - Id 
//*             : oEvt - Event Object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function ur_CXP_expand(sId,oEvt)
{
	ur_EVT_cancelBubble(oEvt);
	var elBody = ur_get(sId); 
	if ( elBody != null && elExp != null )
	{
		if ( elBody.style.display == "none" )
		{
			elBody.style.display = "block";
			ur_setSt(elBody,ur_st.COLLAPSED,false);
			ur_setSt(elBody,ur_st.EXPANDED,true);
		} 
		else
		{
			elBody.style.display = "none";
			ur_setSt(oSkip,ur_st.COLLAPSED,true);
			ur_setSt(oSkip,ur_st.EXPANDED,false);
		}
	}
	return true;
}

//* ------------------------------------------------------------------------
//* function    : ur_CXP_collapse
//* parameter   : sId  - Id 
//*             : oEvt - Event Object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function ur_CXP_collapse(sId,oEvt)
{

}
