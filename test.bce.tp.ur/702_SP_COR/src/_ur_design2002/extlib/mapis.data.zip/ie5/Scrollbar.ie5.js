var ur_SCB_obj;      //stores the scrollbar object during interaction
var ur_SCB_handle;   //stores the handle object during interaction
var ur_SCB_initialMousePos; //stores the mouseposition during interaction
var ur_SCB_initialHandlePos;
var ur_SCB_max;      //stores the available max pixels of the bar during interaction
var ur_SCB_timer;    //stores a timer for intercal of fireing events
var ur_SCB_pixelStop;  //stores the pixel value where to stop scrolling when on the bar element
var ur_SCB_src;      //stores the event source after mouse down
var ur_SCB_arr = new Array(); //array of all available scrollbars on the screen
var ur_SCB_evt; // stores the event object to pass to the framework on scroll finished
var ur_SCB_showst=false; // stores the event object to pass to the framework on scroll finished

//handles events from the html
function sapUrMapi_Scrollbar_handler(oEvt) {
  ur_SCB_evt=oEvt;
  ur_SCB_src=ur_EVT_src(oEvt);  //events src element
  if (ur_SCB_src.className=="urSCBBtn") ur_SCB_src=ur_SCB_src.parentNode;
  var o=ur_getRootObj(ur_SCB_src);

  if(oEvt.type == "mousewheel" && o.getAttribute("ct") != "SCB") {
  	//When scrolling is called by scrolled UI element
  	var oObj = o;
  	
  	while (oObj.tagName!="BODY") {
    	if (oObj && oObj.getAttribute && oObj.getAttribute("ct")=="ST") break;
    	oObj=oObj.parentNode;
  	}
  	
  	if(oObj && oObj.getAttribute("urScrlbar")) {
	  	o = document.getElementById(oObj.getAttribute("urScrlbar"));
	  	ur_SCB_src = o;
	  }
  }

  sArea=ur_getAttD(ur_SCB_src,"area",""); //attribute b holds all types of areas

  if(o && o.id && oEvt.type!="mousemove" && oEvt.type!="mouseup") {
    ur_SCB_obj=ur_Scrollbar_getObj(o.id); // get the scrollbar object. This getter is optimized
    if(ur_Scrollbar_isDisabled(ur_SCB_obj)) return false; // skip handling when scrollbar is disabled
  }
  //create the scrolltips lazy
  if (ur_SCB_obj.showscrolltip) {
    if (!ur_get("ur-scrolltip")) {
      var oScrollTip=document.createElement("SPAN");
      oScrollTip.setAttribute("id","ur-scrolltip");
      oScrollTip.style.position="absolute";
      oScrollTip.style.visibility="hidden";
      oScrollTip.style.top="0";
      oScrollTip.style.left="0";
      document.getElementsByTagName("BODY")[0].appendChild(oScrollTip);
    }
    ur_SCB_obj.scrolltip=ur_get("ur-scrolltip");
    while ( ur_SCB_obj.sScrolltips.indexOf("_")>0) ur_SCB_obj.sScrolltips=ur_SCB_obj.sScrolltips.replace("_","'");
    if(ur_SCB_obj.sScrolltips) ur_SCB_obj.scrolltips = eval("result=" + ur_SCB_obj.sScrolltips +";");
  }


  //mousewheel
  if (oEvt.type == "mousewheel") {
    if (o.sdir!="v") return;
    if (oEvt.wheelDelta > 0){ //positive mousewheel delta means scroll up
       ur_Scrollbar_scroll(ur_SCB_obj,"up");
    } else {
       ur_Scrollbar_scroll(ur_SCB_obj,"down");
    }
    //queue some events for 300 ms and then fire the change
    clearTimeout(ur_SCB_timer);
    // The ur_SCB_evt is invalid when accessed by timeout in fireChange. This leads to execution corruption
    // when code accesses event attributes. Workaround -> reset ur_SCB_evt
    ur_SCB_evt={};
    ur_SCB_timer=ur_callDelayed("ur_Scrollbar_fireChange(ur_SCB_obj, ur_SCB_evt)",300);
    ur_EVT_cancel(oEvt);

  //mousedown
  } else if (oEvt.type=="mousedown" && oEvt.button==1) { //left mouse button pressed
    //mousedown on the scroll handle

    if(document.activeElement && (document.activeElement.tagName == "INPUT" || document.activeElement.tagName == "TEXTAREA")) {
      // blur the active element to trigger a possible onChange of the current focussed element (e.g. InputField)
      // before the scrollbar triggers a roundtrip
      try{
        document.activeElement.blur();
      } catch(e){}
    }

    if (ur_SCB_src.id.indexOf("-h")>-1) { //the handle was clicked
      ur_SCB_handle=ur_SCB_src;
      ur_SCB_handle.setCapture();
      ur_SCB_handle.attachEvent("onmousemove",sapUrMapi_Scrollbar_handler);
      ur_SCB_handle.attachEvent("onmouseup",sapUrMapi_Scrollbar_handler);
      ur_SCB_handle.firstChild.className="urSCBBtnPressed";
      if (ur_SCB_obj.sdir=="v") {
        ur_SCB_initialHandlePos=parseInt(ur_SCB_src.style.marginTop);
        ur_SCB_initialMousePos=oEvt.y;
        ur_SCB_max=ur_SCB_src.parentNode.offsetHeight - ur_SCB_src.offsetHeight;
      } else {
        ur_SCB_initialHandlePos=parseInt((ur_system.direction=="rtl")? ur_SCB_src.style.marginRight: ur_SCB_src.style.marginLeft);
        ur_SCB_initialMousePos=oEvt.x;
        ur_SCB_max = ur_SCB_src.parentNode.offsetWidth - ur_SCB_src.offsetWidth;
      }
      ur_EVT_cancel(oEvt);

    //mousedown on the scroll bar area for
    } else if (sArea == "bar") {
      var iPos=0, offsetPos;
      ur_SCB_handle=ur_get(o.id+"-h");
      ur_SCB_handle.firstChild.className="urSCBBtnPressed";
      ur_SCB_src.setCapture();
      if (ur_SCB_obj.sdir=="v") {
      	offsetPos = oEvt.offsetY;
        iPos=parseInt(ur_SCB_handle.style.marginTop);
      } else {
        if (ur_system.direction=="rtl") {
          offsetPos = ur_SCB_obj.totalPixels-oEvt.offsetX;
          iPos=parseInt(ur_SCB_src.firstChild.style.marginRight);
        } else {
          offsetPos = oEvt.offsetX;
          iPos=parseInt(ur_SCB_src.firstChild.style.marginLeft);
        }
      }
      
      ur_SCB_pixelStop = ur_SCB_obj.range / ur_SCB_obj.totalPixels * offsetPos + ur_SCB_obj.min;
      if (offsetPos<iPos) {//pageup;
        ur_Scrollbar_page(ur_SCB_obj,"up");
        ur_scrollDir="up";
        ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'up')",300);
      } else if (offsetPos>iPos) {//pagedown;
        ur_Scrollbar_page(ur_SCB_obj,"down");
        ur_scrollDir="down";
        ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'down')",300);
      }
      
      ur_SCB_src.attachEvent("onmouseup",ur_Scrollbar_stopButton);
      ur_SCB_src.attachEvent("onmouseout",ur_Scrollbar_stopButton);
      ur_SCB_src.attachEvent("onmousemove",ur_Scrollbar_correctStopValue);

    //mousedown on the scroll buttons
    } else if ("ebudpn".indexOf(sArea)>-1) {
      ur_SCB_handle=ur_get(o.id+"-h");
      ur_SCB_src.setCapture();
      ur_SCB_src.className=ur_SCB_src.className.replace("urSCBBtn","urSCBBtnPressed");
      ur_SCB_src.attachEvent("onmouseup",ur_Scrollbar_stopButton);
      ur_SCB_src.attachEvent("onmouseout",ur_Scrollbar_stopButton);
      ur_SCB_handle.firstChild.className="urSCBBtnPressed";

      if (sArea=="e") {
        ur_Scrollbar_bounce(ur_SCB_obj,"down");
      //mousedown on the scroll begin button
      } else if (sArea=="b") {
        ur_Scrollbar_bounce(ur_SCB_obj,"up");
      //mousedown on the scroll up/prev button
      } else if (sArea=="u" || sArea=="p") {
        ur_Scrollbar_scroll(ur_SCB_obj,"up");
        ur_SCB_timer=setInterval("ur_Scrollbar_scrollStart(ur_SCB_obj,'up')",180);
      //mousedown on the scroll up/prev button
      } else if (sArea=="d" || sArea=="n") {
        ur_Scrollbar_scroll(ur_SCB_obj,"down");
        ur_SCB_timer=setInterval("ur_Scrollbar_scrollStart(ur_SCB_obj,'down')",180);
      }
    }

  //mousemove
  } else if (oEvt.type=="mousemove") {
    if (ur_SCB_handle) {
      var iDiff=0, iNewPos=0;
    	
      if (ur_SCB_obj.sdir=="v") {
      	iDiff=oEvt.y - ur_SCB_initialMousePos;
      } else {
      	iDiff = (ur_system.direction=="rtl")? ur_SCB_initialMousePos - oEvt.x: oEvt.x - ur_SCB_initialMousePos;
      }
      
      iNewPos = ur_SCB_initialHandlePos + iDiff;      
      
      if (iNewPos<0) iNewPos=0;
      if (iNewPos>ur_SCB_max) iNewPos=ur_SCB_max;
      
      if (iNewPos + ur_SCB_obj.handlesize >= ur_SCB_obj.totalPixels ) iNewPos = ur_SCB_obj.totalPixels - ur_SCB_obj.handlesize;
      
      if (ur_SCB_obj.sdir=="v") {
        ur_SCB_handle.style.marginTop = iNewPos;
      } else {
        if (ur_system.direction=="rtl")
          ur_SCB_handle.style.marginRight=iNewPos;
        else
          ur_SCB_handle.style.marginLeft=iNewPos;
       }
       
      ur_SCB_obj.newvalue = Math.floor(ur_SCB_obj.range/ur_SCB_max*iNewPos+ur_SCB_obj.min);
       
      ur_SCB_showst=true;
      ur_Scrollbar_showScrollTip(ur_SCB_obj, ur_SCB_obj.newvalue);
      if(ur_SCB_obj.sCallBackChange && ur_SCB_obj.sid) {
        window[ur_SCB_obj.sCallBackChange](ur_SCB_obj.sid, ur_SCB_obj.newvalue);
      }
      ur_EVT_cancel(oEvt);
    }
  //mouseup
  } else if (oEvt.type=="mouseup") {
    if(!ur_SCB_handle) ur_SCB_handle=ur_get(o.id+"-h");
    ur_SCB_handle.releaseCapture();
    ur_SCB_handle.detachEvent("onmousemove",sapUrMapi_Scrollbar_handler);
    ur_SCB_handle.detachEvent("onmouseup",sapUrMapi_Scrollbar_handler);
    ur_SCB_handle.firstChild.className="urSCBBtn";
    ur_SCB_handle=null;

    ur_Scrollbar_applyHandlePos(ur_SCB_obj);
    //fire the change
    ur_Scrollbar_fireChange(ur_SCB_obj, ur_SCB_evt);
  }
}

function ur_Scrollbar_fireChange(ur_SCB_obj, oEvt) {
  ur_Scrollbar_hideScrollTip();
  ur_SCB_showst=false;
  var iMod=ur_SCB_obj.newvalue%ur_SCB_obj.smallChange;
  if (Math.abs(iMod)>0) {
    if (ur_SCB_obj.smallChange/2>iMod) ur_SCB_obj.newvalue=ur_SCB_obj.newvalue-iMod;
    else ur_SCB_obj.newvalue=ur_SCB_obj.newvalue+ur_SCB_obj.smallChange-iMod;
  }
  if (ur_SCB_obj.newvalue!=ur_SCB_obj.value) {
    ur_SCB_obj.value=ur_SCB_obj.newvalue;
    ur_SCB_obj.ref.setAttribute("val",ur_SCB_obj.value);
    oEvt.ur_param=new Array();
    oEvt.ur_param["pos"]=ur_SCB_obj.value;
    oEvt.ur_param["dir"]=ur_SCB_obj.sdir;
    ur_EVT_fire(ur_SCB_obj.ref,"oscrlf",oEvt);
    if(ur_SCB_obj.sCallBackChange && ur_SCB_obj.sid) {
      window[ur_SCB_obj.sCallBackChange](ur_SCB_obj.sid, ur_SCB_obj.value);
    }
  }
}

function ur_Scrollbar_pageStart(o,sDir) {
  clearInterval(ur_SCB_timer);
  ur_Scrollbar_page(o,sDir);
  ur_SCB_showst=true;
  ur_SCB_timer=setInterval("ur_Scrollbar_page(ur_SCB_obj,'"+sDir+"')",100)
}

function ur_Scrollbar_scrollStart(o,sDir) {
  clearInterval(ur_SCB_timer);
  ur_Scrollbar_scroll(o,sDir);
  ur_SCB_showst=true;
  ur_SCB_timer=setInterval("ur_Scrollbar_scroll(ur_SCB_obj,'"+sDir+"')",50)
}

function ur_Scrollbar_correctStopValue(oEvt) {
  if (ur_SCB_obj.sdir=="v") {
    var newValue=ur_SCB_obj.range / ur_SCB_obj.totalPixels * oEvt.offsetY + ur_SCB_obj.min;
    var iPos=parseInt(ur_SCB_handle.style.marginTop);
    if (ur_scrollDir=="up" && newValue<iPos) ur_SCB_pixelStop=newValue;
    if (ur_scrollDir=="down" && newValue>iPos) ur_SCB_pixelStop=newValue;
  } else {
    var newValue=ur_SCB_obj.range / ur_SCB_obj.totalPixels * oEvt.offsetX + ur_SCB_obj.min;
    var iPos=parseInt(ur_SCB_handle.style.marginLeft);
    if (ur_scrollDir=="up" && newValue<iPos) ur_SCB_pixelStop=newValue;
    if (ur_scrollDir=="down" && newValue>iPos) ur_SCB_pixelStop=newValue;
  }
}

function ur_Scrollbar_stopButton(oEvt) {
  ur_SCB_evt=oEvt;
  if (ur_SCB_timer) window.clearInterval(ur_SCB_timer);
  //reset the button
  if (ur_SCB_src) {
    ur_SCB_src.className=ur_SCB_src.className.replace("urSCBBtnPressed","urSCBBtn");
    ur_SCB_src.detachEvent("onmouseup",ur_Scrollbar_stopButton);
    ur_SCB_src.detachEvent("onmouseout",ur_Scrollbar_stopButton);
    ur_SCB_src.detachEvent("onmousemove",ur_Scrollbar_correctStopValue);
    ur_SCB_handle.firstChild.className="urSCBBtn";
    ur_SCB_src.releaseCapture();
    ur_SCB_src=null;
  }
  ur_Scrollbar_fireChange(ur_SCB_obj, ur_SCB_evt);
  ur_SCB_handle=null;
}

function sapUrMapi_Scrollbar_registerCreate(sId) {
  sapUrMapi_Create_AddItem(sId, "ur_Scrollbar_init('"+sId+"')");
  //sapUrMapi_Resize_AddItem(sId, "ur_Scrollbar_resize('"+sId+"')");
}

var ur_iScrollbarResizeProcessObject;

function ur_Scrollbar_resize(oEvt) {
  if (!oEvt) return;
  var sId = ur_EVT_src(oEvt).id;
  if(!ur_iScrollbarResizeProcessObject) ur_iScrollbarResizeProcessObject = {};
  if(!ur_iScrollbarResizeProcessObject[sId]) ur_iScrollbarResizeProcessObject[sId] = 0;
  ur_iScrollbarResizeProcessObject[sId]++;
  ur_callDelayed("ur_Scrollbar_resize_serialized("+ur_iScrollbarResizeProcessObject[sId]+",'"+sId+"')",0);

}

function ur_Scrollbar_resize_serialized(iProcessId, sId) {
  if(iProcessId == ur_iScrollbarResizeProcessObject[sId]) {
    var oScrollbarObj = ur_Scrollbar_getObj(sId),
      sCallBackResize = oScrollbarObj.sCallBackResize,
      sConnnectedId = oScrollbarObj.sid;

    if(oScrollbarObj.sdir == "v") {
    	if(oScrollbarObj.iLastParentHeight == oScrollbarObj.ref.parentNode.offsetHeight) return;
    	oScrollbarObj.iLastParentHeight = oScrollbarObj.ref.parentNode.offsetHeight;
    }

    delete ur_iScrollbarResizeProcessObject[sId];
    oScrollbarObj = null;
    if(sCallBackResize && sConnnectedId) {
      window[sCallBackResize](sConnnectedId);
    }

    ur_SCB_arr[sId]=null;
    ur_Scrollbar_init(sId);
  }
}


function ur_Scrollbar_EnvironmentCleanUp() {
  ur_SCB_arr=null;
  ur_iScrollbarResizeProcessObject = null;
}

function ur_Scrollbar_EnvironmentInit() {
  ur_SCB_arr = new Array();
  ur_iScrollbarResizeProcessObject = {};
}

function ur_Scrollbar_getObj(sId) {
  var oDomRefScrollbar = ur_get(sId);
  if (!oDomRefScrollbar) return null;
  if (!ur_SCB_arr[sId]) {
    var obj = {id:sId,
         sid:ur_getAttD(oDomRefScrollbar,"sid",""),
         sdir:ur_getAttD(oDomRefScrollbar,"sdir",""),
         value:parseInt(ur_getAttD(oDomRefScrollbar,"val","0")),
         newvalue:parseInt(ur_getAttD(oDomRefScrollbar,"val","0")),
         max:parseInt(ur_getAttD(oDomRefScrollbar,"max","")),
         min:parseInt(ur_getAttD(oDomRefScrollbar,"min","")),
         smallChange:parseInt(ur_getAttD(oDomRefScrollbar,"sml","")),
         largeChange:parseInt(ur_getAttD(oDomRefScrollbar,"lrg","")),
         showscrolltip:ur_getAttD(oDomRefScrollbar,"scs","")=="1",
         scrolltipdefault:ur_getAttD(oDomRefScrollbar,"scd",""),
         sScrolltips:ur_getAttD(oDomRefScrollbar,"sct",""),
         scrolltips:null,
         ref:oDomRefScrollbar,
         handle:ur_get(sId+"-h"),
         sCallBackResize: ur_getAttD(oDomRefScrollbar,"cbRz", null),
         sCallBackChange: ur_getAttD(oDomRefScrollbar,"cbCh", null),
         iLastParentHeight: 0
        };

    
    // When firstVisibleRow is outside the allowed range while the table entries fit
    // in the visibleRowCount, the ScrollBar has to be enabled to allow a scrolling back to the
    // beginning
    if(obj.value > 1 && obj.min >= obj.max) obj.max=obj.value;

    if (obj.sdir == "v") {
      obj.iLastParentHeight = obj.ref.parentNode.offsetHeight;
      obj.totalPixels = obj.handle.parentNode.offsetHeight;
    } else {
      obj.totalPixels = obj.handle.parentNode.offsetWidth;
    }
    if (obj.value < obj.min) obj.value = obj.min;
    obj.range = obj.max-obj.min;
    obj.handlesize=ur_Scrollbar_getHandleSize(obj);
    
    // handle adaption
    if (obj.sdir == "v") {
    	obj.handle.style.width = "100%";
    	obj.handle.style.height = obj.handlesize;
    } else {
      obj.handle.style.width = obj.handlesize;
      obj.handle.style.height = "100%";
    }
    
    ur_SCB_arr[sId] = obj;
		
    

    if (ur_Scrollbar_isDisabled(obj)) {
      //set the images to disabled

    } else {
      //set the images to enabled
    }

    oDomRefScrollbar.attachEvent("onresize",ur_Scrollbar_resize);
    
    if(obj.sdir == "v" && obj.sid) {
    	//Support scrolling on scrolled element by mousewheel
    	var oScrolledElement = document.getElementById(obj.sid);
    	if(oScrolledElement && !oScrolledElement.getAttribute("urScrlbar")) {
    		oScrolledElement.attachEvent("onmousewheel", sapUrMapi_Scrollbar_handler);
    		oScrolledElement.setAttribute("urScrlbar", obj.id);
    	}
    }
    
    return obj;
  } else {
    return ur_SCB_arr[sId];
  }
}

function ur_Scrollbar_page(o,dir,oEvt) {
  if (!oEvt) oEvt=ur_SCB_evt;
  if (dir=="up") o.newvalue=o.newvalue-o.largeChange;
  else o.newvalue=o.newvalue+o.largeChange;
  if (o.newvalue>o.max) o.newvalue=o.max;
  if (o.newvalue<o.min) o.newvalue=o.min;

  //if (ur_SCB_pixelStop && dir=="up" && o.newvalue < ur_SCB_pixelStop - o.largeChange) o.newvalue = ur_SCB_pixelStop;
  //if (ur_SCB_pixelStop && dir=="down" && o.newvalue > ur_SCB_pixelStop  - o.largeChange) o.newvalue = ur_SCB_pixelStop;

  o.newvalue=Math.ceil(o.newvalue);
  ur_Scrollbar_applyHandlePos(o);
  ur_Scrollbar_showScrollTip(o,o.newvalue);
}

function ur_Scrollbar_scroll(o,dir,oEvt) {
  if (!oEvt) oEvt=ur_SCB_evt;
  if (dir=="up") o.newvalue=o.newvalue-o.smallChange;
  else o.newvalue=o.newvalue+o.smallChange;
  if (o.newvalue>o.max) o.newvalue=o.max;
  if (o.newvalue<o.min) o.newvalue=o.min;
  ur_Scrollbar_applyHandlePos(o);
  ur_Scrollbar_showScrollTip(o,o.newvalue);
}

function ur_Scrollbar_bounce(o,dir,oEvt) {
  if (!oEvt) oEvt=ur_SCB_evt;
  if (dir=="up") o.newvalue=o.min;
  else o.newvalue=o.max;
  ur_Scrollbar_applyHandlePos(o);
}

function ur_Scrollbar_getHandleSize(o) {

  if(ur_Scrollbar_isDisabled(o)) return 0;

  var iTotal = 0;
  var elemCount = o.range + o.largeChange;
  var iSize=Math.floor(o.totalPixels / elemCount * o.largeChange);

  if (iSize<6) iSize=6;
  if (o.totalPixels <= iSize) iSize=0;
  o.totalPixels = o.totalPixels;
  return iSize;
}

function ur_Scrollbar_applyHandleSize(o) {
  if(ur_Scrollbar_isDisabled(o)) {
    o.handle.style.display = "none";
  } else {
    o.handle.style.display = "block";
    if (o.sdir == "v") {
      o.handle.style.height = o.handlesize+"px";
      o.handle.firstChild.style.height = "100%"; //override 14px height set by style
    } else {
      o.handle.style.width = o.handlesize+"px";
      o.handle.firstChild.style.width = "100%"; //override 14px width set by style
    }
  }
}

function ur_Scrollbar_isDisabled(o) {
  return (o)? o.min >= o.max: false;
}

function ur_Scrollbar_applyHandlePos(o) {

  if(ur_Scrollbar_isDisabled(o)) return;

  var iVal = o.newvalue - o.min;
  iVal = Math.floor((o.totalPixels / o.range) * iVal);
  //correction of the position. The actual value moves from top to bottom of the handle depending on the handles position.
  if (o.totalPixels == 0) return;
  iVal=iVal - Math.ceil((o.handlesize / o.totalPixels) * iVal);

  if (iVal != 0) {
    if (iVal + o.handlesize >= o.totalPixels) iVal = o.totalPixels - o.handlesize;
  }
  if (o.sdir == "v") {
    o.handle.style.marginTop = iVal;
  } else {
    if (ur_system.direction=="rtl")
      o.handle.style.marginRight = iVal;
    else
      o.handle.style.marginLeft = iVal;
  }
}

function ur_Scrollbar_init(sId) {
   var o = ur_Scrollbar_getObj(sId);
   if (!o) return;
   ur_Scrollbar_applyHandleSize(o);
   ur_Scrollbar_applyHandlePos(o);

}

function sapUrMapi_Scrollbar_scroll(sId,oEvt) {
   var o = ur_get(sId);
   var oScr=ur_Scrollbar_getObj(ur_getRootObj(ur_EVT_src(oEvt).id));
   if (o && o.style.overflow=="hidden") {
      if (oScr.sdir=="v")
        o.scrollTop=(o.scrollHeight/oScr.range)*(oScr.value-oScr.min); //scroll in relation to the scroll container
      else
        o.scrollleft=(o.scrollWidth/oScr.range)*(oScr.value-oScr.min); //scroll in relation to the scroll container
   }
}

function ur_Scrollbar_hideScrollTip() {
  if (oPopup)
    oPopup.hide();
}

function ur_Scrollbar_showScrollTip(obj,val) {
  // shows a scrolltip for a specific scroll position
  // val = current position index of scrollbar
  if (obj.showscrolltip && ur_SCB_showst) {
    var oScrollTip=ur_get('ur-scrolltip');

    var s="<table class=\"urDataTipStd urDataTipTxt\" style=\"text-align:right;padding:1px 3px;height:16px;width:1px;\">";

    // row for application text is created
    if (obj.scrolltips) { // has application provided scrolltips
      var lastMatchValue;
      s += "<tr><td nowrap><b>";
      for(var n in obj.scrolltips) { //Search for the scrolltip given by the application
        if (n>val) break;
        else lastMatchValue=n;
      }
      //in the object the index of the corresponding scrolltip is stored
      var sDomObjIndex = obj.scrolltips[lastMatchValue];
      //with the index we can extract the html from the dom object with the id obj.id + "-sct-"+ sDomObjIndex
      var sHTML = ur_get(obj.id + "-sct-" + sDomObjIndex).innerHTML;
      s += sHTML + "</b></td></tr>";
    }

    // now the standard text is created (e.g. "Row X - Y of Z")
    var fromIndex=val, toIndex=fromIndex+obj.largeChange-1, ofCount=obj.max+obj.largeChange-1;

    if (obj.sdir=="v" && obj.scrolltipdefault=="ROW") {
      s += "<tr><td nowrap>" + getLanguageText("SAPUR_PG_ROW") + " " + fromIndex + " - " + toIndex + " " + getLanguageText("SAPUR_PG_INDEX") + " " + ofCount + "</td></tr>";
    } else if (obj.sdir=="h" && obj.scrolltipdefault=="COL") {
      s += "<tr><td nowrap>" + getLanguageText("SAPUR_PG_COLUMN") + " " + fromIndex + " - " + toIndex + " " + getLanguageText("SAPUR_PG_INDEX") + " " + ofCount + "</td></tr>";
    }

    oScrollTip.innerHTML= s + "</table>";

    if (obj.sdir=="v") {
      oScrollTip.firstChild.style.textAlign="right";
    } else
      oScrollTip.firstChild.style.textAlign="left";

	  var arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
    oPopup = new sapPopup(window,arrUrls,oScrollTip,obj.handle,0);
    oPopup.positionbehavior = sapPopupPositionBehavior.MENURIGHT;
    if (obj.sdir=="v") {
      oPopup.position.left-=obj.ref.offsetWidth;
      oPopup.position.top-=obj.handle.offsetHeight;
    } else {
      oPopup.position.left-=obj.handle.offsetWidth-oScrollTip.offsetWidth;
      oPopup.position.top-=obj.handle.offsetHeight+oScrollTip.offsetHeight;
    }
    oPopup.show(true);
  } else {
    if (oPopup)
      oPopup.hide();
  }
}


function ur_Scrollbar_setSizingParams(sId, iValue, iMax, iLargeChange) {
  var oDomRefScrollbar = ur_get(sId), oScrollBarObj = ur_SCB_arr[sId];

  if(oDomRefScrollbar) {
      oDomRefScrollbar.setAttribute("val", iValue);
      oDomRefScrollbar.setAttribute("max", iMax);
      oDomRefScrollbar.setAttribute("lrg", iLargeChange);
  }
  if (oScrollBarObj) {
    oScrollBarObj.value = iValue;
    oScrollBarObj.max = iMax;
    oScrollBarObj.largeChange = iLargeChange;
  }

}

function ur_Scrollbar_setCallback(sId, sCbRz, sCbCh) {
  var oDomRefScrollbar = ur_get(sId), oScrollBarObj = ur_SCB_arr[sId];

  if(oDomRefScrollbar) {
    oDomRefScrollbar.setAttribute("cbRz", sCbRz);
    oDomRefScrollbar.setAttribute("cbCh", sCbCh);
  }

  if (oScrollBarObj) {
    oScrollBarObj.sCallBackResize = sCbRz;
    oScrollBarObj.sCallBackChange = sCbCh;
  }
}