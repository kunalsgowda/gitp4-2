//* ************************************************************************
//* RoadMap
//* ************************************************************************

//* ------------------------------------------------------------------------
//* function    : ur_RM_RegisterCreate
//* parameter   : sId - string - Id of the RoadMap
//* description : Registers the RoadMap with the create item registry to be
//*				  initialized when the page loads
//* return      : none
//* ------------------------------------------------------------------------
function ur_RM_RegisterCreate(sId)
{
	 var oRm = ur_get(sId);
	if(parseInt(oRm.getAttribute("ic"))==0)return;
 	
 	if(!oRm.getAttribute('selectedstep'))
		oRm.setAttribute("selectedstep","-1");

	 if(oRm.getAttribute('scrl') == "1")
		sapUrMapi_Create_AddItem(sId, "ur_RM_create('" + sId + "')");
	 else
	 {
		if(oRm.getAttribute('selectedstep') == "-1")
		{
			sapUrMapi_setTabIndex(ur_get(sId+'-itm-0'),0);
			oRm.setAttribute("focusedstep","0");
		}
		else
		{
			sapUrMapi_setTabIndex(ur_get(sId+'-itm-'+oRm.getAttribute('selectedstep')),0);
			oRm.setAttribute("focusedstep",oRm.getAttribute('selectedstep'));
		}	
	 }
}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RoadMapEdgesHover
//* parameter   : sId - string Id of the RoadMap
//* parameter   : sEdgeName - string - identifies which roadmap edge recieves the event - 'start'/'end'
//* parameter   : sBool - string - true on mouse over / false on mouse out
//*             : e   - Event Object
//* return      : none
//*	description	: hovereffect on morebefore/after icon
//* ------------------------------------------------------------------------
function sapUrMapi_RoadMap_hoverEdges(sId,edgeType,e){
	var oS= ur_get(sId + "-itm-start");
	var sBts=oS.childNodes[0].className;
	var oE= ur_get(sId + "-itm-end");
	var sBte=oE.childNodes[0].className;
	
	if(e.type=="mouseover" && sBts=="urRMMoreBefore" && edgeType=="start"){
		oS.childNodes[0].className="urRMMoreBeforeHover";
	}
	else if(e.type=="mouseout" && sBts=="urRMMoreBeforeHover" && edgeType=="start"){
		oS.childNodes[0].className="urRMMoreBefore";
	}
	else if(e.type=='mouseover' && sBte=='urRMMoreAfter' && edgeType=="end"){
		oE.childNodes[0].className='urRMMoreAfterHover';
	}
	else if(e.type=='mouseout' && sBte=='urRMMoreAfterHover'&& edgeType=="end"){
		oE.childNodes[0].className='urRMMoreAfter';
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RoadMap_hoverStep
//* parameter   : sId - string Id of the RoadMap
//*             : sStepNr   - string - index of hovered roadmap step
//*				: e - event object
//* return      : none
//*	description	: makes a hovereffect on a step
//* ------------------------------------------------------------------------

function sapUrMapi_RoadMap_hoverStep(sId,iStepNr,e){

	var iSel=parseInt(ur_get(sId).getAttribute("selectedstep"));
	var oTitle = ur_get(sId + "-itm-" + iStepNr).childNodes[1];

	if( iSel == iStepNr || oTitle.className == "urRMNoItem")return;

	if(e.type=="mouseover"){
	   oTitle.className = "urRMStepItem urRMItemHover";
	}
	else if(e.type=="mouseout"){
	   oTitle.className = "urRMStepItem";
	}

}
//* ------------------------------------------------------------------------
//* function    : ur_RM_create
//* parameter   : sId - string Id of the RoadMap
//* return      : none
//*	description	: needed to reset to its original state during scroll
//* ------------------------------------------------------------------------
function ur_RM_create(sId)
{
	ur_get(sId+'-itm-start').setAttribute("stDsgn",ur_get(sId+'-itm-start').firstChild.className);
	ur_get(sId+'-itm-end').setAttribute("endDsgn",ur_get(sId+'-itm-end').firstChild.className);	
	
	ur_IScr_getObj(sId);
	ur_IScr_create(sId);
	sapUrMapi_Resize_AddItem(sId, "ur_IScr_resize('"+sId+"')");
    var oRm = ur_get(sId);
    var oRmScrl = ur_IScr[sId];
    var iSel = parseInt(oRm.getAttribute('selectedstep'));
    var iFoc = parseInt(oRm.getAttribute('focusedstep'));
    var iFScrl = parseInt(oRmScrl.first);
    var iLScrl = parseInt(oRmScrl.last);
	if(iSel <= iLScrl && iSel >=iFScrl)
	{
		sapUrMapi_setTabIndex(ur_get(sId+'-itm-'+iSel),0);
		oRm.setAttribute('focusedstep',iSel);
	}
	else
	{
		sapUrMapi_setTabIndex(ur_get(sId+'-itm-'+iFScrl),0);
		oRm.setAttribute('focusedstep',iFScrl);
	}
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RoadMap_focusSelected
//* parameter   : sId - string Id of the RoadMap
//*             : e   - Event Object
//* return      : none
//*	description	: focuses the currently selected item when whole control is selected and arrow keys are pressed
//* ------------------------------------------------------------------------
function sapUrMapi_RoadMap_focusSelected(sId,e){
	
	var iSelected=parseInt(ur_get(sId).getAttribute('selectedstep'));
	if(e.keyCode==9){
	/*	if (isNaN(iSelected)) 
		{
			if (ur_get(sId).getAttribute('stepamount')!="0") 
			{
				sapUrMapi_setTabIndex(ur_get(sId + '-itm-0'),-1);
			} 
		} else {
			sapUrMapi_setTabIndex(ur_get(sId + '-itm-' + iSelected),-1);
		}*/
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RoadMap_keydown
//* parameter   : sId - string Id of the RoadMap
//*             : sStepName   - string - declaration of all possible roadmap steps
//*             : e   - Event Object
//* return      : none
//*	description	: delivers keyboard navigation through roadmap
//* ------------------------------------------------------------------------

function sapUrMapi_RoadMap_keydownStep(sId,sStepName,e){
	sapUrMapi_RoadMap_keydown(sId,sStepName,e);
}

function sapUrMapi_RoadMap_keydownEdge(sId,sStepName,e){
	sapUrMapi_RoadMap_keydown(sId,sStepName,e);
}

function sapUrMapi_RoadMap_keydown(sId,sStepName,e){
	var oRm = ur_get(sId);
	var iItemCount=parseInt(oRm.getAttribute('stepamount'));
	var iItemFocus=parseInt(oRm.getAttribute('focusedstep'));
	var iSelected=parseInt(oRm.getAttribute('selectedstep'));
	var oStart=ur_get(sId + '-itm-start').childNodes.item(0);
	var oEnd=ur_get(sId + '-itm-end').childNodes.item(0);
	var oRmScrl = ur_IScr[sId];
	var iFirst = (oRmScrl!= null) ? oRmScrl.first : 0;
	var iLast = (oRmScrl!=null) ? oRmScrl.last : iItemCount;
	var scrlMode = oRm.getAttribute("scrl");
//turns string that comes with sStepName into integer
	if(sStepName != 'start' && sStepName != 'end'){
		var iStepIdx=parseInt(sStepName);
	   }

//looks whether there is a bMoreBefore/bMoreAfter icon
		if(oStart.className=='urRMMoreBefore' || oStart.className=='urRMMoreBeforeDsbl'){
		var bMoreBefore=true;
		}else{
		var bMoreBefore=false;
		}

		if(oEnd.className=='urRMMoreAfter' || oEnd.className=='urRMMoreAfterDsbl'){
		var bMoreAfter=true;
		}else{
		var bMoreAfter=false;
		}

	var sStep='-itm-';
	var sStep0=sStep + '0'
	var sLastStep=sStep + iItemCount	// defines the last step
	var sFocusStep=sStep + iStepIdx;        // defines focused step
	var sNextStep=sStep + (iStepIdx + 1);  // increases the step id by one
	var sPrevStep=sStep + (iStepIdx - 1); // decreases the step id by one
	var sStart='start';
	var sEnd='end';

	//sets focus one step further to the right
	// where 'right' in rtl mode means 'towards start' and in ltr mode it means 'towards end'
	if(e.keyCode==39) {
	  if (ur_system.direction=="rtl") {
	    //if focus is somewhere in the middle, sets focus one step further to the right
	    if (iStepIdx > 0){
	       sapUrMapi_RoadMap_setFocus(sId,sFocusStep,(iStepIdx - 1));
	    }
	    //if focus is on end icon, last item gets focused
	    if (sStepName==sEnd){
	       sapUrMapi_RoadMap_setFocus(sId,(sStep + sEnd),sLastStep);
	    }
	    //if focus is on first item and there is a bMoreBefore icon, Page-wise scroll happens
	    if(iStepIdx > 0 && bMoreBefore==true && iStepIdx == iFirst){
	      //sapUrMapi_RoadMap_setFocus(sId,sStep0,(sStep + sStart));
   	       ur_IScr_toPrevPage(sId);
		   var inewIdx = iLast;
		   sNextStep=sStep + inewIdx;
		   sapUrMapi_RoadMap_setFocus(sId,sFocusStep,(iStepIdx - 1));
	    }
	  } else {
	    //if focus is somewhere in the middle, sets focus one step further to the right
	    if (sStepName < iItemCount){
	       sapUrMapi_RoadMap_setFocus(sId,sFocusStep,(iStepIdx + 1));
	    }
	    //if focus is on the last item and there is a bMoreAfter icon, Page-wise scroll happens
		if (iStepIdx<iItemCount && bMoreAfter==true && iStepIdx == iLast){
		   //sapUrMapi_RoadMap_setFocus(sId,sLastStep,(sStep + sEnd));
		   ur_IScr_toNextPage(sId);
		   var inewIdx = iFirst;
		   sNextStep=sStep + inewIdx;
		   sapUrMapi_RoadMap_setFocus(sId,sFocusStep,(iStepIdx + 1));
	    }
	    //if focus is on on the icon at the beginning, the first item is focused
	    if (sStepName==sStart){
	       sapUrMapi_RoadMap_setFocus(sId,(sStep + sStart),sStep0);
	    }
	  }
	}
	//sets focus one step further to the left
	// where 'left' in rtl mode means 'towards end' and in ltr mode it means 'towards start'
	if(e.keyCode==37) {
	  if (ur_system.direction=="rtl") {
	    //if focus is somewhere in the middle, sets focus one step further to the left
	    if (iStepIdx < iItemCount){
	       sapUrMapi_RoadMap_setFocus(sId,sFocusStep,(iStepIdx+1));
	    }
	    //if focus is on the last item and there is a bMoreAfter icon, Page-wise scroll happens
		if (iStepIdx<iItemCount && bMoreAfter==true && iStepIdx == iLast){
		   
		   ur_IScr_toNextPage(sId);
		   var inewIdx = iFirst;
		   sNextStep=sStep + inewIdx;
		   sapUrMapi_RoadMap_setFocus(sId,sFocusStep,(iStepIdx + 1));
	    }
	    //if focus is on on the icon at the beginning, the first item is focused
	    if (sStepName==sStart){
	       sapUrMapi_RoadMap_setFocus(sId,(sStep + sStart),sStep0);
	    }
	  } else {
	    //if focus is somewhere in the middle, sets focus one step further to the left
	    if (iStepIdx > 0){
	       sapUrMapi_RoadMap_setFocus(sId,sFocusStep,(iStepIdx-1));
	    }
	    //if focus is end icon, last item gets focused
	    if (sStepName==sEnd){
	       sapUrMapi_RoadMap_setFocus(sId,(sStep + sEnd),sLastStep);
	    }
	    //if focus is on first item and there is a bMoreBefore icon, Page-wise scroll happens
	    if(iStepIdx > 0 && bMoreBefore==true && iStepIdx == iFirst){
	      //sapUrMapi_RoadMap_setFocus(sId,sStep0,(sStep + sStart));
   	       ur_IScr_toPrevPage(sId);
		   var inewIdx = iLast;
		   sNextStep=sStep + inewIdx;
		   sapUrMapi_RoadMap_setFocus(sId,sFocusStep,(iStepIdx-1));
	    }
	  }
	}
	// Handling of Home, End, PgUp and PgDn keys.
	if (ur_system.direction=="rtl")
	{
		if(scrlMode == "1")
		{
			if(e.keyCode==35)//  End Key in RTL in Scrl Mode
			{
				ur_IScr_toBegin(sId);
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,iFirst);
			}
			else if(e.keyCode==36)// Home key in RTL in Scrl Mode
			{
				ur_IScr_toEnd(sId);
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,iLast);
			}
			else if(e.keyCode==33)		
			{
				ur_IScr_toPrevPage(sId);
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,iLast);
			}
			else if(e.keyCode==34)
			{
				ur_IScr_toNextPage(sId);
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,iLast);
			}
		}
		else
		{
			if(e.keyCode==35)// End Key in RTL
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,0);
			else if(e.keyCode==36)//Home key in RTL
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,iItemCount);
			else if(e.keyCode==33)		
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,iItemCount);
			else if(e.keyCode==34)
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,0);
		}
	}
	else
	{
		if(scrlMode == "1")
		{
			if(e.keyCode==35)// End Key in Scrl mode
			{
				ur_IScr_toEnd(sId);
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,iLast);
			}
			else if(e.keyCode==36)// Home Key in Scrl Mode
			{
				ur_IScr_toBegin(sId);
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,iFirst);
			}
			else if(e.keyCode==33)		
			{
				ur_IScr_toPrevPage(sId);
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,iFirst);
			}
			else if(e.keyCode==34)
			{
				ur_IScr_toNextPage(sId);
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,iFirst);
			}
					
		}
		else
		{
			if(e.keyCode==35)//End Key
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,iItemCount);
			else if(e.keyCode==36)// Home key
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,0);
			else if(e.keyCode==33)		
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,0);
			else if(e.keyCode==34)
				sapUrMapi_RoadMap_setFocus(sId,sFocusStep,iItemCount);

		}
	}
	
	if(e.keyCode==9 && iSelected == "-1")
	{
		sapUrMapi_RoadMap_setFocus(sId,(sStep + iItemFocus),iFirst);
	}	
	else
	{
		//if focus is on a default step, the selected step recieves a tabindex, after jumping out of the roadmap with tap key
		if(e.keyCode==9 && iSelected != iItemFocus)
		{
			if(sStepName != sStart && sStepName != sEnd)
			{
	   			if(oRm.getAttribute('scrl') == '1')
	   				if(iSelected >= iFirst && iSelected <=iLast)
	   					sapUrMapi_RoadMap_setFocus(sId,(sStep + iItemFocus),iSelected);
	   				else
	   					sapUrMapi_RoadMap_setFocus(sId,(sStep + iItemFocus),iFirst);
	   			else
	   				sapUrMapi_RoadMap_setFocus(sId,(sStep + iItemFocus),iSelected);
			}
			if(sStepName == sStart){
				sapUrMapi_RoadMap_setFocus(sId,(sStep + sStart),(sStep + iSelected));
			}
			if(sStepName == sEnd){
	   			sapUrMapi_RoadMap_setFocus(sId,(sStep + sEnd),(sStep + iSelected));
			}
		}
	 }
	 if(e.keyCode==32){
	 	sapUrMapi_RoadMap_setFocus(sId,(sStep+iSelected),iItemFocus);
	 	sapUrMapi_triggerClick(e,new Array('32'));
	 	
	 }
	 //GG: hierarchische Navigation funktioniert nicht mit RM, wenn event gecancelt wird.
	 //ur_EVT_cancelBubble(e);
	 
	if((e.keyCode>=33 && e.keyCode<=37) || e.keyCode==39  )
		e.returnValue=false;
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RoadMap_setFocus
//* parameter   : sId - string Id of the RoadMap
//*             : iStepIdx   - string - index of a single step
//*             : e   - Event Object
//* return      : none
//*	description	: sets focus and enables keyboard navigation
//* ------------------------------------------------------------------------
function sapUrMapi_RoadMap_setFocus(sId,sOldStep,iNewStep,iIdx){
	
	var oRm = ur_get(sId);
	var oOldFoc = ur_get(sId+'-itm-'+oRm.getAttribute("focusedstep"));
	var oNewFoc = ur_get(sId+'-itm-'+iNewStep)
	sapUrMapi_setTabIndex(oOldFoc,-1);
	sapUrMapi_setTabIndex(oNewFoc,0);
	ur_get(sId).setAttribute("focusedstep",iNewStep);
	
	ur_focus(oNewFoc);
}




//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RoadMap_setFocusIdx
//* parameter   : sId - string Id of the RoadMap
//*             : iStepIdx   - string - index of a single step
//*             : e   - Event Object
//* return      : none
//*	description	: changes in html predefined variables correctly
//* ------------------------------------------------------------------------
function sapUrMapi_RoadMap_setFocusStep(sId,iStepIdx,e){
	sapUrMapi_RoadMap_setFocusIdx(sId,iStepIdx,e);
}

function sapUrMapi_RoadMap_setFocusEdge(sId,iStepIdx,e){
	sapUrMapi_RoadMap_setFocusIdx(sId,iStepIdx,e);
}

function sapUrMapi_RoadMap_setFocusIdx(sId,iStepIdx,e){
	ur_get(sId).focusedstep=iStepIdx;
	
	ur_EVT_cancelBubble(e);
}

//* ------------------------------------------------------------------------
//* function    : ur_RM_oadi
//* parameter   : sId - string Id of the RoadMap
//*           
//*           
//* return      : none
//*	description	: The on after draw function for RoadMap specific re-drawing of images
//* ------------------------------------------------------------------------


function ur_RM_oadi(sId,oEvt)
{
	var o = ur_IScr[sId];
	if(o.first!= 0)
		ur_get(sId+'-itm-start').firstChild.className = "urRMMoreBefore";
	else
		ur_get(sId+'-itm-start').firstChild.className = ur_get(sId+'-itm-start').getAttribute("stDsgn");
	if(o.last != o.items.length-1)
	{
		ur_get(sId+'-itm-end').firstChild.className = "urRMMoreAfter";
				
	}
	else
	{
		ur_get(sId+'-itm-end').firstChild.className = ur_get(sId+'-itm-end').getAttribute("endDsgn");
	}
}

//* ------------------------------------------------------------------------
//* function    : ur_RM_s
//* parameter   : sId - string Id of the RoadMap
//*           	  iNr - step number
//*           	  oEv - event object
//* return      : none
//*	description	: Client side step selection
//* ------------------------------------------------------------------------

function ur_RM_select(sId,iNr,oEv){
        var o = ur_get(sId + "-itm-" + iNr);
        var iSelectedIdx = parseInt(ur_get(sId).getAttribute("selectedstep"));
	
	//change design of selected step
	if( o.st && o.st.indexOf("d") > -1  ||
		iSelectedIdx == iNr ||
		o.className == "urRMNotInterActive") return;
		
	var oStepN = o.getElementsByTagName("TD")[1];
	var oTitleN = o.childNodes[1];
	var oRm = ur_get(sId);
		
	oStepN.className = oStepN.className + "Sel";
	oTitleN.className = "urRMStepItem";
	oTitleN.className = oTitleN.className + "Sel";
	//change 508 sttributes and refocus selected step
	if (ur_system.is508) {
		ur_setSt(o,ur_st.NOTSELECTED,false);
		ur_setSt(o,ur_st.SELECTED,true);
		sapUrMapi_refocusElement(o);
	}
	//deselect previous selected, if there is one
	if (iSelectedIdx != -1) {
		var o = ur_get(sId + "-itm-" + iSelectedIdx);
		var oStepO = o.getElementsByTagName("TD")[1];
		var oTitleO = o.childNodes[1];
		
		oStepO.className = oStepO.className.split("Sel")[0];
		oTitleO.className = oTitleO.className.split("Sel")[0];
		sapUrMapi_setTabIndex(oStepO,-1);
			
		if (ur_system.is508) {
			ur_setSt(o,ur_st.NOTSELECTED,true);
			ur_setSt(o,ur_st.SELECTED,false);
		}
	}
		
	//change all according tabindex attributes
	sapUrMapi_setTabIndex(oStepN,0);
	oRm.setAttribute("focusedstep", iNr);
	oRm.setAttribute("selectedstep", iNr);

	// if selection is done programmatically by using this function, the selected step may disappear.
	// Then scroll it into view.
	if ( oRm.scroll == 1 ){
		ur_EVT_addParam(oEv,"FirstVisibleItemIdx",ur_IScr[sId].first);
    	var bVisible = ur_IScr[sId].items[iNr].visible;

	    if ( bVisible ) 
			ur_IScr_draw(sId);
	    else {
	      ur_IScr[sId].first = iNr;
	      ur_IScr[sId].last = -1;
	      ur_IScr_draw(sId);
	    }
    }
}
//* ------------------------------------------------------------------------
//* function    : ur_RM_Scrl
//* parameter   : sId - string Id of the RoadMap
//*           	  
//* return      : none
//*	description	: Invoked when RoadMap is in Scroll mode.
//* ------------------------------------------------------------------------

function ur_RM_Scrl(sId,edgeType,oEvt)
{
	iRmItms = parseInt(ur_get(sId).getAttribute("ic"));	
	if(iRmItms==0)return;
	oRmStart = ur_get(sId+'-itm-start');
	oRmEnd = ur_get(sId+'-itm-end');
	oRmScrl = ur_IScr[sId];
	if( oRmStart.firstChild.className.indexOf("Before") > -1 && edgeType == "start" && oRmScrl.first != 0)
	{
		ur_IScr_toPrevPage(sId);
	}
	else if( oRmEnd.firstChild.className.indexOf("After") && edgeType == "end" && oRmScrl.last != (iRmItms - 1) )
	{
		ur_IScr_toNextPage(sId);
	}
	else if( oRmStart.firstChild.className.indexOf("Before") > -1 || oRmScrl.first == 0 && edgeType == "start") 
	{
		ur_EVT_fire(oRmStart,"onscrl");
	}
	else if( oRmEnd.firstChild.className.indexOf("After") > -1 || oRmScrl.last == iRmItms-1 && edgeType == "end")
	{
		ur_EVT_fire(oRmEnd,"onscrl");
	}
	ur_EVT_addParam(oEvt,"FirstVisibleItemIdx",ur_IScr[sId].first);
}

//* ------------------------------------------------------------------------
//* function    : ur_RM_resetTab
//* parameter   : sId - string Id of the RoadMap
//*           	  
//* return      : none
//*	description	: Re-sets the TabIndex when Client side Scroll is invoked in RoadMap
//* ------------------------------------------------------------------------
function ur_RM_resetTab(sId)
{
	
	var oRm = ur_get(sId);
	var oRmScrl = ur_IScr[sId];
	var iSel = parseInt(oRm.getAttribute('selectedstep'));
	var iFoc = parseInt(oRm.getAttribute('focusedstep'));
	if(iSel == -1)
	{
		
		sapUrMapi_RoadMap_setFocus(sId,sId+'-itm'+iFoc,oRmScrl.first);
	}
	else
	{
		if(iSel <= oRmScrl.last && iSel >=oRmScrl.first)
			sapUrMapi_RoadMap_setFocus(sId,sId+'-itm'+iFoc,iSel);
		else
			sapUrMapi_RoadMap_setFocus(sId,sId+'-itm'+iFoc,oRmScrl.first);
	}
}
