enumUrMessageBarType = {ERROR:"Error",WARNING:"Warning",OK:"Ok",STOP:"Stop",LOADING:"Loading",NONE:"None",TEXT:"Text"};

function sapUrMapi_MessageBar_setAccText(sId,vMessageBarType) {
	var oMBar = ur_get(sId);
	var oMTxt = ur_get(sId+"-txt");
	var sMTxt = oMTxt.innerText;
	if (oMTxt.getAttribute("tt")!=null && oMTxt.getAttribute("tt")!="") sMTxt=oMTxt.getAttribute("tt");
	var sType = vMessageBarType.toUpperCase(); 
	var bHasConId = oMBar.onclick!=null;
	var sTxt = "";
	if (bHasConId) sTxt="SAPUR_MSG_JUMPKEY"; 
	if (vMessageBarType!=enumUrMessageBarType.TEXT) {
		if (ur_system.is508) {
			oMBar.title=getLanguageText("SAPUR_MSG",new Array("SAPUR_MSG_"+sType,sMTxt,sTxt));
		} else {
		  oMBar.title=sMTxt;
		}
	} else {
		if (ur_system.is508) {
			oMBar.title=getLanguageText("SAPUR_MSG",new Array("",sMTxt,sTxt));
		} else {
		  oMBar.title=sMTxt;
		}
	}
}

function sapUrMapi_MessageBar_setType(sId,vMessageBarType) {
	var oMBar = ur_get(sId);
	sapUrMapi_MessageBar_setAccText(sId,vMessageBarType);
	if (vMessageBarType==enumUrMessageBarType.NONE) {
		oMBar.style.display = 'none';
		return;
	} else {
		if (vMessageBarType==enumUrMessageBarType.ERROR || vMessageBarType==enumUrMessageBarType.STOP) oMBar.className="urMsgBarErr";
		else oMBar.className="urMsgBarStd";
		oMBar.style.display = 'block';
    var oMBarImg  = ur_get(sId+"-img");
    if (vMessageBarType!=enumUrMessageBarType.TEXT) {
    	oMBarImg.style.display="inline";
      oMBarImg.className = "urMsgBarImg"+vMessageBarType;
    } else {
    	oMBarImg.style.display="none";
    }
	}
}

function sapUrMapi_MessageBar_getType(sId) {
	var oMBar = ur_get(sId);
  if (oMBar.style.display == 'none') {
  	return enumUrMessageBarType.NONE;
  } else {
    var oMBarImg  = ur_get(sId+"-img");
    if ((oMBarImg.className).indexOf(enumUrMessageBarType.ERROR)>-1) return enumUrMessageBarType.ERROR;
    if ((oMBarImg.className).indexOf(enumUrMessageBarType.WARNING)>-1) return enumUrMessageBarType.WARNING;
    if ((oMBarImg.className).indexOf(enumUrMessageBarType.LOADING)>-1) return enumUrMessageBarType.LOADING;
    if ((oMBarImg.className).indexOf(enumUrMessageBarType.STOP)>-1) return enumUrMessageBarType.STOP;
    if ((oMBarImg.className).indexOf(enumUrMessageBarType.OK)>-1) return enumUrMessageBarType.OK;
    if ((oMBarImg.style.display).indexOf("none")>-1) return enumUrMessageBarType.TEXT;
  }
}
function sapUrMapi_MessageBar_setText(sId,sText) {
	var oMBarText = ur_get(sId+"-txt");
	oMBarText.innerHTML = sText;
	sapUrMapi_MessageBar_setAccText(sId,sapUrMapi_MessageBar_getType(sId));
}
function sapUrMapi_MessageBar_getText(sId) {
	var oMBarText = ur_get(sId+"-txt");
	return oMBarText.innerHTML;
}

function sapUrMapi_MessageBar_navigateToField(sId,sConId,oEvt) {
  //check if click or spacebar was pressed
  if ((oEvt.type=="click") || (sapUrMapi_checkKey(oEvt,"keydown",new Array("32")))) {
    //cancel events
    ur_EVT_cancel(oEvt);
    sapUrMapi_triggerFocus(sConId);
  }
}
