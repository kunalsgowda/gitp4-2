//GET SELECTION
function sapUrMapi_DropDownListBox_getSelectedKey(sId) {
	oSelect = ur_get(sId);
	return oSelect.options[oSelect.selectedIndex].value;
}
//SET SELECTION
function sapUrMapi_DropDownListBox_setSelectedKey(sId,sKey) {
	oSelect = ur_get(sId);
	for (var n=0;n<oSelect.options.length;n++) {
		if (oSelect.options[n].value==sKey) {
			oSelect.selectedIndex=n; return;
		}
	}
}
//GET SELECTED INDEX
function sapUrMapi_DropDownListBox_getSelectedIndex(sId) {
	return ur_get(sId).selectedIndex;
}
//SET SELECTED INDEX
function sapUrMapi_DropDownListBox_setSelectedIndex(sId,iIndex) {
	ur_get(sId).selectedIndex=iIndex;
}
//FOCUS
function sapUrMapi_DropDownListBox_focus(sId) {
   sapUrMapi_focusElement(sId);
}

//ADD OPTIONS
function sapUrMapi_DropDownListBox_addOptions(sId,oKeyValuePairs,sSelectedKey) {
  for(var elem in oKeyValuePairs)
    sapUrMapi_DropDownListBox_addOption(sId,elem,oKeyValuePairs[elem],elem==sSelectedKey);
}
//ADD OPTION
function sapUrMapi_DropDownListBox_addOption(sId,sKey,sValue,bSelected) {
  var ddlb = ur_get(sId);
  ddlb.options[ddlb.options.length] = new Option(sValue,sKey);
  if (bSelected) ddlb.options[ddlb.options.length-1].selected=true;
}
//KEYDOWN
function sapUrMapi_DropDownListBox_keydown(sId,oEvt){
	if(oEvt.keyCode==40 || oEvt.keyCode==38) ur_EVT_cancelBubble(oEvt);
}


