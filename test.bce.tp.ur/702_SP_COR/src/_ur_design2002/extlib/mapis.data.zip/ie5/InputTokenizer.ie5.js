//* ************************************************************************
//* InputTokenizer
//* ************************************************************************
//* ------------------------------------------------------------------------
//* global variables
//* oLastSelTextRange - a pointer to a valid text range object
//* ------------------------------------------------------------------------
var oLastSelTextRange = null;
var sCharKeyCodes = ",48,49,50,51,52,53,54,55,56,57,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,96,97,98,99,100,101,102,103,104,105,106,107,109,110,111,186,187,188,189,190,191,192,219,220,221,222,"

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_MouseUp
//* parameter   : none
//* return      : none
//*	description	: this sets a global variable equal to a generic document 
//*								text range object
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_MouseUp() {
	oLastSelTextRange = document.selection.createRange();
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_Click
//* parameter   : sId - the id of the HTML element we are seaching for tokens in
//*               oEv - window event object
//* return      : none
//*	description	: this selects a text range surrounding a given token based on 
//*								where the user clicked their mouse
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_Click(sId, oEv) {	  	  
	var i = ur_get(sId);
	if (i!=null && i.innerText != "") {
		sName = sapUrMapi_InputTokenizer_selectToken(i,oLastSelTextRange);
	}
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_KeyDown
//* parameter   : sId - id of the HTML element whose innerText needs to be  
//*								validated against a token list
//*               oEv - window event object
//* return      : modifies the innerHTML of the HTML element, creating a visual
//*								representation of the valid/invalid tokens contained therein
//*	description	: this checks for valid tokens in the HTML element's innerText
//*								and marks those elements as valid or invalid
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_KeyDown(sId, oEv) {
	var selTextRange = document.selection.createRange();
	var inp = ur_get(sId);
	if (oEv.keyCode == 13) {	
		//if the user presses enter, fire the validation code
		var inp = ur_get(sId);
		var btn = ur_get(inp.getAttribute("vb"));
			if (btn != null) {
			  btn.click();
			   aChars=null;
			}
		oEv.keyCode=35;
		ur_EVT_cancelBubble(oEv);
		return false;
	}
	else if((oEv.keyCode == 8 || oEv.keyCode ==46)&& inp.innerText != ""){
		if(selTextRange.text.length != 0){
			return;
		}else{
			selTextRange.move("character",-1);
			name=sapUrMapi_InputTokenizer_selectToken(inp,selTextRange,oEv);
			if(name!=""){
				selTextRange.parentElement().className = "urTknUnchecked";
			}
		}
	}
	
	else if ((oEv.keyCode == 39 || oEv.keyCode == 46) && (inp.innerText != "")) {
		if (selTextRange.text.length == 0 && !oEv.shiftKey){
			selTextRange.move("character",1);
			sapUrMapi_InputTokenizer_selectToken(inp,selTextRange,oEv);
			
		}else{
			selTextRange.collapse(false);
			selTextRange.move("character",1);
			sapUrMapi_InputTokenizer_selectToken(inp,selTextRange,oEv);
		}
	}
	
	else if (oEv.keyCode == 37 && inp.innerText != "") {
		selTextRange.move("character",-1);
		sapUrMapi_InputTokenizer_selectToken(inp,selTextRange,oEv);
	}
	else {
		if (sCharKeyCodes.indexOf("," + oEv.keyCode + ",") != -1) {
			if (selTextRange.parentElement() != null && selTextRange.parentElement().tagName.toLowerCase() == "span") {
			 selTextRange.parentElement().className = "urTknUnchecked";
			}
		}
	}
	
	ur_callDelayed("sapUrMapi_Focus_showFocusRect()",0);
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_selectToken
//* parameter   : oInput - pointer to HTML element containing needed values
//*               oSelRange - pointer to valid TextRange object
//* return      : string - either the value of the token's text or an empty string
//*	description	: this searches a given text range for valid tokens and selects
//*								them into the text range, the function then returns the text
//*								value of the token to the caller
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_selectToken(oInput, oSelRange,oEv) {
	var sValue = oInput.innerText;
	var delim = oInput.getAttribute("delimiter");
	var inputtokens = sapUrMapi_InputTokenizer_splitTokens(oInput);
	//var tokenlist = window[oInput.getAttribute("listid"))];
	var tokenlist = sapUrMapi_InputTokenizer_getTokenList(oInput);
	var usecase = oInput.getAttribute("casesensitive");
	var charToMove = 0;
	for (i = 0; i < inputtokens.length; i++) {
	  var range = document.body.createTextRange();
		range.findText(sValue);
		//move to the start of our token
		charToMove = sValue.indexOf(inputtokens[i]);
		range.moveStart("character", charToMove);
		if (inputtokens[i].length > 2) {
			if ((range.findText(inputtokens[i]+delim)) && (range.inRange(oSelRange)) ) {
				if (sapUrMapi_InputTokenizer_matchToken(inputtokens[i], tokenlist, usecase)) {
					if(typeof(oEv)!="undefined"){
						if(oEv.keyCode==39){
							if(oEv.shiftKey){
								range.moveEnd("character",-1);
								range.select();
								return range.text;
								}
						}
						if(oEv.keyCode==37){
							if(oEv.shiftKey){
								range.moveEnd("character",1);
								range.select();
								return range.text;
								}
						}
					}
					range.select();
					return range.text;
				}
				else {
					return range.text;
				}
		  }
		}
	}
	return "";
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_markValidTokens
//* parameter   : sId - id of the HTML element whose innerText needs to be  
//*								validated against a token list
//* return      : modifies the innerHTML of the HTML element, creating a visual
//*								representation of the valid/invalid tokens contained therein
//*	description	: this checks for valid tokens in the HTML element's innerText
//*								and marks those elements as valid or invalid
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_markValidTokens(sId) {
	var oInput = ur_get(sId);
	var val = oInput.innerText;
	var delim = oInput.getAttribute("delimiter");
	if (val == "") { return; }
	var tokenlist = sapUrMapi_InputTokenizer_getTokenList(oInput);
	var keymap = sapUrMapi_InputTokenizer_getKeyMap(oInput);
	var usecase = oInput.getAttribute("casesensitive");
	var newValue = "";
	var msg = "";
	var evt = "";
	var inputtokens = sapUrMapi_InputTokenizer_splitTokens(oInput);
	for (i = 0; i < inputtokens.length; i++) {
	  if (sapUrMapi_InputTokenizer_matchToken(inputtokens[i], tokenlist, usecase)) {
			if (ur_system.is508) {
				tl = inputtokens[i]
				//msg = "title='" + getLanguageText("SAPUR_IT_TK", new Array(inputtokens[i],"SAPUR_IT_V",i+1,inputtokens.length)) + "'";
			}
			evt = "onclick=\"sapUrMapi_InputToken_Click('" + keymap[inputtokens[i]] + "',event);\" ondoubleclick=\"sapUrMapi_InputToken_DblClick('" + keymap[inputtokens[i]] + "',event);\"";
	    	inputtokens[i] = "<span st=\"v\" id=\""+keymap[inputtokens[i]]+"\" class='urTknValid' " + msg + " " + evt +">" + inputtokens[i] + delim + "</span>";
	  }
		else {
			if (ur_system.is508) {
				//msg = "title='" + getLanguageText("SAPUR_IT_TK", new Array(inputtokens[i],"SAPUR_IT_INV",i+1,inputtokens.length)) + "'";
			}
			evt = "onclick=\"sapUrMapi_InputToken_Click('" + keymap[inputtokens[i]] + "',event);\" ondoubleclick=\"sapUrMapi_InputToken_DblClick('" + keymap[inputtokens[i]] + "',event);\"";
		    inputtokens[i] = "<span st=\"i\" id=\""+keymap[inputtokens[i]]+"\" class='urTknInvalid' "+ msg + " " + evt +">" + inputtokens[i] + delim + "</span>";
		}
		newValue += inputtokens[i];
	}
	//replace the inner HTML with the new values
	oInput.innerHTML=newValue;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_getTokenList
//* parameter   : oInput - pointer to an HTML element that has an attribute 
//*								named "listid" set to a non-empty string
//* return      : a string of delimited token values to use as the validation set
//*								for the InputTokenizer's current data
//*	description	: this method accesses a global variable found through the Input's
//*								listid attribute.  The values in this array are concatenated into
//*								a string delimited by |-|.
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_getTokenList(oInput) {
	var listdiv = ur_get(oInput.getAttribute("listid"));
	if (listdiv != null) {
		var tokendelim = listdiv.getAttribute("tokendelim");
		var keydelim = listdiv.getAttribute("keydelim");
  	var list = listdiv.innerHTML.split(tokendelim);
		var retstr = "|-|";
		for (i = 0; i < list.length; i++) {
			var tkn = list[i].split(keydelim);
			retstr += tkn[0] +  "|-|" ;
		}
		return retstr;
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_getKeyMap
//* parameter   : oInput - pointer to an HTML element that has an attribute 
//*								named "listid" set to a non-empty string
//* return      : a 2-dimensional array/keyMap containing the values of the available
//*								tokens and a map to their corresponding id
//*	description	: this method accesses a global variable found through the Input's
//*								listid attribute.
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_getKeyMap(oInput) {
	var listdiv = ur_get(oInput.getAttribute("listid"));
	if (listdiv != null) {
		var tokendelim = listdiv.getAttribute("tokendelim");
		var keydelim = listdiv.getAttribute("keydelim");
  	var list = listdiv.innerHTML.split(tokendelim);
		var keyMap = new Array();
		for (i = 0; i < list.length; i++) {
			var tkn = list[i].split(keydelim);
			keyMap[tkn[0]] = tkn[1];
		}
		return keyMap;
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_ClipData
//* parameter   : sdelim - pointer to an HTML element that has an attribute 
//*								named "delimiter" set to a non-empty string
//* return      : a string of tokens splited by the delimiter
//*	description	: this method checkes whether clipboard data and/or drag and
//*				  drop data that is going to be pasted into the 
//*				  tokenizer's input field is a string and formates the string
//* 			  according to the input field's content.
//* ------------------------------------------------------------------------


function sapUrMapi_InputTokenizer_ClipData(sId,sData){
	if(typeof(sData)=="string"){
		var oInput = ur_get(sId);
		var sdelim = oInput.getAttribute("delimiter");
		var sPasteTxt=sData.split("\r\n");
		var s="";
		for (var n=0;n<sPasteTxt.length;n++) {
		  if (s!="")s+=sdelim;
		  if (sPasteTxt[n].length>0) {
		    s+=sPasteTxt[n];
		  }
		}
		return s;
	}else{
		return false;
	}
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_Drop
//* parameter   : sClipTxt - data transfered via drag and drop.
//*				  s - strings filtered out of the transfered data.
//*				  oInpRange - TextRange containing only the input field's content.
//*				  range - cursor position.
//*				  sTknStyle - css style of a single token

//*	description	: this method drops text into the input tokenizer's input field, 
//*				  that is transfered to it via drag and drop.
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_Drop(sId,oEv){
	var sClipTxt = oEv.dataTransfer.getData("Text");
	var oInput = ur_get(sId);
	oEv.returnValue=false;
	var s = sapUrMapi_InputTokenizer_ClipData(sId,sClipTxt);
	var oInpRange=document.body.createTextRange();
	oInpRange.moveToElementText(oInput);
	var range = document.selection.createRange();
	range.moveToPoint(oEv.x,oEv.y);
	var sTknStyle=range.parentElement().className;

	if(sTknStyle=="urTknInvalid"||sTknStyle=="urTknValid"){
		oInpRange.collapse(false);
		oInpRange.pasteHTML(s);
	}else{
		if(range!="undefined"){
		range.pasteHTML(s);
			if (range.parentElement() != null && range.parentElement().tagName.toLowerCase() == "span") {
			 range.parentElement().className = "";
			}
		}
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_Paste
//* parameter   : sClipTxt - data copied into the clip board.
//*				  s - strings filtered out of the transfered data.
//*				  oInpRange - TextRange containing only the input field's content.
//*				  range - cursor position.
//*	description	: this method pastes text into the input tokenizer's input field, 
//*				  that is transfered to it via drag and drop.
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_Paste(sId,oEv){
	var sClipTxt = clipboardData.getData("Text");
	var oInput = ur_get(sId);
	oEv.returnValue=false;
	var s = sapUrMapi_InputTokenizer_ClipData(sId,sClipTxt);
	var range = document.selection.createRange();
	var oInpRange=document.body.createTextRange();
	oInpRange.moveToElementText(oInput);
	if(range!="undefined"){
		range.pasteHTML(s);
		if (range.parentElement() != null && range.parentElement().tagName.toLowerCase() == "span") {
		 range.parentElement().className = "";
		}
	}
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_splitTokens
//* parameter   : oInput - pointer to an HTML element that has an attribute 
//*								named "delimiter" set to a non-empty string
//* return      : an array of the tokens split by the delimiter
//*	description	: this method accesses a delimiter token from the HTML element's
//*								delimiter attribute and creates a regular expression which 
//*								splits the innerText of the element into an array of token strings
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_splitTokens(oInput) {
	var delim = oInput.getAttribute("delimiter");
	var re = new RegExp("\\s*" + delim + "\\s*", "gi");
	var txt = oInput.innerText;
	
	//trim leading whitespaces for the entire input field
	while (txt.substr(0,1) == " ") {
		txt = txt.substr(1,txt.length-1);
	}

	//trim trailing whitespaces for the entire input field and remove the last delimiter
	//to keep from adding an extra index to the array
	while (txt.substr(txt.length-1, 1) == " " || txt.substr(txt.length-1, 1) == delim) {
		txt = txt.substr(0, txt.length-1);
	}
	
	//if they didn't put in any delimiters, treat the entire
	//innerText value as a single token
	if (txt.indexOf(delim) == -1) {
	  return new Array(txt);
	}
	else {
		return txt.split(re);
	}
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputTokenizer_matchToken
//* parameter   : sTkn - string value of the token to try and match
//*								sTknList - formated list of tokens to match the token value from
//*								bUseCase - whether or not to use case sensitivity during match
//* return      : boolean true if matched, false if not
//*	description	: this method takes a token string, a list of token values generated
//*								by the sapUrMapi_InputTokenizer_getTokenList function and a boolean
//*								switch for whether or not to use case-sensitivity during the test
//* ------------------------------------------------------------------------
function sapUrMapi_InputTokenizer_matchToken(sTkn, sTknList, bUseCase) {
	//switch the comparison based on case-sensitivity
	if (bUseCase=="true") {
	  if (sTknList.indexOf("|-|" + sTkn + "|-|") != -1) {
	    return true;
	  }
	}
	else {
	  if (sTknList.toLowerCase().indexOf("|-|" + sTkn.toLowerCase() + "|-|") != -1) {
	    return true;
	  }
	}
	//we fell through so return false match
	return false;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputToken_Click
//* parameter   : sId - the id of the HTML element surrounding the InputToken
//*								that was clicked inside the InputTokenizer
//*               oEv - window event object
//* return      : none
//*	description	: this function provides an event handle to capture when a user
//*								has clicked on an InputToken inside the InputTokenizer
//* ------------------------------------------------------------------------
function sapUrMapi_InputToken_Click(sId, oEv) {
	//must be overridden by system
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_InputToken_DblClick
//* parameter   : sId - the id of the HTML element surrounding the InputToken
//*								that was double-clicked inside the InputTokenizer
//*               oEv - window event object
//* return      : none
//*	description	: this function provides an event handle to capture when a user
//*								has double-clicked on an InputToken inside the InputTokenizer
//* ------------------------------------------------------------------------

function sapUrMapi_InputToken_DblClick(sId, oEv) {
	//must be overridden by system
}
