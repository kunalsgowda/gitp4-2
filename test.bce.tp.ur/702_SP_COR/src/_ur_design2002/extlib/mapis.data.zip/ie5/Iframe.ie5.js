//* ************************************************************************
//* Iframe
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Iframe_adaptSize
//* parameter   : sId  - Id of the Iframe control
//*             : oEvt - Event Object
//* return      : none
//* description	: Adapt the size of the Iframe to its content
//* ------------------------------------------------------------------------
function sapUrMapi_Iframe_adaptSize(sId, oEvt) {
  var oIf = ur_get(sId);
  if (oIf && (oIf.width == "" || oIf.height == "")) {
    // use try catch if access to content document is denied
    try {
      var oIfBody = oIf.contentWindow.document.body;
      if (oIf.width == "") 
        oIf.width = oIfBody.scrollWidth + oIfBody.offsetWidth - oIfBody.clientWidth;
      if (oIf.height == "") 
        oIf.height = oIfBody.scrollHeight + oIfBody.offsetHeight - oIfBody.clientHeight;
    } 
    catch (e) {
      // nothing to do
    }
  }
}
