//* ************************************************************************
//* RadioButton
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_registerCreate
//* parameter   : sId - Id of the radiobutton 
//* return      : 
//*	description	: register the radiobutton cretae function
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_registerCreate(sId) {
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_RadioButton_create('"+sId+"')");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_create
//* parameter   : sId - Id of the radiobutton 
//* return      : 
//*	description	: Special handling for inerHtml exchange to enable
//*								correct keyboard navigation with arrow keys for
//*								the radiobuttons.
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_create(sId) {
	var aGroup = sapUrMapi_RadioButton_getGroup(sId),
		bSelected = false; 
	for (var i=aGroup.length-1;i>=0;i--) {
		if (aGroup[i].getAttribute("initialized") == "true") return;
		aGroup[i].setAttribute("initialized","true");
		//the last radio button that is checked wins if there are namy checked ones
		if (aGroup[i].checked && !bSelected && (!aGroup[i].disabled || ur_system.is508)) {
			if (!aGroup[i].disabled) {
				sapUrMapi_RadioButton_toggle(aGroup[i].id,{type:""},true);
			} else {
				ur_get(aGroup[i].id+"-r").tabIndex=0;
			}
			bSelected = true;
				
		}
	}
	if (bSelected) return;
	var i = 0;
	while (i<aGroup.length && aGroup[i].disabled && !ur_system.is508) i++;
	if (i>=aGroup.length) return;
	ur_get(aGroup[i].id + "-r").tabIndex = "0";}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_toggle
//* parameter   : sId - string Id of the radiobuttom to toggle
//* return      : true if the radiobutton was toggeled
//*	description	: checks the radiobutton specified by sId (and unchecks all others)
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_toggle(sId,e,create) {
	if(e.type=="keydown" && (e.ctrlLeft || e.ctrlRight)) return;
	var oIn=ur_get(sId),
		oImg=ur_get(sId+"-img"),
		oRoot = ur_get(sId+"-r");
	var newClass = "";
	if (ur_isSt(oRoot,new Array(ur_st.DISABLED)) || ur_isSt(oRoot,new Array(ur_st.READONLY))) return false;
	var oInGrp=sapUrMapi_RadioButton_getGroup(sId);
	ur_setSt(oRoot,ur_st.SELECTED,true);
	ur_setSt(oRoot,ur_st.NOTSELECTED,false);
	oRoot.tabIndex="0";
	if (!create) ur_focus(oRoot);
	oImg.className=oImg.className.replace("Off","On");
	for(var i=0;i<oInGrp.length;i++){
		oImg=ur_get(oInGrp[i].id+"-img");
		oInGrp[i].checked = false;
		oThisRoot=ur_get(oInGrp[i].id+"-r")
		if (oImg==null || oIn==oInGrp[i]) continue; 
		if(ur_isSt(oThisRoot,ur_st.SELECTED)){ 
			oImg.className=oImg.className.replace("On","Off");
			ur_setSt(oThisRoot,ur_st.SELECTED,false);
			ur_setSt(oThisRoot,ur_st.NOTSELECTED,true);			
			oThisRoot.tabIndex = "-1";
		}
	}
	
	// csn: 1635195 bug: radiobuttons don't work in IE9 Quirks Mode	
	newClass=oImg.className;
	oImg.className="";
	oImg.className=newClass;
	
	oIn.checked=true;
	if (ur_system.is508 && !create) oIn.fireEvent("onactivate");
	return true;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_setDisabled
//* parameter   : sId - string Id of the radiobutton
//* description	: sets an enabled radiobutton to disabled and also the connected
//								label
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_setDisabled(sId) {
	sapUrMapi_CheckBox_setDisabled(sId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_setEnabled
//* parameter   : sId - string Id of the radiobutton
//* description	: sets an disabled radiobutton to enabled and also the connected
//								label
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_setEnabled(sId) {
	sapUrMapi_CheckBox_setEnabled(sId); 	
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_setReadonly
//* parameter   : sId - Id of the checkbox
//*								bSet - set/unset the checkbox readonly
//*	description	: sets/unsets a radiobutton readonly and the connected
//								label enabled
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_setReadonly(sId,bSet){
	sapUrMapi_CheckBox_setReadonly(sId,bSet);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_setInvalid
//* parameter   : sId - Id of the radio button
//*	description	: sets the invalid state
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_setInvalid(sId){
	sapUrMapi_CheckBox_setInvalid(sId);
}
function sapUrMapi_RadioButton_getGroup(sId) {
	var oIn=ur_get(sId),
		oInGrp = [],
		oRadioButtonsGrp = [],
		j=0;

	if(oIn.name!="") 
		oInGrp=document.getElementsByName(oIn.name);
	else
		oInGrp[0]=oIn;

	for(var i=0; i<oInGrp.length; i++){
		if(oInGrp[i].getAttribute("ct") == "R") {
			oRadioButtonsGrp[j]=oInGrp[i];
			j++;
		}
	}
	return oRadioButtonsGrp;
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_focus
//* parameter   : sId - string Id of the checkbox
//*								oEvt - event object
//*	description	: show data tip
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_focus(sId,oEvt) {
	sapUrMapi_DataTip_show(sId,"focus");
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_blur
//* parameter   : sId - string Id of the checkbox
//*								oEvt - event object
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_blur(sId,oEvt) {
	//remove the tab index if the radio button has no selection or if all enabled radio buttons are not selected it is not the first
	// do this only if the user did not navigate
	sapUrMapi_RadioButton_reset(sId);
	//hide the data tip
	sapUrMapi_DataTip_hide(sId);
}

function sapUrMapi_RadioButton_reset(sId) { 
	var o = ur_get(sId);
	if (!o.checked) {
		o.tabIndex = "-1";
	}
	var aGroup = sapUrMapi_RadioButton_getGroup(sId),
		bSelected = false; 
	for (var i=0;i<aGroup.length;i++) {
		if (aGroup[i].checked && !bSelected && (!aGroup[i].disabled || ur_system.is508)) {
			ur_get(aGroup[i].id + "-r").tabIndex = "0";
			bSelected = true;	
		} else {
			ur_get(aGroup[i].id + "-r").tabIndex = "-1";
		}
	}
	if (bSelected) return;
	var i = 0;
	while (i<aGroup.length-1 && aGroup[i].disabled && !ur_system.is508) i++;
	if (i==aGroup.length) return;
	ur_get(aGroup[i].id + "-r").tabIndex = "0";
}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_keydown
//* parameter   : sId - string Id of the checkbox
//*								oEvt - event object
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_keydown(sId,oEvt) {
	var iKey=oEvt.keyCode;	
	if(iKey==37)
		iKey==ur_system.direction!="rtl"?37:39;
	else if(iKey==39)
		iKey==ur_system.direction!="rtl"?39:37;

	// show data tip when you press ctrl+shift+i (old key ctrl+q)
	if( oEvt.keyCode==73 && oEvt.shiftKey && sapUrMapi_bCtrl(oEvt) && !oEvt.altKey){
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
		return ur_EVT_cancel(oEvt);
	}
	
	// space
	else if(oEvt.keyCode == "32"){
		//sapUrMapi_RadioButton_toggle(sId,oEvt);
		ur_get(sId).click();
		return ur_EVT_cancel(oEvt);		
	}
	// escape
	else if(oEvt.keyCode == "27"){
		sapUrMapi_DataTip_hide(sId);
		return ur_EVT_cancel(oEvt);		
	}
	// arrow left and up
	else if(iKey==37 || iKey==38){		 
		var oIn=ur_get(sId),
			oInGrp=sapUrMapi_RadioButton_getGroup(sId),
			i = 0;
		for(var n=0; n<oInGrp.length;n++) {
			if (oInGrp[n]==oIn) i=n;
			if (oInGrp[n].checked) {
				ur_get(oInGrp[n].id + "-r").tabIndex = "-1";
			}
		}
		i = i-1;
		while(oInGrp[i] && (oInGrp[i].disabled && !ur_system.is508)) i = i-1;
		if (i>-1) {
			if (oEvt.shiftKey || (oInGrp[i].disabled && ur_system.is508) ) {
				var thisRoot = ur_get(oInGrp[i].id + "-r");
				thisRoot.tabIndex="0";
				thisRoot.setAttribute("ti","0");
				thisRoot.focus();
			} else if (!oInGrp[i].disabled) {
				sapUrMapi_RadioButton_toggle(oInGrp[i].id,oEvt);
				ur_get(oInGrp[i].id).click();
			}
		}
		return ur_EVT_cancel(oEvt);
	}

	// arrow right and down
	else if(iKey==39 || iKey==40){
		var oIn=ur_get(sId),
			oInGrp=sapUrMapi_RadioButton_getGroup(sId),
			i = 0;
		for(var n=0; n<oInGrp.length;n++) {
			if (oInGrp[n]==oIn) i=n;
			if (oInGrp[n].checked) {
				ur_get(oInGrp[n].id + "-r").tabIndex = "-1";
			}
		}
		i = i+1;
		while(oInGrp[i] && (oInGrp[i].disabled && !ur_system.is508)) i = i+1;
		if (i<oInGrp.length)  {
			if (oEvt.shiftKey || (oInGrp[i].disabled && ur_system.is508) ) {
				var thisRoot = ur_get(oInGrp[i].id + "-r");
				thisRoot.tabIndex="0";
				thisRoot.setAttribute("ti","0");
				thisRoot.focus();
			} else if (!oInGrp[i].disabled) {
				sapUrMapi_RadioButton_toggle(oInGrp[i].id,oEvt);
				ur_get(oInGrp[i].id).click();
			}
		}
		return ur_EVT_cancel(oEvt);
	}
}

