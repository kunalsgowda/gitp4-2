
function sapUrMapi_Focus_canFocus(o) {
	if (o==null) return;
	if (!o.tagName) return;
	var tag=","+o.tagName+",";
  //if (tag==",IFRAME,") return true; who added this. this produces bug in iframe control -->where is this needed?
	if((tag==",INPUT,")&&(o.type=="hidden"||o.disabled)){ 
		return false;
	}
	var search=",A,BODY,BUTTON,FRAME,IFRAME,INPUT,ISINDEX,OBJECT,SELECT,TEXTAREA,";
	if (search.indexOf(tag)>-1){
	   if (!ur_system.is508 && o.tabIndex<0)
	       return (o.ti>=0);
	   else
	      return (o.tabIndex>=0);
	}
	if (!o.getAttribute) return;
	if (o.getAttribute("ti")!=null) return (parseInt(o.getAttribute("ti"))>=0);
}

function sapUrMapi_Focus_getNextFocusableElement(o) {
	while (o!=null) {
		if (sapUrMapi_Focus_canFocus(o)) return o;
		o=o.parentNode;
	}
	return null;
}

var oOldFocus=null;
function sapUrMapi_Focus_showFocusRect(sId) {
	try
	{
		if ((document.activeElement!=null) && (document.activeElement.id=="ur-accfocus")) return;
	}
	catch(e)
	{
		return;
	}
	var oTop = ur_get("ur-topfocus");
	if (oTop==null) return;
  var oNewActive=null;
	if (typeof(sId)!="undefined") {
		if (typeof(sId)=="string") {
    oNewActive=ur_get(sId);
	} else {
      oNewActive=sId;
		}
	} else {
    oNewActive=document.activeElement;
	}
	if (oOldFocus!=null) {
	  if (oOldFocus==oNewActive) return;
	}
	oNewActive=sapUrMapi_Focus_getNextFocusableElement(oNewActive);      
	if ((oNewActive==null)||(oNewActive.tagName=="BODY")) return;

  var sType=sapUrMapi_getControlTypeFromObject(oNewActive);
	/*
	if (oNewActive.tagName=="IMG" && oNewActive.className.indexOf("urImgCbg")>-1) {
	  oNewActive=ur_get(oNewActive.id.split("-")[0]);
	}
	if (sType=="TRI" || ((oNewActive.tagName=="INPUT") && (oNewActive.type.toUpperCase()=="CHECKBOX" || oNewActive.type.toUpperCase()=="RADIO"))) {
		var oNew=sapUrMapi_Label_getInputLabel(oNewActive.id);
		if (oNew!=null && oNew.innerText!="") {
				oNewActive.hideFocus="true";
		 		oNewActive=oNew;
		} else {
		  oNewActive=ur_get(oNewActive.id+"-lbl");
		  //enhancement for NON UR Elements (Portal)
		  if(oNewActive==null) oNewActive = document.activeElement;
		}
	}
	*/
	
	if(sType=="C"||sType=="R"||sType=="TRI"){ 
		oNewActive=ur_get(oNewActive.id.split("-")[0]+"-lbl");
	}
	
	if(oNewActive.getAttribute("urhf")=="true") return;
	if (!oNewActive.hideFocus) oNewActive.hideFocus="true";
  
  //Special Handling
	//TabStrip
	if (sType=="TS") {
	  if (oNewActive.id.indexOf("-itm-")>-1 && oNewActive.id.indexOf("-txt")==-1 && oNewActive.id.indexOf("-a")==-1) 
	    oNewActive=oNewActive.firstChild;
	}
	//SelectableLinkbar
  else if (sType=="SB") {
	  if (oNewActive.tagName=="TABLE") {
	    oNewActive=oNewActive.parentNode.parentNode.parentNode;
	  }	else {
	    oNewActive=oNewActive.parentNode;
	  }
	}
	
  //ComboBox
  else if (sType=="CB") {
		oNewActive=oNewActive.parentNode;
  	if(oNewActive.tagName=="TD")	// ComboBox with table rendering
  		oNewActive=oNewActive.parentNode.parentNode.parentNode.parentNode;
  }

 	//Special Handling for text elements that have a relative position
	if(oNewActive.className.indexOf("urVt")>-1){
		oParent=oNewActive.parentNode.className;
		oPParent=oNewActive.parentNode.parentNode.className;
		if(oParent.indexOf("urST")==-1&&oPParent.indexOf("urST")==-1){
	  	     oNewActive.style.position="static";
	        }
	}	
       var activeoffsetonscreen = sapUrMapi_Focus_getFocusOffset(oNewActive,false);
 	if(oNewActive.className.indexOf("urVt")>-1){
		oParent=oNewActive.parentNode.className;
		oPParent=oNewActive.parentNode.parentNode.className;
		if(oParent.indexOf("urST")==-1&&oPParent.indexOf("urST")==-1){
                oNewActive.style.position="relative";
		}
 	}
	var sccontrol = oNewActive.parentNode;
	var oC={top:ur_get("ur-topfocus"),bottom:ur_get("ur-bottomfocus"),left:ur_get("ur-leftfocus"),right:ur_get("ur-rightfocus"),e1:ur_get("ur-edge1focus"),e2:ur_get("ur-edge2focus"),e3:ur_get("ur-edge3focus"),e4:ur_get("ur-edge4focus")};
  if (oNewActive.offsetWidth>0) {
		oFocusRect=sapUrMapi_Focus_calcFocusRect(oNewActive,activeoffsetonscreen,oC.left,oC.right,oC.top,oC.bottom);
		if (oFocusRect==null) return;
		oCC={x1:"top",x2:"bottom",x3:"left",x4:"right"};
		for (xx in oCC) {
			if (xx.charAt(0) == "_") {continue;}
		  oC[oCC[xx]].style.top=oFocusRect[oCC[xx]].top;
		  oC[oCC[xx]].style.left=oFocusRect[oCC[xx]].left;
		  if (oCC[xx]=="top" || oCC[xx]=="bottom") 
		    oC[oCC[xx]].style.width=oFocusRect[oCC[xx]].width;
		  if (oCC[xx]=="left" || oCC[xx]=="right") 
		    oC[oCC[xx]].style.height=oFocusRect[oCC[xx]].height;
	}
		oC.e1.style.left=oC.left.style.left;
		oC.e1.style.top=oC.left.style.top;
		oC.e2.style.left=oC.right.style.left;
		oC.e2.style.top=oC.right.style.top;
		oC.e3.style.left=oC.right.style.left;
		oC.e3.style.top=oC.bottom.style.top;
		oC.e4.style.left=oC.left.style.left;
		oC.e4.style.top=oC.bottom.style.top;
}
}

function sapUrMapi_Focus_hideFocusRect() {
	sapUrMapi_Focus_DeflBtn_hideFocusRect(false);
}
function sapUrMapi_Focus_addFocusRect(sFocusElementId)
{
   document.attachEvent("onactivate",sapUrMapi_DBTN_showDBtn);
   var oDefaultTop=document.createElement("DIV");
   var oDefaultBottom=document.createElement("DIV");
   var oDefaultLeft=document.createElement("DIV");
   var oDefaultRight=document.createElement("DIV");

   oDefaultTop.style.zIndex  = "10000";
   oDefaultBottom.style.zIndex   = "10000";
   oDefaultLeft.style.zIndex   = "10000";
   oDefaultRight.style.zIndex   = "10000";

   oDefaultTop.setAttribute("id","ur-topdefault");
   oDefaultBottom.setAttribute("id","ur-bottomdefault");
   oDefaultLeft.setAttribute("id","ur-leftdefault");
   oDefaultRight.setAttribute("id","ur-rightdefault");



   document.getElementsByTagName("BODY")[0].appendChild(oDefaultTop);
   document.getElementsByTagName("BODY")[0].appendChild(oDefaultBottom);
   document.getElementsByTagName("BODY")[0].appendChild(oDefaultLeft);
   document.getElementsByTagName("BODY")[0].appendChild(oDefaultRight);
   document.onactivate=sapUrMapi_Focus_showFocusRect; 
   document.ondeactivate=sapUrMapi_Focus_hideFocusRect;
   sapUrMapi_Resize_AddItem("ur-DBtn-rect", "sapUrMapi_DBTN_showDBtn()");
   sapUrMapi_Resize_AddItem("ur-focus-rect", "sapUrMapi_Focus_showFocusRect()");
   var oC={top:ur_get("ur-topfocus"),bottom:ur_get("ur-bottomfocus"),left:ur_get("ur-leftfocus"),right:ur_get("ur-rightfocus"),e1:ur_get("ur-edge1focus"),e2:ur_get("ur-edge2focus"),e3:ur_get("ur-edge3focus"),e4:ur_get("ur-edge4focus")};
  if (oC.top==null) return;
  for (var x in oC) {
  	if (x.charAt(0) == "_") {continue;}
  	oC[x].style.top="-10000px";
  }
  try {
    sapUrMapi_focusElement(sFocusElementId);
  } catch(ex) {
  }
}
function sapUrMapi_Focus_RegisterCreate(sId) {
	sapUrMapi_Create_AddItem("ur_focus", "sapUrMapi_Focus_addFocusRect(\""+sId+"\")");
}

function sapUrMapi_Focus_getCurrentId () {
  var o = window.document.activeElement;
  if (o!=null) {
	  if (o.tagName=="LABEL") return o.htmlFor;
	  while (o.id=="") {
			if (o.tagName=="BODY") return "";
			o=o.parentNode;
	  }
	  return o.id;
  }
  return "";
}
function sapUrMapi_Focus_reset() {
	var oTop = ur_get("ur-topfocus");
	var oBottom = ur_get("ur-bottomfocus");
	var oLeft = ur_get("ur-leftfocus");
	var oRight = ur_get("ur-rightfocus");
  var oEdg1 = ur_get("ur-edge1focus");
  var oEdg2 = ur_get("ur-edge2focus");
  var oEdg3 = ur_get("ur-edge3focus");
  var oEdg4 = ur_get("ur-edge4focus");
  if(oTop) {
	  var oParent=oTop.parentNode;
	  var oBody=document.getElementsByTagName("BODY")[0];
	  if (oParent!=oBody) {
			oParent.removeChild(oTop);
			oBody.appendChild(oTop);
			oParent.removeChild(oBottom);
			oBody.appendChild(oBottom);
			oParent.removeChild(oLeft);
			oBody.appendChild(oLeft);
			oParent.removeChild(oRight);
			oBody.appendChild(oRight);
			oParent.removeChild(oEdg1);
			oBody.appendChild(oEdg1);
			oParent.removeChild(oEdg2);
			oBody.appendChild(oEdg2);
			oParent.removeChild(oEdg3);
			oBody.appendChild(oEdg3);
			oParent.removeChild(oEdg4);
			oBody.appendChild(oEdg4);
		}
  }
}

function sapUrMapi_Focus_remove() {
	var oTop = ur_get("ur-topfocus");
	if(oTop==null) return;
	var oBottom = ur_get("ur-bottomfocus");
	var oLeft = ur_get("ur-leftfocus");
	var oRight = ur_get("ur-rightfocus");
  var oEdg1 = ur_get("ur-edge1focus");
  var oEdg2 = ur_get("ur-edge2focus");
  var oEdg3 = ur_get("ur-edge3focus");
  var oEdg4 = ur_get("ur-edge4focus");
  var oParent=oTop.parentNode;
	oParent.removeChild(oTop);
	oParent.removeChild(oBottom);
	oParent.removeChild(oLeft);
	oParent.removeChild(oRight);
	oParent.removeChild(oEdg1);
	oParent.removeChild(oEdg2);
	oParent.removeChild(oEdg3);
	oParent.removeChild(oEdg4);
}

//returns the height of the focus rect bar
function sapUrMapi_Focus_getFocusRectHeight() {
	var oTop = ur_get("ur-topfocus");
	if (oTop) return oTop.offsetHeight;
	return 0;
}
function sapUrMapi_Focus_calcFocusRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom)
{
	var oFcsRect = sapUrMapi_Focus_DflBtn_calcFocusRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom,false);
	return oFcsRect;
}

function sapUrMapi_Focus_DflBtn_getFocusOffset(object,IsDeflBtn) {
	var position= { top: 0, left: 0};
	position = sapUrMapi_getAbsolutePosition(object);
	var sccontrol = object.parentNode;
	var bFoundFirstScrollContainer=false;	
	if(IsDeflBtn)
		var oC={top:ur_get("ur-topdefault"),bottom:ur_get("ur-bottomdefault"),left:ur_get("ur-leftdefault"),right:ur_get("ur-rightdefault")};
	else
		var oC={top:ur_get("ur-topfocus"),bottom:ur_get("ur-bottomfocus"),left:ur_get("ur-leftfocus"),right:ur_get("ur-rightfocus"),e1:ur_get("ur-edge1focus"),e2:ur_get("ur-edge2focus"),e3:ur_get("ur-edge3focus"),e4:ur_get("ur-edge4focus")};	
	while ((sccontrol) && (!bFoundFirstScrollContainer)) {
	  if (sccontrol.tagName=="DIV" || sccontrol.tagName=="SPAN") {
	    if (sccontrol.currentStyle.overflow!="visible") {
				if (sccontrol!=oC.top.parentNode) {
				  oParent=oC.top.parentNode;
					for (var n in oC) {
						if (n.charAt(0) == "_") {continue;}
						oParent.removeChild(oC[n]);
					  sccontrol.appendChild(oC[n]);
				   }
				}
				bFoundFirstScrollContainer=true;
	      if (sccontrol.offsetHeight<sccontrol.scrollHeight) { 
					var pos=sapUrMapi_getOffsetOnScreen(sccontrol);
	       if (sccontrol.currentStyle.borderTopStyle != "none")
				position.top-=pos.top+parseInt(sccontrol.currentStyle.borderTopWidth);
                                                                         
			if (sccontrol.currentStyle.borderLeftStyle != "none")
			 position.left-=pos.left+parseInt(sccontrol.currentStyle.borderLeftWidth);


	       
	      }
	    }
	  }
	  sccontrol = sccontrol.parentNode;
	}
	if (!bFoundFirstScrollContainer) {
			oBody=document.getElementsByTagName("BODY").item(0);
			if (oBody!=oC.top.parentNode) {
			  oParent=oC.top.parentNode;
				for (var n in oC) {
					if (n.charAt(0) == "_") {continue;}
					oParent.removeChild(oC[n]);
					oBody.appendChild(oC[n]);
			}
	}
	}
	return position;
}

function sapUrMapi_Focus_DflBtn_calcFocusRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom,IsDeflBtn) {
	
	var o=new Array();
	o.top = {top:0,left:0,width:0};
	o.bottom = {top:0,left:0,width:0};
	o.left = {top:0,left:0,height:0};
	o.right = {top:0,left:0,height:0};
	sType=sapUrMapi_getControlTypeFromObject(oElement);
	sParentType=sapUrMapi_getControlTypeFromObject(oElement.parentNode);
	if (oElement.className.indexOf("urVt")>-1){
		oParent=oElement.parentNode.className;
		oPParent=oElement.parentNode.parentNode.className;
		if(oParent.indexOf("urST")==-1&&oPParent.indexOf("urST")==-1&&oParent.indexOf("urVaTo")==-1){
		    o.top.top-=2;
		    o.bottom.top-=2;
		    o.left.top-=2;
		    o.right.top-=2;
		}
	}
	if (oElement.className.indexOf("urIlbItmTxt")>-1) {
	  oOffsets=sapUrMapi_Focus_getFocusOffset(oElement.parentNode);
	  oElement=oElement.parentNode;
	  o.top.top+=parseInt(oTop.currentStyle.height);
	  o.bottom.top-=(parseInt(oTop.currentStyle.height));
	  o.left.left+=parseInt(oLeft.currentStyle.width);
	  o.left.top+=parseInt(oTop.currentStyle.height);
	  o.right.left-=(parseInt(oLeft.currentStyle.width)*2);
	}
	if (oElement.parentNode.className.indexOf("urTreN")>-1) {
		if(IsDeflBtn==true) // Default Button
				    o.bottom.top-=6;
		else
		{
	  if (!(oElement.parentNode.childNodes.length>0 && oElement.parentNode.childNodes[0].tagName=="TABLE")) {
	    o.bottom.top-=6;
	  } else {
	    o.top.width-=2;
	    o.bottom.width-=2;
	    o.bottom.top-=1;
	  }}
	}
	/*
	if (sParentType=="C" || sParentType=="R" || sParentType=="TRI") {
	  if (oElement.tagName=="LABEL" && oElement.firstChild.tagName!="IMG") {
	    o.left.left-=15;
	    o.top.left-=15;
	    o.top.top+=1;
	    o.bottom.top-=1;
	    o.top.width+=15;
 	  }
	}
	*/
	if (sapUrMapi_getControlType(oElement.id)=="PI") {
	  if (oElement.id.indexOf("-itm-")>-1){
	    o.top.top+=parseInt(oTop.currentStyle.height);
	    o.bottom.top-=parseInt(oBottom.currentStyle.height);
	    o.left.left+=parseInt(oLeft.currentStyle.width);
	    o.right.left-=parseInt(oRight.currentStyle.width);
	  } else {
	    o.top.top+=parseInt(oTop.currentStyle.height);
	    o.bottom.top-=(parseInt(oBottom.currentStyle.height)+1);
	    o.left.left+=parseInt(oLeft.currentStyle.width);
	    o.right.left-=parseInt(oRight.currentStyle.width);
	  }
	}
	else if (sType=="TB") {
    if (oElement.tagName=="TABLE") {	  
			o.left.left+=(parseInt(oLeft.currentStyle.width));
			o.top.left+=(parseInt(oLeft.currentStyle.width));
			o.top.width-=(parseInt(oLeft.currentStyle.width));
			o.top.top+=(parseInt(oTop.currentStyle.height));
			o.bottom.top-=1+parseInt(oBottom.currentStyle.height);
			o.right.left-=parseInt(oRight.currentStyle.width);
		}
	else if(oElement.getAttribute("hasPopupMnuSec")=="true")
		{
			o.top.width+=10;
			o.bottom.width+=10;
			o.right.top+=10;
		}
	}
	else if (sType=="DN") {
	  if (oElement.tagName=="TD"){
	    o.left.left+=(parseInt(oLeft.currentStyle.width));
	    o.left.height-=1;
	    o.top.left+=(parseInt(oLeft.currentStyle.width));
	    o.top.width-=1+(parseInt(oLeft.currentStyle.width));
	    o.top.top+=(parseInt(oTop.currentStyle.height));
	    o.bottom.top-=1+parseInt(oBottom.currentStyle.height);
	    o.right.left-=parseInt(oRight.currentStyle.width);
	  }
	}
	else if (sType=="SB") {
	  if (oElement.tagName=="TD"){
	    o.top.top+=parseInt(oTop.currentStyle.height);
	    o.bottom.top-=parseInt(oBottom.currentStyle.height);
	    o.left.left+=parseInt(oLeft.currentStyle.width);
	    o.right.left-=(parseInt(oRight.currentStyle.width)+1);
	  }
	}
	else if (sType=="ST") {
		if ((oElement.className.indexOf("SelSecIco")>-1) || (oElement.className.indexOf("SelIco")>-1)){
	    o.top.top+=1;
	    o.bottom.top-=1;
	    o.left.left+=1;
	    o.top.width-=2;
		} else {
		if (oElement.tagName=="TH" || oElement.className.indexOf("urST")>-1) {
				o.top.top+=1
				o.left.left+=1;
				o.top.width-=2;
				o.right.left-=1;
				o.bottom.top-=2;
			}
		}
	}
	else if(sType=="B")
	{
		if(oElement.getAttribute("hasPopupMnuSec")=="true")
		{
			o.top.width+=10;
			o.bottom.width+=10;
			o.right.top+=10;
		}
	}
	if(IsDeflBtn==true) // Default Button
		o.top.top+=oOffsets.top-1;
	else
		o.top.top+=oOffsets.top-parseInt(oLeft.currentStyle.width);
	o.top.left+=oOffsets.left;
	o.top.width+=oElement.offsetWidth;
	o.bottom.top+=(oOffsets.top+oElement.offsetHeight);
	o.bottom.left=o.top.left;
	o.bottom.width=o.top.width;
	o.left.top=o.top.top;
	if(IsDeflBtn==true) // Default Button
		o.left.left+=oOffsets.left-1;
	else
		o.left.left+=(-1*parseInt(oLeft.currentStyle.width))+oOffsets.left;
	o.right.top=o.top.top;
	if(IsDeflBtn==true) // Default Button
		o.right.left+=o.left.left+o.top.width +1;
	else
		o.right.left+=(o.left.left+o.top.width+parseInt(oLeft.currentStyle.width));
	if (oElement.offsetHeight>0) {
		if(IsDeflBtn==true) // Default Button
			o.left.height+=o.bottom.top-o.top.top;
		else
			o.left.height+=o.bottom.top-o.top.top+parseInt(oBottom.currentStyle.height);
		//(oElement.offsetHeight+(parseInt(oLeft.currentStyle.width)*2));
		o.right.height+=o.left.height;
		//(oElement.offsetHeight+(parseInt(oRight.currentStyle.width)*2));
	}
	//add pixels (px) to all values
	for (var iter1 in o) {
		if ((IsDeflBtn==false) && (iter1.charAt(0) == "_")) {continue;}
	  for (var iter2 in o[iter1]) {
	  	if ((IsDeflBtn==false) && (iter2.charAt(0) == "_")) {continue;}
	    if (isNaN(o[iter1][iter2])) return null;
	    o[iter1][iter2]+="px";
	  }
	}
	return o;
}

function sapUrMapi_Focus_DeflBtn_hideFocusRect(IsDeflBtn) {
  var oNewActive=null;
  try {
    oNewActive=document.activeElement;
  } catch (ex) { return; }
  oOldFocus=null;
	if (IsDeflBtn)
	   var oC={top:ur_get("ur-topdefault"),bottom:ur_get("ur-bottomdefault"),left:ur_get("ur-leftdefault"),right:ur_get("ur-rightdefault")};
	else
		var oC={top:ur_get("ur-topfocus"),bottom:ur_get("ur-bottomfocus"),left:ur_get("ur-leftfocus"),right:ur_get("ur-rightfocus"),e1:ur_get("ur-edge1focus"),e2:ur_get("ur-edge2focus"),e3:ur_get("ur-edge3focus"),e4:ur_get("ur-edge4focus")};
  if (oC.top==null) return;
  for (var x in oC) {
  	if (x.charAt(0) == "_") {continue;}
  	oC[x].style.top="-10000px";
}
}
