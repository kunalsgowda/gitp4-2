//* ************************************************************************
//* TabStrip
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_RegisterCreate
//* parameter   : sId - string - Id of the TabStrip
//* description : Registers the tabstrip with the create item registry to be
//*				  initialized when the page loads
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_TabStrip_RegisterCreate(sId,iCount,iActive) {
	if(!sId || iCount==0 || iActive<0) return;
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_TabStrip_create('" + sId + "','" + iCount + "','" + iActive + "')");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_create
//* parameter   : none
//* return      : none
//*	description	: initally the tabstrip height was not set, therefore
//			the height of the tabstrip is set maximum height of its items
//								content. this can only be done after the elements where parsed and calculated
//								this function is set to the onreadystatechange event of the document
//								if the readystate is complete(right before the display of the page)
//                the height of all tabstrips that have no height applied will be recalculated
//								This is an internal function and not to be called from outside
//* ------------------------------------------------------------------------
function sapUrMapi_TabStrip_create(sId,iCount,iActive) {
	
	var oTabTable=ur_get(sId);
	var curTab = ur_get(sId + "-cnt-" + iActive);
	if (curTab == null) return;
	var iHeight=0
	var iWidth=0;
	
	if (curTab.childNodes[0] != null && sapUrMapi_getCurrentStyle(curTab.childNodes[0],"overflow")!="visible") {
	  var oContent=ur_TS_drawScrollContent(sId);
		var iHeight = oContent.height;
		var iWidth = oContent.width;
	}
	
	/*if (oTabTable.getAttribute("exact")=="1") {
		
		var aTabCnts = curTab.parentElement.childNodes;
		var curTabHeight, curTabWidth;

 			for(i=0;i<iCount;i++){

			if (sapUrMapi_getCurrentStyle(aTabCnts[i].childNodes[0],"overflow") == "visible") {
				curTabHeight = aTabCnts[i].scrollHeight;
				curTabWidth = aTabCnts[i].scrollWidth;
				// Ignore 100% width tabs
				if (curTabWidth == aTabCnts[i].parentNode.scrollWidth) curTabWidth = 0;
				if (curTabHeight > iHeight) iHeight = curTabHeight;
				if (curTabWidth > iWidth) iWidth = curTabWidth;
				
				} else {
				aTabCnts[i].childNodes[0].style.height = iHeight;
				aTabCnts[i].childNodes[0].style.width = iWidth;
 				}
		}

		if (curTab.offsetHeight < iHeight) { 
			curTab.style.height = iHeight;
			}
			
		if (curTab.offsetWidth < iWidth && oTabTable.style.width != "100%") {
			curTab.style.width = iWidth;
			}
		}*/
		
		if(ur_get(sId).getAttribute("scrl")=="1") 
		{
			ur_IScr_getObj(sId);
			ur_IScr[sId].scrl.style.width = "auto";
			
			if ( oTabTable.style.width == "" && iWidth != 0 ) {
					oTabTable.style.width = iWidth;
			}
			ur_IScr_create(sId);
			
			/* Remove the TabIndex on Paginator buttons -- Adhoc fix. Later paginiator control could 
				be modified to  take TAB setting as one of the parameters.
			*/
			var oPag = ur_get(sId+"-pg");
			sapUrMapi_Paginator_removeFromTabChain(sId+"-pg");
			var oScr = ur_IScr[sId];
			var iSelIdx = parseInt(oTabTable.getAttribute('sidx'));
		        var iTabWidth = 0;
			for (var n=0;n<oScr.items.length;n++) {
			  if (oScr.items[n].width>iTabWidth) iTabWidth=oScr.items[n].width;
			}
			var iPagWidth=oPag.parentNode.offsetWidth;
			if (iWidth==0) iWidth=oTabTable.offsetWidth;
			
			// Added by Sri, The tabs would collapse if the TabWidth + PaginatorWidth is exactly equal to the 
			// TabStrips offset width, Even though this would occur 1 in 100 times, this Scenario
			// is occuring in some App Dev Case.
			try{
			if(iWidth  < (iPagWidth+iTabWidth+(iTabWidth/2)))
			{
				oTabTable.style.width=iPagWidth+iTabWidth+(iTabWidth/2);
				ur_IScr_draw(sId);
				ur_TS_drawScrollContent(sId);
				}
			}catch(ex){};
			// Re-create the Scroll part if the Selected Tab is not visible.
			// An issue from WDP end, as they are not setting the VisibleIndex.
			// This is just an exception handling from our end. Can later be removed
			// once the WDP starts setting the VisibleIndex properly. @Sri
			if(!oScr.items[iSelIdx].visible)
			{
				//sapUrMapi_setTabIndex(oScr.items[oScr.first][1],0);
				//sapUrMapi_setTabIndex(oScr.items[iSelIdx][1],-1);
				//oTabTable.setAttribute("fidx",oScr.first);
								
				ur_get(sId+"-scrl").setAttribute("fsrl",iSelIdx);
				oScr.first = iSelIdx;
				ur_IScr_create(sId);
				oTabTable.setAttribute("fidx",iSelIdx);
				sapUrMapi_setTabIndex(oScr.items[iSelIdx][1],0);
			}
			else
			{
				sapUrMapi_setTabIndex(oScr.items[iSelIdx][1],0);
				oTabTable.setAttribute("fidx",iSelIdx);
			}
		}
	oTabTable.onresize = new Function("event","sapUrMapi_TabStrip_resize('"+sId+"',"+iWidth+","+iHeight+")"); 
	//sapUrMapi_Resize_AddItem(sId, "sapUrMapi_TabStrip_resize('"+sId+"',"+iWidth+","+iHeight+")");
}

function ur_TS_drawScrollContent(sId) {
	var curTab = ur_get(sId + "-cnt-" + ur_get(sId).getAttribute("sidx"));
	if (sapUrMapi_getCurrentStyle(curTab.childNodes[0],"overflow")!="visible") {
	  var oBorders=curTab.parentNode;
		var iBl=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderBottomWidth"));
		var iBr=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderRightWidth"));
		var iBt=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderTopWidth"));
		var iBb=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderBottomWidth"));
	  curTab.childNodes[0].style.height=curTab.parentNode.offsetHeight-iBt-iBb;
	  curTab.childNodes[0].style.width=curTab.parentNode.offsetWidth-iBl-iBr;
	  curTab.style.overflow="visible";
	  return {height:curTab.parentNode.offsetHeight-iBt-iBb,width:curTab.parentNode.offsetWidth-iBl-iBr};
	} else {
	  return {height:curTab.offsetHeight,width:curTab.offsetWidth};
	}
}

function sapUrMapi_TabStrip_resize(sId,iWidth,iHeight) {
	var o = ur_get(sId);
	if(!o) return;

	if(o.getAttribute("scrl") == 1) {
	var iWidth = o.offsetWidth;
		if (ur_IScr[sId].iWidth && ur_IScr[sId].iWidth == iWidth ) return;
		ur_IScr_resize(sId);
		ur_IScr[sId].iWidth = iWidth;
	}
  	ur_TS_drawScrollContent(sId);
}
//* ------------------------------------------------------------------------

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_getSelectedItemId
//* parameter   : sTabStripId
//* return      : the item id of the selected tabstrip. this is the id of
//                the td (cell).
//                the id is a concatination of sTabStripId the index of the
//                selected item and a string -itm-.
//*	sample			: ur_get(sapUrMapi_TabStrip_getSelectedItemId("yourid")
//* ------------------------------------------------------------------------
function sapUrMapi_TabStrip_getSelectedItemId(sTabStripId) {
  var oTabTable = ur_get(sTabStripId);
	var iSelTab	= parseInt(oTabTable.getAttribute("sidx"));
	return sTabStripId+"-itm-"+iSelTab;
}
//* ------------------------------------------------------------------------

function sapUrMapi_TabStrip_keySelect(strId, intSelectedIdx, intTabCount,e) {
	if(e.keyCode == 9)
	{	
		var oTabScrl = ur_get(strId);
		var iSelIdx = parseInt(ur_get(strId).getAttribute("sidx"));
		var iFocIdx = parseInt(ur_get(strId).getAttribute("fidx"));
		if(ur_get(strId).getAttribute("scrl")!="1")
		{
			sapUrMapi_setTabIndex(ur_get(strId+"-itm-"+iFocIdx),-1);
			sapUrMapi_setTabIndex(ur_get(strId+"-itm-"+iSelIdx),0);
			oTabScrl.setAttribute("fidx",iSelIdx);
		}
		else
		{
			var oScrl = ur_IScr[strId];
			
			if(!oScrl.items[iSelIdx].visible)
			{
				sapUrMapi_setTabIndex(oScrl.items[oScrl.first][1],0);
				sapUrMapi_setTabIndex(oScrl.items[iSelIdx][1],-1);
				if(oScrl.first != iFocIdx)
					sapUrMapi_setTabIndex(oScrl.items[iFocIdx][1],-1);
				oTabScrl.setAttribute("fidx",oScrl.first);
			}
			else
			{
				if(intSelectedIdx != iSelIdx){
				sapUrMapi_setTabIndex(oScrl.items[iSelIdx][1],0);
				sapUrMapi_setTabIndex(oScrl.items[intSelectedIdx][1],-1);
				oTabScrl.setAttribute("fidx",iSelIdx);
				}
			}
		}
			
	}
	if (sapUrMapi_checkKey(e,"keydown",new Array("39","37","33","34","35","36"))){
		if (ur_system.direction == "rtl") {
			if(e.keyCode == 35 || e.keyCode == 36)
			{
				sapUrMapi_TabStrip_focusItem(strId,intSelectedIdx,intTabCount,e.keyCode==36,e.keyCode==35,e);
				ur_EVT_cancel(e);
				return;
			
			}
			if(e.keyCode == 33 || e.keyCode == 34)
			{
				sapUrMapi_TabStrip_focusItem(strId,intSelectedIdx,intTabCount,e.keyCode==33,e.keyCode==34,e);
				ur_EVT_cancel(e);
				return;
			
			}
			else{
			sapUrMapi_TabStrip_focusItem(strId,intSelectedIdx,intTabCount,e.keyCode==37,e.keyCode==39,e);
			ur_EVT_cancel(e);
			return;
			}
		} else {
			if(e.keyCode == 35 || e.keyCode == 36)
			{
				sapUrMapi_TabStrip_focusItem(strId,intSelectedIdx,intTabCount,e.keyCode==35,e.keyCode==36,e);
				ur_EVT_cancel(e);
				return;
			
			}
		
			if(e.keyCode == 33 || e.keyCode == 34)
			{
				sapUrMapi_TabStrip_focusItem(strId,intSelectedIdx,intTabCount,e.keyCode==34,e.keyCode==33,e);
				ur_EVT_cancel(e);
				return;
			
			}else{
			sapUrMapi_TabStrip_focusItem(strId,intSelectedIdx,intTabCount,e.keyCode==39,e.keyCode==37,e);
			ur_EVT_cancel(e);
			return;
			}
		}
  }
  
  if (sapUrMapi_checkKey(e,"keydown",new Array("32"))){
  	e.srcElement.click();
	ur_EVT_cancel(e);
  	return;
  }
  
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_focusItem
//* parameter   : sTabStripId - Id of the TabStrip (required)
//							: iFocusIdx   - Index of the Item to focus (optional),
//														  if not set the selectedItem will be focused
//							: iTabCount - set if you bNext and bPrev use Count of all TabStrips - optional
//							: bNext - if set the next Item gets the focus - optional
//							: bPrev - if set the previous Item gets the focus - optional
//* return      : false
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_TabStrip_focusItem(sTabStripId,iFocusIdx,iTabCount,bNext,bPrev,evt) {
  var oTabTable = ur_get(sTabStripId);

 	if(ur_IScr[sTabStripId] == null || oTabTable != ur_IScr[sTabStripId])
		ur_IScr_getObj(sTabStripId);

  	var objTab = ur_IScr[sTabStripId];
	if (isNaN(iFocusIdx)) iFocusIdx = parseInt(ur_get(sTabStripId).getAttribute("fidx"));
	var iNewIndex=iFocusIdx;
	if (bNext) {// bNext True
		if(oTabTable.getAttribute("scrl") != "1") {// bNext True and not in Scroll mode
			if (iNewIndex < iTabCount-1) {
				iNewIndex=iFocusIdx+1;
			} else 
			  iNewIndex=0;
		} else { //bNext True and in Scroll mode
			if(evt.keyCode == 33 || evt.keyCode == 34) // in RTL, the value is reversed. hence this check
			{
				if(iNewIndex < objTab.items.length - 1)
					ur_IScr_toNextPage(sTabStripId);
				iNewIndex = objTab.first;
			}
			else if(evt.keyCode == 36 || evt.keyCode == 35)
			{
				if(iNewIndex < objTab.items.length - 1)
					ur_IScr_toEnd(sTabStripId);
				iNewIndex = objTab.last;
			}
			else{
				if(iNewIndex < objTab.items.length - 1) {
					iNewIndex=iFocusIdx+1;
				} 
				if(iNewIndex > objTab.last) {
					ur_IScr_toNextItem(sTabStripId);
				}
			}
		}
	}
	if (bPrev) {
		if(oTabTable.getAttribute("scrl") != "1") { // bPrev True and not in Scroll mode
			if (iNewIndex > 0) {
				iNewIndex=iFocusIdx-1;

			} else iNewIndex=objTab.items.length - 1;
		} else {// bPrev True and in Scroll mode
			if(evt.keyCode == 33 || evt.keyCode == 34)
			{
				if(iNewIndex > 0)
					ur_IScr_toPrevPage(sTabStripId);
				iNewIndex = objTab.first;
			}
			else if(evt.keyCode == 36 || evt.keyCode == 35)
			{
				if(iNewIndex > 0)
					ur_IScr_toBegin(sTabStripId);
				iNewIndex = objTab.first;
			}
			else
			{
				if(iNewIndex > 0) {
					iNewIndex=iFocusIdx-1;
				}
				if(iNewIndex < objTab.first){
					ur_IScr_toPrevItem(sTabStripId);
				}
			}
		}
	}
	var iOldFoc     = parseInt(ur_get(sTabStripId).getAttribute("fidx"));
	var oFoc = objTab.items[iNewIndex][1];
	var iSelIdx = parseInt(ur_get(sTabStripId).getAttribute("sidx"));
	
	
	if(oTabTable.getAttribute("scrl") != "1")
	{
		sapUrMapi_setTabIndex(ur_get(sTabStripId+"-itm-"+iOldFoc),-1);
		sapUrMapi_setTabIndex(ur_get(sTabStripId+"-itm-"+iNewIndex),0);
		ur_get(sTabStripId).setAttribute("fidx",iNewIndex);
		oFoc.focus();
		
	}
	else
		ur_TS_setTabIdx(sTabStripId,iFocusIdx,iNewIndex);
	try{
		ur_EVT_addParam(evt,"FirstVisibleItemIdx",objTab.first);
	}catch(ex){};
}

function ur_TS_setTabIdx(sId,iOldFocIdx,iNewIndex)
{
	var oTabScrl = ur_get(sId);
	var iselIdx = oTabScrl.getAttribute("sidx");

	if (ur_IScr[sId] == null) ur_IScr_getObj(sId);
	var oScrl = ur_IScr[sId];
	
	if(!isNaN(iOldFocIdx))
	{
		
		if(iNewIndex == -1) // Flow has come from paginator button click
		{
			iNewIndex  = iselIdx;
			if(!oScrl.items[iselIdx].visible)
			{
				sapUrMapi_setTabIndex(oScrl.items[oScrl.first][1],0);
				if(oScrl.first != iOldFocIdx)
					sapUrMapi_setTabIndex(oScrl.items[iOldFocIdx][1],-1);
				oTabScrl.setAttribute("fidx",oScrl.first);

			}
			else
			{
				sapUrMapi_setTabIndex(oScrl.items[iNewIndex][1],0);
				sapUrMapi_setTabIndex(oScrl.items[iOldFocIdx][1],-1);
				oTabScrl.setAttribute("fidx",iNewIndex);	
			}
			
		}
		else{
			sapUrMapi_setTabIndex(oScrl.items[iOldFocIdx][1],-1);
			sapUrMapi_setTabIndex(oScrl.items[iNewIndex][1],0);
			oTabScrl.setAttribute("fidx",iNewIndex);
			oScrl.items[iNewIndex][1].focus();
		}
	}
}
//* ------------------------------------------------------------------------


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_enter
//* parameter   : sId - Id of the TabStrip
//* description : with the 508 flag turned on this function will check for
//*               keydowns and skip the tabstrip or lead the user to
//								the selected tab item in case of tab, left or right arrow is pressed
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_TabStrip_enter (sId,e) {
	if (e.srcElement.id==sId+"-skipstart") {
		if (sapUrMapi_skip(sId+'-skipstart',sId+'-skipend',e)) return;
    if (!e.shiftKey) { //shift tabs not allowed here
		  if (sapUrMapi_checkKey(e,"keydown",new Array("9","39","37"))){
	        sapUrMapi_TabStrip_focusItem(sId);
	   
				ur_EVT_cancelBubble(e);
		  }
	  }
	}
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_setActiveItem
//* parameter   : sId  - Id of the TabStrip
//  							iIdx - Index of the Item to activate (select)
//* description : selects an item of the tabstrip with the id sId
//* return      : true if the item was selected, else false
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_TabStrip_setActiveItem(sId,iIdx) {

		if (isNaN(iIdx)) return;
		
		if(ur_IScr[sId] == null)
			ur_IScr_getObj(sId);
			
		var oScrl = ur_IScr[sId];
		var obj	= ur_get(sId);
		
		if (obj != oScrl.Ref) {
			ur_IScr_getObj(sId);
			oScrl = ur_IScr[sId]
		}
			
		var iSelTab	= parseInt(obj.getAttribute("sidx"));
		var iTabLength	= parseInt(obj.getAttribute("ic"));
		
		if (oScrl.items[iIdx][1].getAttribute("st")!=null && oScrl.items[iIdx][1].getAttribute("st").indexOf("d")>-1) return false; 
		if ((iTabLength==1) || (iSelTab==iIdx)) return true; 
		
		var oCurrentTxt  = oScrl.items[iSelTab][1].firstChild;
		var oCurrentCell = oScrl.items[iSelTab][1];
		var oClickedTxt  = oScrl.items[iIdx][1].firstChild;
		var oClickedCell = oScrl.items[iIdx][1];
		
		var oCurrentContent  = ur_get(sId+"-cnt-"+iSelTab);
	  	var oClickedContent  = ur_get(sId+"-cnt-"+iIdx);
		
		var oCloseCurrent = ur_get(sId + "-itm-cl-" + iSelTab);
		var oCloseClicked = ur_get(sId + "-itm-cl-" + iIdx);
		
		var oBorders=oClickedContent.parentNode;
		var iBl=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderBottomWidth"));
		var iBr=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderRightWidth"));
		var iBt=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderTopWidth"));
		var iBb=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderBottomWidth"));
		
		oCurrentCell.className="urTbsLabelOff"; 
		oCurrentTxt.className = "urTbsTxtOff";  
		oClickedTxt.className = "urTbsTxtOn";   
	  oClickedCell.className="urTbsLabelOn";  
	  
		if (oCloseCurrent != null) oCloseCurrent.className = "urTbsCloseUnSel";
		if (oCloseClicked != null) oCloseClicked.className = "urTbsCloseSel";
		
	  sapUrMapi_setTabIndex(oCurrentCell,-1);
	  sapUrMapi_setTabIndex(oClickedCell,0);
	  	
	  obj.setAttribute("sidx",iIdx);
	  obj.setAttribute("fidx",iIdx); 

	  //switch the content of the tabs
    if (sapUrMapi_getCurrentStyle(oClickedContent.childNodes[0],"overflow")!="visible") {
  		oClickedContent.childNodes[0].style.height=oClickedContent.parentNode.offsetHeight-iBt-iBb;
  		oClickedContent.childNodes[0].style.width=oClickedContent.parentNode.offsetWidth-iBl-iBr;
		} else {
			if ( obj.getAttribute("exact") == "1") {
		    oClickedContent.style.height=oClickedContent.parentNode.offsetHeight-iBt-iBb;
		    	if ( !oClickedContent.style.width == "100%" )
		    oClickedContent.style.width=oClickedContent.parentNode.offsetWidth-iBl-iBr;
		  }
		}
		
		with ( oCurrentContent.style ) {
			overflow="hidden";
			position="absolute";
			top = "-1000";
			left = "0";
			visibility = "hidden";
		}
		
		with ( oClickedContent.style ) {
			overflow="visible";
			position="static";
			visibility="inherit";
		}

		if(ur_get(sId+"-itm-cl-"+iIdx))
		{
			ur_get(sId+"-itm-cl-"+iIdx).className = "urTbsCloseSel";
	}	
		if(ur_get(sId+"-itm-cl-"+iSelTab))
		{
			ur_get(sId+"-itm-cl-"+iSelTab).className = "urTbsCloseUnSel";
		}
	
	/* set status for the current cell and the clicked cell */
	ur_setSt(oCurrentCell,ur_st.NOTSELECTED,true);
	ur_setSt(oCurrentCell,ur_st.SELECTED,false);
	ur_setSt(oClickedCell,ur_st.NOTSELECTED,false);
	ur_setSt(oClickedCell,ur_st.SELECTED,true);
	
	
  if (obj.getAttribute("exact")=="1")
	  ur_TS_oadi(sId);
  else {
    var bVisible=oScrl.items[iIdx].visible;
    if (bVisible) ur_IScr_draw(sId);
    if (!oScrl.items[iIdx].visible || !bVisible) {
      oScrl.first=iIdx;
      oScrl.last=-1;
      ur_IScr_draw(sId);
    }
  }
  
  if (ur_system.is508) {
	if(oClickedCell.style.display == "inline"){
	   sapUrMapi_refocusElement(oClickedCell.id);
	}else{
		sapUrMapi_refocusElement(oScrl.items[oScrl.first][1]);
	}
}
	return true;
}
/**************************************************/
//  Generic handler of OnClick and delegates it for specific handling
//
/*************************************************/
function ur_TS_cl(sId,evt)
  {
	var sElm = evt.srcElement;
	var bIdPresent = false;
	while(!bIdPresent)
	{		
		if(sElm.getAttribute('idx') !=null)
		{		
			if (oScrl.items[param[1]][1].getAttribute("st")!=null && oScrl.items[param[1]][1].getAttribute("st").indexOf("d")>-1) return false; 
			ur_EVT_fire(ur_get(sId+'-scrl'),"otc");
			bIdPresent = true;
		}
		else{
			sElm = sElm.parentNode;
			}
		
	} 	   
	
  }
	
/************************************************/
//   Item Display
//
/************************************************/

function ur_TS_oadi(sId) {
  var oScrl = ur_IScr[sId];
	// Currently displayed first Scroll Index
	var iFirst = oScrl.first;
	// Currently displayed last Scroll Index
	var iLast = oScrl.last;
  if (oScrl.ref.getAttribute("scrl")!="1") {
    iFirst=0;
    iLast=parseInt(oScrl.ref.getAttribute("ic"))-1;
  }
  
	// The Selected Item Index
	var iSel = parseInt(ur_get(oScrl.ref.id).getAttribute('sidx')); 
	
	for(i=iFirst;i<=iLast;i++) {
		var arrItems = oScrl.items[i];
		var oItemImage = arrItems[0];
		// Condition: First Item front Image
		if(iFirst == i ) {
			if(iFirst != 0) { // Condition: The current first scroll item not the first TabItem (we still have items to the left)
				if(iSel== i) // Condition: The Current Item is selected
					oItemImage.className = "urTbsFirstAngOnPrevOn";
				else
					oItemImage.className = "urTbsFirstAngOffPrevOn";
			} else {//  No items to the left of this item
				if(iSel== i) // The first item is selected
					oItemImage.className = "urTbsFirstAngOnPrevOff";
				else
					oItemImage.className = "urTbsFirstAngOffPrevoff";
			}
		} else { // Not the first Scroll item
			if((i!=0 && iSel== i-1)) 
			  oItemImage.className = "urTbsAngOnOff"; // Set the scroll img for prev item
			else if(iSel == i) // NOT the first scroll item but selected
				oItemImage.className = "urTbsAngOffOn";
			else // NOT the first scroll item and NOT selected either....
				oItemImage.className = "urTbsAngOffOff";
		}
		// handling the last image scroll
		if(iLast == i ) {
			var oLastImg=ur_get(oScrl.ref.id+"-n");
			if(iLast != (oScrl.items.length -1)) { // the current last scroll item IS NOT the last TabItem
				if(iSel== i) //the current last scroll item IS NOT the last TabItem but selected
					oLastImg.className = "urTbsLastOnNextOn";
				else //the current last scroll item IS NOT the last TabItem but NOT selected
					oLastImg.className = "urTbsLastOffNextOn";
			} else {// the current last scroll item IS the last TabItem
				if(iSel== i)// the current last scroll item IS the last TabItem but selected
					oLastImg.className = "urTbsLastOnNextOff";
				else // the current last scroll item IS the last TabItem but NOT Selected
					oLastImg.className = "urTbsLastOffNextOff";
			}
		}
	}
	// set the Paginator Button states
	if(ur_get(sId).getAttribute("scrl") == "1")
		ur_TS_setPagiButtonState(iFirst,iLast,sId);
	
}
function ur_TS_setPagiButtonState(iFirst,iLast,sId) {
  var oScrl = ur_IScr[sId];

	// set all the buttons initially to enabled
	sapUrMapi_Paginator_setStates(sId+'-pg',new Array("","",UR_PAGINATOR_BUTTON.PREVIOUS_ITEM,UR_PAGINATOR_BUTTON.NEXT_ITEM,"",""),new Array("","",true,true,"",""));
	
	// condition to set the 'Next Item' paginator button disabled
	if(ur_IScr[sId].last == oScrl.items.length -1 || ur_IScr[sId].last == -1)
	{
		
		var arrBtn = new Array();
		arrBtn[3] = UR_PAGINATOR_BUTTON.NEXT_ITEM;
				
		var arrBtnState = new Array();
		arrBtnState[3] = false;
		
		sapUrMapi_Paginator_setStates(sId+'-pg',arrBtn,arrBtnState);
	}
    
	// condition to set the  'Previous Item' paginator button disabled
	if(ur_IScr[sId].first == 0)
	{
		
		sapUrMapi_Paginator_setStates(sId+'-pg', new Array("","",UR_PAGINATOR_BUTTON.PREVIOUS_ITEM), new Array("","",false));
	}
}
//* ------------------------------------------------------------------------

function sapUrMapi_TabStripItem_keydown(sId,evt)
{
	if(evt.keyCode== 13)
	{
		var oR = ur_get(sId);
		if(oR.getAttribute("dbid")!=null)
		 {
			 sapUrMapi_triggerDefaultButton(sId,evt);
		 }
	 }	 
}
