//* ************************************************************************
//* Item List Box
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function		: sapUrMapi_ItemListBox_registerCreate
//* parameter		: sId     -  control id
//*								sWidth  -  width of the control
//* return			:
//* description	: set height and width of the control
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_registerCreate(sId,sWidth){
	if(sId=="")return;
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_ItemListBox_setDim('"+sId+"','"+sWidth+"')");
}

function sapUrMapi_ItemListBox_getScrollTop(sId){
	var o = sapUrMapi_ItemListBox_getObject(sId,document,null);
	return o.scrl.scrollTop;
}

function sapUrMapi_ItemListBox_setScrollTop(sId, iScrollTop){
	var o = sapUrMapi_ItemListBox_getObject(sId,document,null);
	o.scrl.scrollTop = iScrollTop;
	o.r.setAttribute("scrltop", iScrollTop);
}

//* ------------------------------------------------------------------------
//* function    : ur_ItemListBox_getIndex
//* parameter   : sId  - id of the item list box
//*								sKey - item key
//* return      :	item index
//* description	: get index of an item with key sKEy
//* ------------------------------------------------------------------------
function ur_ItemListBox_getIndex(sId,sKey){
	if(sId=="")return;
	var o=sapUrMapi_ItemListBox_getObject(sId,document);
	var i=0;
	for(i=0; i<o.itms.length; i++)
		if(o.itms[i].k==sKey)	return i+1;
	return null;
}

//* ------------------------------------------------------------------------
//* function		: sapUrMapi_ItemListBox_getObject
//* parameter		: sId  -  control id
//*								oDoc - document object
//*								oEvt - event object
//* return			:
//* description	: get control object
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_getObject(sId,oDoc,oEvt){
	if(sId=="")return;
	var o=new Object();
	// get root object
	var oR=oDoc.getElementById(sId+"-r");
	if (oR && oR.hasChildNodes() && oR.firstChild.tagName=="XMP") {
	  oR.innerHTML=oR.firstChild.innerHTML; 
	}	
	o.r=oDoc.getElementById(sId);
	// get table objects
	o.tbl=o.r.getElementsByTagName("TABLE")[0];
	o.tbd=o.tbl.firstChild;
	// get box
	o.box=o.tbl.parentNode;
	// get scroll container
	o.scrl=o.box;
	// get all items
	o.itms=o.tbl.getElementsByTagName("TR");
	// get focused item
	var sFocus=o.tbl.getAttribute("focusitm");
	if(sFocus)
		o.focusedItm=o.itms[parseInt(sFocus)-1];
	else
		o.focusedItm=null;
	var sOldFocus=o.tbl.getAttribute("oldfocusitm");
	if(sOldFocus)
		o.oldFocusedItm=o.itms[parseInt(sOldFocus)-1];
	if(o.focusedItm==null)
		o.focusedItm=o.itm;
	// get selected items and previous and next item of the focused item
	o.selItms=new Array();
	o.prevItm=null;
	o.nextItm=null;
	var j=0;
	for(var i=0;i<o.itms.length;i++){
		if(o.itms[i].className=="urIlb2ISel"){
			o.selItms[j]=o.itms[i];
			j++;
		}
		if(o.focusedItm!=null&&o.focusedItm==o.itms[i]){
			if(i>0)
				if(o.itms[i-1].name=="HLine") o.prevItm=o.itms[i-2];
				else o.prevItm=o.itms[i-1];
			if(i<o.itms.length-1)
				if(o.itms[i+1].name=="HLine") o.nextItm=o.itms[i+2];
				else o.nextItm=o.itms[i+1];
		}
	}
	if(o.prevItm==null && o.nextItm==null) o.nextItm=o.itms[0];
	// get parent id
	o.parId=o.r.getAttribute("parid");
	// get control parameters
	if(o.parId!=null&&o.parId!="") o.ro = ur_isSt(o.parId,ur_st.READONLY);
	else o.ro = ur_isSt(o.r.id,ur_st.READONLY);
	o.enbl = !ur_isSt(o.r.id,ur_st.DISABLED);
	o.inv = ur_isSt(o.r.id,ur_st.INVALID);
	o.popup = o.tbl.getAttribute("pop") == "true";
	o.multi = o.tbl.getAttribute("multi") == "true";
	o.size = parseInt(o.tbl.getAttribute("s"));
	o.vissize = parseInt(o.tbl.getAttribute("v"));
	o.userheight = o.tbl.getAttribute("h");
	o.userwidth = o.tbl.getAttribute("w");
	o.cols = o.tbl.getAttribute("cols");
	o.valcol=o.tbl.getAttribute("vcol");
	o.icocol=o.tbl.getAttribute("icol");
	return o;
}

//* ------------------------------------------------------------------------
//* function:		 sapUrMapi_ItemListBox_getItem
//* parameter:	 o    - item list box object
//*							 sKey - item key
//* return:			 item object
//* description: get item object with the passed key
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_getItem(o,sKey){
	for(var i=0; i<o.itms.length;i++){
		if(sKey==o.itms[i].getAttribute("k"))
			return o.itms[i];
	}
	return o.itms[0];
}

//* ------------------------------------------------------------------------
//* function:		 sapUrMapi_ItemListBox_setParentId
//* parameter:	 sId       - id of the item list box
//*							 sParentId : id of the parent control
//* return:			 none
//* description: set parent id if item list box is attached for example to a
//*              combobox
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_setParentId(sId, sParentId){
	if (!ur_get(sId)) sapUrMapi_ItemListBox_getObject(sId,document,null);
	ur_get(sId).setAttribute("parid",sParentId);
}

//* ------------------------------------------------------------------------
//* function		: sapUrMapi_ItemListBox_getSelectedKeys
//* parameter		: sId  -  item list box id
//*								oDoc - document object
//* return			: array of selected keys
//* description	: get item keys and values
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_getSelectedKeys(sId,oDoc){
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,null);
	var aKeys=new Array();
	var j=0;

	for(var i=0; i<o.itms.length;i++){
		if( o.itms[i].className=="urIlb2ISel" ){
			aKeys[j]=o.itms[i].getAttribute("k");
			j++;
		}
	}
	return aKeys;
}

//* ------------------------------------------------------------------------
//* function		: sapUrMapi_ItemListBox_setSelectedKeys
//* parameter		: sId   - control id
//*								aKeys - array of keys to be selected
//*								oDoc  - document object
//* return			:
//* description	: select items specified in the sKeys array
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_setSelectedKeys(sId,aKeys,oDoc){
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,null);
	var sKey=aKeys.toString();

	for(var i=0; i<o.itms.length;i++)
		if( sKey.indexOf(o.itms[i].getAttribute("k")) == 0 )
			sapUrMapi_ItemListBox_selectItem(o,o.itms[i],true,null);
}

//* ------------------------------------------------------------------------
//* function		: sapUrMapi_ItemListBox_setSelectedKey
//* parameter		: sId     - control id
//*								sKey    - key to be selected
//*								oDoc    - document object
//*								bScroll - scroll selected item into view
//* return			:
//* description	: select item with passed key
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_setSelectedKey(sId,sKey,oDoc,bScroll){
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,null);
	
	// check if there are items in the listbox
	if(o.size<=0) return;
	
	for(var i=0; i<o.itms.length;i++){
		if( sKey==o.itms[i].getAttribute("k") ){
			sapUrMapi_ItemListBox_deselectAllItems(o);
			sapUrMapi_ItemListBox_itemSetHighlight(o.itms[i], true);
			sapUrMapi_ItemListBox_focusItem(o,o.itms[i]);
			if(bScroll) sapUrMapi_ItemListBox_scrollIntoView(o,o.itms[i],true);
			return;
		}
	}
}

//* ------------------------------------------------------------------------
//* function		: sapUrMapi_ItemListBox_selectHoveredItem
//* parameter		: sId  - control id
//*								oDoc - document object
//*								oEvt - event object
//* return			:
//* description	: select hovered item
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_selectHoveredItem(sId,oDoc,oEvt){
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,null);
	for(var i=0; i<o.selItms.length;i++)
		sapUrMapi_ItemListBox_selectItem(o,o.selItms[i],true,oEvt);
}

//* ------------------------------------------------------------------------
//* function		: sapUrMapi_ItemListBox_getList
//* parameter		: sId -  control id
//*								doc - document object
//* return			: string of keys and values sparated by | and ||
//* description	: get item keys and values
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_getList(sId,doc){
	var o=sapUrMapi_ItemListBox_getObject(sId,doc,null);
	var oCols = new Array();
	var sItmKey = "";
	var sList = "";
	for( var i=0; i<o.itms.length; i++ ){
		sItmKey = o.itms[i].getAttribute("k");
		oCols =  o.itms[i].getElementsByTagName("TD");
		sList += "||";
		sList += oCols[parseInt(o.valcol)-1].innerText;
		sList += "|";
		sList += sItmKey;
	}
	if(sList!="") sList+="||";
	return sList;
}

//* ------------------------------------------------------------------------
//* function		: sapUrMapi_ItemListBox_setDim
//* parameter		: sId     -  control id
//* 						  sWidth  -  width of the control
//* return			:
//* description	: set height and width of the item list box
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_setDim( sId, sWidth ){
	var o = sapUrMapi_ItemListBox_getObject(sId,document,null);
	
	// get  border height and item height
	var oILBBorder = ur_get("ILBBORDER");
	var oILBItem = ur_get("ILBITEM");
	
	// create element for height calculation if not already available
	if(!oILBBorder){
		oILBBorder = document.createElement("span");
		oILBItem = document.createElement("span");
		oILBBorder.id = "ILBBorder";
		oILBItem.id = "ILBItem";
		oILBBorder.style.position = "absolute";
		oILBBorder.style.top = "-1000";
		oILBItem.style.position = "absolute";
		oILBItem.style.top = "-1000";
		oILBBorder.innerHTML="Text";
		oILBItem.innerHTML="Text";
		oILBBorder.className = "urIlb2Box urIlb2I";
		oILBItem.className = "urIlb2I";
		document.body.appendChild(oILBBorder);
		document.body.appendChild(oILBItem);
	}
	o.iItemHeight = parseInt(oILBItem.offsetHeight);
	o.iBorderHeight = parseInt(oILBBorder.offsetHeight - oILBItem.offsetHeight);
	
	// set height
	if( parseInt(o.vissize) > 0 && !isNaN(parseInt(o.vissize)) )
		sapUrMapi_ItemListBox_setSize(o, parseInt(o.vissize));
	else if( (parseInt(o.userheight) > 0 && !isNaN(parseInt(o.userheight))) || o.popup )
		sapUrMapi_ItemListBox_setHeight(o, parseInt(o.userheight));
	// set width
	if( parseInt(sWidth) >= 0 && !isNaN(parseInt(sWidth)) )
		sapUrMapi_ItemListBox_setWidth(o, parseInt(sWidth));

	// set scroll top
	var iScrollTop = parseInt(o.r.getAttribute("scrltop"));
	if(isNaN(iScrollTop)) iScrollTop = 0;
	o.scrl.scrollTop = iScrollTop;		
}

//* ------------------------------------------------------------------------
//* function		: sapUrMapi_ItemListBox_setSize
//* parameter		: o       -  control object
//* 							sSize   -  number of visible items
//* return			:
//* description	: set control height depending on the number of visible items
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_setSize(o,sSize){
	var iHeight = 0;

	if(parseInt(sSize) <= 0) return;
	if(parseInt(sSize) >= o.itms.length) return;

	iHeight = parseInt(sSize) * o.iItemHeight + o.iBorderHeight;
	
	sapUrMapi_ItemListBox_setHeight(o,iHeight);
}

//* ------------------------------------------------------------------------
//* function		: sapUrMapi_ItemListBox_setHeight
//* parameter		: o				- item list box object
//*               sHeight	- height
//* return			:
//* description	: Set height of the control. The height is set to the next
//* 							smaller value where you see all visible items.
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_setHeight(o,sHeight){
	var iCurrentHeight = o.scrl.offsetHeight; 
	var iNewHeight=0;
	var iWindowHeight=parseInt(document.body.clientHeight); 
	var iNeededHeight = o.iItemHeight * o.itms.length + o.iBorderHeight;
	
	/* create an element for height calculation if not already available */
	var oILBHeight = ur_get("ILBHeight");
	if(!oILBHeight){
		oILBHeight = document.createElement("div");
		oILBHeight.id = "ILBHeight";
		oILBHeight.style.position = "absolute";
		oILBHeight.style.top = "-1000";
		oILBHeight.className = "urIlb2Box urIlb2I";
		document.body.appendChild(oILBHeight);
	}		
	
	/* no height is passed
	 * ITEMLISTBOX: nothing to do
	 * COMBOBOX: try if the needed height fits into the window */
	if( (isNaN(parseInt(sHeight)) || parseInt(sHeight) <= 0 )){
		if(!o.popup) return;
		else iNewHeight = iNeededHeight;
	}
	
	/* get new height in px */
	if(!isNaN(parseInt(sHeight)) && parseInt(sHeight) > 0 ){
		oILBHeight.style.height = sHeight;
		iNewHeight = parseInt(oILBHeight.offsetHeight);
	}
	
	/* make sure that no item is cut, downsize box if yes */
	if(o.itms.length > 0){
		iNewHeight = parseInt((iNewHeight - o.iBorderHeight) / o.iItemHeight) * o.iItemHeight + o.iBorderHeight;
	}
	
	// adjust listbox to window height if listbox is used for a combo box
	if(o.popup && iNewHeight>iWindowHeight){
		iNewHeight=iWindowHeight;
	}
	
	// check if the height must be changed
	if(iCurrentHeight != 0 && iCurrentHeight == iNewHeight){
		return;
	}
	
	// set height and vertical scrolling
	if( iNewHeight < iNeededHeight){
		o.scrl.style.overflowY = "scroll";
		o.scrl.setAttribute("style","overflow-y:scroll;");
	}
	else if(o.popup){
		o.scrl.style.overflowY = "visible";
		o.scrl.setAttribute("style","overflow-y:visible;");
	}
	o.scrl.style.height = iNewHeight;
	o.scrl.setAttribute("style","height:"+iNewHeight+";");
	
	// set number of visible items
	o.tbl.setAttribute("s",parseInt((iNewHeight - o.iBorderHeight) / o.iItemHeight));
}

//* ------------------------------------------------------------------------
//* function		: sapUrMapi_ItemListBox_setWidth
//* parameter		: o				- item list box object
//* 						  sWidth	- width
//* return      :
//* description	: Set width, if width is greater than the width
//								you need for the control.
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_setWidth(o,sWidth){
	var iWidth=0;
	var iNewWidth=parseInt(sWidth);
	if (isNaN(iNewWidth) || iNewWidth<=0) return;
	o.box.style.width = "10px";
	iWidth = o.r.offsetWidth;
	if (iNewWidth<iWidth) return;
	o.box.style.width = iNewWidth;
	o.tbl.style.width = "100%";
	o.box.setAttribute("style","width:"+iNewWidth+";");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_itemSelected
//* parameter   : oItm - Item object
//* return      : true/false
//* description	: Check if an item is selected or not.
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_itemSelected(oItm){
	if( oItm.className == "urIlb2ISel" ) return true;
	return false;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_itemSetHighlight
//* parameter   : sItmId  - item id (= control id + item key)
//*               bOn     - turn highlighting on an off
//* return      :
//* description	: turn highlighting of an item on and off
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_itemSetHighlight(oItm,bOn){
	if( oItm == null || oItm.tagName != "TR" ) return;

	if( bOn && oItm.className != "urIlb2ISel") oItm.className = "urIlb2ISel";
	else if( oItm.className == "urIlb2ISel" ) oItm.className = "";
	else return;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_deselectAllItems
//* parameter   : o - control object
//* return      :
//* description	: turn highlighting of all items off
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_deselectAllItems(o){
	if(o.selItms==null) return;
	for(var i=0; i<o.selItms.length; i++)
		sapUrMapi_ItemListBox_itemSetHighlight(o.selItms[i],false);
}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_getVal
//* parameter   : sId    - control id
//*               sItmId - item id
//* return      : key value
//* description	: get key value of an item
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_getVal(o,oItm){
	if(o.valcol==null) return null;
	var oCols=oItm.getElementsByTagName("TD");
	return oCols[parseInt(o.valcol)-1].innerText;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_getIconSrc
//* parameter   : sId      - control id
//*               sItmId   - item id
//* return      : key value
//* description	: get icon source of an item
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_getIconSrc(o,oItm){
	if(o.icocol==null || o.icocol=="") return null;
	var oCols=oItm.getElementsByTagName("TD");
	var oIco;
	oIco = oCols[parseInt(o.icocol)-1].firstChild;
	return oIco.style.backgroundImage;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_hoverItem
//* parameter   : sId     - control id
//*               sItmId  - item id
//* return      :
//* description	: turn highlighting of all items on and off
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_hoverItem(o,oItm){
	if(o.ro) return;
	sapUrMapi_ItemListBox_deselectAllItems(o);
	sapUrMapi_ItemListBox_itemSetHighlight(oItm, true);
	sapUrMapi_ItemListBox_focusItem(o,oItm);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_scrollIntoView
//* parameter   : sId    - control id
//*               sItmId - item id
//*								bTop   - item on to of the box
//* return      :
//* description	: if item is not visible scroll item into view
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_scrollIntoView(o,oItm,bTop){
	if( (o.box.scrollTop > oItm.rowIndex*oItm.offsetHeight) || (o.box.scrollTop+o.box.offsetHeight-2*o.box.clientTop <= oItm.rowIndex*oItm.offsetHeight) )
		if(!bTop) o.box.scrollTop=(oItm.rowIndex-o.size+1)*oItm.offsetHeight;
		else o.box.scrollTop=oItm.rowIndex*oItm.offsetHeight;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_selectItem
//* parameter   : o    - list box control
//*               oItm - item object
//*								bTop - scroll item on top/bottom
//*               oEvt - event object
//* return      : -
//* description	: Select an item. If list box is a single select list box
//*               or you press ctrl or shift, deselect all other items 
//*								before. Handle combo box communication if list box
//*								is used for a combo box.
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_selectItem(o,oItm,bTop,oEvt){
	if(!o.ro && o.enbl){
		if(!(o.multi&&(oEvt.shiftKey||sapUrMapi_bCtrl(oEvt)))) sapUrMapi_ItemListBox_deselectAllItems(o);
		sapUrMapi_ItemListBox_itemSetHighlight(oItm,true);
		if(o.popup){
			sapUrMapi_ComboBox_setValue(o.parId, oItm.getAttribute("k"), sapUrMapi_ItemListBox_getVal(o,oItm), sapUrMapi_ItemListBox_getIconSrc(o,oItm),oEvt);
		}
	}
	else if(o.popup)
		sapUrMapi_ComboBox_setValue(o.parId, null,null, null,oEvt);	
		
	sapUrMapi_ItemListBox_focusItem(o,oItm);

	if(o.popup) sapUrMapi_ItemListBox_scrollIntoView(o,oItm,bTop);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_deselectItem
//* parameter   : sId     - control id
//*               sItmId  - item id
//*               bPopup  - item list box is popup of combo box
//*               bRo     - read only
//*               doc     - document object
//* return      :
//* description	: deselect an item
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_deselectItem(oItm){
	sapUrMapi_ItemListBox_itemSetHighlight(oItm,false);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_itemListBox_focusItem
//* parameter   : o    - list box object
//*               oItm - item object
//* return      :
//* description	: set focus to an item
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_focusItem(o,oItm){
	// remove focus from previously focused item
	if(!o.popup&&o.focusedItm!=null)
		sapUrMapi_setTabIndex(o.focusedItm.getElementsByTagName("TD")[parseInt(o.valcol)-1],-1);
	// set focus
	o.tbl.setAttribute("focusitm",oItm.rowIndex+1);
	if (!o.popup){
		var oCols=oItm.getElementsByTagName("TD");
		sapUrMapi_setTabIndex(oCols[parseInt(o.valcol)-1],0);
		if(ur_system.is508){									
			oCols[parseInt(o.valcol)-1].setAttribute("t",oItm.getAttribute("t"));								
			if(oItm.className.indexOf("Sel")!=-1){ 
				ur_setSt(oCols[parseInt(o.valcol)-1],ur_st.SELECTED,true);
				ur_setSt(oCols[parseInt(o.valcol)-1],ur_st.NOTSELECTED,false);					
			}
			else{
				ur_setSt(oCols[parseInt(o.valcol)-1],ur_st.SELECTED,false);	
				ur_setSt(oCols[parseInt(o.valcol)-1],ur_st.NOTSELECTED,true);	
			}	
		}
		if (document.activeElement != oCols[parseInt(o.valcol)-1]) {
		  var oTd = oCols[parseInt(o.valcol)-1];
		  ur_focus(oTd);
     }
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_mouseover
//* parameter   : sId  - Id of the item list box (string)
//*               oDoc - document object
//*		  					oEvt - event object
//* return      :
//* description	: Hover item
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_mouseover( sId,oDoc,oEvt) {
	var oFrom=oEvt.fromElement;
	var oTo=oEvt.toElement;
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,oEvt);
	
	if( oTo.tagName=="DIV" || oTo.tagName=="SPAN" || o.ro || !o.enbl || o.size==0) return;

	while( oFrom != null && oFrom.tagName != "TR" )
		oFrom = oFrom.parentNode;
	while( oTo != null && oTo.tagName != "TR" )
		oTo = oTo.parentNode;

	if( oTo==null || oTo.name=="HLine" || oFrom==oTo ) return;

	sapUrMapi_ItemListBox_hoverItem(o,oTo);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_focus
//* parameter   : sId    - id of the item list box
//*               oDoc   - document object
//*		  					oEvt   - event object
//* return      :
//* description	: Handle onfocus event.
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_focus(sId,oDoc,oEvt){
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,oEvt);

	// return if disabled and 508 mode is off
	if(!o.enbl && !ur_system.is508) return;
	sapUrMapi_DataTip_show(sId,"focus");
	// handle focus only for the whole control
	if(ur_evtSrc(oEvt).id!=sId) return;
	// focus popup trigger if used as popup
	if(o.popup){
		ur_focus(ur_get(o.parId));
		return;
	}
	// handle tab back
	if(o.tbl.getAttribute("tabback")=="true"){
		o.tbl.setAttribute("tabback","false");
		var oNewEvt=oDoc.createEventObject();
		oNewEvt.keyCode="9";
		oNewEvt.shiftKey=true;
		o.r.fireEvent("onkeydown",oNewEvt);
		return;
	}
	// get item to be focused
	if(o.selItms.length==0) oItm = o.itms[0];
	else oItm = o.selItms[0];
	// focus item
	var iTop = o.r.scrollTop;
	sapUrMapi_ItemListBox_focusItem(o,oItm);
	o.r.scrollTop = iTop;
}

//* -----------------------------------------------------------------------
//* function	  : sapUrMapi_ItemLIstBox_blur
//* parameter	  : sId	 - id of the item list box 
//*							  oEvt - event object
//* description : Hides the DataTip
//*------------------------------------------------------------------------
function sapUrMapi_ItemListBox_blur(sId,oEvt) {
	if(oEvt.toElement!=null && oEvt.toElement.className.indexOf("Ilb")!=-1) return;
	sapUrMapi_DataTip_hide(sId);
	if(ur_system.is508)
		ur_get(sId).setAttribute("nav","false");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_click
//* parameter   : sId 	 - id of the item list box (string)
//*               oDoc   - document object
//*		  		      oEvt   - event object
//* return      :
//* description	: Select item and set focus. If multiple selection is not allowed,
//*               deselect all other items.
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_click(sId,oDoc,oEvt) {
	// get clicked item, handle only item clicks in this function
	var oItm=ur_evtSrc(oEvt);
	if(oItm.tagName!="TD" && oItm.tagName!="IMG") return; 	
	while(oItm.tagName!="TR"){
		if(oItm.getAttribute("ct")=="ItemListBox") return;
		oItm=oItm.parentNode;
	}
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,oEvt);
	var bSel = false;
	
	// check if there are items in the listbox
	if(o.size<=0) return;
	
	// if multiple selection is on and you have not pressed the control key, deselect all other items
	if( o.multi == true && sapUrMapi_bCtrl(oEvt) == false )
		sapUrMapi_ItemListBox_deselectAllItems(o);

	// if multiple selection is on and you have pressed the shift key, select items between focused item and item you clicked on
	if(oEvt.shiftKey == true && o.multi == true  && (o.focusedItm != oItm) ){
		var oStart=o.oldFocusedItm;
		if(oStart.rowIndex < oItm.rowIndex)
			for(var i=oStart.rowIndex;i<=oItm.rowIndex;i++)
				sapUrMapi_ItemListBox_selectItem(o,o.itms[i], true, oEvt);
		else
			for(var i=oStart.rowIndex;i>=oItm.rowIndex;i--)
				sapUrMapi_ItemListBox_selectItem(o,o.itms[i], true, oEvt);
	}

	// select only item you clicked on
	else{
		sapUrMapi_ItemListBox_selectItem(o, oItm, true,oEvt);
		o.tbl.setAttribute( "oldfocusitm", oItm.rowIndex+1 );
		sapUrMapi_Focus_showFocusRect(document.activeElement);
	}

	return ur_EVT_cancel(oEvt);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_keypress
//* parameter   : sId    - control id
//*               oEvt   - event object
//* return      :
//* description	: Handle key navigation within the box, for example
//*               arrow up and down.
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_keypress( sId, oEvt ){

//CSS: 619346 2011
//WDJ does not handle keypress. We remove the functionality to keyDown

	/*var o=sapUrMapi_ItemListBox_getObject(sId, document, oEvt);
	if (o.popup) return;
  // handle all key down events and select or focus the next matching item
  if( oEvt.keyCode > 0){
    var sSearchChar = String.fromCharCode(oEvt.keyCode);
    var sSelectedKey = "";
    if (o.selItms.length > 0) {
      sSelectedKey = o.selItms[o.selItms.length-1].getAttribute("k");
      
    }
    var sNewKey = sapUrMapi_ItemListBox_findItem(sId,sSearchChar,sSelectedKey,document);
    if (sNewKey!="") sapUrMapi_ItemListBox_setSelectedKey(sId,sNewKey,document,true);
  }  */
  }  

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_findItem
//* parameter   : sId    - control id
//*               sSearch - String to search for
//*               sStartKey - Key from where the search is started
//*               oDoc  - document dom reference 
//* return      :
//* description	: Handle key navigation within the box, for example
//*               arrow up and down.
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_findItem(sId,sSearch,sStartKey,oDoc) {
	var sList=sapUrMapi_ItemListBox_getList(sId,oDoc);
	var sLIST=sList.toUpperCase();
	var sSEARCH="||"+sSearch.toUpperCase();
	var iStart=0;
	var iEnd=0;
	var sKey=sStartKey+"||";
	var sNewKey="";
	var sNewVal="";
	
	if(sKey!=null && sKey!="")
		iStart=sList.indexOf(sKey);
	iStart=sLIST.indexOf(sSEARCH,iStart);
	if(iStart<0)
		iStart=sLIST.indexOf(sSEARCH);
	if(iStart<0) return false;
	
	iStart+=2;
	iEnd=sList.indexOf("|",iStart);
	sVal=sList.slice(iStart,iEnd);
	iStart=iEnd+1;
	iEnd=sList.indexOf("||",iStart);
	sKey=sList.slice(iStart,iEnd);
  return sKey;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_keydown
//* parameter   : sId    - control id
//*               oDoc   - document object
//*               oEvt   - event object
//* return      :
//* description	: Handle key navigation within the box, for example
//*               arrow up and down.
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_keydown( sId, doc, e ){
	var o=sapUrMapi_ItemListBox_getObject(sId, doc, e);
	var iItmIdx = 0;

	// check if there are items in the listbox
	if(o.size<=0) return;

	// show data tip when you press ctrl+shift+i (old key ctrl+q)
	if( e.keyCode==73 && e.shiftKey && sapUrMapi_bCtrl(e) && !e.altKey ){
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
	}
		
	// escape
	else if(e.keyCode==27){
		sapUrMapi_DataTip_hide(sId);
	}
		
	// tab back
	else if(e.keyCode==9 && e.shiftKey){
		if(ur_evtSrc(e).tagName!="SPAN"){
			o.tbl.setAttribute("tabback","true");
			ur_focus(o.r);
		}
		return true;
	}
	
	// arrow up
	else if(e.keyCode==38 && o.prevItm!=null){
		if( sapUrMapi_bCtrl(e) && o.multi )
			sapUrMapi_ItemListBox_focusItem(o,o.prevItm);
		else if( sapUrMapi_ItemListBox_itemSelected(o.prevItm) && o.multi ){
			sapUrMapi_ItemListBox_deselectItem(o.focusedItm);
			sapUrMapi_ItemListBox_focusItem(o,o.prevItm);
		}
		else
			sapUrMapi_ItemListBox_selectItem(o, o.prevItm, true, e );
	}
	
	// handle arrow down
	else if( e.keyCode==40 && o.nextItm!=null ){
		if( sapUrMapi_bCtrl(e) && o.multi )
			sapUrMapi_ItemListBox_focusItem(o,o.nextItm);
		else if( sapUrMapi_ItemListBox_itemSelected(o.nextItm) && o.multi ){
			sapUrMapi_ItemListBox_deselectItem(o.focusedItm);
			sapUrMapi_ItemListBox_focusItem(o,o.nextItm);
		}
		else
			sapUrMapi_ItemListBox_selectItem(o, o.nextItm, false, e );
	}
	
	// spacebar
	else if(e.keyCode==32){
		if( sapUrMapi_ItemListBox_itemSelected(o.focusedItm) &&  sapUrMapi_bCtrl(e) && o.multi)
			sapUrMapi_ItemListBox_deselectItem(o.focusedItm);
		else
			sapUrMapi_ItemListBox_selectItem(o, o.focusedItm, true, e);
		if(ur_system.is508) sapUrMapi_refocusElement(e.srcElement);			
	}
	
	// position 1
	else if( e.keyCode==36 ){
		sapUrMapi_ItemListBox_selectItem(o, o.itms[0], true, e );
		if(ur_system.is508 && o.focusedItm.rowIndex==0) sapUrMapi_refocusElement(e.srcElement);					
	}
		
	// end
	else if(e.keyCode==35){
		sapUrMapi_ItemListBox_selectItem(o, o.itms[o.itms.length-1], false, e );
	}
		
	// page up
	else if( e.keyCode==33 && o.size!=null ){
		if(!o.focusedItm) {
			if(o.itms.length > 0) {
				sapUrMapi_ItemListBox_selectItem(o, o.itms[0], true, e );
			}
		}
		else {
		    iItmIdx = o.focusedItm.rowIndex - o.size + 1;
		    if( iItmIdx < 0 ) iItmIdx = 0;
	   	    sapUrMapi_ItemListBox_selectItem(o, o.itms[iItmIdx], true, e );
	    }
	}
	
	// handle page down
	else if( e.keyCode==34 && o.size!=null ){
		if(!o.focusedItm) {
			if(o.itms.length > 0) {
				sapUrMapi_ItemListBox_selectItem(o, o.itms[o.itms.length-1], true, e );
			}
		}
		else {
		    iItmIdx = o.focusedItm.rowIndex + o.size - 1;
		    if( iItmIdx > o.tbd.lastChild.rowIndex ) iItmIdx = o.tbd.lastChild.rowIndex;
		    sapUrMapi_ItemListBox_selectItem(o, o.itms[iItmIdx], false, e);
      }
  }
  else  {
  		var o=sapUrMapi_ItemListBox_getObject(sId, document, e);
		if (o.popup) return;
	  
		if( e.keyCode > 0){
		    var sSearchChar = String.fromCharCode(e.keyCode);
		    var sSelectedKey = "";
		    if (o.selItms.length > 0) {
		      sSelectedKey = o.selItms[o.selItms.length-1].getAttribute("k");
		      
      }
		    var sNewKey = sapUrMapi_ItemListBox_findItem(sId,sSearchChar,sSelectedKey,document);
		    if (sNewKey!="") sapUrMapi_ItemListBox_setSelectedKey(sId,sNewKey,document,true);
		} 
  }
   
  return ur_EVT_cancel(e);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_setInvalid
//* parameter   : sId    - control id
//* return      :
//* description	: sets/resets invalid state
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_setInvalid(sId,bSet){
	var o=sapUrMapi_ItemListBox_getObject(sId, document);
	if(o.popup) return;
	if(ur_isSt(o.r,ur_st.READONLY) || ur_isSt(o.r,ur_st.DISABLED)) return;
	if(bSet && ur_isSt(o.r,ur_st.INVALID)) return;
	if(!bSet && !ur_isSt(o.r,ur_st.INVALID)) return;
	if(bSet){
		o.box.className=o.box.className.replace("Box","BoxInv");
		ur_setSt(sId,ur_st.INVALID,true);
	}
	else{
		o.box.className=o.box.className.replace("BoxInv","Box");
		ur_setSt(sId,ur_st.INVALID,false);	
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_setDisabled
//* parameter   : sId    - control id
//* return      :
//* description	: sets/resets disabled state
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_setDisabled(sId,bSet){
	var o=sapUrMapi_ItemListBox_getObject(sId, document);
	if(o.popup) return;
	if(bSet && ur_isSt(o.r,ur_st.DISABLED)) return;
	if(!bSet && !ur_isSt(o.r,ur_st.DISABLED)) return;
	if(bSet){
		o.box.className=o.box.className.replace("Box","BoxDsbl");
		ur_setSt(sId,ur_st.DISABLED,true);
		for(var i=0; i<o.itms.length; i++){
			for(var j=0; j<o.itms[i].childNodes.length; j++){
				o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Ilb2I","Ilb2IDsbl");
				o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Dscr","");				
			}
		}
	}
	else{
		o.box.className=o.box.className.replace("BoxDsbl","Box");
		ur_setSt(sId,ur_st.DISABLED,false);	
		for(var i=0; i<o.itms.length; i++){
			for(var j=0; j<o.itms[i].childNodes.length; j++){
				o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Dsbl","");
				if(j!=parseInt(o.valcol)-1)
					o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Ilb2I","Ilb2IDscr");				
			}
		}		
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_ItemListBox_setReadonly
//* parameter   : sId    - control id
//* return      :
//* description	: sets/resets read only state
//* ------------------------------------------------------------------------
function sapUrMapi_ItemListBox_setReadonly(sId,bSet){
	var o=null;
	if(typeof(sId)=="object")
		o=sId;
	else
		o=sapUrMapi_ItemListBox_getObject(sId, document);

	if(bSet && ur_isSt(o.r,ur_st.READONLY)) return;
	if(!bSet && !ur_isSt(o.r,ur_st.READONLY)) return;
	if(bSet){
		o.box.className=o.box.className.replace("Box","BoxRo");
		ur_setSt(o.r,ur_st.READONLY,true);
		for(var i=0; i<o.itms.length; i++){
			for(var j=0; j<o.itms[i].childNodes.length; j++){
				o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Ilb2I","Ilb2IRo");
				o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Dscr","");				
			}
		}
	}
	else{
		o.box.className=o.box.className.replace("BoxRo","Box");
		ur_setSt(o.r,ur_st.READONLY,false);	
		for(var i=0; i<o.itms.length; i++){
			for(var j=0; j<o.itms[i].childNodes.length; j++){
				o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Ro","");
				if(j!=parseInt(o.valcol)-1)
					o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Ilb2I","Ilb2IDscr");				
			}
		}		
	}
}
