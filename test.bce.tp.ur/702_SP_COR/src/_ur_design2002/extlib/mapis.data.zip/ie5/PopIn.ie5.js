
//* ************************************************************************
//* PopIn
//* ************************************************************************

function sapUrPopIn_close(sId, oEvt){
	if ( oEvt.keyCode == 32 || oEvt.type == "click" ) {
		ur_EVT_fire(ur_get(sId + "-cl"),"ocl");
	}
}