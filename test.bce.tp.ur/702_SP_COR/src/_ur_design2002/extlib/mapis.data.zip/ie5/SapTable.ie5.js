//* ------------------------------------------------------------------------
//* SapTable
//* ------------------------------------------------------------------------



function ur_contains(oDomRefContainer, oDomRefChild) {
	var oDomRef = oDomRefChild;
	
	if(oDomRefContainer == oDomRefChild) return true;
	
	while(oDomRef != null) {
		if(oDomRef == oDomRefContainer) return true;
		oDomRef = oDomRef.parentNode;
	}
	
	return false;
};


function sapUrMapi_SapTable_getClickedRowIndex(e)
{
   var o=ur_evtSrc(e);
   while (o!=null && o.getAttribute("rr")==null) o=o.parentElement;
   if(o==null) return;
   try {
     var iRIdx=parseInt(o.rr);
     if (isNaN(iRIdx)) return null;
     else return iRIdx;
   } catch (e) {
     return null;
   }
}

function sapUrMapi_SapTable_getClickedColIndex(e)
{
   var o=ur_evtSrc(e);
   while (o!=null && o.getAttribute("cc")==null) o=o.parentElement;
   if(o==null) return;
   try {
     var iCIdx=parseInt(o.cc);
     if (isNaN(iCIdx)) return null;
     else return iCIdx;
   } catch (e) {
     return null;
   }
}

function sapUrMapi_SapTable_getClickedCellId(e)
{
   var o=ur_evtSrc(e);
   while ( o!=null && o.getAttribute("cc")==null ) o=o.parentElement;
   if(o==null) return;
   try {
     var sId=o.id;
     return sId;
   } catch (e) {
     return null;
   }
}

function sapUrMapi_SapTable_getClickedRow(sTableId,e) {
   var idx=sapUrMapi_SapTable_getClickedRowIndex(e);
   if(idx==null) return;
   return sapUrMapi_SapTable_getRow(sTableId,idx);
}

function sapUrMapi_SapTable_getRow(sTableId, iRowIdx) {
	var oTable=ur_Table_create(sTableId),
		aRows = oTable.rows,
		iRowIndex = -1,
		sRowIndex = null;

	for (var i=0;i<aRows.length;i++) {
		sRowIndex = aRows[i].ref.getAttribute("rr");
		iRowIndex = -1;

		if(sRowIndex) {
			iRowIndex = parseInt(sRowIndex);
			if(isNaN(iRowIndex)) continue;
		} else continue;

		if (iRowIndex==iRowIdx) return aRows[i].ref;
	}
	return null;
}

function sapUrMapi_SapTable_correctSelectionBorder(oRow){}

function sapUrMapi_SapTable_correctSelectionBorder4Table(id){}

function sapUrMapi_SapTable_isSecondarySelected(oButton) {
  return oButton.className=="urSTRowSelSecIcon";
}

function sapUrMapi_SapTable_isPrimarySelected(oButton) {
  return oButton.className=="urSTRowSelIcon";
}


function sapUrMapi_SapTable_toggleSecondarySelection(oRow) {
  var oButton = oRow.getElementsByTagName("DIV").item(0);
  sapUrMapi_SapTable_selectRowByObject(oRow, !sapUrMapi_SapTable_isSecondarySelected(oButton), true);
}


var UR_FOCUS_APPEARANCE = {
  NONE:0,
  CLASS:1,
  FAST:2
};

var eUrFocusAppearance = UR_FOCUS_APPEARANCE.FAST;

function sapUrMapi_SapTable_setFocusAppearance(eLocalUrFocusAppearance) {
	eUrFocusAppearance = eLocalUrFocusAppearance;
};

var UR_SELECTION_STATE = {
  NOT_SELECTED:0,
  PRIMARY:1,
  SECONDARY:2
};

function sapUrMapi_SapTable_setSelection(oRow, eState) {
  if(eState == UR_SELECTION_STATE.NOT_SELECTED) {
    sapUrMapi_SapTable_selectRowByObject(oRow, false, false);
  } else if(eState == UR_SELECTION_STATE.PRIMARY) {
    sapUrMapi_SapTable_selectRowByObject(oRow, true, false);
  } else if(eState == UR_SELECTION_STATE.SECONDARY) {
    sapUrMapi_SapTable_selectRowByObject(oRow, true, true);
  }
}

function sapUrMapi_SapTable_setCellSelection(oCell, eState) {
  if(eState == UR_SELECTION_STATE.NOT_SELECTED) {
    sapUrMapi_SapTableSelectCell(oCell, false, false, false);
  } else if(eState == UR_SELECTION_STATE.PRIMARY) {
    sapUrMapi_SapTableSelectCell(oCell, false, true, false);
  } else if(eState == UR_SELECTION_STATE.SECONDARY) {
    sapUrMapi_SapTableSelectCell(oCell, false, true, true);
  }
}

var oUrFastTableSelectionInfo = null;

function ur_initFastTableSelectionInfo() {

	oUrFastTableSelectionInfo = {
		bValid: false
	};

	oUrFastTableSelectionInfo.oSelectorNames = {
		sPrimary: ".urST4Sel",
		sPrimaryReadOnly: ".urST4SelRo",
		sSecondary: ".urST4Sel2",
		sSecondaryReadOnly: ".urST4Sel2Ro",
		sFocus: ".urSTFoc"
	};
	
	oUrFastTableSelectionInfo.oClassNames = {
		sPrimary: "urST4Sel",
		sPrimaryReadOnly: "urST4SelRo",
		sSecondary: "urST4Sel2",
		sSecondaryReadOnly: "urST4Sel2Ro",
		sReadOnly: "urSTTDRo2",
		sFocus: "urSTFoc"
	};
	
	oUrFastTableSelectionInfo.oColors = {
		sPrimary: null,
		sPrimaryReadOnly: null,
		sSecondary: null,
		sSecondaryReadOnly: null,
		sFocus: null
	};	

	if(window.document.styleSheets) {
		for(var j=0; j<window.document.styleSheets.length; j++) {
			var oStyleSheet = window.document.styleSheets[j];

			if(oStyleSheet.href && oStyleSheet.href.indexOf("/ur_ie") >=0 ) {
		
				var oRules = oStyleSheet.rules,
					oRule = null;
				
				oUrFastTableSelectionInfo.bValid = true;
				
				for(var i=0; i<oRules.length; i++) {
					oRule = oRules[i];
					
					if(oRule.selectorText == oUrFastTableSelectionInfo.oSelectorNames.sPrimary) {
						oUrFastTableSelectionInfo.oColors.sPrimary = oRule.style.backgroundColor;
						continue;
					}
					
					if(oRule.selectorText == oUrFastTableSelectionInfo.oSelectorNames.sPrimaryReadOnly) {
						oUrFastTableSelectionInfo.oColors.sPrimaryReadOnly = oRule.style.backgroundColor;
						continue;
					}
					
					if(oRule.selectorText == oUrFastTableSelectionInfo.oSelectorNames.sSecondary) {
						oUrFastTableSelectionInfo.oColors.sSecondary = oRule.style.backgroundColor;
						continue;
					}
					
					if(oRule.selectorText == oUrFastTableSelectionInfo.oSelectorNames.sSecondaryReadOnly) {
						oUrFastTableSelectionInfo.oColors.sSecondaryReadOnly = oRule.style.backgroundColor;
						continue;
					}
					
					if(oRule.selectorText == oUrFastTableSelectionInfo.oSelectorNames.sFocus) {
						oUrFastTableSelectionInfo.oColors.sFocus = oRule.style.backgroundColor;
						continue;
					}
								
				}
			}
		}
	}
	return oUrFastTableSelectionInfo.bValid? oUrFastTableSelectionInfo: null;
}

function ur_getFastTableSelectionInfo() {
	return (oUrFastTableSelectionInfo)? (oUrFastTableSelectionInfo.bValid? oUrFastTableSelectionInfo: null) : ur_initFastTableSelectionInfo();
}

function ur_fastTableSelectionModeEnabled() {
	return ur_getFastTableSelectionInfo() != null;
}

function ur_fastTableCellSelect(oCell, bReadOnly, bSelect, bSecondary) {
	var oSelectionInfo = ur_getFastTableSelectionInfo();
	
	if(!oSelectionInfo) return false;
	
	//Don't process for InputField and Combobox in ReadOnly/Disabled state since there are cascades which need the selection classes
	if(oCell.firstChild && oCell.firstChild.className && 	
		(oCell.firstChild.className.indexOf("urEdf2WhlDsbl") >= 0 || oCell.firstChild.className.indexOf("urEdf2WhlRo") >= 0)
	){
	 return false;
	}

	if(!(oCell.urFastSelectionClean || bSelect)) {
		if(oCell.className.indexOf(oSelectionInfo.oClassNames.sPrimary) >= 0)
	  	oCell.className = oCell.className.replace(oSelectionInfo.oClassNames.sPrimary, "");
	  if(oCell.className.indexOf(oSelectionInfo.oClassNames.sPrimaryReadOnly) >= 0)
	  	oCell.className = oCell.className.replace(oSelectionInfo.oClassNames.sPrimaryReadOnly, "");
	  if(oCell.className.indexOf(oSelectionInfo.oClassNames.sSecondary) >= 0)
	  	oCell.className = oCell.className.replace(oSelectionInfo.oClassNames.sSecondary, "");
		if(oCell.className.indexOf(oSelectionInfo.oClassNames.sSecondaryReadOnly) >= 0)
	  	oCell.className = oCell.className.replace(oSelectionInfo.oClassNames.sSecondaryReadOnly, "");
	  
	  oCell.urFastSelectionClean = true;
	}

  if (bSelect) {
    if (bSecondary) {
			if(oCell.runtimeStyle.backgroundColor) {
				oCell.runtimeStyle.cssText = oCell.runtimeStyle.cssText.replace(oCell.runtimeStyle.backgroundColor, ((bReadOnly? oSelectionInfo.oColors.sSecondaryReadOnly: oSelectionInfo.oColors.sSecondary) + " !important") );
			} else {
	    	oCell.runtimeStyle.cssText += "background-color:" + (bReadOnly? oSelectionInfo.oColors.sSecondaryReadOnly: oSelectionInfo.oColors.sSecondary) + " !important";
	    }
    } else {
			if(oCell.runtimeStyle.backgroundColor) {
				oCell.runtimeStyle.cssText = oCell.runtimeStyle.cssText.replace(oCell.runtimeStyle.backgroundColor, ((bReadOnly? oSelectionInfo.oColors.sPrimaryReadOnly: oSelectionInfo.oColors.sPrimary) + " !important") );
			} else {
	    	oCell.runtimeStyle.cssText += "background-color:"+ (bReadOnly? oSelectionInfo.oColors.sPrimaryReadOnly: oSelectionInfo.oColors.sPrimary) +" !important";
	    }
    }
  } else {
  	oCell.runtimeStyle.backgroundColor = "";
  }
  
  return true;
};

function ur_fastTableCellFocus(oCell, bFocus) {
	if(eUrFocusAppearance != UR_FOCUS_APPEARANCE.FAST) return false;
	
	var oSelectionInfo = ur_getFastTableSelectionInfo();
	
	if(!oSelectionInfo) return false;
	
	if (bFocus) {
		if(!oCell.bIsFocusColorized) {
			if(oCell.runtimeStyle.backgroundColor) {
				oCell.setAttribute("sOldBgColor", oCell.runtimeStyle.backgroundColor);
				
				oCell.runtimeStyle.cssText = oCell.runtimeStyle.cssText.replace(oCell.runtimeStyle.backgroundColor, oSelectionInfo.oColors.sFocus + " !important");
			
			} else {
	    	oCell.runtimeStyle.cssText += "background-color:"+ oSelectionInfo.oColors.sFocus + " !important";
	    }
	    
	    oCell.bIsFocusColorized = true;
		}	
	} else {
		if(oCell.bIsFocusColorized) {
			
			var sOldBgColor = oCell.getAttribute("sOldBgColor");
			if(sOldBgColor) {
				oCell.runtimeStyle.cssText = oCell.runtimeStyle.cssText.replace(oSelectionInfo.oColors.sFocus, sOldBgColor + " !important");
				oCell.setAttribute("sOldBgColor", "");
			} else oCell.runtimeStyle.backgroundColor = "";
			
			oCell.bIsFocusColorized = false;
		}
	}

	return true;
};

function sapUrMapi_SapTable_selectRowByObject(oRow,bSelect,bSecondary)
{
  var oButton = oRow.getElementsByTagName("DIV").item(0),
    bHasSelectionButton = bHasSelectionButton = (oButton && oButton.className && oButton.className.indexOf("urSTRow") == 0)? true: false;

  if(bHasSelectionButton) {
    if(!sapUrMapi_SapTable_isSelButtonSelectable(oButton)) return;

    //selection mandatory?
    if(!bSelect && oButton.getAttribute("selMust")) return;

    if(!bSelect)
      oButton.className="urSTRowUnSelIcon";
    else if(bSecondary)
      oButton.className="urSTRowSelSecIcon";
    else
      oButton.className="urSTRowSelIcon";
  }

  for (var n=0;n<oRow.childNodes.length;n++) {
    oItem=oRow.childNodes[n];
    sapUrMapi_SapTableSelectCell(oItem,false,bSelect,bSecondary);
  }

  if(ur_system.is508 && bHasSelectionButton){
    if(bSelect){
      ur_setSt(oButton,ur_st.SELECTED,true);
      ur_setSt(oButton,ur_st.NOTSELECTED,false);
    }
    else{
      ur_setSt(oButton,ur_st.SELECTED,false);
      ur_setSt(oButton,ur_st.NOTSELECTED,true);
    }
    oButton.fireEvent("onactivate");
  }

}

function sapUrMapi_SapTable_selectRow(sTableId,sRowIdx,iCol,iGroup,e,bSecondary)
{
  if (typeof(bSecondary)=="undefined") bSecondary=false;
  var oRow = ur_EVT_src(e).parentNode.parentNode;
  while (oRow.tagName!="TR") oRow=oRow.parentNode;
  var oButton = oRow.getElementsByTagName("DIV").item(0);
  if(!sapUrMapi_SapTable_isSelButtonSelectable(oButton)) return oRow;
  var bSelect = sapUrMapi_SapTable_isSecondarySelected(oButton)||sapUrMapi_SapTable_isPrimarySelected(oButton)?false:true;
 
  sapUrMapi_SapTable_selectRowByObject(oRow,bSelect,bSecondary);
  return oRow;
}

function sapUrMapi_SapTableSelectCell(oCell,bEdit,bSelect,bSecondary)
{
  var bEdit=false;

  if (oCell.getAttribute("urRowSpan") &&  parseInt(oCell.getAttribute("urRowSpan")) > 1) return;
  if (typeof(bSelect)=="undefined") bSelect=true;
  if (typeof(bSecondary)=="undefined") bSecondary=false;
  if (oCell.className.indexOf("Ico")>-1) return;

  var bIsReadOnly = oCell.className.indexOf("urSTTDRo2") >= 0;

  if(!ur_fastTableCellSelect(oCell, bIsReadOnly, bSelect, bSecondary)) {
	  if (bSelect) {
	    if (bSecondary)
	      oCell.className = oCell.className + " urST4Sel2" + (bIsReadOnly? "Ro": "");
	    else
	      oCell.className = oCell.className + " urST4Sel" + (bIsReadOnly? "Ro": "");
	  } else {
	  	if(bIsReadOnly) {
	  		oCell.className=oCell.className.replace(" urST4Sel2Ro","");
		    oCell.className=oCell.className.replace(" urST4SelRo","");
	  	} else {
	  		oCell.className=oCell.className.replace(" urST4Sel2","");
		    oCell.className=oCell.className.replace(" urST4Sel","");
	  	}
	  }
  }

  if(ur_system.is508){
    var sSemanticColor = oCell.getAttribute("s")?  oCell.getAttribute("s"): "";

    sSemanticColor = sSemanticColor.replace("s","");

    if(bSelect){
      sSemanticColor += "s";
    }

    oCell.setAttribute("s", sSemanticColor);
  }
}

function sapUrMapi_SapTable_isSelButtonSelectable(oSelButton){
  if(oSelButton) {
    var sClassName = oSelButton.className;
    if(sClassName=="urSTRowUnSelIcon" || sClassName=="urSTRowSelIcon" || sClassName=="urSTRowSelSecIcon") return true;
  }
  return false;
}

function sapUrMapi_SapTable_isSelectable(oRow){
  var oButtons = oRow.getElementsByTagName("DIV");
  if(oButtons.length > 0) {
    return sapUrMapi_SapTable_isSelButtonSelectable(oButtons.item(0));
  }
  return false;
}

function sapUrMapi_SapTable_clickSelButton(oRow,oEvt){
  while(oRow.tagName!="TR") oRow = oRow.parentNode;
  if(oRow.tagName!="TR")return;
  var sButtons = oRow.getElementsByTagName("DIV");
  for(var i=0;i<sButtons.length;i++){
    if(sapUrMapi_SapTable_isSelButtonSelectable(sButtons[i])){
      sButtons[i].fireEvent("onclick",oEvt);
      return;
    }
  }
}

function sapUrMapi_SapTable_getModelCellOfCnt(sId,o) {
  var oTbl=ur_Table_create(sId);
  var oCell=o;
  /* get cell */
	while( (oCell.tagName != "TD" && oCell.tagName != "TH") || (oCell.className.indexOf("urSTT")==-1 || oCell.className.search(/urSTTHL.Txt/)>=0) ){
    if(oCell.id==sId) break;
    oCell = oCell.parentNode;
  }
  /* get cell of the table model */
  oCell=oTbl.lookup[oCell.id];
  return oCell;
}







var UR_SEARCH_DIRECTION = {
    NONE: 0,
    ACCENDING: 1,
    DECENDING: 2,
    LAST: 3,
    FIRST: 4
  };


function sapUrMapi_SapTable_focusDown(sId,o){
  return ur_SapTable_sNavigate(sId, o, UR_SEARCH_DIRECTION.ACCENDING, false);
}

function sapUrMapi_SapTable_focusUp(sId,o){
  return ur_SapTable_sNavigate(sId, o, UR_SEARCH_DIRECTION.DECENDING, false);
}

function sapUrMapi_SapTable_focusNext(sId,o){
  return ur_SapTable_sNavigate(sId, o, UR_SEARCH_DIRECTION.ACCENDING, true);
}

function sapUrMapi_SapTable_focusPrevious(sId,o){
  return ur_SapTable_sNavigate(sId, o, UR_SEARCH_DIRECTION.DECENDING, true);
}


function ur_SapTable_sNavigate(sTableId, oDomRefCell, eSearchDirection, bHorizontal){
  var oTable=ur_Table_create(sTableId),
    oCell = oTable.focusedCell,
    oResultCell = null;

  if (oCell==null) oCell=sapUrMapi_SapTable_getModelCellOfCnt(sTableId,oDomRefCell);
  if (oCell==null) return "UNDEFINED";

  oResultCell = ur_SapTable_oSearchFocusableCell(oTable, oCell, eSearchDirection, bHorizontal);

  if(oResultCell == oCell) return "END";
  if(oResultCell == null) return "UNDEFINED";

  sapUrMapi_SapTable_focusCell(oResultCell, sTableId);

  return "";
}


function ur_SapTable_oSearchFocusableCell(oTable, oCellReference, eSearchDirection, bHorizontal){
  var iCurrRowIndex = -1, iCurrColIndex = -1, oCurrCell = null, oOrgCell = null;

  oOrgCell = oCellReference.oOrgCell;
  iCurrRowIndex = oOrgCell.rowIdx;
  iCurrColIndex = oOrgCell.colIdx;

  if(bHorizontal) {
    if(eSearchDirection == UR_SEARCH_DIRECTION.LAST) {
      iCurrColIndex = oOrgCell.parentRow.cells.length-1;
    } else if (eSearchDirection == UR_SEARCH_DIRECTION.FIRST) {
      iCurrColIndex = 0;
    } else if (eSearchDirection == UR_SEARCH_DIRECTION.ACCENDING) {
      iCurrColIndex = iCurrColIndex + oOrgCell.iColSpan;
    } else if (eSearchDirection == UR_SEARCH_DIRECTION.DECENDING) {
      iCurrColIndex = iCurrColIndex -1;
    }
  } else {
    if(eSearchDirection == UR_SEARCH_DIRECTION.LAST) {
      iCurrRowIndex = oOrgCell.parentCol.cells.length-1;
    } else if (eSearchDirection == UR_SEARCH_DIRECTION.FIRST) {
      iCurrRowIndex = 0;
    } else if (eSearchDirection == UR_SEARCH_DIRECTION.ACCENDING) {
      iCurrRowIndex = iCurrRowIndex + oOrgCell.iRowSpan;
    } else if (eSearchDirection == UR_SEARCH_DIRECTION.DECENDING) {
      iCurrRowIndex = iCurrRowIndex -1;
    }
  }

  if(oTable.rows[iCurrRowIndex]) {
    oCurrCell = oTable.rows[iCurrRowIndex].cells[iCurrColIndex];
  }

  if(oCurrCell == null) return oCellReference;

  //Ignore focus is set?
  if(oCurrCell.ref.fi) {
    var oRecursionResult = null;

    if(eSearchDirection == UR_SEARCH_DIRECTION.LAST)
      oRecursionResult = ur_SapTable_oSearchFocusableCell(oTable, oCurrCell, UR_SEARCH_DIRECTION.DECENDING, bHorizontal);
    else if(eSearchDirection == UR_SEARCH_DIRECTION.FIRST)
      oRecursionResult = ur_SapTable_oSearchFocusableCell(oTable, oCurrCell, UR_SEARCH_DIRECTION.ACCENDING, bHorizontal);
    else {
      oRecursionResult = ur_SapTable_oSearchFocusableCell(oTable, oCurrCell, eSearchDirection, bHorizontal);
    }

    if(oRecursionResult.ref.fi) return oCellReference;
    else return oRecursionResult;

  } else return oCurrCell;
};




var UR_SCROLL_UI = {
  NONE:0,
  PAGINATOR:1,
  SCROLLBAR:2
}

var UR_SCROLL_DIR = {
  VERTICAL:0,
  HORIZONTAL:1
}

var UR_SCROLL_BY = {
  NEXT_ITEM:0,
  NEXT_PAGE:1,
  END:2,
  PREVIOUS_ITEM:3,
  PREVIOUS_PAGE:4,
  BEGIN:5
}

function sapUrMapi_SapTable_canScrollV(sTableId, oTable) {
  if(!oTable) oTable=ur_get(sTableId);
  return (ur_get(oTable.getAttribute("pv")) || ur_get(sTableId+"-scrollV"))? true: false;
}

function sapUrMapi_SapTable_canScrollH(sTableId, oTable) {
  if(!oTable) oTable=ur_get(sTableId);
  return (ur_get(oTable.getAttribute("ph")) || ur_get(sTableId+"-scrollH"))? true: false;
}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SapTable_scroll
//* parameter   : sTableId   - table id
//*               e          - event object
//*               iScrollDir - scroll direction
//*               iScrollBy  - by next/prev item or page, end, begin
//* return      : false if scrolling failed
//* description : triggers scrolling
//* ------------------------------------------------------------------------
function sapUrMapi_SapTable_scroll(sTableId, oEvt, iScrollDir, iScrollBy) {
  var oTable=ur_get(sTableId), sSclId = null, oScl=null, scrollUi=UR_SCROLL_UI.PAGINATOR;

  if (iScrollDir == UR_SCROLL_DIR.VERTICAL) {
    sSclId=oTable.getAttribute("pv");
    oScl=ur_get(sSclId);

    if (!oScl) {
      sSclId=sTableId+"-scrollV";
      oScl=ur_get(sSclId);
      scrollUi=UR_SCROLL_UI.SCROLLBAR;
    }
  } else if (iScrollDir == UR_SCROLL_DIR.HORIZONTAL) {
    sSclId=oTable.getAttribute("ph");
    oScl=ur_get(sSclId);

    if (!oScl) {
      sSclId=sTableId+"-scrollH";
      oScl=ur_get(sSclId);
      scrollUi=UR_SCROLL_UI.SCROLLBAR;
    }
  } else return false;

  if (!oScl) return false;

  if (scrollUi == UR_SCROLL_UI.PAGINATOR) {
    switch (iScrollBy) {
      case 0://NEXT_ITEM
        if (ur_Paginator_triggerClick(sSclId, UR_PAGINATOR_BUTTON.NEXT_ITEM)) return true;
      case 1://NEXT_PAGE
        if (ur_Paginator_triggerClick(sSclId, UR_PAGINATOR_BUTTON.NEXT_PAGE)) return true;
      case 2://END
        if (ur_Paginator_triggerClick(sSclId, UR_PAGINATOR_BUTTON.END)) return true;
        break;

      case 3://PREVIOUS_ITEM
        if (ur_Paginator_triggerClick(sSclId, UR_PAGINATOR_BUTTON.PREVIOUS_ITEM)) return true;
      case 4://PREVIOUS_PAGE
        if (ur_Paginator_triggerClick(sSclId, UR_PAGINATOR_BUTTON.PREVIOUS_PAGE)) return true;
      case 5://BEGIN
        if (ur_Paginator_triggerClick(sSclId, UR_PAGINATOR_BUTTON.BEGIN)) return true;
        break;

      default:
        return false;
    }
  } else if (scrollUi == UR_SCROLL_UI.SCROLLBAR) {
    var oSclInfoObject=ur_Scrollbar_getObj(sSclId);

    switch (iScrollBy) {
      case 0://NEXT_ITEM
        ur_Scrollbar_scroll(oSclInfoObject, "down", oEvt);
        ur_Scrollbar_fireChange(oSclInfoObject, oEvt);
        break;
      case 1://NEXT_PAGE
        ur_Scrollbar_page(oSclInfoObject, "down", oEvt);
        ur_Scrollbar_fireChange(oSclInfoObject, oEvt);
        break;
      case 2://END
        ur_Scrollbar_bounce(oSclInfoObject, "down", oEvt);
        ur_Scrollbar_fireChange(oSclInfoObject, oEvt);
        break;

      case 3://PREVIOUS_ITEM
        ur_Scrollbar_scroll(oSclInfoObject, "up", oEvt);
        ur_Scrollbar_fireChange(oSclInfoObject, oEvt);
        break;
      case 4://PREVIOUS_PAGE
        ur_Scrollbar_page(oSclInfoObject, "up", oEvt);
        ur_Scrollbar_fireChange(oSclInfoObject, oEvt);
        break;
      case 5://BEGIN
        ur_Scrollbar_bounce(oSclInfoObject, "up", oEvt);
        ur_Scrollbar_fireChange(oSclInfoObject, oEvt);
        break;
      default:
        return false;
    }
  }
  return false;
}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SapTable_keydown
//* parameter   : sId - control id
//*               e   - event object
//* return      : none
//* description : handle key navigation
//* ------------------------------------------------------------------------
function sapUrMapi_SapTable_keydown(sId,e) {
  var o=ur_evtSrc(e);
  var sTag=o.tagName;
  var iKey=e.keyCode;
  var bS=e.shiftKey;
  var bA=e.altKey;
  var bC=sapUrMapi_bCtrl(e);
  var sCt=sapUrMapi_getControlTypeFromObject(o);

  var oT=ur_get(sId); //store the table object
	

  //can scroll
  var bCanScrollV=sapUrMapi_SapTable_canScrollV(sId, oT);
  var bCanScrollH=sapUrMapi_SapTable_canScrollH(sId, oT);

  //find the horizontal paginator
  var sPhId=oT.getAttribute("ph");
  var oPh=ur_get(sPhId);
  //find the vertical paginator
  var sPvId=oT.getAttribute("pv");
  var oPv=ur_get(sPvId);

  // spacebar
  if(iKey==32 && sCt!="I" && sCt!="TE" && sCt!="CB" && sCt!="C" && sCt!="R" && sCt!="TRI"){
    try{
      o.fireEvent("onclick",e);
    } catch(ex){ }
    ur_EVT_cancel(e);
    return true;
  }
  // sort column ctrl or shift + arrow up or down
  if((bC || bS) && (iKey==40 || iKey==38)){
    if(sapUrMapiSapTable_sort(o))
      return ur_EVT_cancel(e);
  }
  // arrow down
  if(iKey==40 && sCt!="TE"){
    sResult=sapUrMapi_SapTable_focusDown(sId,o);
    if (sResult=="END" && bCanScrollV) {
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.VERTICAL, UR_SCROLL_BY.NEXT_ITEM);
    }
    ur_EVT_cancel(e);
    return true;
  }

  // arrow up
  if(iKey==38 && sCt!="TE"){
    sResult=sapUrMapi_SapTable_focusUp(sId,o);
    if (sResult=="END" && bCanScrollV) {
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.VERTICAL, UR_SCROLL_BY.PREVIOUS_ITEM);
    }
    ur_EVT_cancel(e);
    return true;
  }

  // arrow right
  if(iKey==39 && (sCt!="I" && sCt!="TE")){
    var sResult="";
    if (ur_system.direction=="rtl")
      sResult=sapUrMapi_SapTable_focusPrevious(sId,o);
    else
      sResult=sapUrMapi_SapTable_focusNext(sId,o);

    if (sResult=="END" && bCanScrollH) {
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.HORIZONTAL, (ur_system.direction=="rtl")? UR_SCROLL_BY.PREVIOUS_ITEM: UR_SCROLL_BY.NEXT_ITEM);
    }
    ur_EVT_cancel(e);
    return true;
  }

  // arrow left
  if(iKey==37 && (sCt!="I" && sCt!="TE")){
    var sResult="";
    if (ur_system.direction=="rtl")
      sResult=sapUrMapi_SapTable_focusNext(sId,o);
    else
      sResult=sapUrMapi_SapTable_focusPrevious(sId,o);

    if (sResult=="END" && bCanScrollH) {
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.HORIZONTAL, (ur_system.direction=="rtl")? UR_SCROLL_BY.NEXT_ITEM: UR_SCROLL_BY.PREVIOUS_ITEM);
    }
    ur_EVT_cancel(e);
    return true;
  }

  else if(iKey==9){
    var oTableInfoObject=ur_Table_create(sId);
    oTableInfoObject.focusedCell=null;
  }
  //hierarchical cell expand and collapse


  //horizontal paging
  //Alt Pos1 Not Possible (Homepage)
  //Alt End  Makes no sense if the Alt Pos1 does not work
  if (bCanScrollH && bA && !bS && !bC && sCt!="TE") {
    //Alt PageUp
    if(iKey==33){
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.HORIZONTAL, UR_SCROLL_BY.PREVIOUS_PAGE);
      ur_EVT_cancel(e);
      return;
    }
    //Alt PageDown
    if(iKey==34){
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.HORIZONTAL, UR_SCROLL_BY.NEXT_PAGE);
      ur_EVT_cancel(e);
      return;
    }
  }

  //vertical paging
  if (bCanScrollV && !bA && !bS && sCt!="I" && sCt!="TE") {
    //Pos1 + Ctrl
    if(iKey==36 && bC){
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.VERTICAL, UR_SCROLL_BY.BEGIN);
      ur_EVT_cancel(e);
      return;
    }
    //End + Ctrl
    if(iKey==35 && bC){
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.VERTICAL, UR_SCROLL_BY.END);
      ur_EVT_cancel(e);
      return;
    }
    //PageUp
    if(iKey==33 && !bC){
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.VERTICAL, UR_SCROLL_BY.PREVIOUS_PAGE);
      ur_EVT_cancel(e);
      return;
    }
    //PageDown
    if(iKey==34 && !bC){
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.VERTICAL, UR_SCROLL_BY.NEXT_PAGE);
      ur_EVT_cancel(e);
      return;
    }
  }

  // skipping
  return sapUrMapi_skip(sId,e);
}

function ur_SapTable_getCell(o){
  var oCell=o;
  while(oCell.getAttribute("tp")!="HIC"){
    if(oCell.getAttribute("ct")=="ST") return null;
    oCell=oCell.parentNode;
  }
  return oCell;
}

//Hierarchical Cell Handling
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SapTable_HiCell_he
//* parameter   : o - cell object
//*               oEvt  - event object of the browser
//* return      : none
//* description : handles click events and keydowns on the hierarchical cell
//*               triggers expand,collapse or click event
//* ------------------------------------------------------------------------
function sapUrMapi_SapTable_HiCell_he(o,oEvt) {
  var o=ur_evtSrc(oEvt);
  var oCell=ur_SapTable_getCell(o);
  var sCt=sapUrMapi_getControlTypeFromObject(o);
  var sFunc="";
  var oFunc=null;



  /* check if you clicked on an object within a SapTable cell */
  if(o==null || oCell==null) return;


  /* check if you clicked on a control which handles the click or spacebar on its own */
  if( (sCt=="FU" || sCt=="I" || sCt=="CB" || sCt=="TE" || sCt=="TGL") && !(sapUrMapi_bCtrl(oEvt) && oEvt.type=="keydown" && (oEvt.keyCode==107 || oEvt.keyCode==109)) )
      return;


  /* handle only click, sapcebar, + or - */
	if( oEvt.type!="click" && !(oEvt.type=="keydown" && (oEvt.keyCode==32 || (oEvt.keyCode==107) || (oEvt.keyCode==109) )))
		return;
		
	if (oEvt.type=="keydown" && o.tagName != "IMG") o = oCell.getElementsByTagName("IMG")[0];

	/* handle status clicks */	
	var sStc=o.getAttribute("stc"); 
	if(sStc) {
		if (oEvt.type=="keydown") {
			if (sStc=="oex" && oEvt.keyCode==107)
				ur_EVT_fire(oCell,sStc,oEvt);
			else if (sStc=="oco" && oEvt.keyCode==109)
        ur_EVT_fire(oCell,sStc,oEvt);
      else if (oEvt.keyCode==32)
        ur_EVT_fire(oCell,sStc,oEvt);
    } else {
      ur_EVT_fire(oCell,sStc,oEvt);
    }
  } else if (oCell.getAttribute("oc"))
    ur_EVT_fire(oCell,"oc",oEvt);

  return ur_EVT_cancel(oEvt);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SapTable_sort
//* parameter   : oCell - cell object
//*               bAsc  - sort ascending
//* return      : none
//* description : sort table column
//* ------------------------------------------------------------------------
function sapUrMapiSapTable_sort(oCell,bAsc){
  var aBtn;
  var oBtn=null;
  var sTp=oCell.getAttribute("tp");

  if(sTp==null || sTp.indexOf("HDR")<0) return false;
  aBtn=oCell.getElementsByTagName("button");
  for(var i=0;i<aBtn.length;i++)
    if(aBtn[i].className.indexOf("urSTIconSor")>=0 || aBtn[i].className=="urSTIconUnsorted")oBtn=aBtn[i];
  if(oBtn!=null) oBtn.click();
  return true;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SapTable_activate
//* parameter   : sId - control id
//*               e   - event object
//* return      : none
//* description : delegate focus to the first focusable element within a cell
//* ------------------------------------------------------------------------
function sapUrMapi_SapTable_activate(sId,e){
  var o=ur_evtSrc(e);
  var oTab=ur_Table_create(sId);

  if(oTab) {
    var oCell=sapUrMapi_SapTable_getModelCellOfCnt(sId,o);
    oTab.focusedCell=oCell;
  }
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_SapTable_deactivate
//* parameter   : oEvt   - event object
//* return      : none
//* description :
//* ------------------------------------------------------------------------
function sapUrMapi_SapTable_deactivate(oEvt){

}

function sapUrMapi_SapTable_focusCell(oCell, sTableId){
  var oFocus = null;
  // check if a cell is focused, if yes delegate the focus to the content
  if(oCell==null) return null; //MS:  removed if(oCell==null || o!=oCell.ref.firstChild )return;
  // find focusable content  @Sri: Check if a PopIn is inside the SAP Table, then do not focus.
  if( oCell.ref.firstChild!=null && oCell.ref.firstChild.nodeType!=3 && (oCell.ref.firstChild).getAttribute('ct')!="PI")
    oFocus=sapUrMapi_findFirstFocus(oCell.ref.firstChild);
  // focus the cell if you find a focusable content
  if(oFocus!=null){
    ur_focus(oFocus);
  }
  // set first child focusable
  else {
    var sCellType=oCell.ref.getAttribute("tp"),
      oDomRefToFocus = oCell.ref.firstChild;

    if(sCellType!=null && sCellType=="ER") return false;
    sapUrMapi_setTabIndex(oDomRefToFocus,"0");
    sapUrMapi_setTabIndexAutoReset(oDomRefToFocus);
    if(sTableId && !oDomRefToFocus.id) oDomRefToFocus.id = sapUrMapi_SapTable_sGenerateMatrixId(sTableId, oCell.rowIdx, oCell.colIdx);
    ur_focus(oDomRefToFocus);
  }
  return true;
}



function sapUrMapi_SapTable_sGenerateMatrixId(sRootId, iRowIndex, iColIndex){ //Changed
  return sRootId + "-mtx_" + iRowIndex + "_" + iColIndex + "_mtx-";
}


function sapUrMapi_SapTable_bIsMatrixId(sId){
  return sId && sId.indexOf("-mtx_") > 0 && sId.indexOf("_mtx-") == sId.length-5;
}


function sapUrMapi_SapTable_focusMatrixItem(sMatrixId){
  var iPosBeginIndex = sMatrixId.indexOf("-mtx_"),
    sRootId = sMatrixId.substring(0, iPosBeginIndex),
    sPos = sMatrixId.substring(iPosBeginIndex+5, sMatrixId.length - 5),
    aPos = sPos.split("_"),
    iRowIndex = parseInt(aPos[0]),
    iColIndex = parseInt(aPos[1]);

  sapUrMapi_SapTable_focusTableCellByPos(sRootId, iRowIndex, iColIndex);
}


function sapUrMapi_SapTable_focusTableCellByPos(sTableId, iRowIndex, iColIndex){
  var oTable = ur_Table_create(sTableId),
    oCell = (oTable.rows[iRowIndex])? oTable.rows[iRowIndex].cells[iColIndex]: null;
  if(oCell) {
    sapUrMapi_SapTable_focusCell(oCell, sTableId);
    oTable.focusedCell = oCell;
  }
}


function sapUrMapi_SapTable_sGetMatrixIdByContentDomRef(sTableId, oContentDomRef){
  var oDomRefTable=ur_get(sTableId),
    oTableInfo = (oDomRefTable.ct == "ST")? ur_Table_create(sTableId): null,
    oCurrDomRef = oContentDomRef;

  if(oTableInfo) {
    while(oCurrDomRef != null && oCurrDomRef != oDomRefTable && oCurrDomRef.tagName!="BODY") {
      if(oCurrDomRef.parentNode && oCurrDomRef.parentNode.rr && oCurrDomRef.id){
        var oCellInfo = oTableInfo.lookup[oCurrDomRef.id];
        if(oCellInfo) return sapUrMapi_SapTable_sGenerateMatrixId(sTableId, oCellInfo.rowIdx, oCellInfo.colIdx);
      }
      oCurrDomRef = oCurrDomRef.parentNode;
    }
  }
  return "";
}


function sapUrMapi_SapTable_bIsTableId(sTableId){
  var oDomRefTable=ur_get(sTableId);
  return oDomRefTable && oDomRefTable.ct == "ST";
}

// get tooltip for a table cell
function sapUrMapi_SapTable_getTooltip(o,oCell,oTab){
  // not used any more
}


// New Table Model
var _ur_tables=new Array();
function ur_Table_create(sId) {
  if (_ur_tables[sId]==null) {

    var oRows = new Array();
    var oRefCells = new Array();
    var oBdy = null;
    var iR=0;
    var oTab=ur_get(sId);
    var bHasTb=false;
    var oTb=null;
    while(oBdy==null){
      if (oTab.rows[iR].cells[0]==null){iR++;continue;}
      var oTmp=oTab.rows[iR].cells[0].firstChild;
      if (oTmp==null) {iR++;continue;}
      if (oTmp.tagName=="TABLE") {
		    if (oTmp.getAttribute("bd")=="1") {
					oBdy=oTmp;
					
					if (oBdy.ur_firstTBodyOnly && oBdy.tBodies && oBdy.tBodies.length && oBdy.tBodies.length > 0)
						oBdy=oBdy.tBodies[0];
					
					break;
		    }	  
		    if (oTmp.firstChild.firstChild.firstChild.getAttribute("ct")=="T") {
					oTb=oTmp.firstChild.firstChild.firstChild;
					bHasTb=true;
		    }	  
      }
      iR++;
    }
    if (oBdy==null) return null;
    var oTRows = oBdy.rows;
    var oDCells = null;
    var oRowSpanedCells = new Array();

    var iMaxCols=0;
    for (var iRowCount=0;iRowCount<oTRows.length;iRowCount++)  {
      for (var iColCount=0;iColCount<oTRows[iRowCount].cells.length;iColCount++) {
        var iColSpan=parseInt(oTRows[iRowCount].cells[iColCount].colSpan);
        if (isNaN(iColSpan)) iColSpan=1;
        iMaxCols=iMaxCols+iColSpan;
      }
      break;
    }

    for (var iRowCount=0;iRowCount<oTRows.length;iRowCount++)  {
      oRows.push({irowidx:iRowCount,ref:null,cells:new Array(iMaxCols)});
    }

    for (var iRowCount=0;iRowCount<oTRows.length;iRowCount++)  {
      var oCells = oRows[iRowCount].cells;
      var iColCount=0, oOrgCell = null, oTmpCell = null;

      oDCells=oTRows[iRowCount].cells;
      for (var iCol = 0; iCol<oDCells.length; iCol++) {
        while (oCells[iColCount]) iColCount++;
        oRows[iRowCount].cells[iColCount] = {ref:oDCells[iCol]};
        var iColSpan=parseInt(oDCells[iCol].colSpan);
        if (isNaN(iColSpan)) iColSpan=1;
        var iRowSpan=parseInt(oDCells[iCol].rowSpan);
        if (isNaN(iRowSpan)) iRowSpan = 1;
        for (var x=1;x<=iColSpan;x++) {
          for (var iRowSpanCount = 1 ; iRowSpanCount <= iRowSpan; iRowSpanCount++) {
            oTmpCell = {ref:oDCells[iCol],cspan:iColSpan>1,rspan:iRowSpan>1};

            if(x == 1 && iRowSpanCount == 1) {
              oOrgCell = oTmpCell;
              oOrgCell.iRowSpan = iRowSpan;
              oOrgCell.iColSpan = iColSpan;
            }

            oTmpCell.oOrgCell = oOrgCell;

            oRows[iRowCount+iRowSpanCount-1].cells[iColCount] = oTmpCell;
          }
          iColCount++;
        }
      }
      iColCount++;
      oRows[iRowCount].ref=oTRows[iRowCount];
    }




    var oCols=new Array();
    for (var i=0; i<oRows.length; i++){
      for (var j=0; j<oRows[i].cells.length; j++) {
        if (oRows[i].cells[j] == null) {
          oRows[i].cells[j]={ref:oRows[i].cells[j-1].ref,empty:true};
          oRows[i].cells[j-1].last=true;
        } else {
          oRows[i].cells[j].empty=false;
          oRows[i].cells[j].last=j==oRows[i].cells.length-1?true:false;
        }
        if (i>0) oRows[i].previousRow=oRows[i-1];
        if (i<oRows.length-1) oRows[i].nextRow=oRows[i+1];
        oRows[i].irowidx=i;
        var oCell=oRows[i].cells[j];

        oRows[i].sel=-1;

        oCell.foc=false;
        oCell.sel=-1;
        oCell.type="te";
        oCell.parentRow=oRows[i];
        oCell.first=j==0?true:false;
        oCell.isTH=oCell.ref.tagName=="TH";
        oCell.rowIdx=i;
        oCell.colIdx=j;


        if (i==0) {
          oCols.push({icolidx:j,cells:new Array()});
        }
        oCell.parentCol=oCols[j];
        oCols[j].cells.push(oCell);

        oCols[j].sel=-1;
        if (oCell.ref.id==null || oCell.ref.id=="") {
          oCell.ref.setAttribute("id",sId+"-cell-"+i+"-"+j);
        }
        oRefCells[oCell.ref.id]=oCell;
      }
    }

    _ur_tables[sId]={rows:oRows,cols:oCols,lookup:oRefCells,ref:oTab,hasToolbar:bHasTb,toolbar:oTb};
    var debugMode="";
    if (debugMode=="table") {
      var sRenderTable = "<table border='1'>";
      for (var y=0;y<_ur_tables[sId].rows.length;y++) {
        sRenderTable+="<tr>";
        for (var x=0;x<_ur_tables[sId].rows[y].cells.length;x++) {
          sRenderTable+="<td>"+_ur_tables[sId].rows[y].cells[x].rspan + x+" "+y+" "+_ur_tables[sId].rows[y].cells[x].ref.innerText+"</td>";
        }
        sRenderTable+="</tr>";
      }
      sRenderTable+="</table>";
      var oDiv = document.createElement("DIV");
      document.body.appendChild(oDiv);
      oDiv.innerHTML = sRenderTable;
    }
  }

  return _ur_tables[sId];
}

function ur_table_getCellHeaders(s) {
	var result=null;
	if (s!=null && s!="") {
		result=new Array();
		var arrHdr=s.split(",");
		for (var iH=0;iH<arrHdr.length;iH++) {
			var oHdr=ur_get(arrHdr[iH]);
			result.push({ref:oHdr,text:""});
			// TODO: get the text representation of a header object
		}
	}
	return result;
}
/* Apply the scrolling from the scrollbar*/
function sapUrMapi_SapTable_Scrollbar_scroll(sId,oEvt) {
  var o=document.getElementById(sId.split("-")[0]);
  if (!o) return;

  if (oEvt.ur_param && oEvt.ur_param["dir"]) {
    var dir=oEvt.ur_param["dir"];
    if (dir=="v") {
      if (ur_getAttD(o,"o"+dir+"scrl","")!="") ur_EVT_fire(o,"o"+dir+"scrl",oEvt);
    } else if (dir=="h") {
      if (ur_getAttD(o,"o"+dir+"scrl","")!="") ur_EVT_fire(o,"o"+dir+"scrl",oEvt);
    }
  }
}

function ur_SapTable_applySortCursor(oEvt) {
  var o=ur_evtSrc(oEvt);
  o = ur_getNextHtmlParentByAttribute(o, "stasc");
  o.style.cursor="url(" + ur_system.mimepath + "saptable/sort.cur)";
  o.onmouseover=null;
  return false;
}
