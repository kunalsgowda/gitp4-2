//*-------------------------------------------------------------------------
//* Event.js 
//*-------------------------------------------------------------------------
//* Defines functions for event handling. Typically the eventing differs between browsers.
//* Functions in this unit try to encapsulate special handling for each browser.
//*-------------------------------------------------------------------------

//*------------------------------------------------------------------------
//* function    : ur_EV_fire
//* parameter   : o - the object on which you fire the event. It will be the "this" reference
//*               sName - the name of the semantic event you like to fire
//*               oEvt - optional:the event object of the browser that should be passed into the called function
//*               hWnd - optional:reference to the window where o is located 
//* return      : none
//* description : fires the event handler stored in a custom attribute sName on an object o that is located in a window hWnd
//*------------------------------------------------------------------------
function ur_EVT_fire(o,sName,oEvt,hWnd) {
  var sFunc = o.getAttribute(sName); //read the attribute
	if (sFunc && sFunc!="") {
		if (typeof(hWnd)=="undefined") hWnd=window; 
		if (typeof(oEvt)=="undefined") oEvt=hWnd.event;
		o.func=new hWnd.Function("event",sFunc); //create a ne function on the object.
		return o.func(oEvt); //execute the function and return its result
	}
	return null;
}

//* ------------------------------------------------------------------------
//* function    : ur_EV_src
//* parameter   : oEvt - the event object
//* return      : object where the event was initially fired
//*	description	: returns the event source element
//* ------------------------------------------------------------------------
function ur_EVT_src(oEvt) {
	return ur_EVT(oEvt).srcElement;
}

//* ------------------------------------------------------------------------
//* function    : ur_EVT_cancel
//* parameter   : oEvt - the event object
//*.........    : oPrimeEvt - the event object where the event was initially fired  
//* return      : returns true
//* description : cancels events bubbling and the return value. shifts the 
//*               keycode that the browser will not react on keys anymore. Moz cannot shift the keycode
//* ------------------------------------------------------------------------
function ur_EVT_cancel(oEvt,oPrimeEvt){
	if (oPrimeEvt) oEvt = oPrimeEvt;
	try{oEvt.keyCode="";}catch(ex){}; //moz cannot shift
	oEvt.cancelBubble=true;
	oEvt.returnValue=false;
	return true;
}

//* ------------------------------------------------------------------------
//* function    : ur_EVT_cancelBubble
//* parameter   : oEvt - the event object
//* return      : none
//* description : cancels bubbling of the given oEvt
//* ------------------------------------------------------------------------
function ur_EVT_cancelBubble(oEvt){
	oEvt.cancelBubble=true;
}

//* ------------------------------------------------------------------------
//* function    : ur_EVT
//* parameter   : oEvt - the event object
//* return      : the browser independant event object representation
//*	description	: enlarges the properties of the event object for moz to the evt object of ie
//* ------------------------------------------------------------------------
function ur_EVT(oEvt) {
	return oEvt;
}


function ur_EVT_addParam(oEvt,sParName, sParValue)
{
	if(oEvt.ur_param)
	{
		var oTemp = oEvt.ur_param;
		oTemp[sParName] = sParValue;
		oEvt.ur_param = oTemp;  
	}
	else
	{
		var oTemp = new Array();
		oTemp[sParName] = sParValue;
		oEvt.ur_param = oTemp;  
	}
}