//* ************************************************************************
//* BreadCrumb
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_BreadCrumb_keydown
//* parameter   : sId  - id	of the breadcrumb
//*             : oEvt - event object
//* return      : none
//*	description	: 
//* ------------------------------------------------------------------------
function sapUrMapi_BreadCrumb_keydown(sId,oEvt){
	var o=ur_get(sId);
	var oCur=ur_EVT_src(oEvt);
	var oNext=null;

	var _ur_K_Next=ur_system.direction=="rtl"?37:39;
	var _ur_K_Prev=ur_system.direction=="rtl"?39:37;	
	
	/* left and right navigation with arrow keys */
	if(oEvt.keyCode==_ur_K_Next || oEvt.keyCode==_ur_K_Prev){
		if(oEvt.keyCode==_ur_K_Next && oCur.nextSibling!=null){
			oNext=oCur.nextSibling;
			if(oNext.className.indexOf("urBrcDiv")>=0)
				oNext=oNext.nextSibling;
			
		}
		else if(oEvt.keyCode==_ur_K_Prev && oCur.previousSibling!=null){	
			oNext=oCur.previousSibling;	
			if(oNext.className.indexOf("urBrcDiv")>=0)
				oNext=oNext.previousSibling;	
		}
		o.setAttribute("nav","true");		
		if(oNext){
			sapUrMapi_setTabIndex(oNext,0);
			sapUrMapi_setTabIndex(oCur,-1);
			sapUrMapi_focusElement(oNext);
			if (oNext.attachEvent) {
				oNext.attachEvent("onblur",sapUrMapi_BreadCrumb_deactivate);
				oCur.detachEvent("onblur",sapUrMapi_BreadCrumb_deactivate);
			} else {
				oNext.addEventListener("blur",sapUrMapi_BreadCrumb_deactivate,true);
				oCur.removeEventListener("onblur",sapUrMapi_BreadCrumb_deactivate,true);
			}
		}
		ur_EVT_cancel(oEvt);
	} else if(oEvt.keyCode==32 && oCur.onclick!=null){
		 //this causes scrolling in FF
		 oCur.click();
		 ur_EVT_cancel(oEvt);
	} else if(oEvt.keyCode==13){
		ur_EVT_cancel(oEvt);
	} else if(oEvt.keyCode==9){
		o.setAttribute("nav","false");	
		setTimeout("sapUrMapi_BreadCrumb_reset('"+sId+"')",10);
	}	
	
	
}

function sapUrMapi_BreadCrumb_activate(sId,oEvt) {
	//set the focus to the selected element
	var o=ur_get(sId);
	var oSel=o.lastChild;
	sapUrMapi_setTabIndex(oSel,0);
	sapUrMapi_focusElement(oSel);
	o.onblur=null;
	sapUrMapi_setTabIndex(o,-1);
	if (oSel.attachEvent) {
		oSel.attachEvent("onblur",sapUrMapi_BreadCrumb_deactivate);
	} else {
		oSel.addEventListener("blur",sapUrMapi_BreadCrumb_deactivate,true);
	}
}


function sapUrMapi_BreadCrumb_deactivate(oEvt){
	//reset the tabindex to the surrounding div
	var oSrc = ur_EVT_src(oEvt);
	var sId = oSrc.id;
	if (!sId) sId=oSrc.parentNode.id;
	setTimeout("sapUrMapi_BreadCrumb_reset('"+sId+"')",10);
}

function sapUrMapi_BreadCrumb_reset(sId) {
	var o = ur_get(sId);
	if (o.getAttribute("nav") == "true") return;  
	sapUrMapi_setTabIndex(o,0);
	var cn = o.childNodes;
	for  (var i=0; i<cn.length;i++) {
		var oCur = cn[i];
		if (oCur.nodeType == 1 && oCur.getAttribute("ti") == "0" ) {
			if (oCur.attachEvent) {
				oCur.detachEvent("onblur",sapUrMapi_BreadCrumb_deactivate);
			} else {
				oCur.removeEventListener("blur",sapUrMapi_BreadCrumb_deactivate,true);
			}
			sapUrMapi_setTabIndex(oCur,-1);
			return;
		}
	}
}


