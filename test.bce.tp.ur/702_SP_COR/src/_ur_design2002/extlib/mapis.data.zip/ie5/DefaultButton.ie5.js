function sapUrMapi_DBTN_RegisterCreate() {
	sapUrMapi_Create_AddItem("ur_dbtn", "sapUrMapi_DBTN_addDBtn()");
}

function sapUrMapi_DBTN_addDBtn()
{
  if (!ur_get("ur-topdefault")) {
		var oDefaultTop=document.createElement("DIV");
		var oDefaultBottom=document.createElement("DIV");
		var oDefaultLeft=document.createElement("DIV");
		var oDefaultRight=document.createElement("DIV");

		oDefaultTop.setAttribute("id","ur-topdefault");
		oDefaultBottom.setAttribute("id","ur-bottomdefault");
		oDefaultLeft.setAttribute("id","ur-leftdefault");
		oDefaultRight.setAttribute("id","ur-rightdefault");

		document.getElementsByTagName("BODY")[0].appendChild(oDefaultTop);
		document.getElementsByTagName("BODY")[0].appendChild(oDefaultBottom);
		document.getElementsByTagName("BODY")[0].appendChild(oDefaultLeft);
		document.getElementsByTagName("BODY")[0].appendChild(oDefaultRight);
  }
  sapUrMapi_Resize_AddItem("ur-DBtn-rect", "sapUrMapi_DBTN_showDBtn()");
}

function sapUrMapi_DBTN_showDBtn() 
{ 
	var dbId=null;

	try {
		var oNewActive=document.activeElement;
	}
	catch (ex) { 
		return; 
	}

	if( oNewActive != null)
	{
		while(dbId==null && oNewActive.tagName != null && oNewActive.tagName!="BODY") //check for tagName because E-CSN 0120025231 0001038740 2009 when activeElement=html object which doesn't have the method getAttribute

		{
		  dbId=oNewActive.getAttribute("dbId");
		  oNewActive=oNewActive.parentNode;
		}
	}
	
	if(dbId!=null && ur_get(dbId).parentNode!=null)
	{
		
		var currentFocusId = sapUrMapi_Focus_getCurrentId();
		var currentFocus = ur_get(currentFocusId);
		var sCt=sapUrMapi_getControlTypeFromObject(currentFocus);
		switch (sCt) 
		{
			case "B":
			case "TB":
			case "LN":
			case "TGL":
			case "TE":
				    sapUrMapi_DBTN_hideDBtn(); 
				break;
			case "TY":
				var sTp = currentFocus.getAttribute("tp");
			    if (sTp != null)
			    {
					if(sTp=="BTN" || sTp=="MNU")
					sapUrMapi_DBTN_hideDBtn(); 
			    }
				else
			    {
					sapUrMapi_DBTN_showDBtnRect(dbId,oNewActive);
				}
				break;
			case "T":
				var sTp = currentFocus.getAttribute("tp");
			    if (sTp != null)
			    {
					if(sTp=="BTN")
					sapUrMapi_DBTN_hideDBtn(); 
			    }
				else
				{
					sapUrMapi_DBTN_showDBtnRect(dbId,oNewActive);
				}
				break;
			case "I":
			case "TI":
				if(currentFocus.onkeypress!=null)
					sapUrMapi_DBTN_hideDBtn(); 
				else
					sapUrMapi_DBTN_showDBtnRect(dbId,oNewActive);
				break;
			
			default :
				sapUrMapi_DBTN_showDBtnRect(dbId,oNewActive);
				
		}
	}
	else 
	{
		sapUrMapi_DBTN_hideDBtn();
	}
	
}

function sapUrMapi_DBTN_showDBtnRect(dbId,oNewActive)
{
	oNewActive=ur_get(dbId);  
	var activeoffsetonscreen; 
	if(ur_get("ur-topdefault")!=null && ur_get("ur-bottomdefault")!=null && ur_get("ur-leftdefault")!=null && ur_get("ur-rightdefault")!=null)
		activeoffsetonscreen = sapUrMapi_DBTN_getOffset(oNewActive);
	else
		return false;
	var oC={top:ur_get("ur-topdefault"),bottom:ur_get("ur-bottomdefault"),left:ur_get("ur-leftdefault"),right:ur_get("ur-rightdefault")};
	var oDefBtn;	
	if (oNewActive.offsetWidth>0)
	{
		oDefBtn=sapUrMapi_DBTN_calcRect(oNewActive,activeoffsetonscreen,oC.left,oC.right,oC.top,oC.bottom);
		if (oDefBtn==null) return;
		oCC={x1:"top",x2:"bottom",x3:"left",x4:"right"};
		for (xx in oCC) 
		{
			if (xx.charAt(0) == "_") {continue;}
			oC[oCC[xx]].style.top=oDefBtn[oCC[xx]].top;
			oC[oCC[xx]].style.left=oDefBtn[oCC[xx]].left;
		   if (oCC[xx]=="top" || oCC[xx]=="bottom") 
			oC[oCC[xx]].style.width=oDefBtn[oCC[xx]].width;
			if (oCC[xx]=="left" || oCC[xx]=="right") 
			oC[oCC[xx]].style.height=oDefBtn[oCC[xx]].height;
		}
	}

    var top = ur_get("ur-topdefault");
	top.style.borderTop="solid DarkSlateGray 1px";
	top.style.height="1px";
	top.style.position="absolute";
	top.style.zIndex="1000";

    var right = ur_get("ur-rightdefault");
	right.style.borderRight="solid DarkSlateGray 1px";
	right.style.height="1px";
	right.style.width="1px";
	right.style.position="absolute";
	right.style.zIndex="1000";

    var bottom = ur_get("ur-bottomdefault");
	bottom.style.borderTop="solid DarkSlateGray 1px";
	bottom.style.height="1px";
	bottom.style.position="absolute";
	bottom.style.zIndex="1000";

    var left = ur_get("ur-leftdefault");
	left.style.borderLeft="solid DarkSlateGray 1px";
	left.style.height="1px";
	left.style.width="1px";
	left.style.position="absolute";
	left.style.zIndex="1000";

}

function sapUrMapi_DBTN_hideDBtn()
{
	sapUrMapi_Focus_DeflBtn_hideFocusRect(true);
 }

function sapUrMapi_DBTN_calcRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom) {    
	var obj=sapUrMapi_Focus_DflBtn_calcFocusRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom,true);
	return obj;
}

function sapUrMapi_DBTN_getOffset(object)
{	
	var pos=sapUrMapi_Focus_DflBtn_getFocusOffset(object,true);
	return pos;
}

/*############################
GG:
This is a default button solution that is supposed to work without focus rect.
The default button highlight is called oFrame in the follwoing two function. 
The function injects a SPAN directly after the button to be highlighted,
an moves it over the button using its offsetWidth in a negative margin.
#############################*/
function sapUr_DBTN_createFrame(sId) {

	var oButton = ur_get(sId),
		iWidth = oButton.offsetWidth,
		iHeight = oButton.offsetHeight,
		
		openingSPAN = "<SPAN ",
		closingTAG = ">",
		closingSPAN = "</SPAN>",
		
		sBorderColor = oButton.currentStyle.borderColor,
		sFontSize = oButton.currentStyle.fontSize,
		sDirection = (ur_system.direction == "rtl") ? "right" : "left",
		
	oFrame = openingSPAN + "style=\"border:2px solid " + sBorderColor + ";";
	oFrame += "width:" + iWidth + ";";
	oFrame += "margin-" + sDirection + ":-" + iWidth + ";";
	oFrame += "height:" + 10 + ";";
	oFrame += "font-size:" + 10 + "px;";
	oFrame += "margin-bottom:-4px;\"" ;
	
	oFrame += " id=\"ur-DbtnBrd\"";
	oFrame += closingTAG;
	oFrame += "&nbsp;";
	oFrame += closingSPAN;
	
	oButton.insertAdjacentHTML("afterEnd", oFrame);
}

/*
Removes the highlight of the default button on deactivate by removing the injected
SPAN from the DOM. For some reason the result of this operation is a text node.
The romoving method is applied on the text node once again, as it creates a wrong
alignment in the button row.
*/
function sapUr_DBTN_removeFrame() {
	var oFrame = ur_get("ur-DbtnBrd");
	
	if (oFrame == null) return;
	
	var oPrevious = oFrame.previousSibling;
	oFrame.removeNode();
	
	if (oPrevious.nextSibling.nodeType == 3) {
		oPrevious.nextSibling.removeNode();
	}
}