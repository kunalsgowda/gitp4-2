// ------------------------------------------------------------------------
// internal functions for the button
// ------------------------------------------------------------------------
//default handler for BUTTONKEYPRESS (onkeypress) event
function ur_Button_keypress(e) { 
	var o=ur_EVT_src(e);
	var o=sapUrMapi_getRootControl(o);
	if (sapUrMapi_getControlTypeFromObject(o)!="B") return;
	if (ur_Button_isDsbl(o)) return;
  if((o.getAttribute("tp")=="MNUSEC")||(o.getAttribute("tp")=="MNU")) {
		if(e.altKey && e.keyCode==40 || e.keyCode==115) {
		  sapUrMapi_Button_openMenu(o.id,e);
			return ur_EVT_cancel(e);
		}
	}
  if (e.keyCode==32) {
	  ur_EVT_cancel(e);
	  if(o.getAttribute("tp")=="MNU") {
			  sapUrMapi_Button_openMenu(o.id,e);
				return ur_EVT_cancel(e);
	  }
	  return ur_EVT_fire(o,"ocl",e);
  }
}
//default handler for BUTTONCLICKINTERNAL (onclick) event
function ur_Button_click(e) { 
	var o=ur_EVT_src(e);
	var o=sapUrMapi_getRootControl(o);
	if (sapUrMapi_getControlTypeFromObject(o)!="B") return;
	// do nothing in the disabled status
	if (ur_Button_isDsbl(o)) return;
  if (o.getAttribute("tp")=="MNU") {
		  sapUrMapi_Button_openMenu(o.id,e);
			return ur_EVT_cancel(e);
  }
  return ur_EVT_fire(o,"ocl",e);
}

//isDsbl returns true if the button is disabled
function ur_Button_isDsbl(o) {
  var sSt=ur_getAttD(o,"st","");
  return sSt.indexOf("d")>-1;
}
//ur_Button_setStatus sets the status of the button
function ur_Button_setStatus(sId,bEnabled) {
	var o=ur_get(sId);
	var bStD=ur_Button_isDsbl(o);
	if (bStD!=bEnabled) return; 
	var arrCls=o.className.split(" ");
	if (bEnabled) {
	  o.setAttribute("st","");
	  arrCls[0]=arrCls[0].replace("Dsbl","");
	} else {
	  o.setAttribute("st","d");
	  arrCls[0]=arrCls[0]+"Dsbl";
	}
	o.className=arrCls.join(" ");
}

// ------------------------------------------------------------------------
// modification functions for the button
// ------------------------------------------------------------------------
//setEnabled
function mf_Button_setEnabled(sId){ur_Button_setStatus(sId,true);}
//setDisbaled						
function mf_Button_setDisabled(sId){ur_Button_setStatus(sId,false);}

function sapUrMapi_Button_openMenu( sButtonId, e){
	var sPopupId=document.getElementById(sButtonId).getAttribute("popup");
	if (!sPopupId) return;
	if (ur_system.direction=="rtl")
 	  sapUrMapi_PopupMenu_showMenu(sButtonId,sPopupId,sapPopupPositionBehavior.MENURIGHT,e);
 	else
 	  sapUrMapi_PopupMenu_showMenu(sButtonId,sPopupId,sapPopupPositionBehavior.MENULEFT,e);
  e.cancelBubble=false;
	if ((e.type=="contextmenu")) {
    e.returnValue=false;
  } else {
    e.returnValue=true;
  }
}