/* HOVER */
function sapUrMapi_MenuBar_hover(sId,e){
	var oTxt=ur_get(sId+"-txt");
	var oBtn=ur_get(sId+"-btn");
	var oMnuBar=ur_get(sId).parentNode;
	var sAi=oMnuBar.getAttribute("ai");
	
	if(ur_isSt(sId,ur_st.DISABLED)) return;
	
	if (oTxt.className.indexOf("Hover")==-1){
		oTxt.className+="Hover";
		oBtn.className+="Hover";
	}
	if(e.type=="mouseout"){
		oTxt.className=oTxt.className.replace("Hover","");
		oBtn.className=oBtn.className.replace("Hover","");
	}
	if(oPopup!=null){
	  if (!oPopup.source.object) return; //if wd opens a context menu via delta the oPopup is set but no source.object was defined.
		var sSrcPopup = oPopup.source.object.parentNode.getAttribute("id");
		var sMenu = oMnuBar.getAttribute("id");
		if (sSrcPopup == sMenu && sAi!=sId){
 			oTxt.click();
			oMnuBar.setAttribute("ai",sId);
                 }
	}
}

/* MENUBARKEYDOWN */
function sapUrMapi_MenuBar_keyDown(sMenuId,e) {
}

/* MENUBARITEMKEYDOWN */
function sapUrMapi_MenuBarItem_keyDown(sItemId,iCurrentIndex,sPopupId,e) {
 	if (!sapUrMapi_checkKey(e,"keydown",new Array("35","36","37","39","9","40"))) 
 		return false;
 		
 	var oMenuItem=ur_get(sItemId);
 	var oMenu=oMenuItem.parentNode;
 	var iKey=e.keyCode;
 	var oNewItem=null;
 	
 	/* RTL */
 	if(ur_system.direction=="rtl" && iKey==37) iKey=39;
 	else if(ur_system.direction=="rtl" && iKey==39) iKey=37;
 	 	
 	if(iKey!=40)sapUrMapi_setTabIndex(oMenuItem,-1);
 	
 	/* previous menu item */
 	if (iKey==37) {
 		if (oMenuItem.previousSibling)
 			oNewItem = oMenuItem.previousSibling;
 		else
 			oNewItem = oMenu.lastChild;
 	}
	/* next menu item */
 	else if (iKey==39) {
 		if (oMenuItem.nextSibling) 
 			oNewItem = oMenuItem.nextSibling;
 		else 
 			oNewItem = oMenu.firstChild;
 	}
	/* first item */
	else if(iKey==36)
		oNewItem=oMenu.firstChild;
	/* last item */
	else if(iKey==35)
		oNewItem=oMenu.lastChild;	
	/* tab */
 	else if (e.keyCode==9) { 
 		oNewItem=oMenu.firstChild;
	 	if(!ur_system.is508)
	 		while(oNewItem==ur_isSt(oMenuItem,ur_st.DISABLED) && oNewItem!=null)
	 			oNewItem=oNewItem.nextSibling;
		ur_focus(oNewItem);	 			
 		sapUrMapi_setTabIndex(oNewItem,0);
 		e.returnValue=true;
		return true;
	}
	/* open menu */
 	else if (iKey==40 && !ur_isSt(oMenuItem,ur_st.DISABLED)) {
		if (oMenuItem.onclick) 
	 		oMenuItem.onclick();
	 	else if (oMenuItem.oncontextmenu)
			oMenuItem.oncontextmenu();
	}	
			
	/* focus new item */
 	if (oNewItem!=null) {
		sapUrMapi_setTabIndex(oNewItem,0);
	 	ur_focus(oNewItem);
	 	if (!ur_system.is508 && ur_isSt(oNewItem,ur_st.DISABLED)) 
	 		sapUrMapi_MenuBarItem_keyDown(oNewItem.id,0,"",e);
	}

	/* cancel event */
	return ur_EVT_cancel(e);		
}

/* CLICK */
function sapUrMapi_MenuBarItem_click(sItemId,sPopupId,oEvt) {
  sapUrMapi_PopupMenu_showMenu(sItemId,sPopupId,sapPopupPositionBehavior.MENULEFT,oEvt);
  ur_EVT_cancel(oEvt);
}

/* FOCUS */
function sapUrMapi_MenuBar_focus(sMenuId,oEvt) {
	 	var oMenu = ur_get(sMenuId);
	 	var oMenuItem = oMenu.firstChild;
	 	if(!ur_system.is508)
	 		while(oMenuItem==ur_isSt(oMenuItem,ur_st.DISABLED) && oMenuItem!=null)
	 			oMenuItem=oMenuItem.nextSibling;
	 	if(oMenuItem!=null){
	 		sapUrMapi_setTabIndex(oMenuItem,0);
	 		ur_focus(oMenuItem);
	 	sapUrMapi_setTabIndex(oMenu,-1);
	 }
}
