
//** GlobalVariables.op6 **
var sapUrDomainRelaxing = {NONE:"NONE",MINIMAL:"MINIMAL",MAXIMAL:"MAXIMAL"};
try {ur_language==null;} catch(e) {ur_language="en"};
ur_txt=new Array();
ur_KEYS = {TAB:9,ESCAPE:27,
           UP:38,DOWN:40,LEFT:37,RIGHT:39,
           BEGIN:36,END:35,PAGE_UP:33,PAGE_DOWN:34,POS1:36,
           BACKSPACE:8,DELETE:46,ENTER:13,SPACE:32,INSERT:45,
           F4:115}
//** GlobalFunctions.op6 **
function sapUrMapi_triggerFocus(sId) {}
function sapUrMapi_initLinkStatus() {}
var sapUrMapi_Create_Registry = new Array();
var sapUrMapi_Create_Apply = new Array();
var sapUrMapi_Resize_Registry = new Array();
function sapUrMapi_Create_CreateItems() {
	if (document.readyState != "complete") return;
	else {
		for (var ctl in sapUrMapi_Create_Registry) {
			if (ctl.indexOf("_") == 0) {continue;}
			if (sapUrMapi_Create_Registry[ctl] != null) {
				eval(sapUrMapi_Create_Registry[ctl].sHandler);
			}
		}
		sapUrMapi_Create_Registry = new Array();
		for (var ctl in sapUrMapi_Create_Apply) {
			if (ctl.indexOf("_") == 0) {continue;}
			if (sapUrMapi_Create_Apply[ctl] != null) {
				eval(sapUrMapi_Create_Apply[ctl].sHandler);
			}
		}
		sapUrMapi_Create_Apply = new Array();		
	}
}
function sapUrMapi_init() {
  oPopup=null;
  oDatePicker=null;
  sapUrMapi_Resize_Registry=new Array();
}
function ur_evtSrc(e){return e.srcElement;}
function ur_get(sId) {
  return document.getElementById(sId);
}
