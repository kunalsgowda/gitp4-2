
//** GlobalVariables.nn7 **

var sapUrDomainRelaxing = {NONE:"NONE",MINIMAL:"MINIMAL",MAXIMAL:"MAXIMAL"};
try {ur_system==null;} catch(e) {ur_system = {doc : window.document , stylepath : document.location.pathname.substring(0,document.location.pathname.substring(1).indexOf("/")+1)+"/resources/style/", is508 : true, domainrelaxing:sapUrDomainRelaxing.MINIMAL, dateformat:1, firstdayofweek:0};}
try {ur_language==null;} catch(e) {ur_language=""};
ur_txt=new Array();
ur_system.browser_abbrev = "nn7";
if (ur_system.mimepath == null) ur_system.mimepath = ur_system.stylepath.substring(0,ur_system.stylepath.indexOf("/ur"))+"/common/";
if(ur_system.emptyhoverurl==null) ur_system.emptyhoverurl = ur_system.mimepath+"emptyhover.html";
ur_KEYS = {TAB:9,ESCAPE:27,
           UP:38,DOWN:40,LEFT:37,RIGHT:39,
           BEGIN:36,END:35,PAGE_UP:33,PAGE_DOWN:34,POS1:36,
           BACKSPACE:8,DELETE:46,ENTER:13,SPACE:32,INSERT:45,
           F4:115}
//** Abbrev.ie5 **

ur_ctmap={AX:"ActiveXContainer",AP:"AppletContainer",BRC:"BreadCrumb",B:"Button",BR:"ButtonRow",CP:"Caption",C:"CheckBox",CG:"CheckBoxGroup",CB:"ComboBox",CXP:"ContextualPanel",DT:"DataTip",DN:"DateNavigator",DRS:"DragSource",DDL:"DropDownListBox",DRT:"DropTarget",FU:"FileUpload",FL:"FlowLayout",FOC:"FocusRect",FRA:"FreeArea",GTBV:"GenericTableView",GM:"GeoMap",GL:"GridLayout",G:"Group",HD:"HorizontalDivider",IF:"Iframe",IMG:"Image",I:"InputField",IT:"InputTokenizer",ITL:"InputTokenList",INV:"Invisible",IL:"ItemList",ILB:"ItemListBox",	L:"Label",LEG:"Legend",LEGDI:"LegendDateNavigatorItem",LEGTI:"LegendTableItem",LN:"Link",LB:"ListBox",LA:"LoadingAnimation",ML:"MatrixLayout",MNB:"MenuBar",MB:"MessageBar",NL:"NavigationList",PH:"ViewSwitch",PG:"Paginator",PC:"PatternContainerContentItem",PCI:"PatternContainerIconButton",PCSEQ:"PatternContainerSequence",PCTAB:"PatternContainerTab",PCTIT:"PatternContainerTitle",PHI:"PhaseIndicator",PI:"PopIn",POMN:"PopupMenu",POTRG:"PopupTrigger",PRI:"ProgressIndicator",R:"RadioButton",RG:"RadioButtonGroup",RL:"RasterLayout",RI:"RatingIndicator",RM:"RoadMap",ST:"SapTable",STC:"SapTableCell",STDB:"SapTableDefaultBody",STHC:"SapTableHeaderCell",STHIC:"SapTableHierarchicalCell",STR:"SapTableRow",STSB:"SapTableScrollingBody",STSC:"SapTableSelectionCell",SC:"ScrollContainer",SLB:"SelectableLinkBar",SL:"SingleColumnLayout",TBV:"TableView",TS:"TabStrip",TSITM:"Tabstrip Item",TXB:"TextBar",TE:"TextEdit",TV:"TextView",TGL:"ToggleLink",T:"Toolbar",TB:"ToolbarButton",TCB:"ToolbarComboBox",TDDL:"ToolbarDropDownListBox",TI:"ToolbarInputField",TLN:"ToolbarLink",TSEP:"ToolbarSeparator",TY:"Tray",TR:"Tree",TRI:"TriStateCheckBox",BS:"UrBase",VC:"ValueComparison",VS:"ViewSwitch"};
ur_st={SUCCESS:"a",ERROR:"b",COMPLETED:"c",DESELECTABLE:"f",DISABLED:"d",END:"e",INVALID:"i",REQUIRED:"m",NOTSELECTED:"n",UNCOMPLETED:"o",READONLY:"r",SELECTABLE:"6",SELECTED:"s",UNDEFINED:"u",WARNING:"w",MINIMIZED:"z",START:"1",EXPANDED:"+",COLLAPSED:"-",SORTEDASC:"2",SORTEDDESC:"3",NOTSORTED:"4",DYNAMIC:"y"};

//** GlobalFunctions.nn6 **
ur_type={ActiveXContainer:"AX",ActiveXContainer_End:"AX_END",AppletContainer:"AP",AppletContainer_End:"AP_END",Button:"B",Button_Menu:"B_MNU",Button_MenuSection:"B_MNUSEC",Button_Toggle:"B_TG",BreadCrumb:"BRC",BreadCrumb_Item:"BRC_I",BreadCrumb_SingleLink:"BRC_SL",CheckBox:"C",ComboBox:"CB",ComboBox_DropDownListBox:"CB_DD",CheckBoxGroup:"CG",CheckBoxGroup_End:"CG_END",Caption:"CP",ContextualPanel:"CXP",ContextualPanel_Help:"CXP_H",ContextualPanel_Personalize:"CXP_P",ContextualPanel_End:"CXP_END",DateNavigator:"DN",DateNavigator_Month:"DN_MONTH",DateNavigator_Day:"DN_DAY",DateNavigator_Week:"DN_WEEK",DateNavigator_End:"DN_END",FileUpload:"FU",FreeArea:"FRA",FreeArea_Personalize:"FRA_P",FreeArea_End:"FRA_END",GeoMap:"GM",GeoMap_Button:"GM_BTN",GeoMap_Image:"GM_IMG",GeoMap_End:"GM_END",GeoMap_ZoomIn:"GM_ZIN",GeoMap_ZoomOut:"GM_ZOUT",Group:"G",Group_End:"G_END",InputField:"I",Iframe:"IF",Iframe_End:"IF_END",ItemList:"IL",ItemListBoxSingle:"ILBS",ItemListBoxSingle_Item:"ILBS_I",ItemListBoxMultiple:"ILBM",ItemListBoxMultiple_Item:"ILBM_I",Image:"IMG",Invisible:"INV",InputTokenizer:"IT",InputTokenList:"ITL",Label:"L",Legend:"LEG",LegendDateNavigatorItem:"LEGDI",LegendTableItem:"LEGTI",Link:"LN",ListBox:"LB",LoadingAnimation:"LA",MatrixLayout:"ML",MenuBar:"MNB",MenuBar_Item:"MNB_I",MessageBar:"MB",MessageBar_Link:"MB_LNK",NavigationList:"NL",NavigationList_Item:"NL_I",NavigationList_Group:"NL_G",NavigationList_Personalize:"NL_P",NavigationList_End:"NL_END",PageHeader:"PH",PageHeaderEnd:"PH_END",Paginator:"PG",Paginator_Button:"PG_B",Paginator_InputField:"PG_I",Paginator_Menu:"PG_MNU",PatternContainerContentItem:"PC",PatternContainerIconButton:"PCI",PatternContainerIconButton_Collapse:"PCI_C",PatternContainerIconButton_Expand:"PCI_E",PatternContainerIconButton_Min:"PCI_M",PatternContainerTab:"PCTAB",PatternContainerTab_Item:"PCTAB_I",PatternContainerTab_End:"PCTAB_END",PatternContainerTab_Menu:"PCTAB_MNU",PatternContainerTitle:"PCTIT",PatternContainerTitle_End:"PCTIT_END",PatternContainerTitle_Menu:"PCTIT_MNU",PatternContainerSequence:"PCSEQ",PatternContainerSequence_Item:"PCSEQ_I",PatternContainerSequence_End:"PCSEQ_END",PatternContainerSequence_Menu:"PCSEQ_MNU",PhaseIndicator:"PHI",PhaseIndicator_Step:"PHI_STN",PopIn:"PI",PopIn_CloseButton:"PI_CLB",PopIn_End:"PI_END",PopupMenu_Item:"POMN_I",PopupMenu_SubMenu:"POMN_ISMNU",PopupTrigger:"POTRG",ProgressIndicator:"PRI",RadioButton:"R",RadioButtonGroup:"RG",RadioButtonGroup_End:"RG_END",RasterLayout:"RL",RatingIndicator:"RI",RoadMap:"RM",RoadMap_RoundTripStep:"RM_SUB",RoadMap_Step:"RM_STN",RoadMap_RoundtripClosed:"RM_RTCLO",RoadMap_RoundtripStart:"RM_RTSTR",RoadMap_RoundtripEnd:"RM_RTEND",ScrollContainer:"SC",ScrollContainer_End:"SC_END",SapTable:"ST",SapTable_Header1:"ST_HDR1",SapTable_Header2:"ST_HDR2",SapTable_Header3:"ST_HDR3",SapTable_SortButtonAsc:"ST_SRTBTNA",SapTable_SortButtonDesc:"ST_SRTBTND",SapTable_SelectionCell:"ST_SC",SapTable_SelectionColumn:"ST_SCOL",SapTable_SelectionMenu:"ST_SMNU",SapTable_FilterButton:"ST_FBTN",SapTable_End:"ST_END",SapTable_Cell:"ST_C",SapTable_EmptyRowCell:"ST_ER",SelectableLinkBar:"SLB",SingleColumnLayout:"SL",TableView:"TBV",TabStrip:"TS",TabstripItem:"TSITM",TextBar:"TXB",TextEdit:"TE",TextView:"TV",ToggleLink:"TGL",Toolbar:"T",Toolbar_ToggleButton:"T_BTN",Toolbar_End:"T_END",ToolbarInputField:"TI",ToolbarLink:"TLN",Tray:"TY",Tray_Button:"TY_BTN",Tray_Menu:"TY_MNU",Tray_End:"TY_END",Tree:"TR",Tree_Folder:"TR_F",Tree_Leaf:"TR_L",TriStateCheckBox:"TRI",ValueComparison:"VC",ViewSwitch:"VS"};
function sapUrMapi_checkKey(e,eType,arrKeys) {
	if (e.type==eType) {
		for (var i=0;i<arrKeys.length;i++) {
			if (e.which==parseInt(arrKeys[i])) {
				e.returnValue=false;
				return true;
			}
		}
	}
	return false;
}
var ur_context={suppressFocus:false};
function sapUrMapi_suppressFocus(){
	ur_context.suppressFocus=true;
}
function sapUrMapi_triggerFocus(sId) {
  ur_callDelayed("sapUrMapi_focusElement('" + sId.replace(/\\/g, "\\\\").replace(/\'/g, "\\'") + "', true)", 0);
}
function sapUrMapi_findFirstFocus(o,bLast) {
  if (o && o.style && (o.style.display == "none" || o.style.visibility == "hidden")) return null;
  var oChild=o;
  if (o==null) return null;
  if (sapUrMapi_Focus_canFocus(o)) {
		return o;
  }
  
  if (ur_system.direction=="rtl" || bLast) {
   	for (var i=oChild.childNodes.length-1;i>=0;i--) {
      var oTmp=oChild.childNodes.item(i);
      if (oTmp && oTmp.style && (oTmp.style.display=="none" || oTmp.style.visibility=="hidden")) continue;
	  if (sapUrMapi_Focus_canFocus(oTmp)) {
	    return oTmp;
      }
      var oTmp=sapUrMapi_findFirstFocus(oTmp,bLast);
      if (oTmp!=null) {
        return oTmp;
      }
    }  
  } else {    
    for (var i=0;i<oChild.childNodes.length;i++) {
      var oTmp=oChild.childNodes.item(i);
      if (oTmp && oTmp.style && (oTmp.style.display=="none" || oTmp.style.visibility=="hidden")) continue;
	  if (sapUrMapi_Focus_canFocus(oTmp)) {
	    return oTmp;
      }
      var oTmp=sapUrMapi_findFirstFocus(oTmp);
      if (oTmp!=null) {
        return oTmp;
      }
    }  
  }
  return null;
}
function ur_focus(o) {
	if (!ur_context.suppressFocus) {
		try {
			o.focus();
		} 
		catch (ex){
		}
	} else {
		ur_context.suppressFocus=false;
	}
}
function sapUrMapi_focusElement(sId, bTriggered) {
  var bErr=false;
  if (ur_context.suppressFocus) {
    window.addEventListener("onfocus",sapUrMapi_focusElement,true);
    ur_context.setfocusto = sId;
    ur_context.triggered = bTriggered;
    ur_context.suppressFocus = false;
    return;
  } 
  if (ur_context.setfocusto != null) {
    sId = ur_context.setfocusto;
    bTriggered = ur_context.triggered;
    window.removeEventListener("onfocus",sapUrMapi_focusElement,true);
    ur_context.setfocusto = null;
    ur_context.triggered = false;
  }
  
  
  if(ur_context.setfocusto == null && typeof(sId)=="object" && sId.type=="focus"){
      window.removeEventListener("focus",sapUrMapi_focusElement);
      return;
  }
	if(sId == "") return;
	
		if( typeof(sId)=="string" && sapUrMapi_SapTable_bIsMatrixId(sId)){
			sapUrMapi_SapTable_focusMatrixItem(sId);
			return;
		}
	
	  var o;
	  if (typeof(sId)=="string") {
	    o=ur_get(sId);
	  } else {
	    o=sId;
	  }
	  if(o == null) return;
	     var sType=sapUrMapi_getControlTypeFromObject(o);
	  
		if (sType=="I" && o.tagName=="INPUT" && bTriggered && ( o.getAttribute('type') == "text" || o.getAttribute('type') == "password" )) {
			if(_ur_cursorInfo && _ur_cursorInfo.id == sId ) {
				var htmlRef = document.getElementById(_ur_cursorInfo.id);
				if(htmlRef) ur_setCursorPos(htmlRef, _ur_cursorInfo.pos);
				  else {
				  	ur_focus(o);
					o.select();
					}
				
			 }
			 else{
			o.select(); ur_focus(o); 
			_ur_cursorInfo = null; 
			}
		}
		if (sType=="TE" && bTriggered) {
			if(_ur_cursorInfo && _ur_cursorInfo.id == sId ) {
				var htmlRef = document.getElementById(_ur_cursorInfo.id);
				if(htmlRef) ur_setCursorPos(htmlRef, _ur_cursorInfo.pos);
			  else ur_setCursorPos(htmlRef,o.value.length);
			 }
			 else{
			   ur_setCursorPos(o,o.value.length); 
			  _ur_cursorInfo = null; 
			}
		}
		if ((sType=="TR")&&((o.className.indexOf("urTreN")>-1)||(o.className.indexOf("urTreExp")>-1))) {
		  sapUrMapi_Tree_focusNode(sapUrMapi_getRootControl(o).id,o.id.split("-")[0],true);
		} else if ((sType=="TS")&&
	            (((o.className.indexOf("urTbsTxt")>-1) || ((o.firstChild!=null)&&(o.firstChild.className.indexOf("urTbsTxt")>-1))))){
		  	sapUrMapi_TabStrip_focusItem(sapUrMapi_getRootControl(o).id,parseInt(o.id.split("-")[2]));
		} else if (sType=="I" || sType=="TE") { 
		   
		} else if (sType=="SLB") {
		    if (o.id.indexOf("-itm-")>-1) {
			    sapUrMapi_SelectableLinkBar_scroll(sapUrMapi_getRootControl(o).id,o.id);
			    sapUrMapi_setTabIndex(o,0);
			  }
			  try {
			   ur_focus(o);
			  } catch (ex){bErr=true};
		} else if ((sType=="PHI")&&(o.id.indexOf("-itm-")>-1)) {
		    sapUrMapi_PhaseIndicator_focusItem(sapUrMapi_getRootControl(o).id,"-itm-0",o.id.substring(o.id.indexOf("-")));
		} else if ((sType=="RM")&&(o.id.indexOf("-itm-")>-1)) {
		    sapUrMapi_RoadMap_setFocus(sapUrMapi_getRootControl(o).id,"-itm-0",o.id.substring(o.id.indexOf("-itm-")+5));
		} else if (sType=="ST") {
		  var oOrgFocusObj = o;
		  
		  if ((o.firstChild!=null) && (o.firstChild.tagName=="BUTTON") && (o.firstChild.className.indexOf("Ico")>-1)) {
		    o=o.firstChild;
		  }
		  o=sapUrMapi_findFirstFocus(o);
		  
		  if(!o && oOrgFocusObj) {
		  	var oElemToFocus = null;
		  	
		  	
		  	if(!oElemToFocus && oOrgFocusObj.getAttribute("tp") == "HIC" || oOrgFocusObj.getAttribute("tp") == "C") {
		  		oElemToFocus = oOrgFocusObj.firstChild;
		  	}
		  	
		  	
		  	if(!oElemToFocus && oOrgFocusObj.tagName == "TH" && oOrgFocusObj.id ) {
		  		var oContentContainer = document.getElementById(oOrgFocusObj.id + "-content");
		  		if(oContentContainer && oContentContainer.getAttribute("tp") &&  oContentContainer.getAttribute("tp").indexOf("HDR") == 0) {
		  			oElemToFocus = oContentContainer;
		  		}
		  		
		  	}
		  	
		  	if(oElemToFocus) {
					sapUrMapi_setTabIndex(oElemToFocus,"0");
					sapUrMapi_setTabIndexAutoReset(oElemToFocus);
					ur_focus(oElemToFocus);
					return;
		  	}
		  }
		    
		  try {
		   ur_focus(o);
		  } catch (ex){bErr=true};
		  
		} else if (sType=="CB") {
		  o=ur_get(sapUrMapi_getRootControl(o).id);
			if (o.disabled==true) { o.disabled=false;ur_focus(o);o.disabled=true;}
			else ur_focus(o);
		} else if (sType=="C") {
			o=ur_get(o.id.split("-")[0]);
			if (o.disabled==true) {o=ur_get(o.id.split("-")[0]+"-img");}
			ur_focus(o);
		} else if (sType=="R") {
			o=ur_get(o.id.split("-")[0]);
		  if (!o.checked) {
				var oInputGrp  = document.getElementsByName(o.name);
				for (var i=0;i<oInputGrp.length;i++){
				  if (oInputGrp[i].checked) {
				    o=oInputGrp[i];
						break;
				  } 
				}
		  }
		  try {
			 if (o.disabled==true) {o=ur_get(o.id.split("-")[0]+"-img");}
		   ur_focus(o);
		  } catch (ex){bErr=true};
		} else if (sType=="RG" && o.id.indexOf("skipend")<-1) {
		  o=sapUrMapi_findFirstFocus(o);
			if (o!=null && !o.checked) {
				var oInputGrp  = document.getElementsByName(o.name);
				for (var i=0;i<oInputGrp.length;i++){
				  if (oInputGrp[i].checked) {
				    o=oInputGrp[i];
				  } 
				}
		  }
		  o=ur_get(o.id.split("-")[0]);
		  try {
		   ur_focus(o);
		  } catch (ex){bErr=true};
		} else {
			if (typeof(sId)=="string") {
				if (ur_get(sId+"-r")!=null) {
					sapUrMapi_focusElement(sId+"-r");
				}
			}
			o=sapUrMapi_findFirstFocus(o);
			if (o==null) return;
		  try {
		   ur_focus(o);
		  } catch (ex){bErr=true};
	  }
	  if (!b508Refocus) {
	   if (bErr) {
	     sapUrMapi_Focus_hideFocusRect();
	   } else {
	     sapUrMapi_Focus_showFocusRect(o);
	   }
	  }
	  return true;
	
}
var b508Refocus=false;
function sapUrMapi_refocusElement(sId){
if (ur_system.is508) {
	  oSpan=ur_get("ur-accfocus");
	  if (oSpan==null) {
	    oSpan=document.createElement("span");
	    oSpan.setAttribute("id","ur-accfocus");
	    oSpan.style.position="absolute";
	    document.getElementsByTagName("BODY").item(0).appendChild(oSpan);
	    oSpan=ur_get("ur-accfocus");
	  }
	  oSpan.tabIndex="2";
	  b508Refocus=true;
	  oSpan.focus();
	  if(typeof(sId)=="object") sId.focus();
	  else ur_get(sId).focus();
	  b508Refocus=false;
	  oSpan.tabIndex="-1";
	}
};
function sapUrMapi_getAbsolutePosition (obj) {
  var position = { top: 0, left: 0, right: 0};  
	var obj2=obj;
	while (obj && obj.tagName!="BODY") {
	  try { 
	    var s=document.defaultView.getComputedStyle(obj,"");
			if (s.getPropertyValue("overflow")!="visible") {
				position.left-=obj.scrollLeft;
				position.top-=obj.scrollTop;
			}
	  } catch(ex) {}
	  if (obj==obj2) {
	    position.left += obj.offsetLeft;
	    position.top  += obj.offsetTop;
		  obj2=obj.offsetParent;
	  }
	  obj = obj.parentNode;
	}
  return position;
}
function sapUrMapi_getRootControl(o) {
	var oR=o;
	try {
		
	  if (oR.id.indexOf("-")>-1) {
	    oR=ur_get(o.id.split("-")[0]);
	  }
	  if(oR.getAttribute("ct")!=null) return oR;
	  
	  oR=o;
	  while (oR.getAttribute("ct")==null) {
	    if (oR.tagName=="BODY") return "";
	    oR=oR.parentNode;
	  }
	  return oR;
	} catch (ex) {return ""};
}
function sapUrMapi_isChildOfControl(oObj,sControlType) {
  while (oObj.tagName!="BODY") {
    if (sapUrMapi_getControlTypeFromObject(oObj)==sControlType) return oObj;
    oObj=oObj.parentNode;
  }
  return null;
}
function sapUrMapi_getControlTypeFromObject(o) {
	try {
	  var sControlType="";
	  while (o.getAttribute("ct")==null) {
	    if (o.tagName=="BODY") return "";
	    o=o.parentNode;
	  }
	  return o.getAttribute("ct");
	} catch (ex) {return ""};
}
function sapUrMapi_getControlType(sId) {
	try {
	  aId=sId.split("-");
	  var sCt=ur_get(aId[0]).getAttribute("ct");
	  if(sCt==null) sCt=ur_get(aId[0]+"-r").getAttribute("ct");
	  return sCt;
	} catch (ex) {return ""};
}
function sapUrMapi_triggerClick(e,arrKeys, o)
{
  if(sapUrMapi_checkKey(e,"keydown",arrKeys) || sapUrMapi_checkKey(e,"keypress",arrKeys)){
    try{
      if (o) {
      	o.click(e); 
      } else {
      	e.target.click(); 
      }
    }
    catch(ex){};
  }
}
function ur_cancelBubble(oEvt){
	oEvt.stopPropagation();
}
function getLanguageText(sMain,arrChildTxt) {
	 var s;
	 try {
	 	s= ur_txt[ur_language][sMain];
	 	if (!arrChildTxt) return s;
	 	for (var i=0;i<arrChildTxt.length;i++) {
	 		 if (ur_txt[ur_language][arrChildTxt[i]]) {
	 	  	 s= s.replace("{"+i+"}",ur_txt[ur_language][arrChildTxt[i]]);
	 	 	} else {
	 	  	 s= s.replace("{"+i+"}",arrChildTxt[i]);
	 	 	}
	 	}
	} catch(e) {
		s="";
	}
	 return s;
}
function ur_get(sId) {
  return document.getElementById(sId);
}
function ur_getAttD(o,sAtt,def) {
  if (!o) return def;
  var s=o.getAttribute(sAtt);
  if (s!=null && s!="") return s;
  else return def;
}
var ur_arr_FrameCollector = new Array();
function sapUrMapi_toggleIframes(inElement,bShow) {
  var arr = sapUrMapi_collectIFrames(inElement);
  for (var i=0;i<arr.length;i++) {
  	if (!bShow) {
  		if ((arr[i].getAttribute("oldheight")=="")||(!arr[i].getAttribute("oldheight"))) {
  			arr[i].setAttribute("oldheight",arr[i].offsetHeight);
  		}
  		if ((arr[i].getAttribute("hidelevel")=="")||(!arr[i].getAttribute("hidelevel"))) {
  		  arr[i].setAttribute("hidelevel",0);
  		}
  		arr[i].setAttribute("hidelevel",parseInt(arr[i].getAttribute("hidelevel"))+1);
 		  arr[i].style.height="0";
    } else {
  		if ((arr[i].getAttribute("hidelevel")=="")||(!arr[i].getAttribute("hidelevel"))) {
  		  arr[i].setAttribute("hidelevel",1);
  		}
  		arr[i].setAttribute("hidelevel",parseInt(arr[i].getAttribute("hidelevel"))-1);
  		if (arr[i].getAttribute("hidelevel")==0) {
	  		if ((arr[i].getAttribute("oldheight")!="")||(arr[i].getAttribute("oldheight"))) {
	  		  arr[i].style.height=arr[i].getAttribute("oldheight");
	  		}
	  	}
    }
  }
}
function sapUrMapi_collectIFrames(el) {
  ur_arr_FrameCollector = new Array();
  if (el.innerHTML.indexOf("iframe")>-1) {
    sapUrMapi_collectIFramesRec(el);
  }
  return ur_arr_FrameCollector;
}
function sapUrMapi_collectIFramesRec(el) {
	  if (el.childNodes) {
	    var i=0;
	    while ( i<el.childNodes.length ) {
	      var o=el.childNodes.item(i)
	      if (o.childNodes) sapUrMapi_collectIFramesRec(o);
	      if (o.tagName=="IFRAME") ur_arr_FrameCollector[ur_arr_FrameCollector.length]=o;
	      i++;
	    }
	  }
}
function sapUrMapi_scrollRight(elem)
{
  return 0;
}
function sapUrMapi_clientRight(elem)
{
  return 0;
}
function sapUrMapi_scrollBarWidth(elem)
{
  return 0;
}
function sapUrMapi_offsetRight(elem)
{
  return 0;
}
function sapUrMapi_clientXtoRight(docBody, e)
{
  return 0;
}
function sapUrMapi_posLeftCorrectionForRTL(elem)
{
  return 0;
}
function sapUr_Scroll_scrollToPosition(sId,x,y) {
	var ct = sapUrMapi_getControlType(sId);
	try{
	if(ct!="")
	{
		if(ct=="G" || ct=="TY")
			sapUrMapi_scrollToPosition(ur_get(sId+"-bd"),x,y);
		else
		if(ct =="TS")
		{
			var iSelIdx = ur_get(sId).getAttribute('sidx'); 
			var oCont = ur_get(sId+"-tbar-cnt-"+iSelIdx); 
			if(!oCont) 
			{
				oCont = ur_get(sId+"-bd-"+iSelIdx); 
			}
			sapUrMapi_scrollToPosition(oCont,x,y);
		}
		else
		{
		    sapUrMapi_scrollToPosition(ur_get(sId),x,y);
		}
	}
	}catch(ex) {};
	
}
function sapUrMapi_scrollToPosition(o,x,y) {
	o.scrollTop=y;
    o.scrollLeft=x;
}
function sapUrMapi_getScrollLeft(o) {
  return o.scrollLeft;
}
function sapUrMapi_getScrollTop(o) {
  return o.scrollTop;
}
function sapUr_Scroll_scrollLeft(sId) {
	
	var ct = sapUrMapi_getControlType(sId);
	try{
	if(ct!="")
	{
		if(ct=="G" || ct=="TY")
			return ur_get(sId+"-bd").scrollLeft;
		else
		if(ct =="TS")
		{
			var iSelIdx = ur_get(sId).getAttribute('sidx'); 
			var oCont = ur_get(sId+"-tbar-cnt-"+iSelIdx); 
			if(!oCont) 
			{
				oCont = ur_get(sId+"-bd-"+iSelIdx); 
			}
			return oCont.scrollLeft;
		}
		else
		{
		  return ur_get(sId).scrollLeft;
		}
	}
	}catch(ex) {};
	
 
}
function sapUr_Scroll_scrollRight(sId) {
	var o = ur_get(sId);
	return sapUrMapi_scrollRight(o);
}
function sapUr_Scroll_scrollTop(sId) {
	
	var ct = sapUrMapi_getControlType(sId);
	try{
	if(ct!="")
	{
		if(ct=="G" || ct=="TY")
			return ur_get(sId+"-bd").scrollTop;
		else
		if(ct =="TS")
		{
			var iSelIdx = ur_get(sId).getAttribute('sidx'); 
			var oCont = ur_get(sId+"-tbar-cnt-"+iSelIdx); 
			if(!oCont) 
			{
				oCont = ur_get(sId+"-bd-"+iSelIdx); 
			}
			return oCont.scrollTop;
		}
		else
		{
		  return ur_get(sId).scrollTop;
		}
	}
	}catch(ex) {};
}
function ur_Scrl_setScrlPosById(sId,oPos)
{
	sapUr_Scroll_scrollToPosition(sId,oPos.x,oPos.y);
}
function ur_Scrl_getScrlPosById(sId)
{
	var oPos = new Object();
	oPos.x = sapUr_Scroll_scrollLeft(sId);
	oPos.y = sapUr_Scroll_scrollTop(sId);
	return oPos;
}
function sapUrMapi_initLinkStatus() {
  var oNodes = document.getElementsByTagName("A");
  for (var n=0;n<oNodes.length;n++) {
    if (oNodes[n].href.indexOf("javascript:void")>-1) {
      oNodes[n].onmouseover=sapUrMapi_resetStatus;
      oNodes[n].onfocus=sapUrMapi_resetStatus;
    }
  }
}
function sapUrMapi_resetStatus() {
  window.status="";
  
}
function sapUrMapi_Resize_Handler(sId, sHandler) {
	this.sId = sId;
	this.sHandler = sHandler;
}
var sapUrMapi_Resize_Registry = new Array();
var sapUrMapi_Resize_Width = null;
var sapUrMapi_Resize_Timeout = null;
var sapUrMapi_Resize_Set = false;
function sapUrMapi_Resize_Capture() {
	if (sapUrMapi_Resize_Set == false) {
		window.addEventListener("resize", sapUrMapi_Resize_CheckSize, false);
		sapUrMapi_Resize_Set = true;
	}
}
function sapUrMapi_Resize_AddItem(sId, sHandler) {
	
	sapUrMapi_Resize_Capture();
	
	if (!sapUrMapi_Resize_Registry[sId] || sapUrMapi_Resize_Registry[sId]) {
		sapUrMapi_Resize_Registry[sId] = new sapUrMapi_Resize_Handler(sId, sHandler);
	}
}
function sapUrMapi_Resize_CheckSize() {
	if (sapUrMapi_Resize_Timeout == null && sapUrMapi_Resize_Width == null) {
		sapUrMapi_Resize_Width = document.body.offsetWidth;
		sapUrMapi_Resize_Timeout = window.ur_callDelayed("sapUrMapi_Resize_CheckSize()", 50);
		return;
	}
	if (sapUrMapi_Resize_Width != document.body.offsetWidth) {
		sapUrMapi_Resize_Width = document.body.offsetWidth;
		sapUrMapi_Resize_Timeout = window.ur_callDelayed("sapUrMapi_Resize_CheckSize()", 50);
	}
	else {
	    window.clearTimeout(sapUrMapi_Resize_Timeout);
		sapUrMapi_Resize_Timeout = null;
		sapUrMapi_Resize_Resize();
		sapUrMapi_Resize_Width = null;
	}
}
function sapUrMapi_Resize_Resize() {
	for (var ctl in sapUrMapi_Resize_Registry) {
		if (ctl.indexOf("_") == 0) {continue;}
		if (sapUrMapi_Resize_Registry[ctl] != null) {
			eval(sapUrMapi_Resize_Registry[ctl].sHandler);
		}
	}
}
function sapUrMapi_Create_Handler(sId, sHandler) {
	this.sId = sId;
	this.sHandler = sHandler;
}
var sapUrMapi_Create_Registry = new Array();
var sapUrMapi_Create_Apply = new Array();
var sapUrMapi_Create_Set = false;
var sapUrMapi_Create_Timeout = null;
var sapUrMapi_Create_Doc = "";
function sapUrMapi_Create_Capture() {
	if (sapUrMapi_Create_Set == false) {
		
		sapUrMapi_Create_Doc = document.body.innerHTML;
		sapUrMapi_Create_Timeout = window.setTimeout("sapUrMapi_Create_CreateItems()", 150);
		sapUrMapi_Create_Set = true;
	}
}
function sapUrMapi_Create_AddItem(sId, sHandler,bApply) {
	
	sapUrMapi_Create_Capture();
	
	if(bApply)
		sapUrMapi_Create_Apply[sId] = new sapUrMapi_Create_Handler(sId, sHandler);
	else	
		sapUrMapi_Create_Registry[sId] = new sapUrMapi_Create_Handler(sId, sHandler);
}
function sapUrMapi_Create_CreateItems() {
	
	var doc = document.body.innerHTML;
	if (doc != sapUrMapi_Create_Doc) {
		sapUrMapi_Create_Doc = doc;
		sapUrMapi_Create_Timeout = window.setTimeout("sapUrMapi_Create_CreateItems()", 150);
	}
	else {
		window.clearTimeout(sapUrMapi_Create_Timeout);
		sapUrMapi_Create_Timeout = null;
		for (var ctl in sapUrMapi_Create_Registry) {
			if (ctl.indexOf("_") == 0) {continue;}
			if (sapUrMapi_Create_Registry[ctl] != null) {
				eval(sapUrMapi_Create_Registry[ctl].sHandler);
			}
		}
		sapUrMapi_Create_Registry = new Array();
		
		for (var ctl in sapUrMapi_Create_Apply) {
			if (ctl.indexOf("_") == 0) {continue;}
			if (sapUrMapi_Create_Apply[ctl] != null) {
				eval(sapUrMapi_Create_Apply[ctl].sHandler);
			}
		}
		sapUrMapi_Create_Apply = new Array();				
	}
}
function sapUrMapi_init() {
	if (ur_system.mimepath == null) ur_system.mimepath = ur_system.stylepath.substring(0,ur_system.stylepath.indexOf("/ur"))+"/common/";
	if (ur_system.emptyhoverurl == null || ur_system.emptyhoverurl == "") ur_system.emptyhoverurl = ur_system.mimepath+"emptyhover.html";
	if (ur_language==null || ur_language=="") {
		var oScript=ur_get("ur_lang_js");
		if (!oScript) {
			var scripts=document.getElementsByTagName("SCRIPT");
			for (var i=0;i<scripts.length;i++) 
				if (scripts[i].src.indexOf("urMessageBundle_")>-1) {
					oScript=scripts[i];
					break;
				}
		}
		if (oScript) {
			var url = oScript.src,
			    beginPos = url.indexOf("urMessageBundle_"),
			    endPos = url.indexOf(".js", beginPos);
			var oParent = oScript.parentNode;
			oParent.removeChild(oScript);
			oScript = document.createElement("script"); 
			oScript.src = url.substring(0,beginPos) + "urMessageBundle" + url.substring(endPos);
			oParent.appendChild(oScript);
      }
	}
  oPopup=null;
  oDatePicker=null;
  sapUrMapi_Resize_Registry=new Array();
  sapUrMapi_PcTabSeq_Registry = new Array();
  _ur_POMN = {all:new Array(),menus:new Array(),level:0};
  _ur_tables=new Array();
  ur_Scrollbar_EnvironmentInit();
}
function ur_evtSrc(e){return e.target;}
function sapUrMapi_cleanUp() {
  
}
function sapUrMapi_getCurrentStyle(o,sStAt){
	var s=document.defaultView.getComputedStyle(o,"").getPropertyValue(sStAt);
	return s;
}
	
function ur_checkFocussedUiElement(htmlRef, browserEvent) {
}
var _ur_tableInputFoc;
function ur_setEditCellColor(o) {
  ur_removeEditCellColor();
  var sCt=sapUrMapi_getControlTypeFromObject(o);
  if (sCt=="I" || sCt=="CB") { 
		if (ur_getAttD(o,"st","").indexOf("r")==-1 && 
		    ur_getAttD(o,"st","").indexOf("d")==-1 && 
				sapUrMapi_isChildOfControl(o,"ST")) {
			var oCell=o;
			while (oCell.tagName!="TD" || oCell.className.indexOf("urSTTD")==-1) {
				oCell=oCell.parentNode;
				
				if (oCell.tagName=="TR" && oCell.firstChild.firstChild!=o) { oCell=null;break;}
			}
			if (oCell!=null && oCell!=o) {
				oCell.className=oCell.className+" urSTFoc";
				_ur_tableInputFoc=oCell;
			}
		}
	}
}
function ur_removeEditCellColor() {
	if (_ur_tableInputFoc!=null) {
	  try {
	    _ur_tableInputFoc.className=_ur_tableInputFoc.className.replace(" urSTFoc","");
	  } catch (ex) {}
	  _ur_tableInputFoc=null;
	}  
}
function ur_callDelayed(sFunc,ms) {
  return setTimeout("try{"+sFunc+"}catch(ex){}",ms);
}
function ur_getPrevItm(o,sAt){
		if(!o || !sAt) return null;
		while(ur_getAttD(o,sAt,"")==""){ 
			o=o.previousSibling;
			if (!o) return null;
		}
	return o;
}
function ur_getNxtItm(o,sAt){
	if(!o || !sAt) return null;
	while(ur_getAttD(o,sAt,"")==""){ 
			o=o.nextSibling;
			if (!o ) return null;
		}
	return o;
}
function ur_focus_Itm(oNew,oOld){
		sapUrMapi_setTabIndex(oOld,-1);
		sapUrMapi_setTabIndex(oNew,0);
		ur_focus(oNew);
}
function sapUrMapi_relaxDomain(integrated, standalone, maxrelax) {
  var hostname = location.hostname,
      nameparts = hostname.split("."),
      partslength = nameparts.length,
      reference = "parent";
  
  
  if (/^(\d|\.)+$/.test(hostname)) return true;
  
  if (partslength == 1) return true;
  
  
  if (standalone == null) standalone = "minimal";
  if (integrated == null) integrated = "auto";
  if (maxrelax == null) {
    
    if (nameparts[partslength - 1].length == 2 &&
        nameparts[partslength - 2].length == 2) {
      maxrelax = 3;
    } else {
      maxrelax = 2;
    }
  }
  
  if (partslength <= maxrelax) return true;
  
  if (standalone == "auto") standalone = "minimal";
  if (window[reference] == window) reference = "opener";
  if (window[reference] == null) method = standalone;
  else method = integrated;
  
  switch (method) {
    case "none": 
      return true;
      break;
    
    case "auto": 
      try {
        window[reference].location.href;
        return true;
      }
      catch (e) {};
      var testdomain;
      for (var i = 0; i <= partslength - maxrelax; i++) {
        testdomain = nameparts.slice(i).join(".");
        try {
          document.domain = testdomain;
          window[reference].location.href;
          return true;
        }
        catch (e) {};
      }
      return false;
      break;
    case "minimal": 
      try {
        document.domain = nameparts.slice(1).join(".");
        return true;
      }
      catch (e) {
        return false;
      }
      break;
    case "maximal": 
      try {
        document.domain = nameparts.slice(partslength - maxrelax).join(".");
        return true;
      }
      catch (e) {
        return false;
      }
      break;
    default:
      alert("Unknown relaxation method: " + method);
  }
  return false;
}
function sapUrMapi_setTabIndex(oElem,sVal) {
	if(oElem.getAttribute("ti")) {
		oElem.setAttribute("orgTi",oElem.getAttribute("ti"));
	}	
  oElem.tabIndex=sVal;
  oElem.setAttribute("ti",sVal);
}
function sapUrMapi_resetTabIndex(oElem) {
	if (oElem.type == "blur") oElem = this;
	if(!oElem) oElem=this;
	
	if(oElem.getAttribute("orgTi")) {
		var sVal = oElem.getAttribute("orgTi");
		oElem.tabIndex=sVal;
		oElem.setAttribute("ti",sVal);
		if(oElem.onblur == sapUrMapi_resetTabIndex)
			oElem.onblur = null;
		oElem.setAttribute("orgTi",null);
	}	else {
  	oElem.tabIndex="-1";
  	oElem.setAttribute("ti",null);
	}
}
function sapUrMapi_setTabIndexAutoReset(oElem) {
	if(!oElem.onblur)
		oElem.onblur = sapUrMapi_resetTabIndex;
}
function sapUrMapi_DOM_bContains(oDomRefContainer, oDomRefChild) {
	var oDomRef = oDomRefChild;
	
	if(oDomRefContainer == oDomRefChild) return true;
	
	while(oDomRef != null) {
		if(oDomRef == oDomRefContainer) return true;
		oDomRef = oDomRef.parentNode;
	}
	
	return false;
};
function sapUrMapi_triggerDefaultButton(sId,oEvt)
{
	var oR=ur_get(sId);
	var dbId = oR.getAttribute("dbid");
	var dbtn = ur_get(dbId);
	if(dbId!=null && ur_get(dbId).parentNode!=null)
	{
		
		var currentFocus = ur_EVT_src(oEvt)
		var sCt=sapUrMapi_getControlTypeFromObject(currentFocus);
		switch (sCt) 
		{
			case "": 
			case "B":
			case "TB":
			case "TE":
			case "TGL":
			case "LN":
			    sapUrMapi_DBTN_hideDBtn(); 
				break;
			case "TY":
				var sTp = currentFocus.getAttribute("tp");
			    if (sTp != null)
			    {
					if(sTp=="BTN" || sTp=="MNU")
					sapUrMapi_DBTN_hideDBtn(); 
			    }
				else
			    {
					sapUrMapi_defaultButtonClick(dbtn);
				}
				break;
			case "T":
				var sTp = currentFocus.getAttribute("tp");
			    if (sTp != null)
			    {
					if(sTp=="BTN")
					sapUrMapi_DBTN_hideDBtn(); 
			    }
				else
				{
					sapUrMapi_defaultButtonClick(dbtn);
				}
				break;
			case "I":
			case "TI":
				if(currentFocus.onkeypress!=null)
					sapUrMapi_DBTN_hideDBtn(); 
				else
				{
					sapUrMapi_defaultButtonClick(dbtn);
				}
				break;
			default :
			{
				sapUrMapi_defaultButtonClick(dbtn);
			}
				
		}
	}
	else 
	{
		sapUrMapi_DBTN_hideDBtn();
	}
		
}
function sapUrMapi_defaultButtonClick(dbtn)
{
	ur_EVT_fire(dbtn,"ocl",{type:"click",target:dbtn});
}
var ur_logIdx = 0;
function ur_logEvent(a,b,c) {
	var oLog = ur_get("ur-log");
	if (!oLog) {
		var oLog = document.createElement("DIV");
		oLog.id="ur-log";
		document.body.appendChild(oLog);
		oLog.style.position="absolute";
		oLog.style.top="0";
		oLog.style.left="0";
		oLog.style.backgroundColor="#fff";
		oLog.style.padding="5px";
	} 
	var o = document.createElement("DIV");
	o.innerHTML = (ur_logIdx++) + "  -  (" + a + "," + b + "," + c + ")";
	oLog.appendChild(o);
}
function ur_findPreviousFocusableElement(o) {
	var oR=o;
	var oN=null;
	var oF=null;
	while(oR!=null && oF==null){
		while(oR!=null && oR.previousSibling==null)
			oR=oR.parentNode;
		if(oR==null)
			break;
		oN=oR.previousSibling;
		while(oN!=null && oF==null){
			oF=sapUrMapi_findFirstFocus(oN,true);
			if(oF==null)
				oN=oN.previousSibling;
		}
		if(oF==null)
			oR=oR.parentNode;
		else
			break;
	}
	return oF;
}
function ur_findNextFocusableElement(o) {
	var oR=o;
	var oN=null;
	var oF=null;
	while(oR!=null && oF==null){
		while(oR!=null && oR.nextSibling==null)
			oR=oR.parentNode;
		if(oR==null)
			break;				
		oN=oR.nextSibling;
		while(oN!=null && oF==null){
			oF=sapUrMapi_findFirstFocus(oN);
			if(oF==null)
				oN=oN.nextSibling;
		}
		if(oF==null)
			oR=oR.parentNode;
		else
			break;
	}
	return oF;
}
function ur_getNextHtmlParentByAttribute(oDomRef, sAttributeName){
	if (oDomRef) {
		var oCurDomRef = oDomRef;
		for(var i=10; i>0; i--) {
			if(oCurDomRef.tagName == "BODY") return null;
			
			if(oCurDomRef.getAttribute(sAttributeName)) return oCurDomRef;
		
			if(oCurDomRef.parentNode) oCurDomRef=oCurDomRef.parentNode;
			else return null;
		}
	}
	return null;
};
function ur_getNextHtmlParentByTagName(oDomRef, sTagName){
	if (oDomRef) {
		var oCurDomRef = oDomRef;
		for(var i=10; i>0; i--) {
			if(oCurDomRef.tagName == "BODY") return null;
			
			if(oCurDomRef.tagName == sTagName) return oCurDomRef;
		
			if(oCurDomRef.parentNode) oCurDomRef=oCurDomRef.parentNode;
			else return null;
		}
	}
	return null;
};
function sapUrMapi_bCtrl( oEvent ) {
	return sapUrMapi_bIsMacOs() ? oEvent.metaKey : oEvent.ctrlKey;
}
function sapUrMapi_bIsMacOs( ) {
	
	try {
		return window.navigator.userAgent.indexOf("Mac OS")>-1;
	} catch( e ) { 
		return false; 
	}
}
//** Context.ie5 **
																																							
var ur_ctx=new Array();
ur_ctx._i=new Array();
ur_ctx.get = function(sId,sKey) { return ur_ctx._i[sId][sKey]; }
ur_ctx.set = function(sId,sKey,sValue) { 
  if (ur_ctx._i[sId]==null) ur_ctx._i[sId]=new Array();
  ur_ctx._i[sId][sKey]=sValue;
}
ur_ctx.write = function() { 
  var s1="";
  for (var x in ur_ctx._i) {
    if (s1!="") s1+=",";
    s1+=x+":{";
    var s2="";
    for (var y in ur_ctx._i[x]) {
      var val=ur_ctx._i[x][y];
      if (s2!="") s2+=",";
      if (typeof(ur_ctx._i[x][y])=="string") val="'"+val+"'";
      s2+=y+":"+val;
    }
    s1+=s2+"}";
  }
  return "{"+s1+"}";
}
ur_ctx.read = function(s) { 
  ur_ctx._i=new Array();
  eval("ur_ctx._i="+s);
  ur_ctx.clear();
}
ur_ctx.push = function(sId,sKey,sValue) {
  if (ur_ctx._i[sId]==null) ur_ctx._i[sId]=new Array();
  ur_ctx._i[sId][sKey]=sValue;
}
ur_ctx.pop = function(sId) {
	ur_ctx._i[sId]=null;
  ur_ctx.clear();
}
ur_ctx.clear = function() {
  var a=new Array();
  for (var x in ur_ctx._i) 
    if (document.getElementById(x)!=null && ur_ctx._i[x]!=null) a[x]=ur_ctx._i[x];
  ur_ctx._i=a;
}

//** ScrollableItems.nn6 **
var ur_IScr = {};
	
function ur_IScr_visFirst(o,x){
	var oItm=o.items[x];
	var iWidth=oItm.width;
	if ( o.availwidth > o.newwidth+iWidth ) {
              oItm.visible = true;
              o.first=x;
        } else {
           oItm.visible=false; 
           o.tmpwidth = o.newwidth+iWidth;
           return true;
         }
	o.newwidth+=iWidth;
	return false;
}
	
function ur_IScr_visLast(o,x){
	var oItm=o.items[x];
	var iWidth=oItm.width;
	if (o.availwidth > o.newwidth+iWidth) {
            oItm.visible = true;
            o.last = x;
         } else {
             oItm.visible = false;
             o.tmpwidth = o.newwidth + iWidth;
             return true;
        }
	o.newwidth+=iWidth;
	return false;
}
	
function ur_IScr_getObj(sId) {
		
		if ( ur_IScr[sId] != null && (ur_IScr[sId].ref == ur_get(sId)) ) {
			return;
		}
		
		ur_IScr[sId]=new Array();
		ur_IScr[sId].availwidth=0;
		ur_IScr[sId].ref=ur_get(sId);
		ur_IScr[sId].scrl=ur_get(sId+"-scrl");
		ur_IScr[sId].items = new Array();
		oCntItms = ur_IScr[sId].scrl.getElementsByTagName("TD");
		
		for (var i=0;i<oCntItms.length;i++) {
			var oItm=oCntItms[i];
			if (oItm && oItm.getAttribute("idx")!=null && oItm.getAttribute("idx")!="") {
				var iIdx=parseInt(oItm.getAttribute("idx"));
				
				if (ur_IScr[sId].items[iIdx]!=null) {
					ur_IScr[sId].items[iIdx][ur_IScr[sId].items[iIdx].length]=oItm;
				}	else {
					ur_IScr[sId].items[iIdx]=new Array();
					ur_IScr[sId].items[iIdx].width=0;
					ur_IScr[sId].items[iIdx][0]=oItm;
					sT=oItm.getAttribute("st");
					
					if (sT != null && sT.indexOf("s") > -1) ur_IScr[sId].items[iIdx]["forcevisible"]=true;
				}
				
				ur_IScr[sId].items[iIdx].width+=oItm.offsetWidth;
		}
	} 
		ur_IScr[sId].first=parseInt(ur_IScr[sId].scrl.getAttribute("fsrl"));
		ur_IScr[sId].last=parseInt(ur_IScr[sId].scrl.parentNode.getAttribute("lsrl"));
}
function ur_IScr_fireEvent(sEvtName,o,idx) {
	if (o.scrl.getAttribute(sEvtName)) {
		var tmpFunc=new Function("event",o.scrl.getAttribute(sEvtName));
		if (sEvtName=="ohi" || sEvtName=="osi")
			ur_EVT_fire(o.scrl,"osi");
		if (sEvtName=="oadi") {
			ur_EVT_fire(o.scrl,"oadi");
		}
	}
	return true;
}
	
function ur_IScr_draw(sId) {
		var o = ur_IScr[sId];
		
		
		
		
		if(o.ref.getAttribute("scrl") != "1"){
			var noScrlWdth = 0;
			for( var i = 0 ; i < o.items.length ; i++) {
				noScrlWdth = noScrlWdth + o.items[i].width;
			}
			noScrlWdth = noScrlWdth + o.items[o.items.length -1].width;
			o.availwidth =noScrlWdth ;
		}
		else
			o.availwidth=o.scrl.offsetWidth+ur_get(sId+'-lscrl').offsetWidth-1;
	o.newwidth=0;
	o.tmpwidth=0;
	for (var i = 0; i < o.items.length; i++) {
		o.items[i].visible=false;
	}
		
	if (o.last==-1) { 
		
			for (var i = o.first; i < o.items.length; i++) {
				
				if ( ur_IScr_visLast(o, i) ) break; 
		}
		if (o.availwidth>o.tmpwidth) { 
			
				for (var i = o.first - 1; i >= 0; i--) 
					if (ur_IScr_visFirst(o,i)) break;
		}
	} else {
		
		for (var i = o.last; i >= 0; i--) 
			
			if (ur_IScr_visFirst(o, i)) break; 
			
		if (o.availwidth>o.tmpwidth) { 
			
			for (var x=o.last+1;x<o.items.length;x++) 
				if (ur_IScr_visLast(o,x)) break;
		}
	}
		
		
	for (var x=0;x<o.items.length;x++) {
	if (o.items[x].visible){
		if (ur_IScr_fireEvent("osi",o,x)) {
				for (var n=0;n<o.items[x].length;n++) {
					o.items[x][n].removeAttribute("style");
					o.items[x][n].style.display="";
				}
			}
	} else {
			if (ur_IScr_fireEvent("ohi",o,x)) {
				for (var n=0;n<o.items[x].length;n++) {
				o.items[x][n].removeAttribute("style");
				o.items[x][n].style.display="none";
				}
			}
	}
	}
		if(ur_get(sId).getAttribute("scrl") != "1") {
			o.first = 0;
			o.last = o.items.length -1;
	}
		
	if (o.ref.getAttribute("ct") == "TS") {
		ur_TS_oadi(sId);
		
		if (o != null) {
		    var oLastImg = ur_get(o.ref.id + "-n");
		    if (oLastImg != null) {
		        oLastImg.style.height = "18px";
		    }
		}
	}else{
	ur_IScr_fireEvent("oadi",o);
             }
	o.scrl.style.minWidth=o.newwidth + "px";
}
function ur_IScr_toBegin(sId) {
	ur_IScr[sId].first = 0;
	ur_IScr[sId].last = -1;
	ur_IScr_draw(sId);
}
function ur_IScr_toEnd(sId) {
	ur_IScr[sId].first = -1;
	ur_IScr[sId].last = ur_IScr[sId].items.length-1;
	ur_IScr_draw(sId);
}
function ur_IScr_toPrevPage(sId) {
	if (ur_IScr[sId].first > 0) {
		ur_IScr[sId].last = ur_IScr[sId].first - 1;
		ur_IScr[sId].first = -1;
	ur_IScr_draw(sId);
	}
}
function ur_IScr_toPrevItem(sId) {
	
		if ( ur_IScr[sId].first > 0) {
			ur_IScr[sId].first--;
		
			ur_IScr[sId].last = -1;
		ur_IScr_draw(sId);
	}
}
function ur_IScr_toNextPage(sId) {
		if (ur_IScr[sId].last < ur_IScr[sId].items.length - 1) {
			ur_IScr[sId].first = ur_IScr[sId].last + 1;
			ur_IScr[sId].last = - 1;
		ur_IScr_draw(sId);
	}
}
function ur_IScr_toNextItem(sId) {
	
		if (ur_IScr[sId].first < ur_IScr[sId].items.length - 1) {
			ur_IScr[sId].first ++;
			ur_IScr[sId].last = -1;
		ur_IScr_draw(sId);
	}
}
	
	function ur_IScr_resize(sId) {
		ur_IScr[sId].last=-1;
	ur_IScr_draw(sId);
}
	
function ur_IScr_create(sId){
	ur_IScr_resize(sId);			
}
function ur_IScr_getFirstVisibleIndex(sId){
		if (ur_IScr[sId].first > 0) {
			return parseInt(ur_IScr[sId].first);
	}
	return 0;
}

//** Event.nn6 **

function ur_EVT_fire(o,sName,oEvt,hWnd) {
	var sFunc = o.getAttribute(sName); 
	if (sFunc && sFunc!="") {
		if (typeof(hWnd)=="undefined") hWnd=window; 
		if (typeof(oEvt)=="undefined") oEvt=hWnd.event;
		o.func=new hWnd.Function("event",sFunc); 
		return o.func(oEvt); 
	}
	return null;
}
function ur_EVT_src(oEvt) {
	return ur_EVT(oEvt).srcElement;
}
function ur_EVT_cancel(oEvt,oPrimeEvt){
	if (oPrimeEvt) oEvt = oPrimeEvt;
	try{oEvt.keyCode="";}catch(ex){}; 
	oEvt.stopPropagation();
	oEvt.preventDefault();
	return true;
}
function ur_EVT_cancelBubble(oEvt){
	oEvt.stopPropagation();
}
function ur_EVT(oEvt) {
	oEvt["srcElement"]=oEvt.target.tagName?oEvt.target:oEvt.target.parentNode;
	oEvt["fromElement"]=oEvt.relatedTarget;
	oEvt["toElement"]=oEvt.currentTarget;
	return oEvt;
}
function ur_EVT_addParam(oEvt,sParName, sParValue)
{
	if(oEvt.ur_param)
	{
		var oTemp = oEvt.ur_param;
		oTemp[sParName] = sParValue;
		oEvt.ur_param = oTemp;  
	}
	else
	{
		var oTemp = new Array();
		oTemp[sParName] = sParValue;
		oEvt.ur_param = oTemp;  
	}
}
//** KeyBoard.ie5 **

ur_KY={RETURN:13,TAB:9,SPACE:32,DOWN:40,UP:38,PREV:ur_system.direction=="rtl"?39:37,NEXT:ur_system.direction=="rtl"?37:39,PGUP:33,PGDOWN:34,END:35,HOME:36}
function ur_KY_nav(oEvt,o,resetId) {
  
  var sMode=o.ref.getAttribute("kb"); 
	if (!sMode) return false;
	
	
	if (!o.items) o.items=o.ref.childNodes 
	
	
	var iKc=oEvt.keyCode 
	
	
	if (iKc<ur_KY.PGUP||iKc>ur_KY.DOWN) return false; 
	
	
	var iFOIdx=parseInt(ur_getAttD(o.ref,"fidx","0")); 
	
	var iFNIdx=iFOIdx;
	if (iKc==ur_KY.PGUP   || iKc==ur_KY.HOME) iFNIdx=0;
	else if (iKc==ur_KY.PGDOWN || iKc==ur_KY.END) iFNIdx=o.items.length-1;
	else if (((iKc==ur_KY.PREV && sMode.indexOf("h")>-1) || (iKc==ur_KY.UP && sMode.indexOf("v")>-1)) && iFOIdx>0) iFNIdx--;
	else if (((iKc==ur_KY.NEXT && sMode.indexOf("h")>-1) || (iKc==ur_KY.DOWN && sMode.indexOf("v")>-1)) && iFOIdx<o.items.length-1) iFNIdx++;
	
	if (iFNIdx!=iFOIdx) { 
	  
      var oItm=o.items[iFOIdx];
	  if(!(ur_system.is508) && ur_isSt(o.items[iFNIdx],ur_st.DISABLED)) return false; 
	  else
	  {   
		  
		  sapUrMapi_setTabIndex(oItm,-1); 
		  var oItm=o.items[iFNIdx];
		  
	      o.ref.setAttribute("fidx",iFNIdx);
		  
	      sapUrMapi_setTabIndex(oItm,0);
		  
	      sapUrMapi_focusElement(oItm);
	      if (resetId) {
	    	var oReset = ur_get(resetId);
	      	oItm.setAttribute("resetId",resetId);
	      	if (oItm.attachEvent) {
	      		oItm.attachEvent("onblur",ur_KY_nav_blur);
	      	} else {
	      		oItm.addEventListener("blur",ur_KY_nav_blur,true);
	      	}
	      } 
	  }
	}
	return true;
}
function ur_KY_nav_blur(oEvt) {
	var oItm = ur_EVT_src(oEvt);
	if (oItm) {
	    sapUrMapi_setTabIndex(oItm,-1);
		var sResetId = oItm.getAttribute("resetId");
		var oReset = ur_get(sResetId);
		if (oReset) {
			setTimeout("ur_KY_reset('" + sResetId + "')",10);
		}      
	    if (oItm.detachEvent) {
	    	oItm.detachEvent("onblur",ur_KY_nav_blur);
	    } else {
	    	oItm.removeEventListener("blur",ur_KY_nav_blur,true);
	    }
	} 
}
function ur_KY_reset(resetId) {
	var oReset = ur_get(resetId);
	var oActiveElement = document.activeElement; 
	if (!oActiveElement || !sapUrMapi_DOM_bContains(oReset,oActiveElement)) {
		sapUrMapi_setTabIndex(oReset,0);
	}
}

//** Button.ie5 **

function ur_Button_keypress(e) { 
	var o=ur_EVT_src(e);
	o=sapUrMapi_getRootControl(o);
	if (sapUrMapi_getControlTypeFromObject(o)!="B") return;
	if (ur_Button_isDsbl(o)) return;
	if ((o.getAttribute("tp")=="MNUSEC" || o.getAttribute("tp")=="MNU") && e.altKey && e.keyCode==40 || e.keyCode==115 ) {
		sapUrMapi_Button_openMenu(o.id,e);
		return ur_EVT_cancel(e);
	}
	if (e.keyCode==32) {
		ur_EVT_cancel(e);
		if (o.getAttribute("tp")=="MNU") {
			sapUrMapi_Button_openMenu(o.id,e);
			return ur_EVT_cancel(e);
		}
		return ur_EVT_fire(o,"ocl",e);
	}
}
function ur_Button_click(e) { 
	var o=ur_EVT_src(e);
	o=sapUrMapi_getRootControl(o);
	if (sapUrMapi_getControlTypeFromObject(o)!="B") return;
	
	if (ur_Button_isDsbl(o)) return;
	if (o.getAttribute("tp")=="MNU") {
		sapUrMapi_Button_openMenu(o.id,e);
		return ur_EVT_cancel(e);
	}
	return ur_EVT_fire(o,"ocl",e);
}
function ur_Button_isDsbl(o) {
	return ur_getAttD(o,"st","").indexOf("d")>-1;
}
function ur_Button_setStatus(sId,bEnabled) {
	var o=ur_get(sId)
		bStD=ur_Button_isDsbl(o);
	if (bStD!=bEnabled) return; 
	var arrCls=o.className.split(" ");
	if (bEnabled) {
		o.setAttribute("st","");
		arrCls[0]=arrCls[0].replace("Dsbl","");
	} else {
		o.setAttribute("st","d");
		arrCls[0]=arrCls[0]+"Dsbl";
	}
	o.className=arrCls.join(" ");
}
function mf_Button_setEnabled(sId){
	ur_Button_setStatus(sId,true);
}
function mf_Button_setDisabled(sId){
	ur_Button_setStatus(sId,false);
}
function sapUrMapi_Button_openMenu( sButtonId, e){
	var o = document.getElementById(sButtonId);
	if (!o) return;
	var sPopupId = o.getAttribute("popup");
	if (!sPopupId) return;
	if (ur_system.direction=="rtl") {
 		sapUrMapi_PopupMenu_showMenu(sButtonId,sPopupId,sapPopupPositionBehavior.MENURIGHT,e);
	} else {
 		sapUrMapi_PopupMenu_showMenu(sButtonId,sPopupId,sapPopupPositionBehavior.MENULEFT,e);
	}
	e.cancelBubble=false;
	if (e.type=="contextmenu") {
		e.returnValue=false;
	} else {
		e.returnValue=true;
	}
}
function sapUrMapi_Button_setIconSrc(sId,sIconSrc){
	var o=ur_get(sId);
	if(!o) return;
	var oImg=o.getElementsByTagName("IMG")[0];
	if(!oImg) return;
	oImg.src=sIconSrc;
}
//** BreadCrumb.ie5 **

function sapUrMapi_BreadCrumb_keydown(sId,oEvt){
	var o=ur_get(sId);
	var oCur=ur_EVT_src(oEvt);
	var oNext=null;
	var _ur_K_Next=ur_system.direction=="rtl"?37:39;
	var _ur_K_Prev=ur_system.direction=="rtl"?39:37;	
	
	
	if(oEvt.keyCode==_ur_K_Next || oEvt.keyCode==_ur_K_Prev){
		if(oEvt.keyCode==_ur_K_Next && oCur.nextSibling!=null){
			oNext=oCur.nextSibling;
			if(oNext.className.indexOf("urBrcDiv")>=0)
				oNext=oNext.nextSibling;
			
		}
		else if(oEvt.keyCode==_ur_K_Prev && oCur.previousSibling!=null){	
			oNext=oCur.previousSibling;	
			if(oNext.className.indexOf("urBrcDiv")>=0)
				oNext=oNext.previousSibling;	
		}
		o.setAttribute("nav","true");		
		if(oNext){
			sapUrMapi_setTabIndex(oNext,0);
			sapUrMapi_setTabIndex(oCur,-1);
			sapUrMapi_focusElement(oNext);
			if (oNext.attachEvent) {
				oNext.attachEvent("onblur",sapUrMapi_BreadCrumb_deactivate);
				oCur.detachEvent("onblur",sapUrMapi_BreadCrumb_deactivate);
			} else {
				oNext.addEventListener("blur",sapUrMapi_BreadCrumb_deactivate,true);
				oCur.removeEventListener("onblur",sapUrMapi_BreadCrumb_deactivate,true);
			}
		}
		ur_EVT_cancel(oEvt);
	} else if(oEvt.keyCode==32 && oCur.onclick!=null){
		 
		 oCur.click();
		 ur_EVT_cancel(oEvt);
	} else if(oEvt.keyCode==13){
		ur_EVT_cancel(oEvt);
	} else if(oEvt.keyCode==9){
		o.setAttribute("nav","false");	
		setTimeout("sapUrMapi_BreadCrumb_reset('"+sId+"')",10);
	}	
	
	
}
function sapUrMapi_BreadCrumb_activate(sId,oEvt) {
	
	var o=ur_get(sId);
	var oSel=o.lastChild;
	sapUrMapi_setTabIndex(oSel,0);
	sapUrMapi_focusElement(oSel);
	o.onblur=null;
	sapUrMapi_setTabIndex(o,-1);
	if (oSel.attachEvent) {
		oSel.attachEvent("onblur",sapUrMapi_BreadCrumb_deactivate);
	} else {
		oSel.addEventListener("blur",sapUrMapi_BreadCrumb_deactivate,true);
	}
}
function sapUrMapi_BreadCrumb_deactivate(oEvt){
	
	var oSrc = ur_EVT_src(oEvt);
	var sId = oSrc.id;
	if (!sId) sId=oSrc.parentNode.id;
	setTimeout("sapUrMapi_BreadCrumb_reset('"+sId+"')",10);
}
function sapUrMapi_BreadCrumb_reset(sId) {
	var o = ur_get(sId);
	if (o.getAttribute("nav") == "true") return;  
	sapUrMapi_setTabIndex(o,0);
	var cn = o.childNodes;
	for  (var i=0; i<cn.length;i++) {
		var oCur = cn[i];
		if (oCur.nodeType == 1 && oCur.getAttribute("ti") == "0" ) {
			if (oCur.attachEvent) {
				oCur.detachEvent("onblur",sapUrMapi_BreadCrumb_deactivate);
			} else {
				oCur.removeEventListener("blur",sapUrMapi_BreadCrumb_deactivate,true);
			}
			sapUrMapi_setTabIndex(oCur,-1);
			return;
		}
	}
}

//** CheckBox.ie5 **

function sapUrMapi_CheckBox_toggle(sId,e) {
	var oIn = ur_get(sId),
		oRoot = ur_get(sId + "-r");
	if ( ur_isSt(oRoot,ur_st.READONLY) || ur_isSt(oRoot,ur_st.DISABLED) ) return false;  
	var oLbl=ur_get(sId+"-lbl"),
		oImg=ur_get(sId+"-img");
	var newClass = "";
	
	if (ur_isSt(oRoot,ur_st.SELECTED)){
		oIn.checked=false;
		ur_setSt(oRoot,ur_st.SELECTED,false);
		ur_setSt(oRoot,ur_st.NOTSELECTED,true);
		oImg.className=oImg.className.replace("On","Off");
	} else { 
		oIn.checked = true;
		ur_setSt(oRoot,ur_st.NOTSELECTED,false);
		ur_setSt(oRoot,ur_st.SELECTED,true);
		oImg.className=oImg.className.replace("Off","On");
	}
	
	
	newClass=oImg.className;
	oImg.className="";
	oImg.className=newClass;
	
	if (ur_system.is508) oIn.fireEvent("onactivate");
	return true;
}
function sapUrMapi_CheckBox_setDisabled(sId) {
	var oIn=ur_get(sId),
		oRoot = ur_get(sId + "-r"),
		oLbl=ur_get(sId+"-lbl"),
		oImg=ur_get(sId+"-img"),
		sClass = "",
		newClass = "";
	if (ur_isSt(oRoot,ur_st.DISABLED)) return;
	if (ur_isSt(oRoot,ur_st.INVALID)){
		sClass = "Inv";
	}
	oLbl.className=oLbl.className.replace("Lbl" + sClass,"LblDsbl");
	if (ur_isSt(oRoot,ur_st.READONLY)){
		sClass += "Ro";
	}
	if (ur_isSt(oRoot,ur_st.SELECTED))
		oImg.className=oImg.className.replace("On" + sClass,"OnDsbl");
	else if(ur_isSt(oRoot,ur_st.UNDEFINED))
		oImg.className=oImg.className.replace("Ind" + sClass,"IndDsbl");
	else
		oImg.className=oImg.className.replace("Off" + sClass ,"OffDsbl");	
	
	
	newClass=oImg.className;
	oImg.className="";
	oImg.className=newClass;	
	
	if (ur_system.is508) {
		sapUrMapi_setTabIndex(oRoot,"0");
	} else {
		sapUrMapi_setTabIndex(oRoot,"-1");
	}
	oIn.disabled=true;	
	ur_setSt(oRoot,ur_st.DISABLED,true);
	if (ur_isSt(oRoot,ur_st.INVALID)) {
		sapUrMapi_Label_setInvalid(sapUrMapi_Label_getInputLabel(sId),false);
		sapUrMapi_Label_setDisabled(sapUrMapi_Label_getInputLabel(sId));
	} else {
		sapUrMapi_Label_setDisabled(sapUrMapi_Label_getInputLabel(sId));
	}		
}
function sapUrMapi_CheckBox_setEnabled(sId) {
	var oIn=ur_get(sId),
		oRoot = ur_get(sId + "-r"),
		oLbl=ur_get(sId + "-lbl"),
		oImg=ur_get(sId + "-img");
	var newClass = "";
	oLbl.className=oLbl.className.replace("Dsbl","");
	oLbl.className=oLbl.className.replace("Ro","");
	oLbl.className=oLbl.className.replace("Inv","");
	oImg.className=oImg.className.replace("Dsbl","");
	oImg.className=oImg.className.replace("Ro","");
	oImg.className=oImg.className.replace("Inv","");
	
	
	newClass=oImg.className;
	oImg.className="";
	oImg.className=newClass;
	
	oIn.disabled=false;
	ur_setSt(oRoot,ur_st.DISABLED,false);
	ur_setSt(oRoot,ur_st.READONLY,false);
	ur_setSt(oRoot,ur_st.INVALID,false);
	sapUrMapi_setTabIndex(oRoot,"0");
	sapUrMapi_Label_setInvalid(sapUrMapi_Label_getInputLabel(sId),false);
	sapUrMapi_Label_setEnabled(sapUrMapi_Label_getInputLabel(sId));
}
function sapUrMapi_CheckBox_setReadonly(sId,bSet){
	var oIn=ur_get(sId),
		oRoot = ur_get(sId + "-r"),
		oLbl=ur_get(sId+"-lbl"),
		oImg=ur_get(sId+"-img"),
		sClass="",
		newClass = "";
	if (bSet){
		if (ur_isSt(oRoot,ur_st.READONLY)) return;
		if (ur_isSt(oRoot,ur_st.DISABLED)){
			return;
		}
		if (ur_isSt(oRoot,ur_st.INVALID)){
			sClass = "Inv";
		}
		if (ur_isSt(oRoot,ur_st.SELECTED))
			oImg.className=oImg.className.replace("On" +sClass,"On" + sClass +"Ro");
		else if (ur_isSt(oRoot,ur_st.UNDEFINED))
			oImg.className=oImg.className.replace("Ind"+sClass,"Ind" + sClass +"Ro");			
		else
			oImg.className=oImg.className.replace("Off"+sClass,"Off" + sClass +"Ro");	
			
		
		newClass=oImg.className;
		oImg.className="";
		oImg.className=newClass;
			
		oIn.disabled=true;	
		ur_setSt(oRoot,ur_st.READONLY,true);
		if (ur_system.is508) {
			sapUrMapi_setTabIndex(oRoot,"0");
		} else {
			sapUrMapi_setTabIndex(oRoot,"-1");
		}
		
	} else {
		if (!ur_isSt(oRoot,ur_st.DISABLED)) {
			if (ur_isSt(oRoot,ur_st.INVALID)){
				sapUrMapi_CheckBox_setEnabled(sId);
				sapUrMapi_CheckBox_setInvalid(sId);
			} else {
				sapUrMapi_CheckBox_setEnabled(sId);
			}
	
		}
		ur_setSt(oRoot,ur_st.READONLY,false);
	}
}
function sapUrMapi_CheckBox_setInvalid(sId) {
	var oIn=ur_get(sId),
		oRoot = ur_get(sId + "-r"),
		oLbl=ur_get(sId+"-lbl");
		oImg=ur_get(sId+"-img");
		var newClass = "";
	if (ur_isSt(oRoot,ur_st.INVALID) || ur_isSt(oRoot,ur_st.DISABLED)) return;
	oLbl.className=oLbl.className.replace("Lbl","LblInv");
	oImg.className=oImg.className.replace("Off","OffInv");
	oImg.className=oImg.className.replace("On","OnInv");
	oImg.className=oImg.className.replace("Ind","IndInv");
	
	
	newClass=oImg.className;
	oImg.className="";
	oImg.className=newClass;
	
	ur_setSt(oRoot,ur_st.INVALID,true);
	sapUrMapi_Label_setInvalid(sapUrMapi_Label_getInputLabel(sId),true);
}
function sapUrMapi_CheckBox_focus(sId,oEvt) {
	sapUrMapi_DataTip_show(sId,"focus");
}
function sapUrMapi_CheckBox_blur(sId,oEvt) {
	sapUrMapi_DataTip_hide(sId);
}
function sapUrMapi_CheckBox_keydown(sId,oEvt) {
	if(oEvt.keyCode==73 && oEvt.shiftKey && sapUrMapi_bCtrl(oEvt) ){
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
		return ur_EVT_cancel(oEvt);
	}
	
	else if(oEvt.keyCode==27){
		sapUrMapi_DataTip_hide(sId);
		return ur_EVT_cancel(oEvt);
	}
	
	else if(oEvt.keyCode==32 && !oEvt.altKey && !sapUrMapi_bCtrl(oEvt) ){
		var o=ur_EVT_src(oEvt);
		if(o) {
			o.click();
			ur_EVT_cancel(oEvt);
		}
	}
}
//** ComboBox.nn6 **

function ur_ComboBox_fireBeforeListLoad(sId,sListId,oEvt){
	var o=sapUrMapi_ComboBox_getObject(sId);
  var sFunc=o.main.getAttribute("onbll");	
  if(sFunc && sFunc.indexOf("UR_NotHandled")<0){
		o.main.fBefListLoad = new Function("event",sFunc);
		o.main.fBefListLoad(oEvt);
  }
  else return false;
  return true;
}
function sapUrMapi_ComboBox_getObject(sId) {
	var o=new Object();
	var sLblFor="";
	o.main=ur_get(sId+"-r");
	o.txt=ur_get(sId);
	o.isdd=o.txt.getAttribute("tp")=="DD";
	o.isro=ur_isSt(sId,ur_st.READONLY);
	o.isdsbl=ur_isSt(sId,ur_st.DISABLED);
	o.isinv=ur_isSt(sId,ur_st.INVALID);
	o.isreq=ur_isSt(sId,ur_st.REQUIRED);	
	o.key=o.txt.getAttribute("k");
	o.vt=o.txt.getAttribute("vt")=="true";
	o.lid=o.txt.getAttribute("lid");
	o.open=o.txt.getAttribute("op")=="true";
	sLblFor=o.txt.getAttribute("f");
	if(sLblFor!=null && sLblFor!="")
		o.lblFor=ur_get(sLblFor);
	else
		o.lblFor=null;
	return o;
}
function sapUrMapi_ComboBox_registerCreate(sId,sListId,sWidth){
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_ComboBox_setWidth('"+sId+"','"+sListId+"','"+sWidth+"')");
}
var aCoB=new Array();
var aCoBWidth=new Array();
function sapUrMapi_ComboBox_setWidth(sId,sListId,sWidth){
	if(sWidth!="") return;
	var o=ur_get(sId);
	var oL=ur_get(sListId+"-r");
	if(oL==null) return;
	sapUrMapi_ItemListBox_setDim( sListId, "10px" );
	aCoB[aCoB.length]=o;
	oL=ur_get(sListId);
	aCoBWidth[aCoBWidth.length]=oL.firstChild.offsetWidth;
	sapUrMapi_Create_AddItem("CoB", "sapUrMapi_ComboBox_set()",true);
}
function sapUrMapi_ComboBox_set(){
	for(var i=0; i<aCoB.length; i++)
		if(aCoB[i]!=null && typeof(aCoB[i])=="object")
		aCoB[i].style.width=parseInt(aCoBWidth[i]);
}
function sapUrMapi_ComboBox_addClass(sId,sClass,bSetIt) {
  var o=sapUrMapi_ComboBox_getObject(sId);
  var bInTbl=o.main.parentNode.className.indexOf("STTD")>=0;
  
	if (o.txt.className.indexOf(sClass)==-1 && bSetIt){
		o.txt.className=o.txt.className+" "+sClass; 
		if(bInTbl) o.main.className=o.main.className+" "+sClass;
	}
	else if(o.txt.className.indexOf(sClass)>=0 && !bSetIt){
		o.txt.className=o.txt.className.replace(" "+sClass,"");
		if(bInTbl) o.main.className=o.main.className.replace(" "+sClass,"");
	}
	return o;
}
function sapUrMapi_ComboBox_mousedown(sId,e) {
	var o=sapUrMapi_ComboBox_getObject(sId);
	if(e.button!=0 && o.open) return;
  o.txt.setAttribute("noblur","true");
}
function sapUrMapi_ComboBox_click(sId,e) {
	var o=sapUrMapi_ComboBox_getObject(sId);
	if (o.isdsbl) return;
	if (o.isdd || e.type=="keydown" || ur_EVT_src(e).className.indexOf("urCoB2Btn")>=0) {
	  if (!o.open) 
			sapUrMapi_ComboBox_showList(sId,e);
		else{
			sapUrMapi_ComboBox_hideList(sId);
			if(o.isdd) sapUrMapi_ComboBox_addClass(sId,"urCoB2Hv",true);			
		}
		if(ur_EVT_src(e).className.indexOf("urCoB2Btn")>=0) 
			ur_focus(o.txt);
  }
  o.txt.setAttribute("noblur","false");
  return ur_EVT_cancel(e);
}
function sapUrMapi_ComboBox_focusDdlb(sId,e) { 
	var o=sapUrMapi_ComboBox_getObject(sId);
	if (!o.open) sapUrMapi_DataTip_show(sId,"focus");
	if (o.isdsbl) return;
	o.txt.setAttribute("noblur","false");
	if(!o.isdd) return;
	if (o.open) sapUrMapi_ComboBox_addClass(sId,"urCoB2Hv",false);
	else sapUrMapi_ComboBox_addClass(sId,"urCoB2Hv",true);
	ur_setEditCellColor(o.txt);
	return ur_EVT_cancel(e);
}
var oComboBoxSCTimer=null;
var oComboBoxSCEvent=null;
function sapUrMapi_ComboBox_prepareFireSelectionChange(o, oEvt){
	
  if(o.txt.getAttribute("ks")==o.txt.getAttribute("k") && o.txt.getAttribute("vs")==o.txt.value) 
		return;
  
  
   if((oEvt.type=="keydown" || oEvt.type=="keypress") && o.open && oEvt.keyCode!=13) 
		return;
		
	
	oComboBoxSCEvent = oEvt;
	
	
	if(oComboBoxSCTimer) clearTimeout(oComboBoxSCTimer);  
  if(oEvt.type=="blur" || oEvt.type=="click" || oEvt.keyCode==13) { 
		sapUrMapiComboBox_fireSelectionChange(o, oEvt);
	}
	
	else{	
			var sId=o.txt.id;
    	oComboBoxSCTimer=setTimeout("sapUrMapiComboBox_fireSelectionChange(\""+sId+"\")",500);  	                 
    }
}
function sapUrMapiComboBox_fireSelectionChange(o, oEvt){
	
	if(typeof(o)=="string"){
		o=sapUrMapi_ComboBox_getObject(o);
	}
	
	if(o.lblFor!=null){
		o.lblFor.setAttribute("lbl",o.txt.value);	
  }
  
  
  o.txt.setAttribute("vs",o.txt.value);
  o.txt.setAttribute("ks",o.txt.getAttribute("k"));
    
  
  var sFunc=o.main.getAttribute("onsc");
  if(sFunc){
		o.main.fSelCh = new Function("event",sFunc);
		o.main.fSelCh(oComboBoxSCEvent);
  }
}
function sapUrMapi_ComboBox_blurDdlb(sId,e) { 
	var o=sapUrMapi_ComboBox_getObject(sId);
	ur_removeEditCellColor();
	
	if (o.isdsbl) {sapUrMapi_DataTip_hide(sId);return;}
	if(o.txt.getAttribute("noblur")=="true" || (oPopup!=null && oPopup.frame.window.mover && o.open)){
		o.txt.setAttribute("noblur","false");
		ur_focus(o.txt);
		return ur_EVT_cancel(e);
	}
	
	if (o.isdd) sapUrMapi_ComboBox_addClass(sId,"urCoB2Hv",false);
	if (oPopup!=null && o.open) sapUrMapi_ComboBox_hideList(sId);
	if (oPopup!=null && !o.open) sapUrMapi_DataTip_hide(sId);
	sapUrMapi_ComboBox_prepareFireSelectionChange(o,e);
	return ur_EVT_cancel(e);
}
function sapUrMapi_ComboBox_setReadonly(sId,bReadonly) {
  var o=ur_get(sId);
  if(bReadonly && ur_isSt(o,ur_st.READONLY)) return;
  ur_setSt(o,ur_st.READONLY,bReadonly);
  if(bReadonly)
		o.className+=" urCoB2Ro";
	else
		o.className=o.className.replace(" urCoB2Ro","");
  o.readOnly=bReadonly;
}
function sapUrMapi_ComboBox_setDisabled(sId,bSet) {
  var o=ur_get(sId);
  var oBtn=o.nextSibling;
  if(bSet && ur_isSt(o,ur_st.DISABLED)) return;
  ur_setSt(o,ur_st.DISABLED,bSet);
  if(bSet){
		o.className+=" urCoB2Dsbl";
		oBtn.className="urCoB2BtnDsbl";
	}
	else{
		o.className=o.className.replace(" urCoB2Dsbl","");
		oBtn.className="urCoB2Btn";
	}
  o.readOnly=bSet;
}
function sapUrMapi_ComboBox_setInvalid(sId,bInvalid) {
  var o=ur_get(sId);
  if(bInvalid && ur_isSt(o,ur_st.INVALID)) return;
  ur_setSt(o,ur_st.INVALID,bInvalid);
  if(bInvalid)
		o.className+=" urCoB2Inv";
	else
		o.className=o.className.replace(" urCoB2Inv","");
}
var sUrComboBox_virtualTyping="";
function sapUrMapi_ComboBox_keydown(sId,e) {
	var o=sapUrMapi_ComboBox_getObject(sId);
	
	if (o.isdsbl) return;
	
	
	if (e.keyCode==9) {
		if(o.open) sapUrMapi_ItemListBox_selectHoveredItem(o.lid, oPopup.frame.window.document,e);
		if (o.isdd) sapUrMapi_ComboBox_addClass(sId,"urCoB2Hv",false);
		if (oPopup!=null && o.open) sapUrMapi_ComboBox_hideList(sId);
		return;
	}
	
	
	if( (e.altKey && (e.keyCode==40||e.keyCode==38)) || e.keyCode==115 ){
		sapUrMapi_ComboBox_click(sId,e);
		return ur_EVT_cancel(e);
	}
	
	
	if(e.keyCode==40 || e.keyCode==38 || e.keyCode==33 || e.keyCode==34 || e.keyCode==35 || e.keyCode==36){
		if(o.open) sapUrMapi_ItemListBox_keydown(o.lid, oPopup.frame.window.document, e );
		else{
			
			if(ur_ComboBox_fireBeforeListLoad(sId,o.lid,e))
				return ur_EVT_cancel(e);
			sapUrMapi_ItemListBox_setParentId(o.lid, sId);
			sapUrMapi_ItemListBox_setSelectedKey(o.lid,o.key,document,false);
			sapUrMapi_ItemListBox_keydown(o.lid, document, e );
		}		
		return ur_EVT_cancel(e);
	}
	
	
  if (e.keyCode==27 && o.open) { 
		o.txt.value=o.txt.getAttribute("vs");
		o.txt.setAttribute("k",o.txt.getAttribute("ks"));
  	sapUrMapi_ComboBox_hideList(sId);
  	sapUrMapi_ComboBox_focusDdlb(sId,e);
  	return ur_EVT_cancel(e);
  }
  else if (e.keyCode==27 && !o.open) {
		sapUrMapi_DataTip_hide(sId);
  }
  else if( (e.keyCode==73) && e.shiftKey && sapUrMapi_bCtrl(e)  && !e.altKey ){
  		if (o.open) {
  			o.txt.value=o.txt.getAttribute("vs");
			o.txt.setAttribute("k",o.txt.getAttribute("ks"));
  			sapUrMapi_ComboBox_hideList(sId);
  			sapUrMapi_ComboBox_focusDdlb(sId,e);
  		} 
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
		return ur_EVT_cancel(e);
	}
	if(e.which == 27){
		sapUrMapi_DataTip_hide(sId);
		return ur_EVT_cancel(e);
	}  
  
  if (e.keyCode==13 && o.open) { 
		sapUrMapi_ItemListBox_selectHoveredItem(o.lid, oPopup.frame.window.document,e);
  	sapUrMapi_ComboBox_hideList(sId);
  	o.open=false;
  	return ur_EVT_cancel(e);
  }
  else if (e.keyCode==13 && !o.isdd){
    	if(!sapUrMapi_ComboBox_findItem(sId,o.txt.value,true,e))
    		sapUrMapi_ComboBox_prepareFireSelectionChange(o, e);
  }  
  
  	if ((e.keyCode>64 && e.keyCode<126)||(e.keyCode>127 && e.keyCode<192)) {
		if (o.isdd){
	  	if (o.vt) sapUrMapi_ComboBox_initVirtualTyping();
	  	var sSearch=String.fromCharCode(e.keyCode);
	  	if (!o.vt) sUrComboBox_virtualTyping=sSearch;
			else sUrComboBox_virtualTyping+=sSearch;
	  	sapUrMapi_ComboBox_findItem(sId,sUrComboBox_virtualTyping,true,e);
	  	if(o.open){
	  		o=sapUrMapi_ComboBox_getObject(sId);
	  		sapUrMapi_ItemListBox_setSelectedKey(o.lid,o.key,oPopup.frame.window.document,true);
	  	}	  	
	 	}
		else{
				o.txt.setAttribute("k","");
	  	}
		}
	}
function sapUrMapi_ComboBox_keypress(sId,e) {
}
var oVTTimer=null;
function sapUrMapi_ComboBox_initVirtualTyping() {
  if (oVTTimer!=null) clearTimeout(oVTTimer); 
 	oVTTimer=ur_callDelayed("sUrComboBox_virtualTyping='';clearTimeout(oVTTimer);oVTTimer=null;",250);
 }
function sapUrMapi_ComboBox_findItem(sId,sSearch,bSelect,oEvt) {
	var o=sapUrMapi_ComboBox_getObject(sId);
	var sKey=o.txt.getAttribute("k");
	var sNewKey = sapUrMapi_ItemListBox_findItem(o.lid,sSearch,sKey,document);
  if (bSelect && sNewKey && sNewKey != "")
		sapUrMapi_ComboBox_setValue(sId,sNewKey,sVal,null,oEvt);	
	return true;
}
function sapUrMapi_ComboBox_showList(sId,oEvt) {
	var o=sapUrMapi_ComboBox_getObject(sId);
	var oIlb;
	var arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
	
	if(ur_ComboBox_fireBeforeListLoad(sId,o.lid,oEvt))
		return ur_EVT_cancel(oEvt);
	o.open=o.txt.setAttribute("op","true");
  if (o.isdd) sapUrMapi_ComboBox_addClass(sId,"urCoB2Hv",false);
  	
	
	clearTimeout(_ur_DataTip_timer);
	
	
	sapUrMapi_ItemListBox_setParentId(o.lid, sId);	
	oIlb=sapUrMapi_ItemListBox_getObject(o.lid,document,null);
	sapUrMapi_ItemListBox_setDim(o.lid, o.main.offsetWidth);
	sapUrMapi_ItemListBox_setReadonly(oIlb,o.isro);	
	oPopup = new sapPopup(window,arrUrls,ur_get(o.lid+"-r"),ur_get(sId),oEvt,0);
	oPopup.size.height=oIlb.box.offsetHeight;
	oPopup.size.width=oIlb.box.offsetWidth;
	oPopup.sizebehaviour=sapPopupSizeBehavior.USER
	if (ur_system.direction=="rtl") oPopup.positionbehavior = sapPopupPositionBehavior.MENURIGHT;
	else sapPopupPositionBehavior.MENULEFT;	
	oPopup.show(true,true);
	if(!o.isro) sapUrMapi_ItemListBox_setSelectedKey(o.lid,o.key,oPopup.frame.window.document,true);	
}
function sapUrMapi_ComboBox_hideList(sId) {
  var o=sapUrMapi_ComboBox_getObject(sId);
	o.txt.setAttribute("op","false");
	o.txt.setAttribute("noblur","false");
	if (oPopup) oPopup.hide();
}
function sapUrMapi_ComboBox_setValue(sId,sKey,sValue,sImgSrc,oEvt) {
  var o = sapUrMapi_ComboBox_getObject(sId);
  if(!o.isro && !o.isdsbl && sKey!=null && (o.txt.ks!=sKey || o.txt.k!=sKey)){
		
			o.txt.setAttribute("k",sKey);
			o.txt.value=sValue;
			if (sImgSrc!="" && sImgSrc!=null)
  			if (sImgSrc.indexOf("url(")!=0 && sImgSrc.length>0) o.txt.style.backgroundImage="url("+sImgSrc+")";
  			else o.txt.style.backgroundImage=sImgSrc;
		
		sapUrMapi_ComboBox_prepareFireSelectionChange(o,oEvt);
  }
  
  
  if (oEvt!=null && oEvt.type=="click"){
		sapUrMapi_ComboBox_hideList(sId);
		ur_focus(o.txt);
	}
}
function sapUrMapi_ComboBox_getSelectedKey(sId) {
  var o=sapUrMapi_ComboBox_getObject(sId);
  return o.txt.getAttribute("k");
}
function sapUrMapi_ComboBox_getSelectedValue(sId) {
  var o=sapUrMapi_ComboBox_getObject(sId);
	return o.txt.value;
}

//** ContextualPanel.ie5 **

function ur_CXP_cl(sId,oEvt){
}
function ur_CXP_kd(sId,oEvt)
{
	return sapUrMapi_skip(sId,oEvt)
}
function ur_CXP_expand(sId,oEvt)
{
	ur_EVT_cancelBubble(oEvt);
	var elBody = ur_get(sId); 
	if ( elBody != null && elExp != null )
	{
		if ( elBody.style.display == "none" )
		{
			elBody.style.display = "block";
			ur_setSt(elBody,ur_st.COLLAPSED,false);
			ur_setSt(elBody,ur_st.EXPANDED,true);
		} 
		else
		{
			elBody.style.display = "none";
			ur_setSt(oSkip,ur_st.COLLAPSED,true);
			ur_setSt(oSkip,ur_st.EXPANDED,false);
		}
	}
	return true;
}
function ur_CXP_collapse(sId,oEvt)
{
}

//** DataTip.nn6 **

var _ur_DataTip_timer;
function sapUrMapi_DataTip_getText(sId) {
	var oDTText = ur_get(sId+"-dtip");
	oDTText = oDTText.firstChild.lastChild;
	return oDTText.innerHTML;
}
enumUrDataTipType = {ERROR:"Error",WARNING:"Warning",OK:"Ok",TEXT:"Text"};
function sapUrMapi_DataTip_getType(sId) { 
	var oDTTyp  = ur_get(sId+"-dtip");
	oDTTyp = oDTTyp.firstChild.firstChild;
    if ((oDTTyp.className).indexOf(enumUrDataTipType.ERROR)>-1) return enumUrDataTipType.ERROR;
    if ((oDTTyp.className).indexOf(enumUrDataTipType.WARNING)>-1) return enumUrDataTipType.WARNING;
    if ((oDTTyp.className).indexOf(enumUrDataTipType.OK)>-1) return enumUrDataTipType.OK;
    if ((oDTTyp.className).indexOf("urDataTipTxt")>-1) return enumUrDataTipType.TEXT;
  }
function sapUrMapi_DataTip_show(sId,sEvtType) {
	var bShow=false;
	oDataTip = ur_get(sId+"-dtip");
	if (oDataTip==null) return;
	var bAf=((oDataTip.getAttribute("af")!=null) && (oDataTip.getAttribute("af")=="a"));
	var bAff=((oDataTip.getAttribute("af")!=null) && (oDataTip.getAttribute("af")=="f"));
	var iTo=0;
	if ((oDataTip.getAttribute("to")!=null) && (oDataTip.getAttribute("to")!="")) {
	  iTo=parseInt(oDataTip.getAttribute("to"));
	}
	if (typeof(sEvtType)=="undefined" || sEvtType=="") {
	  bShow=true;
	}
	if (sEvtType=="keydown") {
	  bShow=true;
	  iTo=0;
	}
	if (sEvtType=="focus") {
	  if (bAf) bShow=true;
	  if ((bAff) && (oDataTip.getAttribute("first")==null || oDataTip.getAttribute("first")=="")) {
	    bShow=true;
		oDataTip.setAttribute("first","true");
	  } else {
	    if (!bAf) iTo=0;
	  }
	}
	if(sEvtType=="mousemove"){
		bShow=true;
	 	iTo=0;
	}
	if(sEvtType=="mouseleave"){
		iTo=5;
	}
	if (bShow) {
		var oDT = ur_get(sId+"-dtip");
		oDT.open = oDT.setAttribute("op", "true");
		var arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
		sTriggerId=sId;
		oTrg=ur_get(sId);
		if (oTrg.tagName=="INPUT" && (oTrg.type.toLowerCase()=="radio" || oTrg.type.toLowerCase()=="checkbox")) {
		  oTrg=oTrg.nextSibling;
		}
		oPopup = new sapPopup(window,arrUrls,ur_get(sId+'-dtip'),oTrg,null,0);
		if (ur_system.direction=="rtl") oPopup.positionbehavior = sapPopupPositionBehavior.MENURIGHT;
		else sapPopupPositionBehavior.MENULEFT;	
		oPopup.show(true,true);
	}
	if (iTo>0) {
	  _ur_DataTip_timer = ur_callDelayed("sapUrMapi_DataTip_hide(\""+sId+"\")",iTo*1000);
	}
}
function sapUrMapi_DataTip_hide(sId) {
	var oDT = ur_get(sId+"-dtip");
	
	if(oDT==null) return;
	clearTimeout(_ur_DataTip_timer);
	if (oPopup!=null) oPopup.hide();
 	oDT.setAttribute("op", "false");
}
function sapUrMapi_DataTip_isOpen(sId){
	var oDT = ur_get(sId+"-dtip");
	if(oDT!=null)
	return (oDT.getAttribute("op")=="true");
}

//** DateNavigator.ie5 **

function ur_DateNavigator_getMonthHdr(o){
  try {
	return o.firstChild.firstChild.firstChild.cells[1].firstChild;
	} catch (ex) {
	  return null;
  } 
} 
function ur_DateNavigator_getMonth(o){
	while(o.tagName!="TABLE")
		o=o.parentNode;
	return o.parentNode;  
      }
function ur_DateNavigator_focusNextMonth(o){
	var oThis=ur_DateNavigator_getMonth(o);
	var oThisHdr=ur_DateNavigator_getMonthHdr(oThis);
	if (!oThisHdr) return false;
	var oPrev=null;
	var oPrevHdr=null;
	if(oThisHdr && oThisHdr.parentNode.nextSibling && oThisHdr.parentNode.nextSibling.className.indexOf("ArrNext")>-1 && oThisHdr.parentNode.nextSibling.className.indexOf("Dsbl")==-1) { 
		oThisHdr.parentNode.nextSibling.click();
  } else{		
		oNext=oThis.nextSibling; 
		if(oNext==null&&oThis.parentNode.nextSibling!=null)	
			oNext=oThis.parentNode.nextSibling.firstChild;
		if(oNext==null) return false;
		oNextHdr=ur_DateNavigator_getMonthHdr(oNext);
		if(oNextHdr!=null)
			ur_focus(oNextHdr);
			return true;
  }
}
function ur_DateNavigator_focusUpMonth(o){
	var oThis=ur_DateNavigator_getMonth(o);
	var oPrevRow=oThis.parentNode.previousSibling;
	if(oPrevRow==null) return;
	ur_DateNavigator_getMonthHdr(oPrevRow.childNodes[oThis.cellIndex]).focus();
  }
function ur_DateNavigator_focusDownMonth(o){
	var oThis=ur_DateNavigator_getMonth(o);
	var oNextRow=oThis.parentNode.nextSibling;
	if(oNextRow==null) return;
	ur_DateNavigator_getMonthHdr(oNextRow.childNodes[oThis.cellIndex]).focus();
			    }
function ur_DateNavigator_focusPrevMonth(o){
	var oThis=ur_DateNavigator_getMonth(o);
	var oThisHdr=ur_DateNavigator_getMonthHdr(oThis);
	var oPrev=null;
	var oPrevHdr=null;
  if(oThisHdr.parentNode.previousSibling.className.indexOf("urCalArrPrev")>-1) {
		oThisHdr.parentNode.previousSibling.click();
        }
  else{		
		oPrev=oThis.previousSibling;	
		if(oPrev==null&&oThis.parentNode.previousSibling!=null)	
			oPrev=oThis.parentNode.previousSibling.lastChild;
		if(oPrev==null) return;
		oPrevHdr=ur_DateNavigator_getMonthHdr(oPrev);
		if(oPrevHdr!=null)
			oPrevHdr.focus();
      }
    }
function ur_DateNavigator_focusThisMonth(o){
	var oThis=ur_DateNavigator_getMonth(o);
	var oThisHdr=ur_DateNavigator_getMonthHdr(oThis);
	if(oThisHdr!=null)
		oThisHdr.focus();
  } 
function ur_DateNavigator_focusNextDay(o){
	var oNext=o.nextSibling;
	while(oNext!=null && ur_isSt(oNext.id,ur_st.DISABLED)) 
			oNext=oNext.nextSibling;
	if(oNext!=null && o.className.indexOf("urCalNum")==-1) oNext.setAttribute("sameWeek","true");
	if(oNext==null&&o.parentNode.nextSibling!=null)
	{
		oNext=o.parentNode.nextSibling.firstChild;
		oNext.setAttribute("sameWeek","false");
	}
	if(oNext==null) return;
	if(oNext.getAttribute("ti")=="0")
		oNext.focus();
	else
		ur_DateNavigator_focusNextDay(oNext);
   }
function ur_DateNavigator_focusPrevDay(o){
	var oPrev=o.previousSibling;
	while(oPrev!=null && ur_isSt(oPrev.id,ur_st.DISABLED)) 
			oPrev=oPrev.previousSibling;
	if(oPrev!=null && o.className.indexOf("urCalNum")==-1) oPrev.setAttribute("sameWeek","true");
	if(oPrev==null&&o.parentNode.previousSibling!=null)
	{
		oPrev=o.parentNode.previousSibling.lastChild;
		oPrev.setAttribute("sameWeek","false");
	}
	if(oPrev==null||oPrev.className.indexOf("urCalName")>=0) return;
	if(oPrev.getAttribute("ti")=="0")
		oPrev.focus();
	else
		ur_DateNavigator_focusPrevDay(oPrev);
		 }
function ur_DateNavigator_focusNextWeek(o){
	var oNext=o.parentNode.nextSibling;
	if(oNext==null) return;
	oNext=oNext.cells[o.cellIndex];
	if(oNext.getAttribute("ti")=="0")
		oNext.focus();
	else
		ur_DateNavigator_focusNextWeek(oNext);
  }
function ur_DateNavigator_focusPrevWeek(o){
	var oPrev=o.parentNode.previousSibling;
	if(oPrev==null) return;
	oPrev=oPrev.cells[o.cellIndex];
	if(oPrev.className.indexOf("urCalName")>=0) return;
	if(oPrev.getAttribute("ti")=="0")
		oPrev.focus();
	else
		ur_DateNavigator_focusPrevWeek(oPrev);
}
function sapUrMapi_DateNavigator_keydown(sId,oEvt) {
  var o=ur_evtSrc(oEvt);
  var iKey=oEvt.keyCode;
	
  if(iKey==37)
		iKey=ur_system.direction!="rtl"?37:39;
	else if(iKey==39)
		iKey=ur_system.direction!="rtl"?39:37;
		
	
	if(iKey==117)
		return sapUrMapi_skip(sId,oEvt);
	
	
	if(iKey==32){
		o.click();
    return ur_EVT_cancel(oEvt);
  }
			
		
	if(iKey==39){
		if(o.className.indexOf("Whl")>=0) return;
		if (o.parentNode.className.indexOf("urCalHdr")>-1)
			ur_DateNavigator_focusNextMonth(o);
		else
			ur_DateNavigator_focusNextDay(o);
		return ur_EVT_cancel(oEvt);
				}
	
		
	if(iKey==37){
		if(o.className.indexOf("Whl")>=0) return;
		if (o.parentNode.className.indexOf("urCalHdr")>-1)
			ur_DateNavigator_focusPrevMonth(o);
		else
			ur_DateNavigator_focusPrevDay(o);
		return ur_EVT_cancel(oEvt);
			}
	
	
	if(iKey==38){
		if(o.className.indexOf("Whl")>=0) return;
		if(o.getAttribute("tp")=="DAY")
		{
			o.setAttribute("sameWeek","false");
		}
		
		if(o.parentNode.className.indexOf("urCalHdr")>=0)
			ur_DateNavigator_focusUpMonth(o);
		else
			ur_DateNavigator_focusPrevWeek(o);
		return ur_EVT_cancel(oEvt);
				}
	
	if(iKey==40){
		if(o.className.indexOf("Whl")>=0) return;
		if(o.getAttribute("tp")=="DAY")
		{
			o.setAttribute("sameWeek","false");
		}
		if(o.parentNode.className.indexOf("urCalHdr")>=0)
			ur_DateNavigator_focusDownMonth(o);
		else		
			ur_DateNavigator_focusNextWeek(o);
		return ur_EVT_cancel(oEvt);
			}
	
	
	if(iKey==9&&o.id!=sId&&o.id!=sId+"-skipend"){
		if(o.className.indexOf("Whl")>=0||o.parentNode.className.indexOf("urCalHdr")>-1) return;
		if(oEvt.shiftKey)
			ur_DateNavigator_focusThisMonth(o);
		else{
			var oThis=ur_DateNavigator_getMonth(o);
			var oThisHdr=ur_DateNavigator_getMonthHdr(oThis);
      if (!ur_DateNavigator_focusNextMonth(oThisHdr)) {
			  if (ur_get(sId+"-skipend")) {
				ur_get(sId+"-skipend").focus();
      		return ur_EVT_cancel(oEvt);
			  } else {
			    
			    var tds = o.parentNode.parentNode.parentNode.getElementsByTagName("TD");
			    var td = tds[tds.length-1];
			    ur_focus(td);
    }
			} else {
    return ur_EVT_cancel(oEvt);
  }
    }
  }
  
	
	if(iKey==9&&oEvt.shiftKey&&o.id==sId+"-skipend"){
		o.previousSibling.firstChild.firstChild.lastChild.lastChild.firstChild.firstChild.firstChild.childNodes[1].firstChild.focus();
		return ur_EVT_cancel(oEvt);
	}	  
}
function sapUrMapi_DateNavigator_mousemove(sId,oEvt) {
 
}
function sapUrMapi_DateNavigator_activate(sId,oEvt){
	var o=ur_evtSrc(oEvt);
	var sDay=o.getAttribute("day");
	var sSep=" "+getLanguageText("SAPUR_SEPARATOR")+" ";	
	
	if(sDay!=null){
		var oRow=o.parentNode;
		var oWeekday=oRow.parentNode.rows[1].cells[o.cellIndex];
		var sDesign=o.getAttribute("ds");
		var sTt=o.getAttribute("tt");
		o.title=sDay+sSep+getLanguageText("SAPUR_CALWEEK")+" "+oRow.firstChild.innerText+sSep+oWeekday.title;
		if(sDesign!=null&&sDesign!="")
			o.title+=sSep+sDesign;
		if(sTt!=null&&sTt!="")
			o.title+=sSep+sTt;
		if(o.getAttribute("cl")=="true")
			o.title+=sSep+getLanguageText("SAPUR_CALSEL_TUTOR");
	}
	
	else if (o.parentNode!=null&&o.parentNode.className.indexOf("urCalHdr")>-1){
		o.title=o.innerText;
		var iIdx=o.getAttribute("idx");
		if(iIdx=="f"){
			o.title+=sSep+getLanguageText("SAPUR_CALFIRSTMONTH");
			if(ur_get(sId).getAttribute("nav")=="true")
				o.title+=sSep+getLanguageText("SAPUR_CALPREVMONTH_TUTOR");
			if(o.getAttribute("cl")=="true")
				o.title+=" "+getLanguageText("SAPUR_CALSEL_TUTOR");													
		}
		else if(iIdx=="l"){
			o.title+=sSep+getLanguageText("SAPUR_CALLASTMONTH");
			if(ur_get(sId).getAttribute("nav")=="true")
				o.title+=sSep+getLanguageText("SAPUR_CALNEXTMONTH_TUTOR");
			if(o.getAttribute("cl")=="true")
				o.title+=" "+getLanguageText("SAPUR_CALSEL_TUTOR");						
}
		else if(o.getAttribute("cl")=="true")
			o.title+=sSep+getLanguageText("SAPUR_CALSEL_TUTOR");
	}
}
function sapUrMapi_DateNavigator_getDateFromId(sId){}

//** DefaultButton.ie5 **
function sapUrMapi_DBTN_RegisterCreate() {
	sapUrMapi_Create_AddItem("ur_dbtn", "sapUrMapi_DBTN_addDBtn()");
}
function sapUrMapi_DBTN_addDBtn()
{
  if (!ur_get("ur-topdefault")) {
		var oDefaultTop=document.createElement("DIV");
		var oDefaultBottom=document.createElement("DIV");
		var oDefaultLeft=document.createElement("DIV");
		var oDefaultRight=document.createElement("DIV");
		oDefaultTop.setAttribute("id","ur-topdefault");
		oDefaultBottom.setAttribute("id","ur-bottomdefault");
		oDefaultLeft.setAttribute("id","ur-leftdefault");
		oDefaultRight.setAttribute("id","ur-rightdefault");
		document.getElementsByTagName("BODY")[0].appendChild(oDefaultTop);
		document.getElementsByTagName("BODY")[0].appendChild(oDefaultBottom);
		document.getElementsByTagName("BODY")[0].appendChild(oDefaultLeft);
		document.getElementsByTagName("BODY")[0].appendChild(oDefaultRight);
  }
  sapUrMapi_Resize_AddItem("ur-DBtn-rect", "sapUrMapi_DBTN_showDBtn()");
}
function sapUrMapi_DBTN_showDBtn() 
{ 
	var dbId=null;
	try {
		var oNewActive=document.activeElement;
	}
	catch (ex) { 
		return; 
	}
	if( oNewActive != null)
	{
		while(dbId==null && oNewActive.tagName != null && oNewActive.tagName!="BODY") 
		{
		  dbId=oNewActive.getAttribute("dbId");
		  oNewActive=oNewActive.parentNode;
		}
	}
	
	if(dbId!=null && ur_get(dbId).parentNode!=null)
	{
		
		var currentFocusId = sapUrMapi_Focus_getCurrentId();
		var currentFocus = ur_get(currentFocusId);
		var sCt=sapUrMapi_getControlTypeFromObject(currentFocus);
		switch (sCt) 
		{
			case "B":
			case "TB":
			case "LN":
			case "TGL":
			case "TE":
				    sapUrMapi_DBTN_hideDBtn(); 
				break;
			case "TY":
				var sTp = currentFocus.getAttribute("tp");
			    if (sTp != null)
			    {
					if(sTp=="BTN" || sTp=="MNU")
					sapUrMapi_DBTN_hideDBtn(); 
			    }
				else
			    {
					sapUrMapi_DBTN_showDBtnRect(dbId,oNewActive);
				}
				break;
			case "T":
				var sTp = currentFocus.getAttribute("tp");
			    if (sTp != null)
			    {
					if(sTp=="BTN")
					sapUrMapi_DBTN_hideDBtn(); 
			    }
				else
				{
					sapUrMapi_DBTN_showDBtnRect(dbId,oNewActive);
				}
				break;
			case "I":
			case "TI":
				if(currentFocus.onkeypress!=null)
					sapUrMapi_DBTN_hideDBtn(); 
				else
					sapUrMapi_DBTN_showDBtnRect(dbId,oNewActive);
				break;
			
			default :
				sapUrMapi_DBTN_showDBtnRect(dbId,oNewActive);
				
		}
	}
	else 
	{
		sapUrMapi_DBTN_hideDBtn();
	}
	
}
function sapUrMapi_DBTN_showDBtnRect(dbId,oNewActive)
{
	oNewActive=ur_get(dbId);  
	var activeoffsetonscreen; 
	if(ur_get("ur-topdefault")!=null && ur_get("ur-bottomdefault")!=null && ur_get("ur-leftdefault")!=null && ur_get("ur-rightdefault")!=null)
		activeoffsetonscreen = sapUrMapi_DBTN_getOffset(oNewActive);
	else
		return false;
	var oC={top:ur_get("ur-topdefault"),bottom:ur_get("ur-bottomdefault"),left:ur_get("ur-leftdefault"),right:ur_get("ur-rightdefault")};
	var oDefBtn;	
	if (oNewActive.offsetWidth>0)
	{
		oDefBtn=sapUrMapi_DBTN_calcRect(oNewActive,activeoffsetonscreen,oC.left,oC.right,oC.top,oC.bottom);
		if (oDefBtn==null) return;
		oCC={x1:"top",x2:"bottom",x3:"left",x4:"right"};
		for (xx in oCC) 
		{
			if (xx.charAt(0) == "_") {continue;}
			oC[oCC[xx]].style.top=oDefBtn[oCC[xx]].top;
			oC[oCC[xx]].style.left=oDefBtn[oCC[xx]].left;
		   if (oCC[xx]=="top" || oCC[xx]=="bottom") 
			oC[oCC[xx]].style.width=oDefBtn[oCC[xx]].width;
			if (oCC[xx]=="left" || oCC[xx]=="right") 
			oC[oCC[xx]].style.height=oDefBtn[oCC[xx]].height;
		}
	}
    var top = ur_get("ur-topdefault");
	top.style.borderTop="solid DarkSlateGray 1px";
	top.style.height="1px";
	top.style.position="absolute";
	top.style.zIndex="1000";
    var right = ur_get("ur-rightdefault");
	right.style.borderRight="solid DarkSlateGray 1px";
	right.style.height="1px";
	right.style.width="1px";
	right.style.position="absolute";
	right.style.zIndex="1000";
    var bottom = ur_get("ur-bottomdefault");
	bottom.style.borderTop="solid DarkSlateGray 1px";
	bottom.style.height="1px";
	bottom.style.position="absolute";
	bottom.style.zIndex="1000";
    var left = ur_get("ur-leftdefault");
	left.style.borderLeft="solid DarkSlateGray 1px";
	left.style.height="1px";
	left.style.width="1px";
	left.style.position="absolute";
	left.style.zIndex="1000";
}
function sapUrMapi_DBTN_hideDBtn()
{
	sapUrMapi_Focus_DeflBtn_hideFocusRect(true);
 }
function sapUrMapi_DBTN_calcRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom) {    
	var obj=sapUrMapi_Focus_DflBtn_calcFocusRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom,true);
	return obj;
}
function sapUrMapi_DBTN_getOffset(object)
{	
	var pos=sapUrMapi_Focus_DflBtn_getFocusOffset(object,true);
	return pos;
}
function sapUr_DBTN_createFrame(sId) {
	var oButton = ur_get(sId),
		iWidth = oButton.offsetWidth,
		iHeight = oButton.offsetHeight,
		
		openingSPAN = "<SPAN ",
		closingTAG = ">",
		closingSPAN = "</SPAN>",
		
		sBorderColor = oButton.currentStyle.borderColor,
		sFontSize = oButton.currentStyle.fontSize,
		sDirection = (ur_system.direction == "rtl") ? "right" : "left",
		
	oFrame = openingSPAN + "style=\"border:2px solid " + sBorderColor + ";";
	oFrame += "width:" + iWidth + ";";
	oFrame += "margin-" + sDirection + ":-" + iWidth + ";";
	oFrame += "height:" + 10 + ";";
	oFrame += "font-size:" + 10 + "px;";
	oFrame += "margin-bottom:-4px;\"" ;
	
	oFrame += " id=\"ur-DbtnBrd\"";
	oFrame += closingTAG;
	oFrame += "&nbsp;";
	oFrame += closingSPAN;
	
	oButton.insertAdjacentHTML("afterEnd", oFrame);
}
function sapUr_DBTN_removeFrame() {
	var oFrame = ur_get("ur-DbtnBrd");
	
	if (oFrame == null) return;
	
	var oPrevious = oFrame.previousSibling;
	oFrame.removeNode();
	
	if (oPrevious.nextSibling.nodeType == 3) {
		oPrevious.nextSibling.removeNode();
	}
}
//** DragSource.nn6 **

var _ur_DragDrop=null;
function ur_Drag_hideCursor() {
	if (_ur_DragDrop) {
   if (_ur_DragDrop.cursor) {
     _ur_DragDrop.cursor.style.display="none";
   }
  }
}
function ur_Drag_showCursor() {
	if (_ur_DragDrop) {
   if (_ur_DragDrop.cursor) {
     _ur_DragDrop.cursor.style.display="block";
   }
  }
}
function ur_Drag_progress(e) {
  if (_ur_DragDrop && _ur_DragDrop.progress) {
    var o=ur_EVT_src(e);
    _ur_DragDrop.isddoperation=true;
    var oChildContainer=sapUrMapi_isChildOfControl(o,"DRT");
    if (oChildContainer) {
	    if (_ur_DragDrop.target!=oChildContainer) {
	      _ur_DragDrop.target=oChildContainer;
	      ur_Drag_enter(_ur_DragDrop.target.id,e);
	    } else {
	      ur_Drag_over(_ur_DragDrop.target.id,e);
	    }
	    if (_ur_DragDrop.cursor!=_ur_DragDrop.drag) {
	      ur_Drag_hideCursor();
	      _ur_DragDrop.cursor=_ur_DragDrop.drag;
	    };
	  } else {
	    if (_ur_DragDrop.target) ur_Drag_leave(_ur_DragDrop.target.id,e);
	    _ur_DragDrop.target=null;
	    if (_ur_DragDrop.cursor!=_ur_DragDrop.nodrag) {
	      ur_Drag_hideCursor();
	      _ur_DragDrop.cursor=_ur_DragDrop.nodrag;
	    };
	  }
	  var oBody=document.getElementsByTagName("BODY")[0];
	  if (e.x>oBody.offsetWidth-26 ||e.y>oBody.offsetHeight-26 || e.x<0 || e.y<0) {
	    ur_Drag_hideCursor();
	  } else {
	  	if (ur_system.direction=="rtl") {
				iHorCorr = oBody.scrollLeft-sapUrMapi_posLeftCorrectionForRTL(oBody);
			} else {
				iHorCorr = oBody.scrollLeft;
			}
			_ur_DragDrop.cursor.style.top=e.clientY+14;
			_ur_DragDrop.cursor.style.left=e.clientX+10;
	    ur_Drag_showCursor();
	  }
    ur_EVT_fire(ur_get(_ur_DragDrop.source.id),"odrag",e);
  }
}
function ur_Drag_start(sId,e){
  if (!_ur_DragDrop) {
    _ur_DragDrop={cursor:null,drag:null,nodrag:null,progress:false,isddoperation:false};
    var o=document.createElement("IMG");
    o.src=ur_system.mimepath+"dragdrop/nodrop.gif";
		o.style.position="absolute";
	  o.style.display="none";
	  o.style.zIndex="1000";
	  _ur_DragDrop.nodrag=o;
	  document.body.appendChild(_ur_DragDrop.nodrag);
    var o=document.createElement("IMG");
    o.src=ur_system.mimepath+"dragdrop/drop.gif";
		o.style.position="absolute";
	  o.style.display="none";
	  o.style.zIndex="1000";
	  _ur_DragDrop.drag=o;
	  document.body.appendChild(_ur_DragDrop.drag);
	} 
	_ur_DragDrop.progress=true;
	_ur_DragDrop.source=sapUrMapi_isChildOfControl(ur_get(sId),"DRS");
	window.addEventListener("mousemove",ur_Drag_progress,true);
	window.addEventListener("mouseup",ur_Drag_end,true);
  ur_EVT_fire(ur_get(sId),"ods",e);
  ur_EVT_cancel(e);
}
function ur_Drag_end(e){
	if (_ur_DragDrop && _ur_DragDrop.progress && _ur_DragDrop.isddoperation) {
    ur_Drag_hideCursor();
    if (_ur_DragDrop.target) ur_Drop(_ur_DragDrop.target.id,e);
	  ur_EVT_fire(_ur_DragDrop.source,"ode",e);
  	window.removeEventListener("mousemove",ur_Drag_progress,true);
  	window.removeEventListener("mouseup",ur_Drag_end,true);
		ur_Drag_hideCursor();
		_ur_DragDrop.source=null;
		_ur_DragDrop.target=null;
		_ur_DragDrop.isddoperation=false;
		_ur_DragDrop.progress=false;
  }
}
function ur_Drop(sId,e) {
	if (_ur_DragDrop && _ur_DragDrop.progress && _ur_DragDrop.isddoperation) {
		ur_EVT_fire(ur_get(sId),"odrop",e);
	}
}
function ur_Drag_enter(sId,e) {
	if (_ur_DragDrop && _ur_DragDrop.progress && _ur_DragDrop.isddoperation) {
	  ur_EVT_fire(ur_get(sId),"odenter",e);
	}
}
function ur_Drag_over(sId,e) {
	if (_ur_DragDrop && _ur_DragDrop.progress && _ur_DragDrop.isddoperation) {
	  ur_EVT_fire(ur_get(sId),"odo",e);
	}
}
function ur_Drag_leave(sId,e) {
	if (_ur_DragDrop && _ur_DragDrop.progress && _ur_DragDrop.isddoperation) {
  	ur_EVT_fire(ur_get(sId),"odl",e);
  }
}

//** DropDownListBox.ie5 **

function sapUrMapi_DropDownListBox_getSelectedKey(sId) {
	oSelect = ur_get(sId);
	return oSelect.options[oSelect.selectedIndex].value;
}
function sapUrMapi_DropDownListBox_setSelectedKey(sId,sKey) {
	oSelect = ur_get(sId);
	for (var n=0;n<oSelect.options.length;n++) {
		if (oSelect.options[n].value==sKey) {
			oSelect.selectedIndex=n; return;
		}
	}
}
function sapUrMapi_DropDownListBox_getSelectedIndex(sId) {
	return ur_get(sId).selectedIndex;
}
function sapUrMapi_DropDownListBox_setSelectedIndex(sId,iIndex) {
	ur_get(sId).selectedIndex=iIndex;
}
function sapUrMapi_DropDownListBox_focus(sId) {
   sapUrMapi_focusElement(sId);
}
function sapUrMapi_DropDownListBox_addOptions(sId,oKeyValuePairs,sSelectedKey) {
  for(var elem in oKeyValuePairs)
    sapUrMapi_DropDownListBox_addOption(sId,elem,oKeyValuePairs[elem],elem==sSelectedKey);
}
function sapUrMapi_DropDownListBox_addOption(sId,sKey,sValue,bSelected) {
  var ddlb = ur_get(sId);
  ddlb.options[ddlb.options.length] = new Option(sValue,sKey);
  if (bSelected) ddlb.options[ddlb.options.length-1].selected=true;
}
function sapUrMapi_DropDownListBox_keydown(sId,oEvt){
	if(oEvt.keyCode==40 || oEvt.keyCode==38) ur_EVT_cancelBubble(oEvt);
}

//** FileUpload.ie5 **

function sapUrMapi_FileUpload_change(sId,oEvt){
	
}

//** FocusRect.nn6 **
function sapUrMapi_Focus_getFocusOffset(object){}
function sapUrMapi_Focus_canFocus(o){
	if (o==null) return;
	if (!o.tagName) return;
	var tag=","+o.tagName+",";
  
	if((tag==",INPUT,")&&(o.type=="hidden"||o.disabled)){ 
		return false;
	}
	var search=",A,BODY,BUTTON,FRAME,IFRAME,INPUT,ISINDEX,OBJECT,SELECT,TEXTAREA,";
	if (search.indexOf(tag)>-1){
	   if (!ur_system.is508 && o.tabIndex<0)
	       return (o.ti>=0);
	   else
	      return (o.tabIndex>=0);
	}
	if (!o.getAttribute) return;
	if (o.getAttribute("ti")!=null) return (parseInt(o.getAttribute("ti"))>=0);
}
function sapUrMapi_Focus_getNextFocusableElement(o){
	while (o!=null) {
		if (sapUrMapi_Focus_canFocus(o)) return o;
		o=o.parentNode;
	}
	return null;
}
function sapUrMapi_Focus_showFocusRect(sId){}
function sapUrMapi_Focus_RegisterCreate(sId){}
function sapUrMapi_Focus_getCurrentId(){}
function sapUrMapi_Focus_reset(){}
function sapUrMapi_Focus_remove(){}
function sapUrMapi_Focus_getFocusRectHeight() {return 0;}
function sapUrMapi_Focus_calcFocusRect(oElement,oOffsets,oLeft,oRight,oTop,oBottom){}
function sapUrMapi_Focus_DeflBtn_hideFocusRect(IsDeflBtn){};

//** FreeContextualArea.ie5 **

function mf_FRA_exp(sId)
{
  var o=ur_get(sId);
  var oImg=o.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild;
  oImg.className="urFRAExpOp";
  var oCnt=o.firstChild.childNodes[1].firstChild.firstChild;
  oCnt.style.display="block";
  
  ur_setSt(o,ur_st.COLLAPSED,false);
  ur_setSt(o,ur_st.EXPANDED,true);
  sapUrMapi_DBTN_showDBtn();
  sapUrMapi_refocusElement(sId);
}
function mf_FRA_col(sId)
{
  var o=ur_get(sId);
  var oImg=o.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild.firstChild;
  oImg.className="urFRAExpClo";
  var oCnt=o.firstChild.childNodes[1].firstChild.firstChild;
  oCnt.style.display="none";
  ur_setSt(o,ur_st.COLLAPSED,true);
  ur_setSt(o,ur_st.EXPANDED,false);
  sapUrMapi_DBTN_hideDBtn(); 
  sapUrMapi_refocusElement(sId);
}
function ur_FRA_cl(oEvt)
{
  if (ur_FRA_tgl(oEvt)) return true;
  var oCl=ur_EVT_src(oEvt);
  var o=ur_getRootObj(oCl);
  if (oCl.className=="urFRAPers")
  {
    ur_EVT_fire(o,"opers",oEvt);
    return true;	
  }
}
function ur_FRA_kd(sId,oEvt)
{
	
	var o=ur_get(sId);
	if(oEvt.keyCode==107)
	{
		if (ur_isSt(o,ur_st.COLLAPSED))
		{
			mf_FRA_exp(sId);
		 	ur_EVT_cancel(oEvt);
		 
		}
		return true;
	 }
	 
	 else  if(oEvt.keyCode==109)
	 {
		 if (ur_isSt(o,ur_st.EXPANDED))
		 {
			 mf_FRA_col(sId);
			 sapUrMapi_DBTN_hideDBtn(); 
			 ur_EVT_cancel(oEvt);
			
		 }
		 return true;
	 }
     else if(oEvt.keyCode== 13)
	 {
		oSrc = ur_EVT_src(oEvt);
		if (oSrc && oSrc.id && oSrc.id.indexOf("-pers")>0) {
			ur_EVT_fire(o,"opers",oEvt);
			ur_EVT_cancel(oEvt);
		} else {
			sapUrMapi_triggerDefaultButton(sId,oEvt);
		}
	 }	 
	 else
		return sapUrMapi_skip(sId,oEvt);
}
function ur_FRA_tgl(oEvt)
{
  var oCl=ur_EVT_src(oEvt);
  var o=ur_getRootObj(oCl);
  if (oCl.className=="urFRAExpOp") 
  {
    ur_EVT_fire(o,"ocol",o.id);
    return true;
  } else if (oCl.className=="urFRAExpClo")
  {
    ur_EVT_fire(o,"oexp",oEvt);
    return true;
  }
}

//** GeoMap.ie5 **

function sapUrMapi_GeoMap_keydown(sId, oEvt){
	var o=ur_get(sId);
	var oSrc = 	ur_EVT_src(oEvt);
	var oBtn=null;
 	var iKey=oEvt.keyCode;
	
	if(o==null) return;
	if(oSrc && oSrc.tagName && oSrc.tagName!="IMG") return;
	
 	if(ur_system.direction=="rtl" && iKey==37) iKey=39;
 	else if(ur_system.direction=="rtl" && iKey==39) iKey=37;
	if(iKey==107)
		oBtn=ur_GeoMap_getImage("ZIN",o);
	else if(iKey==109)
		oBtn=ur_GeoMap_getImage("ZOUT",o);
	else if(iKey==38)
		oBtn=ur_GeoMap_getImage("N",o);
	else if(iKey==39)
		oBtn=ur_GeoMap_getImage("E",o);
	else if(iKey==40)
		oBtn=ur_GeoMap_getImage("S",o);
	else if(iKey==37)
		oBtn=ur_GeoMap_getImage("W",o);
		
	if(oBtn!=null){
		ur_EVT_cancel(oEvt);
		oBtn.parentNode.click();
		return;
	}
	
	return sapUrMapi_skip(sId,oEvt);
}
function sapUrMapi_GeoMap_handleSpace(oEvt){
	var oSrc = ur_EVT_src(oEvt);
	if (oSrc.onclick && oEvt.keyCode==32) {
		oSrc.click(oEvt);
		ur_EVT_cancel(oEvt);
	}
}
function ur_GeoMap_getImage(sType,o){
	var a=o.getElementsByTagName("IMG");
	for(var i=0; i<a.length; i++){
		if(a[i].getAttribute("tp")==sType)
			return a[i];
	}
	a=o.getElementsByTagName("A");
	for(var i=0; i<a.length; i++){
		if(a[i].getAttribute("tp")==sType)
			return a[i];
	}
	return null;
}
//** HorizontalContextualPanel.ie5 **

function ur_Hcnp_RegisterCreate(sId,iCount,iSel,iMenuIdx)
{
	if(!sId || iCount==0 || iSel<0) return;
	sapUrMapi_Create_AddItem(sId, "ur_Hcnp_create('" + sId + "','" + iCount + "','" + iSel + "')");
}
function ur_Hcnp_create(sId,Count,SelIndex)
{
	var oHcnp = ur_get(sId);
	if(SelIndex >0 )
	{
		var iPrevSel = parseInt(SelIndex) -1;
		ur_get(sId+"-itm-"+iPrevSel+"-b").style.display="none";
	}
}
function ur_Hcnp_setActiveItem(sId,iSel,iPrevSel,evt)
{
	
	var oTbl = ur_get(sId);	
	var iOldSel = oTbl.getAttribute("sidx");
	
	if(iSel == iOldSel) return;
	
	if(iOldSel !=0)
	{
		var iPrevSel = parseInt(iOldSel) -1;
		ur_get(sId+"-itm-"+iPrevSel+"-b").style.display="";
	}
	
	
	var curTabBeg = ur_get(sId+"-itm-"+iSel+"-a");
	var curTabEnd = ur_get(sId+"-itm-"+iSel+"-b");
	var curTabTxt = ur_get(sId+"-itm-"+iSel);
	var oldTabBeg = ur_get(sId+"-itm-"+iOldSel+"-a");
	var oldTabEnd = ur_get(sId+"-itm-"+iOldSel+"-b");
	var oldTabTxt = ur_get(sId+"-itm-"+iOldSel);
	if(iOldSel ==0 )
	{
		oldTabBeg.className = "urHcnpfirstAngOff urHcnpTopUndBdr";
		oldTabEnd.className = "urHcnpUnSelTabEnd urHcnpTopUndBdr";
		oldTabTxt.className = "urHcnpUnSelTabText urHcnpTopUndBdr";
	}
	else
	{
		oldTabBeg.className = "urHcnpUnSelTabStart urHcnpTopUndBdr";
		oldTabEnd.className = "urHcnpUnSelTabEnd urHcnpTopUndBdr"; 
		oldTabTxt.className = "urHcnpUnSelTabText urHcnpTopUndBdr";
		oldTabBeg.childNodes[0].className = "urHcnpBetwAng";
	}
	if(iSel == 0)
	{
		curTabBeg.className = "urHcnpfirstAngOn";
		curTabEnd.className = "urHcnpSelTabEnd";
		curTabTxt.className = "urHcnpSelTabText";
	}
	else
	{
		curTabBeg.className = "urHcnpSelTabStart";
		curTabEnd.className = "urHcnpSelTabEnd";
		curTabTxt.className = "urHcnpSelTabText";
		curTabBeg.childNodes[0].className = "urHcnpBetSelAng";			
	}
	oTbl.setAttribute("sidx",iSel);
	if (ur_system.is508) {
		ur_setSt(oldTabTxt,ur_st.NOTSELECTED,true);
		ur_setSt(oldTabTxt,ur_st.SELECTED,false);
		ur_setSt(curTabTxt,ur_st.NOTSELECTED,false);
		ur_setSt(curTabTxt,ur_st.SELECTED,true);
	
		sapUrMapi_refocusElement(curTabTxt.id);
	}
	if(iSel !=0)
	{
		var iPrevSel = parseInt(iSel) -1;
		ur_get(sId+"-itm-"+iPrevSel+"-b").style.display="none";
	}
	
	
	var oOldCont = ur_get(sId+"-cnt-"+iOldSel);
	var oNewCont = ur_get(sId+"-cnt-"+iSel);
	oOldCont.style.display= "none";
	oNewCont.style.display ="block";
}
function ur_HcnpMnu_Select(sId,tabIdx,mnuIdx,oEvt)
{
	var iMenuSel = parseInt(ur_get(sId+"-cnt-"+tabIdx).getAttribute('sidx'));
	var oNewSelMenuItm = ur_get(sId+"-cnt-"+tabIdx+"-mnu-"+mnuIdx);
	
	var oPrevSelMenuItm =  ur_get(sId+"-cnt-"+tabIdx+"-mnu-"+iMenuSel);
	
	if(mnuIdx == iMenuSel) return;
	
	if(iMenuSel == -1)
	{
		oNewSelMenuItm.className = "urHcnpMenuSel";
		ur_get(sId+"-cnt-"+tabIdx).setAttribute('sidx',mnuIdx);
	}
	else if(iMenuSel >= 0)
	{
		oNewSelMenuItm.className = "urHcnpMenuSel";
		oPrevSelMenuItm.className = "urHcnpMenuUnSel";
		ur_get(sId+"-cnt-"+tabIdx).setAttribute('sidx',mnuIdx);
		if (ur_system.is508){
			ur_setSt(oPrevSelMenuItm,ur_st.NOTSELECTED,true);
			ur_setSt(oPrevSelMenuItm,ur_st.SELECTED,false);
			ur_setSt(oNewSelMenuItm,ur_st.NOTSELECTED,false);
			ur_setSt(oNewSelMenuItm,ur_st.SELECTED,true);
		
			sapUrMapi_refocusElement(oNewSelMenuItm.id);
	        }	
	}	
		
}
function ur_Hcnp_keySelect(sId,oEvt){
	var o = ur_get(sId);
	var oItm = ur_EVT_src(oEvt);
	var sItmId=oItm.id;
	var sItm="-itm-";
	
	if(sItmId.indexOf("mnu")>-1){
		var tabIdx=sItmId.split("-")[2];
		sItm="-cnt-"+tabIdx+"-mnu-";
		o=ur_EVT_src(oEvt).parentNode;
	}
	if(ur_system.direction!="rtl"){
		oPrev=ur_getPrevItm(oItm.previousSibling,"idx");
		oNext = ur_getNxtItm(oItm.nextSibling,"idx");
	}else{
	     oNext=ur_getPrevItm(oItm.previousSibling,"idx");
	   oPrev = ur_getNxtItm(oItm.nextSibling,"idx");
	}
	if((oEvt.keyCode == 39 || oEvt.keyCode == 40) && oNext!=null) {
		 ur_focus_Itm(oNext,oItm);
		 ur_EVT_cancel(oEvt);
	}
	else if((oEvt.keyCode == 37 || oEvt.keyCode == 38) && oPrev!=null){
		ur_focus_Itm(oPrev,oItm);
		ur_EVT_cancel(oEvt);
	}
	else if(oEvt.keyCode==9){
		var iSel=o.getAttribute("sidx");
		var oSel = ur_get(sId+sItm+iSel);
		ur_focus_Itm(oSel,oItm);
	}
	else if(oEvt.keyCode==32 || oEvt.keyCode==13){
		oItm.click();
		 ur_EVT_cancelBubble(oEvt);
	}else
		sapUrMapi_skip(sId,oEvt);
}

//** Iframe.nn6 **

function sapUrMapi_Iframe_adaptSize(sId, oEvt) {
  var oIf = ur_get(sId);
  if (oIf) {
    var iWidth = oIf.getAttribute("width"), 
        iHeight = oIf.getAttribute("height");
    if (iWidth == null || iHeight == null) {
      
      try {
        var oIfBody = oIf.contentWindow.document.body;
	if (iWidth == null) 
          oIf.setAttribute("width", oIfBody.scrollWidth + 16);
        if (iHeight == null) 
          oIf.setAttribute("height", oIfBody.scrollHeight + 16);
      } 
      catch (e) {
        
      }
    }
  }
}

//** Image.ie5 **

function sapUrMapi_Image_menuActivate(sImageId,e) {
	oImage = ur_get(sImageId);
	if (sapUrMapi_checkKey(e,"keydown",new Array("32","40"))) {
		if (oImage.onclick) {oImage.onclick();ur_EVT_cancel(e);return false;} 
		if (oImage.oncontextmenu) {oImage.oncontextmenu();ur_EVT_cancel(e);return false;} 
		if (oImage.onmouseover) {oImage.onmouseover();return false;} 
	}
	return false;
}
function sapUrMapi_Image_checkClick(sId, e) {
	if (e.type=="click") return true;
	return sapUrMapi_checkKey(e,"keydown",new Array("32"));
}
function sapUrMapi_Image_registerCreate(sId,MaxWidth,MaxHeight){
	if( MaxWidth =="" && MaxHeight =="") {
		return;
	}
	else {
		ur_Image_Create(sId,MaxWidth,MaxHeight);
	}
}
		
function ur_Image_Create(sId, TargetWidth, TargetHeight) {
	TargetWidth = parseInt(TargetWidth);
	TargetHeight = parseInt(TargetHeight);
	
	if(isNaN(TargetWidth) || TargetWidth < 0) TargetWidth = 0;
	if(isNaN(TargetHeight) || TargetHeight < 0) TargetHeight = 0;
	
	var oLoadedImage = ur_get(sId);
	
	if (oLoadedImage == null) return;
	
	if (TargetWidth <= 0 && TargetHeight <= 0){ 
		ur_Image_showImg(oLoadedImage);
		  return;
		}		
	
	if (oLoadedImage.tagName == "SPAN") oLoadedImage = oLoadedImage.firstChild;
	
    var ActWidth = oLoadedImage.offsetWidth,
  		ActHeight = oLoadedImage.offsetHeight,
		PropHeight = ur_Image_getProportionlaSize(TargetWidth, ActWidth, ActHeight);
	
	
	if (PropHeight > TargetHeight) {
	  	oLoadedImage.style.height = TargetHeight;
	}
	
	else {
		oLoadedImage.style.width = TargetWidth;
		}
	
	ur_Image_showImg(oLoadedImage);
    }
function ur_Image_getProportionlaSize(TargetSize, ActualSizeA, ActualSizeB ){
	return Math.floor( ActualSizeB * ( TargetSize / ActualSizeA ) );
}
function ur_Image_showImg(img) {
	var sVisibility = img.getAttribute("visibility");
	
	if (img == null || sVisibility == "BLANK") return;
	
	img.style.visibility ="visible";
	img.parentNode.style.overflow = "";
	img.parentNode.style.display = "inline-block"; 
	
	
	if (ur_system.browser_abbrev.indexOf("ie") > -1) {
		img.parentNode.style.height = "auto";
		img.parentNode.style.width = "auto";
	}
	
}

//** InputField.nn6 **

var aMonthNames=null;
var aDayNames=null;
var aDayNameAbbrevs=null;
var aDayCount=null;
function sapUrMapi_InputField_setInvalid(sId,bSet,sTooltip) {
	var oIn=ur_get(sId);
	if (oIn.disabled || oIn.readonly || (ur_isSt(sId,ur_st.INVALID)&&bSet) || (!ur_isSt(sId,ur_st.INVALID)&&!bSet)) return;
  var oLbl=sapUrMapi_Label_getInputLabel(sId);
	sapUrMapi_Label_setInvalid(oLbl,bSet);
	if(sTooltip!="") oIn.setAttribute("tt",sTooltip);
	ur_setSt(sId,ur_st.INVALID,bSet);
	if(bSet)
		oIn.className=oIn.className+" urEdf2TxtInv";
	else
    oIn.className=oIn.className.replace(" urEdf2TxtInv","");
}
function sapUrMapi_InputField_setDisabled(sId,bSet) {
	var oIn=ur_get(sId);
  var oLbl=sapUrMapi_Label_getInputLabel(sId);
  var oBtn=ur_get(sId+"-btn");
  
	if (bSet && !ur_isSt(sId,ur_st.DISABLED)) {
		sapUrMapi_Label_setDisabled(oLbl);
	  oIn.readOnly=true;
		oIn.className+=" urEdf2TxtDsbl";
		if(oBtn!=null) 
			oBtn.className=oBtn.className+"Dsbl";
		ur_setSt(sId,ur_st.DISABLED,bSet);	
	} 
	else if(!bSet && ur_isSt(sId,ur_st.DISABLED)){
		sapUrMapi_Label_setEnabled(oLbl);
	  oIn.readOnly=false;
    oIn.className=oIn.className.replace(" urEdf2TxtDsbl","");
		if(oBtn!=null)
			oBtn.className=oBtn.className.substring(0,oBtn.className.length-4);
	  ur_setSt(sId,ur_st.DISABLED,bSet);
  }
}
function sapUrMapi_InputField_setReadonly(sId,bSet) {
	var oIn=ur_get(sId);
  var oLbl=sapUrMapi_Label_getInputLabel(sId);
  var oBtn=ur_get(sId+"-btn");
  
	if (bSet && !ur_isSt(sId,ur_st.READONLY)) {
		sapUrMapi_Label_setDisabled(oLbl);
	  oIn.readOnly=true;
		oIn.className+=" urEdf2TxtRo";
		ur_setSt(sId,ur_st.READONLY,bSet);
	} 
	else if(!bSet && ur_isSt(sId,ur_st.READONLY)){
		sapUrMapi_Label_setEnabled(oLbl);
	  oIn.readOnly=false;
		oIn.className=oIn.className.replace(" urEdf2TxtRo","");
	  ur_setSt(sId,ur_st.READONLY,bSet);
  }
}
function sapUrMapi_InputField_keydown(sId,e){
	var o=ur_get(sId);
	var iKeyCode=e.keyCode;
	
	if((e.altKey && (e.keyCode==40||e.keyCode==38)) || e.keyCode==115){
		var oBtn = ur_get(sId+"-btn") 
		if(oBtn)
			oBtn.onclick(e);
		return ur_EVT_cancel(e);
	}
	
	if( (e.keyCode==73) && e.shiftKey && sapUrMapi_bCtrl(e)  && !e.altKey ){
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
		return ur_EVT_cancel(e);
	}
	if(e.which == 27){
		sapUrMapi_DataTip_hide(sId);
		return ur_EVT_cancel(e);
	}
	
	
	var sDefaultValue=o.getAttribute("defval");
	if(sDefaultValue && o.value == sDefaultValue){
		var sNavigationKeys="|"+ur_KEYS.UP+"|"+ur_KEYS.DOWN+"|"+ur_KEYS.LEFT+"|"+ur_KEYS.RIGHT+"|"+ur_KEYS.POS1+"|"+ur_KEYS.END+"|"+ur_KEYS.PAGE_UP+"|"+ur_KEYS.PAGE_DOWN+"|";
		if(sNavigationKeys.indexOf("|"+iKeyCode+"|") >=0) {
			return ur_EVT_cancel(e);		
		}				
	}	
}
function sapUrMapi_InputField_changeLabel(sId,sNewLabel){
}
function sapUrMapi_InputField_focus(sId,oEvt) {
	var o=ur_get(sId);
  sapUrMapi_focusElement(sId);
  if (o.getAttribute("st").indexOf("d")>-1) o.disabled=true;
  sapUrMapi_DataTip_show(sId,"focus");
  ur_setEditCellColor(o);
  sapUrMapi_InputField_showButton(o,oEvt);
  
  var sDefaultValue=o.getAttribute("defval");
  if(sDefaultValue && o.value == sDefaultValue){
       o.select();
	    o.onclick=ur_InputField_click;
  }
}
function ur_InputField_click(oEvt) {
	var o=ur_evtSrc(oEvt);
	
	
	var sDefaultValue=o.getAttribute("defval");
	if(sDefaultValue && o.value == sDefaultValue){
		o.select();
	}
}
function sapUrMapi_InputField_focusWithFormat(sId,sFormat,oEvt) {
	var o=ur_get(sId);
	sapUrMapi_InputField_focus(sId,oEvt);
	if (ur_getAttD(o,"tp","")=="DATE") {
	   o.setAttribute("df",sFormat);
	}
}
function sapUrMapi_InputField_triggerOnChange(sId,sOldValue,sNewValue) {
  var oInp = ur_get(sId);
  if (sOldValue!=sNewValue) {
    if (oInp.onchange!=null) return oInp.onchange();
  }
}
function sapUrMapi_InputField_setValue(sId,sValue) {
  ur_get(sId).value=sValue;
}
function sapUrMapi_InputField_getValue(sId) {
  return ur_get(sId).value;
}
var oDatePicker;
var dActDate;
function sapUrMapi_Date_getArray(sFormat,sDate) {
  var q;
  if ( sFormat == 1 || sFormat == 4 )
    q=sDate.split(".");
  if ( sFormat == 2 || sFormat == 5 || sFormat == 7)
    q=sDate.split("/" );
  if ( sFormat == 3 || sFormat == 6 || sFormat == 8)
    q=sDate.split("-");
  for (var i=0;i<q.length;i++) {
  	var str=q[i];
		if(str.length==2 && str.charAt(0)=='0'){
		  str=str.charAt(1);
		}
		q[i]=parseInt(str);
  }
  return q;
}
function sapUrMapi_Date_normalize(sFormat,arrDate) {
  
	var Day=1;
	var Month=0;
	var Year=0;
	if(sFormat==1 || sFormat==7 || sFormat==8){
		Day=arrDate[0];
		Month=arrDate[1];
		Year=arrDate[2];
	}
	else if(sFormat==2 || sFormat==3){
		Day=arrDate[1];
		Month=arrDate[0];
		Year=arrDate[2];
        }
	else if(sFormat==4 || sFormat==5 || sFormat== 6){
		Day=arrDate[2];
		Month=arrDate[1];
		Year=arrDate[0];
	}
	var arrRet=new Array(3);
	arrRet[0]=Year;
	arrRet[1]=Month-1;
	arrRet[2]=Day;
	return arrRet;
}
function sapUrMapi_Date_make(sFormat,vYear,vMonth,vDay)
{
  var dateString;
  if ( sFormat == 1 )
    dateString=sapUrMapi_Date_setZero(parseInt(vDay)) + "." + sapUrMapi_Date_setZero(parseInt(vMonth)) + "." + vYear;
  if ( sFormat == 2 )
    dateString=sapUrMapi_Date_setZero(parseInt(vMonth)) + "/" + sapUrMapi_Date_setZero(parseInt(vDay)) + "/" + vYear;
  if ( sFormat == 3 )
    dateString=sapUrMapi_Date_setZero(parseInt(vMonth)) + "-" + sapUrMapi_Date_setZero(parseInt(vDay)) + "-" + vYear;
  if ( sFormat == 4 )
    dateString="" + vYear + "." + sapUrMapi_Date_setZero(parseInt(vMonth)) + "." + sapUrMapi_Date_setZero(parseInt(vDay));
  if ( sFormat == 5 )
    dateString="" + vYear + "/" + sapUrMapi_Date_setZero(parseInt(vMonth)) + "/" + sapUrMapi_Date_setZero(parseInt(vDay));
  if ( sFormat == 6 )
    dateString="" + vYear + "-" + sapUrMapi_Date_setZero(parseInt(vMonth)) + "-" + sapUrMapi_Date_setZero(parseInt(vDay));
  if ( sFormat == 7 )
    dateString=sapUrMapi_Date_setZero(parseInt(vDay)) + "/" + sapUrMapi_Date_setZero(parseInt(vMonth)) + "/" + vYear;
  if ( sFormat == 8 )
    dateString=sapUrMapi_Date_setZero(parseInt(vDay)) + "-" + sapUrMapi_Date_setZero(parseInt(vMonth)) + "-" + vYear;
  return dateString;
}
function sapUrMapi_InputField_showActualDatePicker(sId, oEvt) {
	  var dt=sapUrMapi_DateField_getDate(sId);
    sapUrMapi_InputField_showDatePicker(sId,dt.year,dt.month-1,dt.day,ur_system.firstdayofweek, oEvt);
}
function sapUrMapi_InputField_showDatePicker(sId,iYear,iMonth,iDay,iFirstDayOfWeek, oEvt) {
	oInput=ur_get(sId);
	if (ur_getAttD(oInput,"st","").indexOf("d")>-1) return;
	ur_focus(oInput);
  if (typeof(iFirstDayOfWeek)=="undefined") {
  	iFirstDayOfWeek=ur_system.firstdayofweek;
  }
  if (isNaN(iYear) || isNaN(iMonth) || isNaN(iDay)) {
	  var dt=sapUrMapi_DateField_getDate(sId);
	  iYear=dt.year;
	  iMonth=dt.month;
	  iDay=dt.day;
	  if (isNaN(iYear) || isNaN(iMonth) || isNaN(iDay)) {
			var dt=new Date();
			iYear  = dt.getFullYear();
			iMonth = dt.getMonth();
			iDay   = dt.getDate();
		} 
  }
	if (oInput.getAttribute("dsbl")=="true") return;
	var arrUrls;
	arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
	if (oDatePicker) {
	    var oCal = sapUrMapi_DatePicker_make(sId,iYear,iMonth,iDay,iFirstDayOfWeek);
	  	try {
	  	  oDatePicker.frame.window.document.getElementsByTagName("BODY")[0].innerHTML=oCal.innerHTML;
	  	} catch(ex) {}
	  } else {
	    dActDate  = new Date(iYear,iMonth,iDay);
	    var oCal = sapUrMapi_DatePicker_make(sId,iYear,iMonth,iDay,iFirstDayOfWeek);
	    oDatePicker = new sapPopup(window,arrUrls,oCal,ur_get(sId+"-btn"),oEvt,0);
		oDatePicker.positionbehavior = sapPopupPositionBehavior.MENURIGHT;
		
		if (ur_system.direction=="rtl") {
		  oDatePicker.position.right=oDatePicker.position.right-1;
		} else {
		  oDatePicker.position.left=oDatePicker.position.left-1;
		}
		oDatePicker.inputId=sId;
		oDatePicker.position.top=oDatePicker.position.top-1;
	  	oDatePicker.show();
	  	oDatePicker.frame.window.focus();
	  	
	  	var focusedDateCell=oDatePicker.frame.window.document.getElementById(iYear + "-"+ (iMonth+1)+ "-"+iDay);
	  	if (focusedDateCell) {
	  		focusedDateCell.tabIndex = "0";
	  		focusedDateCell.focus()
	  	} else {
	  		oDatePicker.frame.window.document.getElementById("dp").focus();
	  	}
	  	window.onfocus = sapUrMapi_hideDatePicker;
		
		
		
	}
	var focusedDateCell=oDatePicker.frame.window.document.getElementById(iYear + "-"+ (iMonth+1)+ "-"+iDay);
	if (focusedDateCell) {
		focusedDateCell.tabIndex = "0";
		focusedDateCell.focus()
	} else {
		oDatePicker.frame.window.document.getElementById("dp").focus();
	}
  oEvt.stopPropagation();
}
function sapUrMapi_hideDatePicker() {
	try {
  		window.focus(); 
	    ur_focus(oPopup.source.object);
	} catch(e) {}
	
 	if (oDatePicker) {
		oDatePicker.hide();
		oDatePicker.onblur=null;
 	  if (oDatePicker.inputId) document.getElementById(oDatePicker.inputId).focus();
		oDatePicker=null;
		oPopup=null;
	}
}
function sapUrMapi_DatePicker_keydown(hWnd,sId,iFirstDayOfWeek,oEvt) {
	var iKey = oEvt.keyCode,
		oCell = ur_EVT_src(oEvt);
		iOneDay = 1000*60*60*24;
	if (oCell.tagName == "TD") {
		var oFocusCell = null;
		var sDay = oCell.id;
		var aDate = sDay.split("-");
		var dDate = new Date(aDate[0],aDate[1]-1,aDate[2],15);
		var iDays = 0;
		
		if (iKey==ur_KY.PREV) {
			dDate.setTime(dDate.getTime() - iOneDay);
		} else if(iKey==ur_KY.NEXT) {
			dDate.setTime(dDate.getTime() + iOneDay);
		} else if(iKey==ur_KY.UP) {
			dDate.setTime(dDate.getTime() - (7*iOneDay));
		} else if(iKey==ur_KY.DOWN) {
			dDate.setTime(dDate.getTime() + (7*iOneDay));
		} else if((iKey==ur_KY.PGUP || iKey==ur_KY.PGDOWN)) {
			
			var iYear = dDate.getFullYear();
			var iMonth = dDate.getMonth();
			var iDays= dDate.getDate();
			if (oEvt.shiftKey)
				iYear = iKey==ur_KY.PGUP ? iYear-1 : iYear+1;
			else
				iMonth = iKey==ur_KY.PGUP ? iMonth-1 : iMonth+1;
		
			dDate.setFullYear(iYear);
			if (iMonth<0) {
				dDate.setFullYear(dDate.getFullYear()-1);
				iMonth=11;
			}
			if (iMonth>11) {
				dDate.setFullYear(dDate.getFullYear()+1);
				iMonth=0;
			}
			dDate.setMonth(iMonth);
			dDate.setDate(iDays);
		
			
			if (dDate.getMonth()>iMonth) {
				sapUrMapi_Date_setDayCount(iMonth,iYear);
				iDays = aDayCount[iMonth];
				dDate.setDate(iDays);
				dDate.setMonth(iMonth);
			}
		} else if(iKey==ur_KY.HOME && oEvt.shiftKey) {
			dDate.setDate(1);
		} else if(iKey==ur_KY.END  && oEvt.shiftKey) {
			sapUrMapi_Date_setDayCount(dDate.getMonth(),dDate.getFullYear());
			dDate.setDate(aDayCount[dDate.getMonth()]);
		} else if(iKey==ur_KY.HOME) {
			var iDays = dDate.getDay() - iFirstDayOfWeek;
			if (iFirstDayOfWeek>0 && dDate.getDay() < iFirstDayOfWeek) iDays = dDate.getDay()+ 7 - iFirstDayOfWeek;
			dDate.setTime(dDate.getTime() - (iDays * iOneDay));
		} else if(iKey==ur_KY.END) {
			var iDays = 6 - dDate.getDay() + iFirstDayOfWeek;
			if (iDays==7) iDays=0;
			dDate.setTime(dDate.getTime() + (iDays * iOneDay));
		} else if(iKey==ur_KY.TAB || iKey == 27 || iKey == 115 ) {
			sapUrMapi_hideDatePicker();
			window.focus();
			if (iKey == 27 || iKey == 115) ur_EVT_cancel(oEvt);
			return;
		} else if(iKey==ur_KY.RETURN || iKey==ur_KY.SPACE) {
			sapUrMapi_DatePicker_select(sId,oEvt);
			window.focus();
			return;
		}
		var sDayId = dDate.getFullYear()+"-"+(dDate.getMonth()+1)+"-"+dDate.getDate();
		var oFocusCell = hWnd.document.getElementById(sDayId);
		if (oFocusCell && oFocusCell.className!="urCalIna") {
			oFocusCell.tabIndex = "0";
			oCell.tabIndex = "-1";
			oFocusCell.focus();
		} else {
			if (dDate.getFullYear()==10000) {
				oCell.focus();
			} else {
				sapUrMapi_InputField_showDatePicker(sId,dDate.getFullYear(),dDate.getMonth(),dDate.getDate(),iFirstDayOfWeek,oEvt,true)
			}
		}
	}	
	ur_EVT_cancel(oEvt);
	return false;
}
function sapUrMapi_DatePicker_select(sId,e) {
  var o = e.target;
  var oInput=ur_get(sId);
  if(ur_isSt(sId,ur_st.READONLY))
	  return;
  while (o.tagName!="TD") {
  	o = o.parentNode;
  	if (o==null) return;
  }
	sDay = o.getAttribute("id");
	if (sDay==null || sDay=="") return;
  if (sDay) {
    var aDate = sDay.split("-");
    var arrValue=new Array();
    arrValue[0]=parseInt(aDate[2]);
    arrValue[1]=parseInt(aDate[1]);
    arrValue[2]=parseInt(aDate[0]);
    sapUrMapi_DateField_setDate(sId,arrValue[0],arrValue[1],arrValue[2]);
		  sapUrMapi_hideDatePicker();
		  ur_focus(oInput);
    
  }
}
function sapUrMapi_Date_setZero(iInt) {
	return iInt<10?"0"+iInt:iInt;
}
function sapUrMapi_DatePicker_make(sId,iYear,iMonth,iDay,iFirstDayOfWeek) {
  var arrTmp = ur_txt[ur_language];
  if (aMonthNames==null) aMonthNames = new Array (arrTmp["SAPUR_JANUARY"],arrTmp["SAPUR_FEBRUARY"],arrTmp["SAPUR_MARCH"],arrTmp["SAPUR_APRIL"],arrTmp["SAPUR_MAY"],arrTmp["SAPUR_JUNE"],arrTmp["SAPUR_JULY"],arrTmp["SAPUR_AUGUST"],arrTmp["SAPUR_SEPTEMBER"],arrTmp["SAPUR_OCTOBER"],arrTmp["SAPUR_NOVEMBER"],arrTmp["SAPUR_DECEMBER"]);
  if (aDayNameAbbrevs==null)   aDayNameAbbrevs   = new Array (arrTmp["SAPUR_SUNDAY_ABBREV"],arrTmp["SAPUR_MONDAY_ABBREV"],arrTmp["SAPUR_TUESDAY_ABBREV"],arrTmp["SAPUR_WEDNESDAY_ABBREV"],arrTmp["SAPUR_THURSDAY_ABBREV"],arrTmp["SAPUR_FRIDAY_ABBREV"],arrTmp["SAPUR_SATURDAY_ABBREV"]);
  if (aDayCount==null)  aDayCount = new Array (31,28,31,30,31,30,31,31,30,31,30,31);
  sapUrMapi_Date_setDayCount(iMonth,iYear);
  if (typeof(iFirstDayOfWeek)=="undefined") {
  	iFirstDayOfWeek=ur_system.firstdayofweek;
  }
  var oCal = ur_get("ur-date-picker");
  if (!oCal) {
	  var oBody = document.getElementsByTagName("BODY")[0];
	  var oCal = document.createElement("SPAN");
	  oCal.id="ur-date-picker";
	  oCal.style.position="absolute";
	  if (ur_system.direction=="rtl") {
	    oCal.style.right="0";
	  } else {
	    oCal.style.left="0";
	  }
	  oCal.style.top="-1999px";
	  oBody.appendChild(oCal);
  }
  var o=ur_get(sId);
  var bRO=o.readOnly;
  var sCalHtml = "<div onkeydown=\"return me.sapUrMapi_DatePicker_keydown(window,'"+sId+"',"+iFirstDayOfWeek+",event)\" onclick=\"me.sapUrMapi_DatePicker_select('"+sId+"',event);return false;\"><table class='urCalPicWhl' cellpaddding='0' cellspacing='0' border='0' viscnt='0'><tbody><tr>";
  var pm = iMonth-1;
  var nm = iMonth+1;
  var dy = iDay;
  var py = iYear;
  var ny = iYear;
  if (pm==-1) {pm = 11;py--;}
  if (nm==12) {nm = 0;ny++;}
  if (dy>28) {dy=25}
 if (py<0 && pm==11) {
		sCalHtml    += "<td class=\"urCalArrPrevDsbl\">&nbsp;</td>";
	} else {
		sCalHtml    += "<td id=\"prev\" class=\"urCalArrPrev\" onclick=\"me.sapUrMapi_InputField_showDatePicker('"+sId+"',"+py+","+pm+","+dy+","+iFirstDayOfWeek+",event,true);\">&nbsp;</td>";
	}
  sCalHtml    += "<td colspan=6 class=urCalHdr nowrap align=center>"+aMonthNames[iMonth]+" "+iYear+"</td>";
  sCalHtml    += "<td ";
  if(ny>9999 && nm==0) {
    sCalHtml  += " class=\"urCalArrNextDsbl\">";
  } else {
    sCalHtml  += "id=\"next\" class=\"urCalArrNext\" onclick=\"me.sapUrMapi_InputField_showDatePicker('"+sId+"',"+ny+","+nm+","+dy+","+iFirstDayOfWeek+",event,true);\">";
  }
  sCalHtml    += "&nbsp;";
  sCalHtml    += "</td>";
  sCalHtml    += "</tr>";
  sCalHtml    += "<tr>";
  iLastDayOfWeek = iFirstDayOfWeek-1;
  if (iLastDayOfWeek==-1) iLastDayOfWeek=6;
  
  if (ur_system.direction=="rtl") {
    sCalHtml    += "<td class=urCalName style=\"border-left:0px none\">&nbsp;</td>";
  } else {
    sCalHtml    += "<td class=urCalName style=\"border-right:0px none\">&nbsp;</td>";
  }
  for (var i=iFirstDayOfWeek;i<aDayNameAbbrevs.length;i++) {
    if (aDayNameAbbrevs.length>3) {
      aDayNameAbbrevs[i]=aDayNameAbbrevs[i].substring(0,3);
    }
    sCalHtml    += "<td class=urCalName>"+aDayNameAbbrevs[i]+"</td>";
  }
  for (var i=0;i<iFirstDayOfWeek;i++) {
    sCalHtml    += "<td class=urCalName>"+aDayNameAbbrevs[i]+"</td>";
  }
  var dDate  = new Date(iYear,iMonth,1,12);
  dDate.setFullYear(iYear);
  var dStart=dDate;
  dStart = new Date(dStart.getTime()-((dStart.getDay()-iFirstDayOfWeek)*1000*60*60*24));
  if (dStart.getDate() >= 1 && dStart.getDate() <= 7) dStart = new Date(dStart.getTime()-(7*1000*60*60*24));
  var iFirstWeekCode=30;                                                   
  
 
  var iMinimalDaysInFirstWeek=ur_system.minimalDaysInFirstWeek;
  if (!iMinimalDaysInFirstWeek) iMinimalDaysInFirstWeek=4;
		
	for (var i=0;i<6;i++) {
   
    var oDateObj=new Date();
    var weekNum=ur_getWeek(dStart,iMinimalDaysInFirstWeek);
    
    sCalHtml    += "<tr class=urCalRow";
    if (!bRO) sCalHtml    += " style=\"cursor:pointer;\"";
		sCalHtml    += ">";
		
		sCalHtml    +=                                                           
		"<th class=urCalName style='border-style:none" +                         
		((i<5)?" none solid none":"")+" !important;'>" +                         
		weekNum+"</th>";                                       
    for (var n=0;n<7;n++) {
			var sClass="",
				sId=dStart.getFullYear()+"-"+(dStart.getMonth()+1)+"-"+dStart.getDate();
			if (dStart.getFullYear()<0 || dStart.getFullYear()>9999) {
				sId="";
			}
	  		if (dStart.getMonth()!=iMonth) {
	  			sClass="urCalIna";
	  		} else {
	  			sClass="";
	  		}
	  		if ((dStart.getFullYear()==dActDate.getFullYear()) && (dStart.getMonth()==dActDate.getMonth()) && (dStart.getDate()==dActDate.getDate())) {
	  			sClass+=" urCalDaySelEmp";
	  		}
	  		sCalHtml+="<td";
				if (n==0) {
	  		  sCalHtml+=" style=\"border-left-style:solid\"";
	  		}
	  		var dToday = new Date();
	  		var sCellContent = dStart.getDate();
	  		var bToday = false;
	  		if ((dStart.getFullYear()==dToday.getFullYear()) && (dStart.getMonth()==dToday.getMonth()) && (dStart.getDate()==dToday.getDate())) {
	  			sCellContent = "<div style=\"margin:-1;cursor:hand;background-color:transparent\" class=urCalTod>"+dStart.getDate()+"</div>"
	  			bToday = true;
	  		}
			if (sClass!="") {
        		sCalHtml+=" class="+sClass+" id=\""+sId+"\">"+sCellContent+"</td>";
	      	} else {
	        	sCalHtml+=" id=\""+sId+"\">"+sCellContent+"</td>";
	      	}
	  		var oldStart = dStart;
	  		dStart = new Date(dStart.getTime()+(1000*60*60*24));
	  		if (dStart.getDate()==oldStart.getDate()) {
	  		  
	  		  dStart = new Date(dStart.getTime()+(1000*60*60*1));
	  		}
	  		if (dStart.getHours()==1) {
	  		  dStart = new Date(dStart.getTime()-(1000*60*60*1));
	  		}
  	}
    sCalHtml    += "</tr>";
  }
  sCalHtml += "</tr></tbody></table></div>";
  oCal.innerHTML=sCalHtml;
  return oCal;
}
function sapUrMapi_Date_setDayCount(iMonth, iYear) {
	if ((iMonth == 1) && ((iYear % 400 == 0)) || ((iYear % 4 == 0) && (iYear % 100 != 0))) aDayCount[1] = 29;
	else aDayCount[1] = 28;
}
var urSizeDiv = null;
var urInpSizes = new Array();
var urInpWidths = new Array();
function sapUrMapi_InputField_KeyUp(id, event) {
	return false;
}
function sapUrMapi_InputField_Blur(id, event) {
	var o=ur_get(id);
	sapUrMapi_DataTip_hide(id);
	if (ur_getAttD(o,"tp","")=="DATE") {
	  sapUrMapi_DateField_checkDate(id);
	}
	ur_removeEditCellColor();
	sapUrMapi_InputField_hideButton(o,event);
}
function sapUrMapi_InputField_change(sId,oEvt) {}
function sapUrMapi_InputFieldHelpClick(sId,oEvt) {
	
	if (ur_getAttD(ur_get(sId),"st","").indexOf("d")>-1) return;
        var o=ur_get(sId);	
	if (o.getAttribute("dp")!="1") {
            o.onfocus();
            sapUrMapi_InputField_showActualDatePicker(sId,oEvt);
	} else {
	    sapUrMapi_hideDatePicker();
	}
}
function sapUrMapi_InputField_showButton(o,oEvt){
	var oBtn=ur_get(o.id+"-btn");
	
	if(oBtn==null || oBtn.parentNode.offsetTop>=0) return;
	
	
	var iTop=o.offsetTop;
	var oParent=o.offsetParent;
	while(oParent!=document.body){
		if(oParent.style.position=="absolute") 
			break;	
		iTop+=oParent.offsetTop;
		iTop-=oParent.scrollTop;
		oParent=oParent.offsetParent;
	}
	
		oParent=o.parentNode;
		while(oParent!=document.body){
			iTop-=oParent.scrollTop;
			oParent=oParent.parentNode;
	}
	oBtn.parentNode.style.top=iTop;
	oBtn.style.zIndex=101;  
}
function sapUrMapi_InputField_hideButton(o,oEvt){
	var oBtn=ur_get(o.id+"-btn");
	if(oBtn==null || oBtn.parentNode.style.position!="absolute")return;
	ur_callDelayed("ur_get('"+oBtn.id+"').parentNode.style.top='-900px'",500);
}
function sapUrMapi_DateField_checkDate(sId) {
  
  
  
}
function sapUrMapi_DateField_getDate(sId) {
  var dToday=new Date();
  var sValue=sapUrMapi_InputField_getValue(sId);
  if (sValue=="") return {day:iDay,month:iMonth,year:iYear};
  var sPattern=ur_DateField_getDatePattern(sId);
  var sLongPattern=sPattern;
  var dgtsYr=0;
  
  var sFindNumber="0123456789";
  var sFindPattern="dMy";
  var iDay,iMonth,iYear;
  var iErrors=0;
	while(sFindNumber.indexOf(sValue.charAt(0))==-1) {
		sValue=sValue.substring(1);
		iErrors++;
	}
	while(sFindNumber.indexOf(sValue.charAt(sValue.length-1))==-1) {
	  sValue=sValue.substring(0,sValue.length-1);
		iErrors++;
	}
  
  var sRegPattern="([^0-9])";
  var reg=new RegExp(sRegPattern,"ig");
  var arr=reg.exec(sValue);
  var xValue=sValue;
	var sCh=RegExp.$1;
	var sCh1;
	var twodelimiters=false;
	
	 try{
	xValue=sValue.split(sCh);
  if (xValue.length != 3)
  {
	var reg1=new RegExp(sRegPattern,"ig");
	var stempval=xValue[1];
	if(stempval!=null)
	while(reg1.exec(stempval))
	{
		var arr1= reg1.exec(stempval);
		sCh1=RegExp.$1;
		xValue=stempval.split(sCh1);
		stempval=xValue[1];
	}
	}
 
	
	if(sCh1!=null) {
	twodelimiters=true;
	if (sValue.indexOf(sCh) > sValue.indexOf(sCh1))
	{
		var tmp=sCh1;
		sCh1=sCh;
		sCh=tmp;
		
	}
	}
	}catch(Exp){}
    reg=new RegExp(sRegPattern,"ig");
    arr=reg.exec(sValue);
	if (reg.lastIndex>0) {
    if (sValue.indexOf(sCh)==4 || sValue.indexOf(sCh)==3) {
		  xValue=sPattern.replace("yyyy",sValue.substring(0,sValue.indexOf(sCh)));
				  if(twodelimiters)
			{
			  xValue=xValue.replace("MM",sValue.substring(sValue.indexOf(sCh)+1,sValue.lastIndexOf(sCh1)));
			  xValue=xValue.replace("M",sValue.substring(sValue.indexOf(sCh)+1,sValue.lastIndexOf(sCh1)));
			  xValue=xValue.replace("dd",sValue.substring(sValue.lastIndexOf(sCh1)+1));
			  xValue=xValue.replace("d",sValue.substring(sValue.lastIndexOf(sCh1)+1));
			}
	      else
			{
		  xValue=xValue.replace("MM",sValue.substring(sValue.indexOf(sCh)+1,sValue.lastIndexOf(sCh)));
		  xValue=xValue.replace("M",sValue.substring(sValue.indexOf(sCh)+1,sValue.lastIndexOf(sCh)));
		  xValue=xValue.replace("dd",sValue.substring(sValue.lastIndexOf(sCh)+1));
		  xValue=xValue.replace("d",sValue.substring(sValue.lastIndexOf(sCh)+1));
			}
		  sValue=xValue;
    }
  } 
	while(sFindPattern.indexOf(sPattern.charAt(sPattern.length-1))==-1) sPattern=sPattern.substring(0,sPattern.length-1);
  while (sPattern.indexOf(" ")>-1) sPattern=sPattern.replace(" ","");
  while (sValue.indexOf(" ")>-1) {
		
    sValue=sValue.replace(" ","");
  }
  if (iErrors>3) return {day:iDay,month:iMonth,year:iYear};
  
  
  var reg=ur_DateField_getRegExpTest(sValue,sPattern);
  if (reg.lastIndex>0) {
    
    
    var iDayPos=sPattern.indexOf("d");
    var iMonthPos=sPattern.indexOf("M");
    var iYearPos=sPattern.indexOf("y");
    var sDay,sMonth,sYear="";
    if(iDayPos != -1)
    {    
		if (iDayPos<iMonthPos && iDayPos<iYearPos) sDay=RegExp.$1;
    if (iDayPos>iMonthPos && iDayPos<iYearPos) sDay=RegExp.$2;
    if (iDayPos<iMonthPos && iDayPos>iYearPos) sDay=RegExp.$2;
    if (iDayPos>iMonthPos && iDayPos>iYearPos) sDay=RegExp.$3;
    if (iMonthPos==-1)
		{
		if( iDayPos<iYearPos) sDay=RegExp.$1;
		else
		if(iDayPos>iYearPos) sDay=RegExp.$2;
		}
	if (iYearPos==-1)
		{
		if( iDayPos<iMonthPos) sDay=RegExp.$1;
		else
		if(iDayPos>iMonthPos) sDay=RegExp.$2;
		}
    if(iMonthPos==-1 && iYearPos==-1)
		sDay=RegExp.$1;
		
		while (sDay.indexOf("0")==0 && sDay.length>1) sDay=sDay.substring(1);
		iDay=parseInt(sDay);
		if (iDay==0) iDay=1;
	}
	else
	{iDay=-1;}
	if (iMonthPos != -1	)
	{
    if (iMonthPos<iDayPos && iMonthPos<iYearPos) sMonth=RegExp.$1;
    if (iMonthPos>iDayPos && iMonthPos<iYearPos) sMonth=RegExp.$2;
    if (iMonthPos<iDayPos && iMonthPos>iYearPos) sMonth=RegExp.$2;
    if (iMonthPos>iDayPos && iMonthPos>iYearPos) sMonth=RegExp.$3;
    
    if (iDayPos==-1)
		{
		if( iMonthPos<iYearPos) sMonth=RegExp.$1;
		else
		if(iMonthPos>iYearPos) sMonth=RegExp.$2;
		}
	if (iYearPos==-1)
		{
		if( iMonthPos<iDayPos) sMonth=RegExp.$2;
		else
		if(iMonthPos>iDayPos) sMonth=RegExp.$1;
		}
	if(iDayPos==-1 && iYearPos==-1)
		sMonth=RegExp.$1;
		
   
    while (sMonth.indexOf("0")==0 && sMonth.length>1) sMonth=sMonth.substring(1);
		iMonth=parseInt(sMonth);
	}
	else
		iMonth=-1;
	if(iYearPos != -1)
	{
    if (iYearPos<iMonthPos && iYearPos<iDayPos) sYear=RegExp.$1;
    if (iYearPos>iMonthPos && iYearPos<iDayPos) sYear=RegExp.$2;
    if (iYearPos<iMonthPos && iYearPos>iDayPos) sYear=RegExp.$2;
    if (iYearPos>iMonthPos && iYearPos>iDayPos) sYear=RegExp.$3;
    
    if (iDayPos==-1)
		{
		if(iMonthPos<iYearPos) sYear=RegExp.$2;
		else
		if(iMonthPos>iYearPos) sYear=RegExp.$1;
		}
	if (iMonthPos==-1)
		{
		if(iYearPos<iDayPos) sYear=RegExp.$1;
		else
		if(iYearPos>iDayPos) sYear=RegExp.$2;
		}
	if(iDayPos==-1 && iMonthPos==-1)
		sYear=RegExp.$1;    
	dgtsYr=sYear.length;
    while (sYear.indexOf("0")==0 && sYear.length>1) sYear=sYear.substring(1);
		iYear=parseInt(sYear);
	}
	else
	iYear =-1;
		var arrMonth=new Array(0,31,29,31,30,31,30,31,31,30,31,30,31);
  	if (isNaN(iYear) && isNaN(iMonth) && isNaN(iDay)) return {day:iDay,month:iMonth,year:iYear};
		if (isNaN(iYear)) iYear=dToday.getFullYear();
		if (isNaN(iMonth)) iMonth=dToday.getMonth()+1;
		if (isNaN(iDay) && iMonth==dToday.getMonth()+1) iDay=dToday.getDate();
		if (isNaN(iDay) && iMonth!=dToday.getMonth()+1) iDay=1;
		if (isNaN(iYear) || isNaN(iMonth) || isNaN(iDay)) return {day:iDay,month:iMonth,year:iYear};
		if (iMonth>12) iMonth=12;
		if (iMonth<1) iMonth=1;
		if (iDay>arrMonth[iMonth]) iDay=arrMonth[iMonth];
		if ( dgtsYr != 4 && dgtsYr !=0)
		{
		if (iYear<=20) iYear+=	2000;
		else if (iYear>20 && iYear<=99) iYear+=1900;
		}
		if (iMonth==2 && iDay==29 && (!ur_DateField_isLeapYear(iYear))) iDay=28;
    return {day:iDay,month:iMonth,year:iYear};
  } else {
  	
    return {day:iDay,month:iMonth,year:iYear};
  }
  oEvt.returnValue=false;
  
}
function ur_DateField_getRegExpTest(sValue,sPattern) {
  var sPatternNew="";
  var sEscapeChars="()*$[]\/^{}|. -";
  var sFindNumberPattern="dMy";
  var bFoundNumber=false;
  for (var j=0;j<sPattern.length;j++) {
    if (!bFoundNumber && sFindNumberPattern.indexOf(sPattern.charAt(j))>-1) bFoundNumber=true;
    if (bFoundNumber) {
			if (sEscapeChars.indexOf(sPattern.charAt(j))>-1) sPatternNew=sPatternNew+"[^0-9]{0,1}";
			else sPatternNew+=sPattern.charAt(j);
		}
  }
  sRegPattern=sPatternNew.replace("dd","([0-9]{1,2})");
  sRegPattern=sRegPattern.replace("MM","([0-9]{1,2})");
  sRegPattern=sRegPattern.replace("d","([0-9]{1,2})");
  sRegPattern=sRegPattern.replace("M","([0-9]{1,2})");
  sRegPattern=sRegPattern.replace("yyyy","([0-9]{1,4})");
  sRegPattern=sRegPattern.replace("yy","([0-9]{1,4})");
  var reg=new RegExp(sRegPattern,"ig");
  var arr=reg.exec(sValue);
	if (reg.lastIndex==0) {
		sRegPattern=sPatternNew.replace("dd","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("MM","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("d","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("M","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("yyyy","([0-9]{1,4})");
		sRegPattern=sRegPattern.replace("yy","([0-9]{1,4})");
		var reg=new RegExp(sRegPattern,"ig");
		var arr=reg.exec(sValue);
  }
  if (reg.lastIndex==0 && sValue.length>2) {
		sRegPattern=sPatternNew.replace("dd","([0-9]{2,2})");
		sRegPattern=sRegPattern.replace("MM","([0-9]{2,2})");
		sRegPattern=sRegPattern.replace("d","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("M","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("yyyy","");
		sRegPattern=sRegPattern.replace("yy","");
		if (sRegPattern.indexOf("\\(")==-1 && sRegPattern.indexOf("\\)")==-1) {
		  sRegPattern=sRegPattern.substring(sRegPattern.indexOf("("),sRegPattern.lastIndexOf(")")+1);
		}
		var reg=new RegExp(sRegPattern,"ig");
	  var arr=reg.exec(sValue);
	}
  if (reg.lastIndex==0 && sValue.length>2) {
		sRegPattern=sPatternNew.replace("dd","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("MM","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("d","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("M","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("yyyy","");
		sRegPattern=sRegPattern.replace("yy","");
		if (sRegPattern.indexOf("\\(")==-1 && sRegPattern.indexOf("\\)")==-1) {
		  sRegPattern=sRegPattern.substring(sRegPattern.indexOf("("),sRegPattern.lastIndexOf(")")+1);
		}
		var reg=new RegExp(sRegPattern,"ig");
	  var arr=reg.exec(sValue);
	}
  if (reg.lastIndex==0) {
		sRegPattern=sPatternNew.replace("dd","([0-9]{2,2})");
		sRegPattern=sRegPattern.replace("MM","");
		sRegPattern=sRegPattern.replace("d","([0-9]{1,2})");
		sRegPattern=sRegPattern.replace("M","");
		sRegPattern=sRegPattern.replace("yyyy","");
		sRegPattern=sRegPattern.replace("yy","");
		if (sRegPattern.indexOf("\\(")==-1 && sRegPattern.indexOf("\\)")==-1) {
		  sRegPattern=sRegPattern.substring(sRegPattern.indexOf("("),sRegPattern.lastIndexOf(")")+1);
		}
		var reg=new RegExp(sRegPattern,"ig");
	  var arr=reg.exec(sValue);
	}
	return reg;
}
function ur_DateField_isLeapYear(iYear) {
  return ((iYear % 400 == 0) || ((iYear % 4 == 0) && (iYear % 100 != 0)));
}
function sapUrMapi_DateField_setDate(sId,iDay,iMonth,iYear) {
  var sPattern=ur_DateField_getDatePattern(sId);
  if (iYear<10) iYear = "000"+iYear;
  else if (iYear<100) iYear = "00"+iYear;
  else if (iYear<1000) iYear = "0"+iYear;
  var sFormat=sPattern;
  var s=sPattern.replace("dd",ur_DateField_addZero(iDay));
  s=s.replace("MM",ur_DateField_addZero(iMonth));
  s=s.replace("yyyy",iYear+"");
  if (iYear<1950) {
    s=s.replace("yy",iYear+"");
  } else {
    s=s.replace("yy",(iYear+"").substring(2));
  }
  s=s.replace("d",iDay+"");
  s=s.replace("M",iMonth+"");
	sapUrMapi_InputField_setInvalid(sId,false,"");
	var oldValue=sapUrMapi_InputField_getValue(sId);
	sapUrMapi_InputField_setValue(sId,s)
	sapUrMapi_InputField_triggerOnChange(sId,oldValue,s);
}
function ur_DateField_getDatePattern(sId) {
	var o=ur_get(sId);
	var sFormatString="";
	if (ur_getAttD(o,"tp","")=="DATE") {
	  sFormatString=ur_getAttD(o,"df","");
	}
	if (sFormatString=="") {
	  sFormatString=ur_system.dateformatstring;
	}
	if (sFormatString!=null && sFormatString!="") 
		{
		while(sFormatString.indexOf("'")>-1) {sFormatString=sFormatString.replace("'","");}
		return sFormatString;
		}
	var iFormat=ur_system.dateformat;
	if (iFormat==1) return "dd.MM.yyyy";
	if (iFormat==2) return "MM/dd/yyyy";
	if (iFormat==3) return "MM-dd-yyyy";
	if (iFormat==4) return "yyyy.MM.dd";
	if (iFormat==5) return "yyyy/MM/dd";
	if (iFormat==6) return "yyyy-MM-dd";
	if (iFormat==7) return "dd/MM/yyyy";
	if (iFormat==8) return "dd-MM-yyyy";
}
function ur_DateField_addZero(i) {
  return i<10&&i>0?"0"+i:""+i;
}
function ur_getFirstDayOfFirstWeek(iFullYear, minDays) {
    var oFirstDay = new Date(iFullYear, 0, minDays, 12, 0, 0),
        iFirstDay = oFirstDay.getDay(),
        iDiff = iFirstDay - ur_system.firstdayofweek,
        DAY = 86400000;
    if (iDiff < 0)
        iDiff += 7;
    var ilFirstDayOfFirstWeek = oFirstDay.getTime() - (iDiff) * DAY;
    return ilFirstDayOfFirstWeek;
};
function ur_getWeek(oDate, minDays) {
    var iFirstDayOfFirstWeekYear = oDate.getFullYear(),
        iFirstDayOfFirstWeek = ur_getFirstDayOfFirstWeek(iFirstDayOfFirstWeekYear, minDays),
        WEEK = 86400000 * 7,
        iWeekNum = Math.floor((oDate.getTime() - iFirstDayOfFirstWeek) / WEEK + .5) + 1;
    if (iWeekNum >= 53) {
        var itFirstDayOfFirstYear = ur_getFirstDayOfFirstWeek(oDate.getFullYear() + 1, minDays);
        if (itFirstDayOfFirstYear - oDate.getTime() < WEEK)
            iWeekNum = 1;
    }
    return iWeekNum;
}
//** InputTokenizer.nn6 **

var oLastSelTextRange = null;
function sapUrMapi_InputTokenizer_MouseUp() {
	
}
function sapUrMapi_InputTokenizer_Click(sId, oEv) {	  	  
	
}
function sapUrMapi_InputTokenizer_KeyDown(sId, oEv) {
	
	
	
	if (oEv.which == 13) {	
		
		if (sapUrMapi_bCtrl(oEv)) {
		  var inp = ur_get(sId);
			var btn = ur_get(inp.getAttribute("validatebtn"));
			if (btn != null) {
				btn.onclick();
			}
		}
		oEv.stopPropagation();
		return false;
	}
}
function sapUrMapi_InputTokenizer_selectToken(oInput, oSelRange) {
	
}
function sapUrMapi_InputTokenizer_markValidTokens(sId) {
	var oInput = ur_get(sId);
	var val = oInput.value;
	if (val == "") { return; }
	var tokenlist = sapUrMapi_InputTokenizer_getTokenList(oInput);
	var usecase = oInput.getAttribute("casesensitive");
	var delim = oInput.getAttribute("delimiter");
	var newValue = "";
	
	var inputtokens = sapUrMapi_InputTokenizer_splitTokens(oInput);
	for (i = 0; i < inputtokens.length; i++) {
	  if (sapUrMapi_InputTokenizer_matchToken(inputtokens[i], tokenlist, usecase)) {
			inputtokens[i] = "[" + inputtokens[i] + "]" + delim + " ";
	  }
		else {
		  inputtokens[i] = "{" + inputtokens[i] + "}" + delim + " ";
		}
		newValue += inputtokens[i];
	}
	
	oInput.value=newValue;
}
function sapUrMapi_InputTokenizer_getTokenList(oInput){
	var listdiv = ur_get(oInput.getAttribute("listid"));
	if (listdiv != null) {
		var tokendelim = listdiv.getAttribute("tokendelim");
		var keydelim = listdiv.getAttribute("keydelim");
  		var list = listdiv.innerHTML.split(tokendelim);
		var retstr = "|-|";
		for (i = 0; i < list.length; i++) {
			var tkn = list[i].split(keydelim);
			retstr += tkn[0] +  "|-|" ;
		}
		return retstr;
	}
}
function sapUrMapi_InputTokenizer_splitTokens(oInput) {
	var delim = oInput.getAttribute("delimiter");
	var re = new RegExp("\\s*" + delim + "\\s*", "gi");
	var txt = oInput.value;
	
	
	while (txt.substr(0,1) == " ") {
		txt = txt.substr(1,txt.length-1);
	}
	
	
	while (txt.substr(txt.length-1, 1) == " " || txt.substr(txt.length-1, 1) == delim) {
		txt = txt.substr(0, txt.length-1);
	}
	
	txt = txt.replace(/\[/gi,"");
	txt = txt.replace(/\]/gi,"");
	txt = txt.replace(/\{/gi,"");
	txt = txt.replace(/\}/gi,"");
	
	
	if (txt.indexOf(delim) == -1) {
	  return new Array(txt);
	}
	else {
		return txt.split(re);
	}
}
function sapUrMapi_InputTokenizer_matchToken(sTkn, sTknList, bUseCase) {
	
	if (bUseCase) {
	  if (sTknList.indexOf("|-|" + sTkn + "|-|") != -1) {
	    return true;
	  }
	}
	else {
	  if (sTknList.toLowerCase().indexOf("|-|" + sTkn.toLowerCase() + "|-|") != -1) {
	    return true;
	  }
	}
	
	return false;
}

//** ItemListBox.nn6 **

function sapUrMapi_ItemListBox_registerCreate(sId,sWidth){
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_ItemListBox_setDim('"+sId+"','"+sWidth+"')");
}
function sapUrMapi_ItemListBox_getScrollTop(sId){
	var o = sapUrMapi_ItemListBox_getObject(sId,document,null);
	return o.scrl.scrollTop;
}
function sapUrMapi_ItemListBox_setScrollTop(sId, iScrollTop){
	var o = sapUrMapi_ItemListBox_getObject(sId,document,null);
	o.scrl.scrollTop = iScrollTop;
	o.r.setAttribute("scrltop", iScrollTop);
}
function ur_ItemListBox_getIndex(sId,sKey){
	if(sId=="") return 0;
	var o=sapUrMapi_ItemListBox_getObject(sId,document);
	if(!o) return 0;
	var i=0;
	for(i=0; i<o.itms.length; i++)
		if(o.itms[i].k==sKey)	return i+1;
	return null;
}
function sapUrMapi_ItemListBox_getObject(sId,oDoc,oEvt){
	if(sId=="")return null;
	var o = new Object();
	
	var oR=oDoc.getElementById(sId+"-r");
	if (oR && oR.hasChildNodes() && oR.firstChild.tagName=="XMP") {
	  oR.innerHTML=oR.firstChild.innerHTML; 
	}	
	o.r=oDoc.getElementById(sId);
	if(!o.r) return null;
	
	aTbl=o.r.getElementsByTagName("TABLE");
	o.tbl=aTbl[aTbl.length-1];
	o.tbd=o.tbl.firstChild;
	
	o.box=o.tbl;
	
	o.scrl=o.tbd;	
	
	o.itms = o.tbl.getElementsByTagName("TR");
	
	var sFocus=o.tbl.getAttribute("focusitm");
	if(sFocus)
		o.focusedItm=o.itms[parseInt(sFocus)-1];
	else
		o.focusedItm=null;
	var sOldFocus=o.tbl.getAttribute("oldfocusitm");
	if(sOldFocus)
		o.oldFocusedItm=o.itms[parseInt(sOldFocus)-1];
	if(o.focusedItm==null)
		o.focusedItm=o.itm;
	
	o.selItms=new Array();
	o.prevItm=null;
	o.nextItm=null;
	var j=0;
	for(var i=0;i<o.itms.length;i++){
		if(o.itms[i].className=="urIlb2ISel"){
			o.selItms[j]=o.itms[i];
			j++;
		}
		if(o.focusedItm!=null&&o.focusedItm==o.itms[i]){
			if(i>0)
				if(o.itms[i-1].name=="HLine") o.prevItm=o.itms[i-2];
				else o.prevItm=o.itms[i-1];
			if(i<o.itms.length-1)
				if(o.itms[i+1].name=="HLine") o.nextItm=o.itms[i+2];
				else o.nextItm=o.itms[i+1];
		}
	}
	if(o.prevItm==null && o.nextItm==null) o.nextItm=o.itms[0];
	
	o.parId=o.r.getAttribute("parid");
	
	if(o.parId!=null&&o.parId!="") o.ro = ur_isSt(o.parId,ur_st.READONLY);
	else o.ro = ur_isSt(o.r.id,ur_st.READONLY);
	o.enbl = !ur_isSt(o.r.id,ur_st.DISABLED);
	o.inv = ur_isSt(o.r.id,ur_st.INVALID);
	o.popup = o.tbl.getAttribute("pop") == "true";
	o.multi = o.tbl.getAttribute("multi") == "true";
	o.size = parseInt(o.tbl.getAttribute("s"));
	o.vissize = parseInt(o.tbl.getAttribute("v"));
	o.userheight = o.tbl.getAttribute("h");
	o.userwidth = o.tbl.getAttribute("w");
	o.cols = o.tbl.getAttribute("cols");
	o.valcol=o.tbl.getAttribute( "vcol" );
	o.icocol=o.tbl.getAttribute( "icol" );
	return o;
}
function sapUrMapi_ItemListBox_getItem(o,sKey){
	for(var i=0; i<o.itms.length;i++){
		if(sKey==o.itms[i].getAttribute("k"))
			return o.itms[i];
	}
	return o.itms[0];
}
function sapUrMapi_ItemListBox_setParentId(sId, sParentId)  {
	if (!ur_get(sId)) sapUrMapi_ItemListBox_getObject(sId,document,null);
	ur_get(sId).setAttribute("parid",sParentId);
}
function sapUrMapi_ItemListBox_getSelectedKeys(sId,oDoc){
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,null);
	var aKeys=new Array();
	var j=0;
	for(var i=0; i<o.itms.length;i++){
		if( o.itms[i].className == "urIlb2ISel" ){
			aKeys[j]=o.itms[i].getAttribute("k");
			j++;
		}
	}
	return aKeys;
}
function sapUrMapi_ItemListBox_setSelectedKeys(sId,aKeys,oDoc){
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,null);
	var sKey=aKeys.toString();
	for(var i=0; i<o.itms.length;i++)
		if( sKey.indexOf(o.itms[i].getAttribute("k")) == 0 )
			sapUrMapi_ItemListBox_selectItem(o,o.itms[i],true,null);
}
function sapUrMapi_ItemListBox_setSelectedKey(sId,sKey,oDoc,bScroll){
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,null);
	
	
	if(o.size<=0) return;
	for(var i=0; i<o.itms.length;i++){
		if( sKey==o.itms[i].getAttribute("k") ){
			sapUrMapi_ItemListBox_deselectAllItems(o);
			sapUrMapi_ItemListBox_itemSetHighlight(o.itms[i], true);
			sapUrMapi_ItemListBox_focusItem(o,o.itms[i]);
			if(bScroll) sapUrMapi_ItemListBox_scrollIntoView(o,o.itms[i],true);			
			return;
		}
	}
}
function sapUrMapi_ItemListBox_selectHoveredItem(sId,oDoc,oEvt){
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,null);
	for(var i=0; i<o.selItms.length;i++)
		sapUrMapi_ItemListBox_selectItem(o,o.selItms[i],true,oEvt);
}
function sapUrMapi_ItemListBox_getList(sId,doc){
	var o=sapUrMapi_ItemListBox_getObject(sId,doc,null);
	var oCols = new Array();
	var sItmKey = "";
	var sList = "";
	for( var i=0; i<o.itms.length; i++ ){
		sItmKey = o.itms[i].getAttribute("k");
		oCols =  o.itms[i].getElementsByTagName("TD");
		sList += "||";
		sList += oCols[parseInt(o.valcol)-1].innerHTML;
		sList += "|";
		sList += sItmKey;
	}
	if(sList!="") sList+="||";
	return sList;
}
function sapUrMapi_ItemListBox_setDim( sId, sWidth ){
	var o = sapUrMapi_ItemListBox_getObject(sId,document,null);
	
	
	var oILBBorder = ur_get("ILBBORDER");
	var oILBItem = ur_get("ILBITEM");
	
	
	if(!oILBBorder){
		oILBBorder = document.createElement("span");
		oILBItem = document.createElement("span");
		oILBBorder.id = "ILBBorder";
		oILBItem.id = "ILBItem";
		oILBBorder.style.position = "absolute";
		oILBBorder.style.top = "-1000";
		oILBItem.style.position = "absolute";
		oILBItem.style.top = "-1000";
		oILBBorder.innerHTML="Text";
		oILBItem.innerHTML="Text";
		oILBBorder.className = "urIlb2Box urIlb2I";
		oILBItem.className = "urIlb2I";
		document.body.appendChild(oILBBorder);
		document.body.appendChild(oILBItem);
	}
	o.iItemHeight = parseInt(oILBItem.offsetHeight);
	o.iBorderHeight = 0;
	
	
	if( parseInt(o.vissize) > 0 && !isNaN(parseInt(o.vissize)) )
		sapUrMapi_ItemListBox_setSize(o, parseInt(o.vissize));
	else if( (parseInt(o.userheight) > 0 && !isNaN(parseInt(o.userheight))) || o.popup )
		sapUrMapi_ItemListBox_setHeight(o, parseInt(o.userheight));
	
	if( parseInt(sWidth) >= 0 && !isNaN(parseInt(sWidth)) )
		sapUrMapi_ItemListBox_setWidth(o, parseInt(sWidth));
		
	
	var iScrollTop = parseInt(o.r.getAttribute("scrltop"));
	if(isNaN(iScrollTop)) iScrollTop = 0;
	o.scrl.scrollTop = iScrollTop;
			
}
function sapUrMapi_ItemListBox_setSize(o,sSize){
	var iHeight = 0;
	if(parseInt(sSize) <= 0) return;
	if(parseInt(sSize) >= o.itms.length) return;
	iHeight = parseInt(sSize) * o.iItemHeight + o.iBorderHeight;
	
	sapUrMapi_ItemListBox_setHeight(o,iHeight);
}
function sapUrMapi_ItemListBox_setHeight(o,sHeight){
	var iCurrentHeight = o.scrl.offsetHeight; 
	var iNewHeight=0;
	var iWindowHeight=parseInt(document.body.clientHeight); 
	var iNeededHeight = o.iItemHeight * o.itms.length + o.iBorderHeight;
	
	
	var oILBHeight = ur_get("ILBHeight");
	if(!oILBHeight){
		oILBHeight = document.createElement("div");
		oILBHeight.id = "ILBHeight";
		oILBHeight.style.position = "absolute";
		oILBHeight.style.top = "-1000";
		oILBHeight.className = "urIlb2Box urIlb2I";
		document.body.appendChild(oILBHeight);
	}		
	
	
	if( (isNaN(parseInt(sHeight)) || parseInt(sHeight) <= 0 )){
		if(!o.popup) return;
		else iNewHeight = iNeededHeight;
	}
	
	
	if(!isNaN(parseInt(sHeight)) && parseInt(sHeight) > 0 ){
		oILBHeight.style.height = sHeight;
		iNewHeight = parseInt(oILBHeight.offsetHeight);
	}
	
	
	if(o.itms.length > 0){
		iNewHeight = parseInt((iNewHeight - o.iBorderHeight) / o.iItemHeight) * o.iItemHeight + o.iBorderHeight;
	}
	
	
	if(o.popup && iNewHeight>iWindowHeight){
		iNewHeight=iWindowHeight;
	}
	
	
	if(iCurrentHeight != 0 && iCurrentHeight == iNewHeight){
		return;
	}
	
	
	o.scrl.style.display = "block";
	
	
	if( iNewHeight < iNeededHeight){
		o.scrl.style.overflowY = "auto";
		o.scrl.style.overflowX = "hidden";
	}
	else if(o.popup){
		o.scrl.style.overflowY = "visible";
		o.scrl.style.overflowX = "visible";
	}
	o.scrl.style.height = iNewHeight;
	
	o.tbl.setAttribute("s",parseInt((iNewHeight - o.iBorderHeight) / o.iItemHeight));
}
function sapUrMapi_ItemListBox_setWidth(o,sWidth){
	var iWidth = 0;
	var iNewWidth=parseInt(sWidth);
	if (isNaN(iNewWidth) || iNewWidth<=0) return;
	o.box.style.width = "10px";
	iWidth = o.r.offsetWidth;
	if (iNewWidth<iWidth) return;
	o.box.style.width = iNewWidth;
	o.tbl.style.width = "100%";
	o.box.setAttribute("style","width:"+iNewWidth+";");
	oFirstTD = o.box.getElementsByTagName("TD")[0];
	oFirstTD.setAttribute("style","width:"+sWidth+";");
}
function sapUrMapi_ItemListBox_itemSelected(oItm){
	if( oItm.className == "urIlb2ISel" ) return true;
	return false;
}
function sapUrMapi_ItemListBox_itemSetHighlight(oItm,bOn){
	if( oItm == null || oItm.tagName != "TR" ) return;
	if( bOn && oItm.className != "urIlb2ISel") oItm.className = "urIlb2ISel";
	else if( oItm.className == "urIlb2ISel" ) oItm.className = "";
	else return;
}
function sapUrMapi_ItemListBox_deselectAllItems(o){
	if(o.selItms==null) return;
	for(var i=0; i<o.selItms.length; i++)
		sapUrMapi_ItemListBox_itemSetHighlight(o.selItms[i],false);
}
function sapUrMapi_ItemListBox_getVal(o,oItm){
	if(o.valcol==null) return null;
	var oCols=oItm.getElementsByTagName("TD");
	var sVal="";
	sVal = oCols[parseInt(o.valcol)-1].childNodes[0].data;
	if( sVal.search(/\s/) == 0 ) sVal = sVal.substr(1,sVal.length);
	return sVal;
}
function sapUrMapi_ItemListBox_getIconSrc(o,oItm){
	if(o.icocol==null || o.icocol=="") return null;
	var oCols=oItm.getElementsByTagName("TD");
	var oIco;
	oIco = oCols[parseInt(o.icocol)-1].firstChild;
	return oIco.style.backgroundImage;
}
function sapUrMapi_ItemListBox_hoverItem(o,oItm){
	if(o.ro) return;
	sapUrMapi_ItemListBox_deselectAllItems(o);
	sapUrMapi_ItemListBox_itemSetHighlight(oItm, true);
	sapUrMapi_ItemListBox_focusItem(o,oItm);
}
function sapUrMapi_ItemListBox_scrollIntoView(o,oItm,bTop){
	if( (o.tbd.scrollTop > oItm.rowIndex*oItm.offsetHeight) || (o.tbd.scrollTop+o.tbd.clientHeight-5 <= oItm.rowIndex*oItm.offsetHeight) )
		if(!bTop) o.tbd.scrollTop=(oItm.rowIndex-o.size+1)*oItm.offsetHeight;
		else o.tbd.scrollTop= oItm.rowIndex * 18;
}
function sapUrMapi_ItemListBox_selectItem(o,oItm,bTop,oEvt){
	if(!o.ro && o.enbl){
		if(!(o.multi&&(oEvt.shiftKey||sapUrMapi_bCtrl(oEvt)))) sapUrMapi_ItemListBox_deselectAllItems(o);
		sapUrMapi_ItemListBox_itemSetHighlight(oItm,true);
		if(o.popup){
			sapUrMapi_ComboBox_setValue(o.parId,oItm.getAttribute("k"), sapUrMapi_ItemListBox_getVal(o,oItm), sapUrMapi_ItemListBox_getIconSrc(o,oItm),oEvt);
		}
	}
	sapUrMapi_ItemListBox_focusItem(o,oItm);
	sapUrMapi_ItemListBox_scrollIntoView(o,oItm,bTop);
}
function sapUrMapi_ItemListBox_deselectItem(oItm){
	sapUrMapi_ItemListBox_itemSetHighlight(oItm,false);
}
function sapUrMapi_ItemListBox_focusItem(o,oItm){
	
	if(!o.popup&&o.focusedItm!=null)
		sapUrMapi_setTabIndex(o.focusedItm.getElementsByTagName("TD")[parseInt(o.valcol)-1],-1);
	
	o.tbl.setAttribute("focusitm",oItm.rowIndex+1);
	if (!o.popup){
		var oCols=oItm.getElementsByTagName("TD");
		sapUrMapi_setTabIndex(oCols[parseInt(o.valcol)-1],0);
		if(ur_system.is508){									
			oCols[parseInt(o.valcol)-1].setAttribute("t",oItm.getAttribute("t"));								
			if(oItm.className.indexOf("Sel")!=-1){ 
				ur_setSt(oCols[parseInt(o.valcol)-1],ur_st.SELECTED,true);
				ur_setSt(oCols[parseInt(o.valcol)-1],ur_st.NOTSELECTED,false);					
			}
			else{
				ur_setSt(oCols[parseInt(o.valcol)-1],ur_st.SELECTED,false);	
				ur_setSt(oCols[parseInt(o.valcol)-1],ur_st.NOTSELECTED,true);	
			}	
		}
		if (document.activeElement != oCols[parseInt(o.valcol)-1]) {
		  var oTd = oCols[parseInt(o.valcol)-1];
		  ur_focus(oTd);
     }
	}
}
function sapUrMapi_ItemListBox_mouseover( sId,oDoc,oEvt) {
	var oFrom=oEvt.relatedTarget;
	var oTo=oEvt.target;
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,oEvt);
	
	if( oTo.tagName=="DIV" || oTo.tagName=="SPAN" || o.ro || !o.enbl || o.size==0) return;
	while( oFrom != null && oFrom.tagName != "TR" )
		oFrom = oFrom.parentNode;
	while( oTo != null && oTo.tagName != "TR" )
		oTo = oTo.parentNode;
	if( oTo==null || oTo.name=="HLine" || oFrom==oTo ) return;
	sapUrMapi_ItemListBox_hoverItem(o,oTo);
}
function sapUrMapi_ItemListBox_focus(sId,oDoc,oEvt){
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,oEvt);
	
	
	if(!o.enbl && !ur_system.is508) return;
	sapUrMapi_DataTip_show(sId,"focus");
	
	if(ur_evtSrc(oEvt).id!=sId) return;
	
	if(o.selItms.length==0) oItm = o.itms[0];
	else oItm = o.selItms[0];
	
	sapUrMapi_ItemListBox_focusItem(o,oItm);
}
function sapUrMapi_ItemListBox_blur( sId, oEvt ){
	sapUrMapi_DataTip_hide();
}
function sapUrMapi_ItemListBox_click(sId,oDoc,oEvt) {
	
	var oItm=ur_evtSrc(oEvt);
	if(oItm.tagName!="TD") return; 
	while(oItm.tagName!="TR"){
		if(oItm.getAttribute("ct")=="ItemListBox") return;
		oItm=oItm.parentNode;
	}
	var o=sapUrMapi_ItemListBox_getObject(sId,oDoc,oEvt);
	var bSel = false;
	
	
	if(o.size<=0) return;
	
	
	if( o.multi == true && sapUrMapi_bCtrl(oEvt) == false )
		sapUrMapi_ItemListBox_deselectAllItems(o);
	
	if(oEvt.shiftKey == true && o.multi == true  && (o.focusedItm != oItm) ){
		var oStart=o.oldFocusedItm;
		if(oStart.rowIndex < oItm.rowIndex)
			for(var i=oStart.rowIndex;i<=oItm.rowIndex;i++)
				sapUrMapi_ItemListBox_selectItem(o,o.itms[i],true, oEvt);
		else
			for(var i=oStart.rowIndex;i>=oItm.rowIndex;i--)
				sapUrMapi_ItemListBox_selectItem(o,o.itms[i],true, oEvt);
	}
	
	else{
		sapUrMapi_ItemListBox_selectItem(o, oItm, true,oEvt);
		o.tbl.setAttribute( "oldfocusitm", oItm.rowIndex+1 );
	}
	ur_focus(ur_get(sId).firstChild);
	return ur_EVT_cancel(oEvt);
}
function sapUrMapi_ItemListBox_keypress( sId, oEvt ){
	var o=sapUrMapi_ItemListBox_getObject(sId, document, oEvt);
	if (o.popup) return;
  
  if( oEvt.charCode > 0){
    var sSearchChar = String.fromCharCode(oEvt.charCode);
    var sSelectedKey = "";
    if (o.selItms.length > 0) {
      sSelectedKey = o.selItms[o.selItms.length-1].getAttribute("k");
    }
    var sNewKey = sapUrMapi_ItemListBox_findItem(sId,sSearchChar,sSelectedKey,document);
    if (sNewKey!="") sapUrMapi_ItemListBox_setSelectedKey(sId,sNewKey,document,true);
  }  
}
function sapUrMapi_ItemListBox_findItem(sId,sSearch,sStartKey,oDoc) {
	var sList=sapUrMapi_ItemListBox_getList(sId,oDoc);
	var sLIST=sList.toUpperCase();
	var sSEARCH="||"+sSearch.toUpperCase();
	var iStart=0;
	var iEnd=0;
	var sKey=sStartKey+"||";
	var sNewKey="";
	var sNewVal="";
	
	if(sKey!=null && sKey!="")
		iStart=sList.indexOf(sKey);
	iStart=sLIST.indexOf(sSEARCH,iStart);
	if(iStart<0)
		iStart=sLIST.indexOf(sSEARCH);
	if(iStart<0) return false;
	
	iStart+=2;
	iEnd=sList.indexOf("|",iStart);
	sVal=sList.slice(iStart,iEnd);
	iStart=iEnd+1;
	iEnd=sList.indexOf("||",iStart);
	sKey=sList.slice(iStart,iEnd);
  return sKey;
}
function sapUrMapi_ItemListBox_keydown( sId, doc, e ){
	var o=sapUrMapi_ItemListBox_getObject(sId, doc, e);
	var iItmIdx = 0;
	
	if(o.size<=0) return;
	
	if( e.keyCode==73 && e.shiftKey && sapUrMapi_bCtrl(e) && !e.altKey ){
		sapUrMapi_DataTip_show(sId,"keydown");
	}
	
	
	else if(e.keyCode==27){
		sapUrMapi_DataTip_hide(sId);
	}
	
	
	else if(e.keyCode==9 && !o.popup){
		if (e.shiftKey) {
			var oR=o.r;
			var oN=null;
			var oF=null;
			while(oR!=null && oF==null){
				while(oR!=null && oR.previousSibling==null)
					oR=oR.parentNode;
				if(oR==null)
					break;
				oN=oR.previousSibling;
				while(oN!=null && oF==null){
					oF=sapUrMapi_findFirstFocus(oN,true);
					if(oF==null)
						oN=oN.previousSibling;
				}
				if(oF==null)
					oR=oR.parentNode;
				else
					break;
			}
			if(oF!=null)
			{
				ur_focus(oF);
				return ur_EVT_cancel(e);
			} else {
				document.body.tabIndex="0";
				ur_focus(document.body);
				document.body.tabIndex="-1";
			}
		}
		if (!e.shiftKey) {
			var oR=o.r;
			var oN=null;
			var oF=null;
			while(oR!=null && oF==null){
				while(oR!=null && oR.nextSibling==null)
					oR=oR.parentNode;
				if(oR==null)
					break;				
				oN=oR.nextSibling;
				while(oN!=null && oF==null){
					oF=sapUrMapi_findFirstFocus(oN);
					if(oF==null)
						oN=oN.nextSibling;
				}
				if(oF==null)
					oR=oR.parentNode;
				else
					break;
			}
			if(oF!=null)
			{
				ur_focus(oF);
				return ur_EVT_cancel(e);
			}
		}
		return true;
	}
	
	
	else if( e.keyCode==38 && o.prevItm != null ){
		if( sapUrMapi_bCtrl(e) && o.multi )
			sapUrMapi_ItemListBox_focusItem(o,o.prevItm);
		else if( sapUrMapi_ItemListBox_itemSelected(o.prevItm) && o.multi){
			sapUrMapi_ItemListBox_deselectItem(o.focusedItm);
			sapUrMapi_ItemListBox_focusItem(o,o.prevItm);
		}
		else
			sapUrMapi_ItemListBox_selectItem(o, o.prevItm,true, e );
	}
	
	
	else if( e.keyCode==40 && o.nextItm != null ){
		if( sapUrMapi_bCtrl(e) && o.multi )
			sapUrMapi_ItemListBox_focusItem(o,o.nextItm);
		else if( sapUrMapi_ItemListBox_itemSelected(o.nextItm) && o.multi){
			sapUrMapi_ItemListBox_deselectItem(o.focusedItm);
			sapUrMapi_ItemListBox_focusItem(o,o.nextItm);
		}
		else
			sapUrMapi_ItemListBox_selectItem(o, o.nextItm,false, e );
	}
	
	
	else if( e.keyCode==32 ){
		if( sapUrMapi_ItemListBox_itemSelected(o.focusedItm) &&  sapUrMapi_bCtrl(e) && o.multi)
			sapUrMapi_ItemListBox_deselectItem(o.focusedItm);
		else
			sapUrMapi_ItemListBox_selectItem(o, o.focusedItm,true, e);
	}
	
	
	else if( e.keyCode==36 ){
		sapUrMapi_ItemListBox_selectItem(o, o.itms[0],true, e );
	}
		
	
	else if( e.keyCode==35 ){
		sapUrMapi_ItemListBox_selectItem(o, o.itms[o.itms.length-1],false, e );
	}
		
	
	else if( e.keyCode==33 && o.size!=null ){
		if(!o.focusedItm) {
			if(o.itms.length > 0) {
				sapUrMapi_ItemListBox_selectItem(o, o.itms[0], true, e );
			}
		}
		else {
		    iItmIdx = o.focusedItm.rowIndex - o.size + 1;
  		    if( iItmIdx < 0 ) iItmIdx = 0;
		    sapUrMapi_ItemListBox_selectItem(o, o.itms[iItmIdx],true, e );
	    }
	}
	
	
	else if( e.keyCode==34 && o.size!=null ){
		if(!o.focusedItm) {
			if(o.itms.length > 0) {
				sapUrMapi_ItemListBox_selectItem(o, o.itms[o.itms.length-1], true, e );
			}
		}
		else {
		    iItmIdx = o.focusedItm.rowIndex + o.size - 1;
		    if( iItmIdx > o.tbd.lastChild.rowIndex ) iItmIdx = o.tbd.lastChild.rowIndex;
  		    sapUrMapi_ItemListBox_selectItem(o, o.itms[iItmIdx],false, e);
      }
  }
  else return;
   
  return ur_EVT_cancel(e);
}
function sapUrMapi_ItemListBox_setInvalid(sId,bSet){
	var o=sapUrMapi_ItemListBox_getObject(sId, document);
	if(o.popup) return;
	if(ur_isSt(o.r,ur_st.READONLY) || ur_isSt(o.r,ur_st.DISABLED)) return;
	if(bSet && ur_isSt(o.r,ur_st.INVALID)) return;
	if(!bSet && !ur_isSt(o.r,ur_st.INVALID)) return;
	if(bSet){
		o.box.className=o.box.className.replace("Box","BoxInv");
		ur_setSt(sId,ur_st.INVALID,true);
	}
	else{
		o.box.className=o.box.className.replace("BoxInv","Box");
		ur_setSt(sId,ur_st.INVALID,false);	
	}
}
function sapUrMapi_ItemListBox_setDisabled(sId,bSet){
	var o=sapUrMapi_ItemListBox_getObject(sId, document);
	if(o.popup) return;
	if(bSet && ur_isSt(o.r,ur_st.DISABLED)) return;
	if(!bSet && !ur_isSt(o.r,ur_st.DISABLED)) return;
	if(bSet){
		o.box.className=o.box.className.replace("Box","BoxDsbl");
		ur_setSt(sId,ur_st.DISABLED,true);
		for(var i=0; i<o.itms.length; i++){
			for(var j=0; j<o.itms[i].childNodes.length; j++){
				o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Ilb2I","Ilb2IDsbl");
				o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Dscr","");				
			}
		}
	}
	else{
		o.box.className=o.box.className.replace("BoxDsbl","Box");
		ur_setSt(sId,ur_st.DISABLED,false);	
		for(var i=0; i<o.itms.length; i++){
			for(var j=0; j<o.itms[i].childNodes.length; j++){
				o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Dsbl","");
				if(j!=parseInt(o.valcol)-1)
					o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Ilb2I","Ilb2IDscr");				
			}
		}		
	}
}
function sapUrMapi_ItemListBox_setReadonly(sId,bSet){
	var o=null;
	if(typeof(sId)=="object")
		o=sId;
	else
		o=sapUrMapi_ItemListBox_getObject(sId, document);
	if(bSet && ur_isSt(o.r,ur_st.READONLY)) return;
	if(!bSet && !ur_isSt(o.r,ur_st.READONLY)) return;
	if(bSet){
		o.box.className=o.box.className.replace("Box","BoxRo");
		ur_setSt(o.r,ur_st.READONLY,true);
		for(var i=0; i<o.itms.length; i++){
			for(var j=0; j<o.itms[i].childNodes.length; j++){
				o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Ilb2I","Ilb2IRo");
				o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Dscr","");				
			}
		}
	}
	else{
		o.box.className=o.box.className.replace("BoxRo","Box");
		ur_setSt(o.r,ur_st.READONLY,false);	
		for(var i=0; i<o.itms.length; i++){
			for(var j=0; j<o.itms[i].childNodes.length; j++){
				o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Ro","");
				if(j!=parseInt(o.valcol)-1)
					o.itms[i].childNodes[j].className=o.itms[i].childNodes[j].className.replace("Ilb2I","Ilb2IDscr");				
			}
		}		
	}
}

//** Label.ie5 **

function sapUrMapi_Label_setDisabled(oLbl) {
	if(oLbl==null || oLbl.className.indexOf("Dsbl")>-1) return;
	if(oLbl.className.indexOf("Bar")>-1)
		oLbl.className=oLbl.className.replace("LBar","LBarDsbl");
	else
		oLbl.className=oLbl.className.replace("L","LDsbl");
}
function sapUrMapi_Label_setEnabled(oLbl) {
	if (oLbl==null) return;
	oLbl.className=oLbl.className.replace("Dsbl","");
}
function sapUrMapi_Label_setInvalid(oLbl,bSet) {
	if (oLbl==null) return;
	
	if(!bSet){
		oLbl.className=oLbl.className.replace("Inv","");
		return;
	}
	
	if(oLbl.className.indexOf("Inv")>-1) return;
	if (oLbl.className.indexOf("Bar")>-1) 
		oLbl.className=oLbl.className.replace("Bar","BarInv");
	else
		oLbl.className+="Inv";
}
function sapUrMapi_Label_getInputLabel(sId) {
	var ur_arrLabels = document.getElementsByTagName("LABEL");
	for (var i=0;i<ur_arrLabels.length;i++) {
		if (ur_arrLabels.item(i).getAttribute("f")==sId) {
			return ur_arrLabels.item(i);
		}
	}
	for (var i=0;i<ur_arrLabels.length;i++) {
		if (ur_arrLabels.item(i).getAttribute("htmlFor")==sId) {
			return ur_arrLabels.item(i);
		}
	}
	return null;
}
function sapUrMapi_Label_FocusLabeledElement(sForId) {
  sapUrMapi_focusElement(sForId);
}
function sapUrMapi_Label_getLabelText(sId) {
	var oLbl=sapUrMapi_Label_getInputLabel(sId);
	if(oLbl==null) return null;
	var sTxt=oLbl.getAttribute("lbl");
	if(sTxt==null || sTxt=="")
		sTxt=oLbl.innerText;
	if(sTxt.lastIndexOf(" *")>-1 && sTxt.lastIndexOf(" *")==sTxt.length-2)
		sTxt=sTxt.substring(0,sTxt.lastIndexOf(" *"));	
	if(sTxt.lastIndexOf(":")>-1 && sTxt.lastIndexOf(":")==sTxt.length-1)
		sTxt=sTxt.substring(0,sTxt.lastIndexOf(":"));
	return sTxt;
}
function sapUrMapi_Label_clickLabeledElement(sForId) {
	var o=ur_get(sForId);
	try{
	  var sCt=o.getAttribute("ct");
		if(sCt=="C" || sCt=="R" || sCt=="TRI") ur_get(sForId +"-r").click();
		else ur_focus(o);
	} catch(e){}
}
function ur_L_getF(sId){
  sF=ur_get(sId).f;
  return sF;
}
function ur_L_mm(sId,oEvt){
	clearTimeout(_ur_DataTip_timer);
	if(typeof(sId)== "object"){
		oEvt = sId;
		sId = oEvt.srcElement.getAttribute("id");
	}
	var o=ur_get(sId);
	
	if(!o) return;
	
	var sCt=o.getAttribute("ct");
	if(ur_EVT_src(oEvt).className=="urHlpTHFont")
		_ur_DataTip.time_out=70;
	else
		_ur_DataTip.time_out=0;
	if(sCt=="L")sId=ur_L_getF(sId);
	if(sapUrMapi_DataTip_isOpen(sId)==false)
		_ur_DataTip_timer=ur_callDelayed("sapUrMapi_DataTip_show('"+sId+"','mousemove')",500);
}
function ur_L_ml(sId,oEvt){
	clearTimeout(_ur_DataTip_timer);
	if(typeof(sId)== "object"){
		oEvt = sId;
		sId = oEvt.srcElement.getAttribute("id");
	}
	var o=ur_get(sId);
	
	if(!o) return;
	
	var oInput = null;
	var sCt=o.getAttribute("ct");
	if(sCt=="L"){
		sId=ur_L_getF(sId);
		oInput = ur_get(sId+"-r");
		
		if(oInput.getAttribute("evt")==null){
		  oInput.attachEvent("onmouseover",ur_L_mm);
		  oInput.attachEvent("onmouseout",ur_L_ml);
		  oInput.setAttribute("evt","true");
		}
	}
	
	if(oPopup){
		_ur_DataTip_timer = ur_callDelayed("sapUrMapi_DataTip_hide(\""+sId+"\")",_ur_DataTip.time_out);
	}
}

//** Link.ie5 **

function sapUrMapi_Link_activate(sLinkId,e) {
	oLink = ur_get(sLinkId);
	var iKeyCode=e.keyCode;
	
	
	if(iKeyCode==32 && oLink.onclick){
		ur_EVT_cancel(e);
		oLink.click(); 
		e.returnValue=false;
		return true;
	}
	
	else if (oLink.getAttribute("hasmenu")=="true" && iKeyCode==40 && oLink.oncontextmenu) {
		ur_EVT_cancel(e);
		oLink.oncontextmenu();
		e.returnValue=false;
		return false;
	}  
	
	if (oLink.getAttribute("hasmenu")=="true" && (iKeyCode==32 || iKeyCode==40) && oLink.onmouseover) {
		ur_EVT_cancel(e);
		oLink.onmouseover();
		e.returnValue=false;
		return false;
	}
  e.returnValue=true;
  return true;
}
function sapUrMapi_Link_contextMenu(oEvt) {
	var o = ur_EVT_src(oEvt);
	while (o && o.tagName && o.tagName!="A") o = o.parentNode;
	if (o && o.getAttribute && o.getAttribute("ocm")) {
		ur_EVT_fire(o,"ocm",oEvt);
		ur_EVT_cancel(oEvt);
	}
}
//** ListBox.ie5 **

function sapUrMapi_ListBox_focus(sId,e) {
    
	sapUrMapi_DataTip_show(sId,"focus");
}
function sapUrMapi_ListBox_blur(sId,event) {
	sapUrMapi_DataTip_hide(sId);
}
function sapUrMapi_ListBox_keydown(sId,oEvt) {
	
	if( oEvt.keyCode==73 && oEvt.shiftKey && sapUrMapi_bCtrl(oEvt) && !oEvt.altKey ){
		ur_EVT_cancel(oEvt);
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
	}
	if(oEvt.keyCode == "27"){
		ur_EVT_cancel(oEvt);
		sapUrMapi_DataTip_hide(sId);
	}
}
//** LoadingAnimation.nn6 **

var _ur_LoadingAni_delay = 2000;
var _ur_LoadingAni_timerId = null;
var _ur_LoadingPopup = null;
function sapUrMapi_LoadingAnimation_getObject() {
	return ur_get("ur-loading");
}
function sapUrMapi_LoadingAnimation_getText() {
	var oLAText = ur_get("ur-loading");
	oLAText = oLAText.firstChild.lastChild;
	return oLAText.innerHTML;
}
function sapUrMapi_LoadingAnimation_trigger() {
	_ur_LoadingAni_timerId = ur_callDelayed("sapUrMapi_LoadingAnimation_show('ur-loading')", _ur_LoadingAni_delay);
}
function sapUrMapi_LoadingAnimation_show(sId) {
	if (_ur_LoadingAni_timerId) {
		var arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
		_ur_LoadingPopup = new sapPopup(window,arrUrls,ur_get("ur-loading"),ur_get("ur-loading"),null,0);
		_ur_LoadingPopup.positionbehavior=sapPopupPositionBehavior.BROWSERCENTER;
		_ur_LoadingPopup.show(true);
		_ur_LoadingAni_timerId = null;
	}
}
function sapUrMapi_LoadingAnimation_cancel() {
	if (_ur_LoadingAni_timerId) {
		clearTimeout(_ur_LoadingAni_timerId);
	_ur_LoadingAni_timerId = null;
	} else {
		sapUrMapi_LoadingAnimation_hide();
        }
}
function sapUrMapi_LoadingAnimation_hide() {
	if (_ur_LoadingPopup) {
	   _ur_LoadingPopup.hide();
	   _ur_LoadingPopup=null;
        }
}

//** MenuBar.ie5 **

function sapUrMapi_MenuBar_hover(sId,e){
	var oTxt=ur_get(sId+"-txt");
	var oBtn=ur_get(sId+"-btn");
	var oMnuBar=ur_get(sId).parentNode;
	var sAi=oMnuBar.getAttribute("ai");
	
	if(ur_isSt(sId,ur_st.DISABLED)) return;
	
	if (oTxt.className.indexOf("Hover")==-1){
		oTxt.className+="Hover";
		oBtn.className+="Hover";
	}
	if(e.type=="mouseout"){
		oTxt.className=oTxt.className.replace("Hover","");
		oBtn.className=oBtn.className.replace("Hover","");
	}
	if(oPopup!=null){
	  if (!oPopup.source.object) return; 
		var sSrcPopup = oPopup.source.object.parentNode.getAttribute("id");
		var sMenu = oMnuBar.getAttribute("id");
		if (sSrcPopup == sMenu && sAi!=sId){
 			oTxt.click();
			oMnuBar.setAttribute("ai",sId);
                 }
	}
}
function sapUrMapi_MenuBar_keyDown(sMenuId,e) {
}
function sapUrMapi_MenuBarItem_keyDown(sItemId,iCurrentIndex,sPopupId,e) {
 	if (!sapUrMapi_checkKey(e,"keydown",new Array("35","36","37","39","9","40"))) 
 		return false;
 		
 	var oMenuItem=ur_get(sItemId);
 	var oMenu=oMenuItem.parentNode;
 	var iKey=e.keyCode;
 	var oNewItem=null;
 	
 	
 	if(ur_system.direction=="rtl" && iKey==37) iKey=39;
 	else if(ur_system.direction=="rtl" && iKey==39) iKey=37;
 	 	
 	if(iKey!=40)sapUrMapi_setTabIndex(oMenuItem,-1);
 	
 	
 	if (iKey==37) {
 		if (oMenuItem.previousSibling)
 			oNewItem = oMenuItem.previousSibling;
 		else
 			oNewItem = oMenu.lastChild;
 	}
	
 	else if (iKey==39) {
 		if (oMenuItem.nextSibling) 
 			oNewItem = oMenuItem.nextSibling;
 		else 
 			oNewItem = oMenu.firstChild;
 	}
	
	else if(iKey==36)
		oNewItem=oMenu.firstChild;
	
	else if(iKey==35)
		oNewItem=oMenu.lastChild;	
	
 	else if (e.keyCode==9) { 
 		oNewItem=oMenu.firstChild;
	 	if(!ur_system.is508)
	 		while(oNewItem==ur_isSt(oMenuItem,ur_st.DISABLED) && oNewItem!=null)
	 			oNewItem=oNewItem.nextSibling;
		ur_focus(oNewItem);	 			
 		sapUrMapi_setTabIndex(oNewItem,0);
 		e.returnValue=true;
		return true;
	}
	
 	else if (iKey==40 && !ur_isSt(oMenuItem,ur_st.DISABLED)) {
		if (oMenuItem.onclick) 
	 		oMenuItem.onclick();
	 	else if (oMenuItem.oncontextmenu)
			oMenuItem.oncontextmenu();
	}	
			
	
 	if (oNewItem!=null) {
		sapUrMapi_setTabIndex(oNewItem,0);
	 	ur_focus(oNewItem);
	 	if (!ur_system.is508 && ur_isSt(oNewItem,ur_st.DISABLED)) 
	 		sapUrMapi_MenuBarItem_keyDown(oNewItem.id,0,"",e);
	}
	
	return ur_EVT_cancel(e);		
}
function sapUrMapi_MenuBarItem_click(sItemId,sPopupId,oEvt) {
  sapUrMapi_PopupMenu_showMenu(sItemId,sPopupId,sapPopupPositionBehavior.MENULEFT,oEvt);
  ur_EVT_cancel(oEvt);
}
function sapUrMapi_MenuBar_focus(sMenuId,oEvt) {
	 	var oMenu = ur_get(sMenuId);
	 	var oMenuItem = oMenu.firstChild;
	 	if(!ur_system.is508)
	 		while(oMenuItem==ur_isSt(oMenuItem,ur_st.DISABLED) && oMenuItem!=null)
	 			oMenuItem=oMenuItem.nextSibling;
	 	if(oMenuItem!=null){
	 		sapUrMapi_setTabIndex(oMenuItem,0);
	 		ur_focus(oMenuItem);
	 	sapUrMapi_setTabIndex(oMenu,-1);
	 }
}

//** MessageBar.ie5 **
enumUrMessageBarType = {ERROR:"Error",WARNING:"Warning",OK:"Ok",STOP:"Stop",LOADING:"Loading",NONE:"None",TEXT:"Text"};
function sapUrMapi_MessageBar_setAccText(sId,vMessageBarType) {
	var oMBar = ur_get(sId);
	var oMTxt = ur_get(sId+"-txt");
	var sMTxt = oMTxt.innerText;
	if (oMTxt.getAttribute("tt")!=null && oMTxt.getAttribute("tt")!="") sMTxt=oMTxt.getAttribute("tt");
	var sType = vMessageBarType.toUpperCase(); 
	var bHasConId = oMBar.onclick!=null;
	var sTxt = "";
	if (bHasConId) sTxt="SAPUR_MSG_JUMPKEY"; 
	if (vMessageBarType!=enumUrMessageBarType.TEXT) {
		if (ur_system.is508) {
			oMBar.title=getLanguageText("SAPUR_MSG",new Array("SAPUR_MSG_"+sType,sMTxt,sTxt));
		} else {
		  oMBar.title=sMTxt;
		}
	} else {
		if (ur_system.is508) {
			oMBar.title=getLanguageText("SAPUR_MSG",new Array("",sMTxt,sTxt));
		} else {
		  oMBar.title=sMTxt;
		}
	}
}
function sapUrMapi_MessageBar_setType(sId,vMessageBarType) {
	var oMBar = ur_get(sId);
	sapUrMapi_MessageBar_setAccText(sId,vMessageBarType);
	if (vMessageBarType==enumUrMessageBarType.NONE) {
		oMBar.style.display = 'none';
		return;
	} else {
		if (vMessageBarType==enumUrMessageBarType.ERROR || vMessageBarType==enumUrMessageBarType.STOP) oMBar.className="urMsgBarErr";
		else oMBar.className="urMsgBarStd";
		oMBar.style.display = 'block';
    var oMBarImg  = ur_get(sId+"-img");
    if (vMessageBarType!=enumUrMessageBarType.TEXT) {
    	oMBarImg.style.display="inline";
      oMBarImg.className = "urMsgBarImg"+vMessageBarType;
    } else {
    	oMBarImg.style.display="none";
    }
	}
}
function sapUrMapi_MessageBar_getType(sId) {
	var oMBar = ur_get(sId);
  if (oMBar.style.display == 'none') {
  	return enumUrMessageBarType.NONE;
  } else {
    var oMBarImg  = ur_get(sId+"-img");
    if ((oMBarImg.className).indexOf(enumUrMessageBarType.ERROR)>-1) return enumUrMessageBarType.ERROR;
    if ((oMBarImg.className).indexOf(enumUrMessageBarType.WARNING)>-1) return enumUrMessageBarType.WARNING;
    if ((oMBarImg.className).indexOf(enumUrMessageBarType.LOADING)>-1) return enumUrMessageBarType.LOADING;
    if ((oMBarImg.className).indexOf(enumUrMessageBarType.STOP)>-1) return enumUrMessageBarType.STOP;
    if ((oMBarImg.className).indexOf(enumUrMessageBarType.OK)>-1) return enumUrMessageBarType.OK;
    if ((oMBarImg.style.display).indexOf("none")>-1) return enumUrMessageBarType.TEXT;
  }
}
function sapUrMapi_MessageBar_setText(sId,sText) {
	var oMBarText = ur_get(sId+"-txt");
	oMBarText.innerHTML = sText;
	sapUrMapi_MessageBar_setAccText(sId,sapUrMapi_MessageBar_getType(sId));
}
function sapUrMapi_MessageBar_getText(sId) {
	var oMBarText = ur_get(sId+"-txt");
	return oMBarText.innerHTML;
}
function sapUrMapi_MessageBar_navigateToField(sId,sConId,oEvt) {
  
  if ((oEvt.type=="click") || (sapUrMapi_checkKey(oEvt,"keydown",new Array("32")))) {
    
    ur_EVT_cancel(oEvt);
    sapUrMapi_triggerFocus(sConId);
  }
}

//** NavigationList.ie5 **

function ur_NL_getItem(oEvt){
	var oItm=ur_EVT_src(oEvt);
	while(ur_getAttD(oItm,"idx","")==""){ 
		oItm=oItm.parentNode;
		if (!oItm || oItm.tagName=="BODY") return null;
	}
	return oItm;
}
function ur_NL_getGroup(oEvt){
	var oItm=ur_EVT_src(oEvt);
	while(ur_getAttD(oItm,"gidx","")==""){ 
		oItm=oItm.parentNode;
		if (!oItm || oItm.tagName=="BODY") return null;
	}
	return oItm;
}
function ur_NL_cl(oEvt){
	var oSrcElement = ur_EVT_src(oEvt);
	var oNL = sapUrMapi_getRootControl(oSrcElement);
	var sId = oNL.getAttribute("id");	
	var o = ur_NL_getObj(sId);
	
	for(i=0; i<o.items.length; i++){
		if(oSrcElement.id==o.items[i].id){
			o.ref.setAttribute("iFidx",i);
			break;
		}
	}
  if (ur_FRA_cl(oEvt)) return;
	var oItm=ur_NL_getItem(oEvt);
	
	if (oItm==null) {
	  oItm=ur_NL_getGroup(oEvt);
	  if (oItm!=null) {
		  ur_EVT_fire(oItm,"ogc",oEvt);
	  } else {
	  	if (oSrcElement.className.indexOf("MnuIco") > -1) {
			
			if (oSrcElement.tagName == "IMG") {
				oItm = oSrcElement.parentNode.previousSibling;
			}
		}
	  }
	}
	if(oItm==null) return;
	if (ur_getAttD(oItm,"st","").indexOf("d")>-1) return;
	var sMenuId=oItm.parentNode.getAttribute("pop");
	var sChildId=oItm.getAttribute("id");
	
	if(sMenuId!=null && sMenuId!=""){
		if (ur_system.direction=="rtl")
		  sapUrMapi_PopupMenu_showMenu(sChildId,sMenuId,sapPopupPositionBehavior.MENULEFT,oEvt);
		else
	 	  sapUrMapi_PopupMenu_showMenu(sChildId,sMenuId,sapPopupPositionBehavior.MENURIGHT,oEvt);
	}
	else{
	  ur_EVT_fire(oItm,"oic",oEvt);
	}
}
function ur_NL_keyNav(oEvt){
	var oSrcElement=ur_EVT_src(oEvt);
	var oNL = sapUrMapi_getRootControl(oSrcElement);
	var sId = oNL.getAttribute("id");	
	var o = ur_NL_getObj(sId);
	 
	var iKey = oEvt.keyCode;
	var oItem = null;
	var iFidx=o.ref.getAttribute("iFidx");
	if (iFidx!=null) iFidx = parseInt(iFidx);
	if(iFidx==null)
		iFidx=o.items.selidx;
	if(iFidx==null && o.items.length>1) {
		iFidx=0;
		
		sapUrMapi_setTabIndex(o.items[0],"0");
	}
	var iOldIndex = iFidx;
			
	if(iKey==40 && oSrcElement!=o.end){
		if(oSrcElement!=o.ref && oSrcElement!=o.ref.pers)
			if (iFidx<=o.items.length ){
				iFidx=iFidx+1;
				oItem=o.items[iFidx];
			} else return;
			
		}	
	else if(iKey==38 && oSrcElement!=o.end && oSrcElement!=o.ref && oSrcElement!=o.pers){
		iFidx=iFidx-1;
		if(iFidx>=0){	
		   oItem=o.items[iFidx];
		}else
			return;
		}
	else if(iKey==9){
		 if(oEvt.shiftKey){ 
		 	if(oSrcElement!=o.ref && oSrcElement!=o.end && o.ref.pers==null){
			   oItem=o.ref;
			   if(o.items.selected==null)
			  		iFidx=0;
			   else
			     	iFidx=o.items.selidx;
			}
			else if(oSrcElement!=o.ref && oSrcElement!=o.end && o.ref.pers!=null && oSrcElement!=o.ref.pers ){
			   oItem=o.ref.pers;
			   iFidx=0;
			} else if (oSrcElement==o.end){
				if(o.items.selected==null){
					oItem=o.items[o.items.length-1];
					iFidx=o.items.length-1;
						}else{
				   oItem=o.items[o.items.selidx];
				   iFidx=o.items.selidx;
				}
			}
			else if(oSrcElement==o.ref.pers)
				oItem=o.ref;
		} else if (!oEvt.shiftKey){
		 	if(oSrcElement!=o.ref && oSrcElement!=o.end && oSrcElement!=o.ref.pers){
	 			oItem=o.end;
	 			iFidx=o.items.length-1;
			}	else if((oSrcElement==o.ref && o.ref.pers==null) || oSrcElement==o.ref.pers){
				if(o.items.selected==null){
					oItem=o.items[0];
					iFidx=0;
				}
				else {
					oItem=o.items[o.items.selidx];
					iFidx=o.items.selidx;
				}
			}
		}
	}
	
	if(iFidx<o.items.length) {
	    o.ref.setAttribute("iFidx",iFidx);
	    
	    sapUrMapi_setTabIndex(o.items[iOldIndex],"-1");
	}
	
	if(oItem!=null){
		try{
			sapUrMapi_setTabIndex(oItem,0);
			ur_focus(oItem);
		} catch(err){}
		return ur_EVT_cancel(oEvt);
		}
				}
function ur_NL_getObj(sId){
		var oNL=ur_get(sId);
		var oCnt=ur_get(sId+"-cnt");
		var o = {
			ref:oNL,
			items:new Array(),
			end:ur_get(sId+"-end")
			};
	o.ref.pers = ur_get(sId+"-pers");
	var oItems=oCnt.getElementsByTagName("TD");
	for(i=0; i<oItems.length; i++){
		if(oItems[i].getAttribute("idx")!=null || oItems[i].getAttribute("gidx")!=null){
			
			if (oItems[i].getAttribute("st") && oItems[i].getAttribute("st").indexOf("d")>-1 && !ur_system.is508) continue;
			o.items.push(oItems[i]);
		}
				
			}
	for(i=0; i<o.items.length; i++){
		if(o.items[i].getAttribute("sel")!=null){
		   o.items["selected"]=o.items[i].getAttribute("sel");
		}		
		if(o.items[i].id==o.items.selected){
		   o.items["selidx"]=i;
		   break; 
	         }
	}
		return o;
}
function ur_NL_kd(oEvt){
	var o = ur_EVT_src(oEvt);
	 o = sapUrMapi_getRootControl(o);
	var sId = o.getAttribute("id");	
	var oSrcElement=ur_EVT_src(oEvt);
	
  if(oEvt.keyCode==38 || oEvt.keyCode==40 || oEvt.keyCode==9){
	ur_NL_keyNav(oEvt);
   }
   else if(oEvt.keyCode==107 && ur_isSt(o,ur_st.COLLAPSED) && oSrcElement.getAttribute("ct")=="NL")
	 {
		if (ur_isSt(o,ur_st.COLLAPSED))
		{
			mf_FRA_exp(sId);
		}
		return ur_EVT_cancel(oEvt);
	 }
	 
	 else if(oEvt.keyCode==109 && oSrcElement.getAttribute("ct")=="NL")
	 {
		 if (ur_isSt(o,ur_st.EXPANDED))
		 {
			 mf_FRA_col(sId);
		 }
		 return ur_EVT_cancel(oEvt);
	 }
	
	else if(oEvt.keyCode==32 || oEvt.keyCode==13){
		ur_EVT_src(oEvt).click();
		return ur_EVT_cancel(oEvt);
	}	
	
	else if(oEvt.keyCode==39 || oEvt.keyCode==115){
		var oMnuNode=ur_NL_getPrevObj(ur_NL_getItem(oEvt),"pop");
		var sSt = oSrcElement.getAttribute("st");
		
		if(oMnuNode==null || sSt=="d" || sSt==null)return ur_EVT_cancel(oEvt);
		else {
			sChildId=oSrcElement.getAttribute("id");
			sMenuId=oMnuNode.getAttribute("pop");
				if (ur_system.direction=="rtl")
				  sapUrMapi_PopupMenu_showMenu(sChildId,sMenuId,sapPopupPositionBehavior.MENULEFT,oEvt);
				else
			 	  sapUrMapi_PopupMenu_showMenu(sChildId,sMenuId,sapPopupPositionBehavior.MENURIGHT,oEvt);
			return ur_EVT_cancel(oEvt);
		}
	}
	else
		return sapUrMapi_skip(sId,oEvt);
}
function ur_NL_getPrevObj(o,sAt){
		if(!o || !sAt) return null;
		while(ur_getAttD(o,sAt,"")==""){ 
			o=o.parentNode;
			if (!o || o.getAttribute("ct")=="NL") return null;
		}
	return o;
}

//** Paginator.ie5 **

UR_PAGINATOR_BUTTON = {BEGIN:0, PREVIOUS_PAGE:1, PREVIOUS_ITEM:2,NEXT_ITEM:3,NEXT_PAGE:4,END:5};
function sapUrMapi_Paginator_setStates(sId, arrBtns, arrStates) {
	var oPaginator  = ur_get(sId);
	var oButton;
	var bHorizontal = oPaginator.getAttribute("ur_direction")=="horizontal";
	for (var n=0;n<arrBtns.length;n++) {
		try {
		  oButton= ur_get(sId+"-btn-"+arrBtns[n]);
		  if (oButton==null) continue;
		} catch (e) {
		  continue;
		}
		if (arrStates[n]) {
		  if (ur_isSt(oButton,ur_st.DISABLED)) {
		  	var arrClass=oButton.className.split(" ");
		  	arrClass[0]=arrClass[0].replace("Dsbl","");
		  	arrClass[2]=arrClass[2].replace("Dsbl","");
		  	oButton.className=arrClass.join(" ");
		  	ur_setSt(oButton,ur_st.DISABLED,false);
		  	oButton.setAttribute("href","javascript:void(0)");
		  }
		} else {
		  if (!ur_isSt(oButton,ur_st.DISABLED)) {
		  	var arrClass=oButton.className.split(" ");
		  	arrClass[0]=arrClass[0]+"Dsbl";
		  	arrClass[2]=arrClass[2]+"Dsbl";
		  	oButton.className=arrClass.join(" ");
		  	oButton.href=null;
		  	ur_setSt(oButton,ur_st.DISABLED,true);
		  	oButton.removeAttribute("href");
		  }
		}
	}
  sapUrMapi_Focus_showFocusRect();
}
function sapUrMapi_Paginator_buttonDisabled(o) {
  if (o.ct=="PG") return true;
  return ur_isSt(o,ur_st.DISABLED);
}
function sapUrMapi_Paginator_getInputValue(sId) {
  var oInp=ur_get(sId+"-inp");
  if (oInp!=null) return parseInt(oInp.value);
}
function sapUrMapi_Paginator_setInputValue(sId,iNewValue) {
  var oInp=ur_get(sId+"-inp");
  if (oInp!=null) oInp.value=iNewValue;
}
function sapUrMapi_Paginator_click(sId,sConId,oEvt) {
  var o=ur_EVT_src(oEvt);
  if (o.id.indexOf("-btn")==-1) return;
  if (!sapUrMapi_Paginator_buttonDisabled(o)) {
    ur_EVT_fire(o,"ocl",oEvt);
  }
}
function sapUrMapi_Paginator_keydown(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
  if (o.id.indexOf("-btn")==-1) return;
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
    sapUrMapi_triggerClick(oEvt,new Array("32"),o.parentNode); 
  }
  if ((o.id.indexOf("-menu")>-1) && ((oEvt.keyCode==40) || (oEvt.keyCode==13)|| (oEvt.keyCode==32))) {
    return ur_EVT_cancel(oEvt);
  }
  if (oEvt.keyCode>36 && oEvt.keyCode<41) {
	  return ur_EVT_cancel(oEvt);
  }
  if (oEvt.keyCode==32) {
	  return ur_EVT_cancel(oEvt);
  }
  if (oEvt.keyCode>=33 && oEvt.keyCode<=36) {
    var oBtn=null;
		if (oEvt.keyCode==33) { 
			oBtn=ur_get(sId+"-btn-1");
		}
		if (oEvt.keyCode==34) { 
			oBtn=ur_get(sId+"-btn-4");
		}
		if (oEvt.keyCode==36) { 
			oBtn=ur_get(sId+"-btn-0");
		}
		if (oEvt.keyCode==35) { 
			oBtn=ur_get(sId+"-btn-5");
		}
    if (oBtn!=null) { 
      sapUrMapi_focusElement(oBtn.id);
      if (!sapUrMapi_Paginator_buttonDisabled(oBtn)) {
        ur_EVT_fire(oBtn,"ocl",oEvt);
      }
    }
	}
}
function sapUrMapi_Paginator_navBegin(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
		var arrButtonArray = new Array();
		arrButtonArray[0]=UR_PAGINATOR_BUTTON.PREVIOUS_PAGE;
		arrButtonArray[1]=UR_PAGINATOR_BUTTON.PREVIOUS_ITEM;
		arrButtonArray[2]=UR_PAGINATOR_BUTTON.BEGIN;
		arrButtonArray[3]=UR_PAGINATOR_BUTTON.NEXT_PAGE;
		arrButtonArray[4]=UR_PAGINATOR_BUTTON.NEXT_ITEM;
		arrButtonArray[5]=UR_PAGINATOR_BUTTON.END;
		var arrStateArray = new Array();
		arrStateArray[0]=false;
		arrStateArray[1]=false;
		arrStateArray[2]=false;
		arrStateArray[3]=true;
		arrStateArray[4]=true;
		arrStateArray[5]=true;
		sapUrMapi_Paginator_setStates(sId,arrButtonArray,arrStateArray);
		try {
	    if (sapUrMapi_getControlType(sConId)=="PCSEQ") 
	      sapUrMapi_bounceItem(sConId,-1,"PCSEQ");
			if (sapUrMapi_getControlType(sConId)=="PCTAB") 
				sapUrMapi_bounceItem(sConId,-1,"PCTAB");
	  } catch (ex) {}  
		return true;
  }
  return false
}
function sapUrMapi_Paginator_navEnd(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
		var arrButtonArray = new Array();
		arrButtonArray[0]=UR_PAGINATOR_BUTTON.NEXT_PAGE;
		arrButtonArray[1]=UR_PAGINATOR_BUTTON.NEXT_ITEM;
		arrButtonArray[2]=UR_PAGINATOR_BUTTON.END;
		arrButtonArray[3]=UR_PAGINATOR_BUTTON.PREVIOUS_PAGE;
		arrButtonArray[4]=UR_PAGINATOR_BUTTON.PREVIOUS_ITEM;
		arrButtonArray[5]=UR_PAGINATOR_BUTTON.BEGIN;
		var arrStateArray = new Array();
		arrStateArray[0]=false;
		arrStateArray[1]=false;
		arrStateArray[2]=false;
		arrStateArray[3]=true;
		arrStateArray[4]=true;
		arrStateArray[5]=true;
		sapUrMapi_Paginator_setStates(sId,arrButtonArray,arrStateArray);
		try {
	    if (sapUrMapi_getControlType(sConId)=="PCSEQ") 
	      sapUrMapi_bounceItem(sConId,1,"PCSEQ");
			if (sapUrMapi_getControlType(sConId)=="PCTAB") 
				sapUrMapi_bounceItem(sConId,1,"PCTAB");
	  } catch (ex) {}  
		return true;
  }
  return false;
}
function sapUrMapi_Paginator_navPrevPage(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
		try {
	    if (sapUrMapi_getControlType(sConId)=="PCSEQ") 
	      ur_PcSeq_pageItem(sConId,-1,"PCSEQ");
			if (sapUrMapi_getControlType(sConId)=="PCTAB") 
				sapUrMapi_pageItem(sConId,-1,"PCTAB");				
	  } catch (ex) {}  
		return true;
  }
  return false;
}
function	sapUrMapi_Paginator_navNextPage(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
		try {
	    if (sapUrMapi_getControlType(sConId)=="PCSEQ") 
	      ur_PcSeq_pageItem(sConId,1,"PCSEQ");
	        if (sapUrMapi_getControlType(sConId)=="PCTAB") 
				sapUrMapi_pageItem(sConId,1,"PCTAB");
			
	  } catch (ex) {}  
		return true;
  }
  return false;
}
function sapUrMapi_Paginator_navPrev(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
		try {
	    if (sapUrMapi_getControlType(sConId)=="PHI") 
	        sapUrMapi_PhaseIndicator_paging(sConId,"BACK");
	    if (sapUrMapi_getControlType(sConId)=="PCSEQ") 
	      ur_PcSeq_scrollItem(sConId,-1,"PCSEQ");
			if (sapUrMapi_getControlType(sConId)=="PCTAB") 
				sapUrMapi_scrollItem(sConId,-1,"PCTAB");
			if(sapUrMapi_getControlType(sConId)=="TS")
			{
				ur_IScr_toPrevItem(sConId);
				var oCon = ur_get(sConId);
				var ifocIdx = parseInt(oCon.getAttribute('fidx'));
				if(ifocIdx > 0)
					ur_TS_setTabIdx(sConId,ifocIdx,-1);
			    ur_EVT_addParam(oEvt,"FirstVisibleItemIdx",ur_IScr[sConId].first);
			}
	    } catch (ex) {}  
		return true;
  }
  return false;
}
function sapUrMapi_Paginator_navNext(sId,sConId,oEvt) {
  o=ur_evtSrc(oEvt);
	if (!sapUrMapi_Paginator_buttonDisabled(o)) {
    try {
	    if (sapUrMapi_getControlType(sConId)=="PHI") 
	      sapUrMapi_PhaseIndicator_paging(sConId,"FURTHER");
	    if (sapUrMapi_getControlType(sConId)=="PCSEQ") 
	      ur_PcSeq_scrollItem(sConId,1,"PCSEQ");
	    if (sapUrMapi_getControlType(sConId)=="PCTAB") 
	      sapUrMapi_scrollItem(sConId,1,"PCTAB");
		if(sapUrMapi_getControlType(sConId)=="TS")
		{
		  ur_IScr_toNextItem(sConId);	      	      
		  var oCon = ur_get(sConId);
		  var ifocIdx = parseInt(oCon.getAttribute('fidx'));
		  var iCount = parseInt(oCon.getAttribute('ic'));
		  if(ifocIdx < iCount )
			ur_TS_setTabIdx(sConId,ifocIdx,-1);
		  ur_EVT_addParam(oEvt,"FirstVisibleItemIdx",ur_IScr[sConId].first);
		}
	  } catch (ex) {}  
		return true;
  }
  return false;
}
function sapUrMapi_Paginator_showMenu(sId,sMenuId,sConId,oEvt) {
  if (oEvt.type=="click" || (oEvt.keyCode==40) || (oEvt.keyCode==13)|| (oEvt.keyCode==32)) {
    if (sapUrMapi_getControlType(sConId)=="TS") {
      sId=sConId+"-pg";
    }
    sapUrMapi_PopupMenu_showMenu(sId+"-menu",sMenuId,sapPopupPositionBehavior.MENURIGHT,oEvt);
  }
  return false;
}
function ur_Paginator_triggerClick(sId,enumButton) {
  var oBtn=null;
	oBtn=ur_get(sId+"-btn-"+enumButton);
  if (oBtn!=null) { 
    if (!sapUrMapi_Paginator_buttonDisabled(oBtn)) {
      oBtn.click();
      return true;
    }
  }
}
function sapUrMapi_Paginator_enrichParameters(sConId) {
	try {
		if (sapUrMapi_getControlType(sConId)=="PHI") {
	  	return sapUrMapi_PhaseIndicator_getFirstVisible(ur_get(sConId));
	   }
	} catch (ex) {}  
	return "";
}
function sapUrMapi_Paginator_removeFromTabChain(sId) {
  var o=ur_get(sId);
  if (!o.hasChildNodes) return;
  var oC=o.childNodes;
  for (var i=0;i<oC.length;i++) sapUrMapi_setTabIndex(oC[i],-1);
}

//** PatternContainerContentItem.nn7 **

function sapUrMapi_Pc_Resize(sId) {
	sapUrMapi_Resize_AddItem(sId, "sapUrMapi_PcTabSeq_Draw('" + sId + "')");
}
function sapUrMapi_Pc_RegisterCreate(sId) {
	sapUrMapi_PcTabSeq_Create(sId);
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_PcTabSeq_Draw('" + sId + "')");
}
function sapUrMapi_Pc_toggle(sId, sCtlType, e) {
	if ((e.type!="click") && (!sapUrMapi_checkKey(e,"keydown",new Array("32","30")))) return false;
	e.cancelBubble=true;
	var tbdy = ur_get(sId+"-tbd");
	var tbl = tbdy.parentNode;
	var tbar = ur_get(sId+"-tbar");
	var thead = ur_get(sId+"-hd");
	var ico = ur_get(sId+"-exp");
	if ( tbdy != null && ico != null ) {
		if ( tbdy.style.display == "none" ) {
			if (tbar) tbar.style.display = "";
			tbdy.style.display = "";
			
			if (tbl.getAttribute("sized") != "true"){
				sapUrMapi_Pc_Create(sId, tbl.getAttribute("scrolltype"), false );
			}
			if (ico.className.indexOf("urPcExpClosedIco") != -1){ ico.className = ico.className.replace("urPcExpClosedIco", "urPcExpOpenIco");}
			if (thead != null && thead.className == "urPcHdBgClosedIco" ){ thead.className = "urPcHdBgOpenIco";}
			if (ur_system.is508) {
				ico.title=getLanguageText(sCtlType + "_COLLAPSE",new Array(thead.innerText,sCtlType + "_COLLAPSE_KEY"));
			}
		} else {
			if (tbar){ tbar.style.display = "none";}
			var helper = tbdy.parentNode.offsetWidth;
			tbdy.style.display = "none";
			tbdy.parentNode.style.width=helper+"px";
			if (ico.className.indexOf("urPcExpOpenIco") != -1 ){ ico.className = ico.className.replace("urPcExpOpenIco", "urPcExpClosedIco");}
			if (thead != null && thead.className == "urPcHdBgOpenIco" ){ thead.className = "urPcHdBgClosedIco";}
			if (ur_system.is508) {
				ico.title=getLanguageText(sCtlType + "_EXPAND",new Array(thead.innerText, sCtlType + "_EXPAND_KEY"));
			}
	}
		
		sapUrMapi_focusElement(sId+"-exp")
}
	return true;
}
function sapUrMapi_Pc_showOptionMenu(sId,e) {
  var sTrayId=sId;
  var sTriggerId=sId+"-menu";
  var sMenuContentId=ur_get(sTriggerId).getAttribute("mid");
 	if (ur_system.direction=="rtl")
	  var enumPositionBehavior=sapPopupPositionBehavior.MENULEFT;
	else
	  var enumPositionBehavior=sapPopupPositionBehavior.MENURIGHT;
  var sControlType=sapUrMapi_getControlTypeFromObject(ur_get(sId));
	switch (sControlType) {
		case "PCTAB" :
			if (e.type!="click") {
				if (sapUrMapi_checkKey(e,"keydown",new Array("32","40","13"))){
					sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
				}
				else if (sapUrMapi_checkKey(e,"keydown",new Array("39","37"))) {
					var intTabCount = parseInt(ur_get(sTrayId + "-tbl").getAttribute("tabcount"));
					if (ur_system.direction=="rtl") {
					  sapUrMapi_PcTabs_focusItem(sTrayId,null,null,e.keyCode==37,e.keyCode==39);
					} else {
					  sapUrMapi_PcTabs_focusItem(sTrayId,null,null,e.keyCode==39,e.keyCode==37);
					}
					return;
				}
				else {
					return false;
				}
			}
			else {
				sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
			}
			break;
		case "PCSEQ" :
			if (e.type!="click") {
				if (sapUrMapi_checkKey(e,"keydown",new Array("32","40","13"))){
					sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
				}
				else if (sapUrMapi_checkKey(e,"keydown",new Array("39","37"))) {
					var intTabCount = parseInt(ur_get(sTrayId + "-tbl").getAttribute("tabcount"));
					if (ur_system.direction=="rtl") {
					  sapUrMapi_PcSeq_focusItem(sTrayId,null,null,e.keyCode==37,e.keyCode==39);
					} else {
					  sapUrMapi_PcSeq_focusItem(sTrayId,null,null,e.keyCode==39,e.keyCode==37);
					}
					return;
				}
				else {
					return false;
				}
			}
			else {
				sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
			}
			break;
		case "PCTIT" :
			if (e.type!="click") {
				if (sapUrMapi_checkKey(e,"keydown",new Array("32","40","13"))){
					sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
				}
			}
			else {
			  sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
			}
			break;
		default :
			return;
	}
}
function sapUrMapi_PcTab_Resize(sId) {
	sapUrMapi_Resize_AddItem(sId, "sapUrMapi_PcTabSeq_Draw('" + sId + "')");
}
function sapUrMapi_PcTabSeq_RegisterCreate(sId) {
	sapUrMapi_PcTabSeq_Create(sId);
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_PcTabSeq_Draw('" + sId + "')");
}
var sapUrMapi_PcTabSeq_Registry = new Array();
function sapUrMapi_PcTabSeq_Create(sId) {
	sapUrMapi_PcTabSeq_Registry[sId] = false;
	
	var bCollapsed = ur_get(sId).getAttribute("collapsed");
	var tbl = ur_get(sId + "-tbd").parentNode;
	if (bCollapsed == "true"){
		tbl.setAttribute("sized", "false");
	}
	else{
		tbl.setAttribute("sized", "true");
	}
	
	sapUrMapi_Resize_AddItem(sId, "sapUrMapi_PcTabSeq_Draw('" + sId + "')");
	sapUrMapi_PcTabSeq_Registry[sId] = true;
}
function sapUrMapi_PcTabSeq_Draw() {
	var divlist = new Array();
	var tbdylist = new Array();
	var iIdx = "null";
	for (var ctls in sapUrMapi_PcTabSeq_Registry) {
		if (ctls.indexOf("_") == 0) {continue;}
		var tbdy = ur_get(ctls + "-tbd");
		tbdylist[ctls] = tbdy;
		divlist[ctls] = null;
		if (tbdy.style.display == "none") {
			continue;
		}
		iIdx = ur_get(ctls + "-tbl").getAttribute("selectedtab");
		if (iIdx == -9999) {
			iIdx = "Title";
		}
		var div = ur_get(ctls + "-cnt-" + iIdx);
		if (div==null) return;
		divlist[ctls] = div;
		for (i = 0; i < div.childNodes.length; i++) {
			if (div.childNodes[i].nodeType == 1) {div.childNodes[i].style.display = "none";}
		}
	}
	for (var ctls in sapUrMapi_PcTabSeq_Registry) {
		if ((ctls.indexOf("_") == 0) || (tbdylist[ctls].style.display == "none")) {
			continue;
		}
		var div = divlist[ctls];
		var maxWidth = parseInt(div.offsetWidth);
		for (var i = 0; i < div.childNodes.length; i++) {
			if (div.childNodes[i].nodeType == 1) {div.childNodes[i].style.width = (maxWidth - 1) + "px";}
		}
	}
	for (var ctls in sapUrMapi_PcTabSeq_Registry) {
		if ((ctls.indexOf("_") == 0) || (tbdylist[ctls].style.display == "none")) {
			continue;
		}
		var div = divlist[ctls];
		for (var i = 0; i < div.childNodes.length; i++) {
			if (div.childNodes[i].nodeType == 1) {
			if (div.childNodes[i].style.display == "none") {
				div.childNodes[i].style.display = "";
				}
			}
		}
	}
}
function sapUrMapi_PcTabs_getSelectedItemId(sTabStripId) {
  var oTabTable 	= ur_get(sTabStripId+"-tbl");
	var iSelTab			=	parseInt(oTabTable.getAttribute("selectedtab"));
	return sTabStripId+"-itm-"+iSelTab;
}
function sapUrMapi_PcTabs_focusItem(sTabStripId,iFocusIdx,iTabCount,bNext,bPrev) {
	var oTabTable = ur_get(sTabStripId+"-tbl");
	if (isNaN(iFocusIdx)) {iFocusIdx = parseInt(oTabTable.getAttribute("selectedtab"));}
	if (isNaN(iTabCount)) {iTabCount = parseInt(oTabTable.getAttribute("tabcount"));}
	var ico = ur_get(sTabStripId + "-menu");
	var iNewIndex=iFocusIdx;
	if (ico != null && ico.getAttribute("hasfocus") == "true") {
		if (bNext) {
			iNewIndex = parseInt(oTabTable.getAttribute("starttab"));
		}
		if (bPrev) {
			iNewIndex = parseInt(oTabTable.getAttribute("starttab")) - 1 + parseInt(oTabTable.getAttribute("vistabs"));
		}
	}
	else {
		if (bNext) {
			if (iFocusIdx<iTabCount-1) iNewIndex=iFocusIdx+1;
			else iNewIndex=0;
		}
		if (bPrev) {
			if (iFocusIdx>0) iNewIndex=iFocusIdx-1;
			else iNewIndex=iTabCount-1;
		}
	}
	oFocusedTab = ur_get(sTabStripId+"-itm-"+iNewIndex);
	if (oFocusedTab.style.display != "none") {
		var iOldFoc     = parseInt(oTabTable.getAttribute("focusedtab"));
		if (!isNaN(iOldFoc)) {
			sapUrMapi_setTabIndex(ur_get(sTabStripId+"-itm-"+iOldFoc+"-txt"),-1);
		}
		var oFoc = ur_get(sTabStripId+"-itm-"+iNewIndex+"-txt");
		sapUrMapi_setTabIndex(oFoc,0);
		
		sapUrMapi_focusElement(oFoc.id);
		oTabTable.setAttribute("focusedtab",iNewIndex);
		if (ico != null) {
			ico.setAttribute("hasfocus", "false");
		}
		if ((oFocusedTab.getAttribute("dsbl")=="true")&&(!ur_system.is508)) {
			sapUrMapi_PcTabs_focusItem(sTabStripId,iNewIndex,iTabCount,bNext,bPrev);
			return;
		}
	}
	else {
	    if (ico != null) {
			sapUrMapi_setTabIndex(ico,0);
			ico.setAttribute("hasfocus", "true");
			sapUrMapi_focusElement(ico.id);
	    }
	}
}
function sapUrMapi_PcTabs_enter (sId,e) {
	if (e.target.id==sId+"-skipstart") {
		if (sapUrMapi_Skip(sId,true,e)) return;
    if (!e.shiftKey) { 
		  if (sapUrMapi_checkKey(e,"keydown",new Array("9","39","37"))){
	      sapUrMapi_PcTabs_focusItem(sId);
			  e.cancelBubble=false;
		  }
	  }
	}
}
function sapUrMapi_PcTabs_setActiveItem(sId,iIdx) {
	with (document) {
		var oTabTable 	= getElementById(sId+"-tbl");
		var tbdy = getElementById(sId+"-tbd");
		var iSelTab			=	parseInt(oTabTable.getAttribute("selectedtab"));
		var iTabLength	=	parseInt(oTabTable.getAttribute("tabcount"));
		var iCurIdx = parseInt(oTabTable.getAttribute("starttab"));
		var iVisTabs = parseInt(oTabTable.getAttribute("vistabs"));
		if (isNaN(iIdx)) return;
		if (getElementById(sId+"-itm-"+iIdx).getAttribute("dsbl")=="true") return false; 
		if ((iTabLength==1) || (iSelTab==iIdx)) return true; 
		var oCurrentTxt  = getElementById(sId+"-itm-"+iSelTab+"-txt");
		var oCurrentCell = getElementById(sId+"-itm-"+iSelTab);
		var oCurrentCon = getElementById(sId+"-itm-"+iSelTab+"-c");
		var oClickedTxt  = getElementById(sId+"-itm-"+iIdx+"-txt");
		var oClickedCell = getElementById(sId+"-itm-"+iIdx);
		var oClickedCon = getElementById(sId+"-itm-"+iIdx+"-c");
		var oFirstImage  = getElementById(sId+"-p");
		var oLastImage   = getElementById(sId+"-n");
		if (oCurrentCell != null){
			oCurrentCell.className="urPcTbsLabelOff"; 
			oCurrentTxt.className = "urPcTbsTxtOff";  
			if (oCurrentCon != null){
				oCurrentCon.className = "urPcConOff";	
			}
		}
		oClickedTxt.className = "urPcTbsTxtOn";   
		oClickedCell.className="urPcTbsLabelOn";  
		if (oClickedCon != null){
			oClickedCon.className = "urPcConOn";	
		}
		
		if (iCurIdx != 0){
			if (iIdx!=iCurIdx){oFirstImage.className="urPcTbsFirstAngOffPrevOn"; }
			else{oFirstImage.className="urPcTbsFirstAngOnPrevOn"; }
		}
		else{
			if (iIdx!=iCurIdx){oFirstImage.className="urPcTbsFirstAngOffPrevOff"; }
			else{oFirstImage.className="urPcTbsFirstAngOnPrevOff"; }
		}
		
		if (iCurIdx + iVisTabs >= iTabLength){
			if (iIdx == iTabLength - 1){
				oLastImage.className="urPcTbsLastOnNextOff"; 
			}
			else{
				if (iIdx != (iCurIdx + iVisTabs - 1)){oLastImage.className="urPcTbsLastOffNextOff"; }
				else{oLastImage.className="urPcTbsLastOnNextOff"; }
			}
		}
		else{  
			if (iIdx != (iCurIdx + iVisTabs - 1))oLastImage.className="urPcTbsLastOffNextOn"; 
			else{oLastImage.className="urPcTbsLastOnNextOn"; }
		}
		
		if (iSelTab == iCurIdx){
			getElementById(sId+"-itm-"+(iSelTab)+"-a").className="urPcTbsAngOffOff";
			getElementById(sId+"-itm-"+(iSelTab+1)+"-a").className="urPcTbsAngOffOff";
		} else  {
			getElementById(sId+"-itm-"+(iSelTab)+"-a").className="urPcTbsAngOffOff";
			if (iSelTab != iTabLength - 1){
				getElementById(sId+"-itm-"+(iSelTab+1)+"-a").className="urPcTbsAngOffOff";
			}
		}
		
		if (iIdx==iCurIdx){
			getElementById(sId+"-itm-"+(iIdx)+"-a").className="urPcTbsAngOffOn";
			getElementById(sId+"-itm-"+(iIdx+1)+"-a").className="urPcTbsAngOnOff";
		} else {
			getElementById(sId+"-itm-"+(iIdx)+"-a").className="urPcTbsAngOffOn";
			if (iIdx != iTabLength - 1) {
				getElementById(sId+"-itm-"+(iIdx+1)+"-a").className="urPcTbsAngOnOff";
			}
		}
		oTabTable.setAttribute("selectedtab",iIdx); 
		sapUrMapi_PcTabs_focusItem(sId,iIdx); 
		
		var oCurrentContent  = getElementById(sId+"-cnt-"+iSelTab);
		var oClickedContent  = getElementById(sId+"-cnt-"+iIdx);
		
		if (tbdy.style.display != "none") {
			var maxwidth = parseInt(oCurrentContent.clientWidth);
			for (var i = 0; i < oClickedContent.childNodes.length; i++){
				oClickedContent.childNodes[i].style.width = (maxwidth - 1) + "px";
				}
			}
		
		oClickedContent.className = "urPcTbsDspSel";
		oCurrentContent.className = "urPcTbsDsp";
	}
	if (ur_system.is508) {
		oClickedTxt.title = getLanguageText("SAPUR_PCTABS_ITEM",new Array(oClickedTxt.innerText,"SAPUR_PCTABS_ITEM_SELECTED"));
		oCurrentTxt.title = getLanguageText("SAPUR_PCTABS_ITEM",new Array(oCurrentTxt.innerText,"SAPUR_PCTABS_ITEM_ENABLED"));
	}
	return true
}
function sapUrMapi_PcTabs_keySelect(sId, iSelectedIdx, iTabCount,e) {
	if (sapUrMapi_checkKey(e,"keydown",new Array("39","37"))){
	  if (ur_system.direction=="rtl") {
	    sapUrMapi_PcTabs_focusItem(sId,iSelectedIdx,iTabCount,e.keyCode==37,e.keyCode==39);
		return;
	  } else {
		sapUrMapi_PcTabs_focusItem(sId,iSelectedIdx,iTabCount,e.keyCode==39,e.keyCode==37);
		return;
	  }
	}
	if (sapUrMapi_checkKey(e,"keydown",new Array("32"))){
		sapUrMapi_PcTabs_setActiveItem(sId,iSelectedIdx,0,false);
		return;
	}
}
function sapUrMapi_scrollItem( sId, iDir, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	if (iDir != -1 && iDir != 1){
		return false;
	}
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
	var diff = vistabs;
	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs - 1;}
	}
	if (lasttab != firsttab + vistabs - 1){
		diff = lasttab - firsttab;
	}
	if (iDir == 1){
		
		if (lasttab == tabcount - 1){return false;}
		
		SCROLL_FUNCTIONS[sCtlType](sId, firsttab, false, true, false);
		
		firsttab += 1;
		SCROLL_FUNCTIONS[sCtlType](sId, firsttab, true, true, false);
		if (diff > 2) {
			
			SCROLL_FUNCTIONS[sCtlType](sId, lasttab, true, false, false);
		}
		if (diff != 1) {
		
		lasttab += 1;
		SCROLL_FUNCTIONS[sCtlType](sId, lasttab, true, false, true);
	}
	else{
		
		lasttab = firsttab;
		SCROLL_FUNCTIONS[sCtlType](sId, lasttab, true, true, true);
		}
	}
	else{
		
		if (firsttab == 0){return false;}
		
		
		if (diff >= vistabs - 1){
			
			SCROLL_FUNCTIONS[sCtlType](sId, lasttab, false, false, true);
			
			lasttab -= 1;
			SCROLL_FUNCTIONS[sCtlType](sId, lasttab, true, false, true);
		}
		if (diff > 1) {
		
		SCROLL_FUNCTIONS[sCtlType](sId, firsttab, true, false, false);
		
		firsttab -= 1;
		SCROLL_FUNCTIONS[sCtlType](sId, firsttab, true, true, false);
	}
		else {
		
    SCROLL_FUNCTIONS[sCtlType](sId, firsttab, true, false, true);
		firsttab -= 1;
		SCROLL_FUNCTIONS[sCtlType](sId, firsttab, true, true, true);
		}
	}
	
	ICON_FUNCTIONS[sCtlType]( sId, firsttab, lasttab, tabcount );
	
	var newtabpage = Math.floor(firsttab / vistabs);
	oTabs.setAttribute("starttab", firsttab);
	oTabs.setAttribute("lasttab", lasttab);
	sapUrMapi_Pc_togglePager(sId)
}
function sapUrMapi_pageItem( sId, iDir, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	if (iDir != 1 && iDir != -1){
		return false;
	}
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs-1;}
	}
	
	if ((iDir == -1 && firsttab == 0) || ( iDir == 1 && lasttab == tabcount -1)){
		return false;
	}
	
	if (((iDir == 1) && ((tabpage + iDir) * vistabs) < (tabcount)) ||
		((iDir == -1) && (tabpage + iDir >= 0) )){
		tabpage = tabpage + iDir;
	}
	
	var lbound = Math.floor(tabpage * vistabs);
	var ubound = lbound + vistabs - 1;
	
	if (ubound > tabcount - 1){
		ubound = tabcount -1;
	}
	
	for (var i = 0; i < tabcount; i++){
		
		if (i < lbound || i > ubound){
			if (i == firsttab){
				SCROLL_FUNCTIONS[sCtlType](sId, i, false, true, false);
			}
			else if (i == lasttab){
				SCROLL_FUNCTIONS[sCtlType](sId, i, false, false, true);
			}
			else{
			   SCROLL_FUNCTIONS[sCtlType](sId, i, false, false, false);
			}
		}
		else{
		   if (i == lbound){
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, true, false);
		   }
		   else if (i == tabcount -1 || i == ubound){
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, false, true);
		   }
		   else{
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, false, false);
		   }
		}
	}
	
	ICON_FUNCTIONS[sCtlType]( sId, lbound, ubound, tabcount );
	
	oTabs.setAttribute("starttab", lbound);
	oTabs.setAttribute("lasttab", ubound);
	oTabs.setAttribute("tabpage", tabpage);
	sapUrMapi_Pc_togglePager(sId)
}
function sapUrMapi_boundsItem( sId, iDir, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	if (iDir != 1 && iDir != -1){
		return false;
	}
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs-1;}
	}
	
	if ((iDir == -1 && firsttab == 0) || ( iDir == 1 && lasttab == tabcount -1)){
		return false;
	}
	
	if (iDir == 1){
		tabpage = Math.ceil(tabcount / vistabs) - 1;
	}
	else{
		tabpage = 0;
	}
	
	var lbound = Math.floor(tabpage * vistabs);
	var ubound = lbound + vistabs - 1;
	
	if (ubound > tabcount - 1){
		ubound = tabcount -1;
	}
	
	for (var i = 0; i < tabcount; i++){
		
		if (i < lbound || i > ubound){
			if (i == firsttab){
				SCROLL_FUNCTIONS[sCtlType](sId, i, false, true, false);
			}
			else if (i == lasttab){
				SCROLL_FUNCTIONS[sCtlType](sId, i, false, false, true);
			}
			else{
			   SCROLL_FUNCTIONS[sCtlType](sId, i, false, false, false);
			}
		}
		else{
		   if (i == lbound){
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, true, false);
		   }
		   else if (i == tabcount -1 || i == ubound){
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, false, true);
		   }
		   else{
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, false, false);
		   }
		}
	}
	
	ICON_FUNCTIONS[sCtlType]( sId, lbound, ubound, tabcount );
	
	oTabs.setAttribute("starttab", lbound);
	oTabs.setAttribute("lasttab", ubound);
	oTabs.setAttribute("tabpage", tabpage);
	sapUrMapi_Pc_togglePager(sId)
}
function sapUrMapi_jumpItem( sId, iTab, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
	var seltab = parseInt(oTabs.getAttribute("selectedtab"));
	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs-1;}
	}
	
	if (iTab >= tabcount || iTab < 0){
		return false;
	}
	
	var tabpage = Math.floor(iTab / vistabs);
	
	var lbound = Math.floor(tabpage * vistabs);
	var ubound = lbound + vistabs - 1;
	
	if (ubound > tabcount - 1){
		ubound = tabcount -1;
	}
	
	for (var i = 0; i < tabcount; i++){
		
		if (i < lbound || i > ubound){
			if (i == firsttab){
				SCROLL_FUNCTIONS[sCtlType](sId, i, false, true, false);
			}
			else if (i == lasttab){
				SCROLL_FUNCTIONS[sCtlType](sId, i, false, false, true);
			}
			else{
			   SCROLL_FUNCTIONS[sCtlType](sId, i, false, false, false);
			}
		}
		else{
		   if (i == lbound){
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, true, false);
		   }
		   else if (i == tabcount -1 || i == ubound){
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, false, true);
		   }
		   else{
				SCROLL_FUNCTIONS[sCtlType](sId, i, true, false, false);
		   }
		}
	}
	
	oTabs.setAttribute("starttab", lbound);
	oTabs.setAttribute("lasttab", ubound);
	oTabs.setAttribute("tabpage", tabpage);
	sapUrMapi_Pc_togglePager(sId)
	
	
	SELECT_FUNCTIONS[sCtlType](sId, iTab, seltab, false);
	
	ICON_FUNCTIONS[sCtlType]( sId, lbound, ubound, tabcount );
}
function showTab(sId, iIdx, bShow, bIsFirst, bIsLast ){
	
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var tabimg = ur_get(sId + "-itm-" + iIdx + "-a");
	var tabcell = ur_get(sId + "-itm-" + iIdx);
	
	var conimg = ur_get(sId + "-itm-" + iIdx + "-ca");
	var concell = ur_get(sId + "-itm-" + iIdx + "-c");
	if (bShow){
		
		if (!bIsFirst && !bIsLast){
			tabimg.style.display = "";
			tabcell.style.display = "";
			if (concell != null){
				concell.style.display = "";
				conimg.style.display = "";
			}
		}
		else if (bIsFirst){
			tabimg.style.display = "none";
			tabcell.style.display = "";
			if (concell != null){
				concell.style.display = "";
				conimg.style.display = "none";
			}
		}
		else if (bIsLast && !bIsFirst){
			tabimg.style.display = "";
			tabcell.style.display = "";
			if (concell != null){
				concell.style.display = "";
				conimg.style.display = "";
			}
		}
	}
	else{
		
		tabimg.style.display = "none";
		tabcell.style.display = "none";
		if (concell != null){
			concell.style.display = "none";
			conimg.style.display = "none";
		}
	}
}
function setTabIcons( sId, firsttab, lasttab, tabcount ){
	var prev = ur_get(sId + "-p");
	var next = ur_get(sId + "-n");
	var first = ur_get(sId + "-itm-" + firsttab);
	var last = ur_get(sId + "-itm-" + lasttab);
	var prevtmp = prev.className;
	var nexttmp = next.className
	
	if (firsttab == 0){
		if (first.className.indexOf("LabelOn") != -1){
			prev.className = "urPcTbsFirstAngOnPrevOff";
		}
		else{
			prev.className = "urPcTbsFirstAngOffPrevOff";
		}
	}
	else{
		if (first.className.indexOf("LabelOn") != -1){
			prev.className = "urPcTbsFirstAngOnPrevOn";
		}
		else{
			prev.className = "urPcTbsFirstAngOffPrevOn";
		}
	}
	
	if (lasttab == tabcount - 1){
		if (last.className.indexOf("LabelOn") != -1){
			next.className = "urPcTbsLastOnNextOff";
		}
		else{
			next.className = "urPcTbsLastOffNextOff";
		}
	}
	else{
		if (last.className.indexOf("LabelOn") != -1){
			next.className = "urPcTbsLastOnNextOn";
		}
		else{
			next.className = "urPcTbsLastOffNextOn";
		}
	}
	prev.childNodes.item(0).className = "urPcTbsPreFirstAng";
	next.childNodes.item(0).className = "urPcTbsAfterLastAng";
}
try{
SCROLL_FUNCTIONS = {PCTAB:showTab,PCSEQ:showItem};
ICON_FUNCTIONS = {PCTAB:setTabIcons,PCSEQ:setSeqIcons}
SELECT_FUNCTIONS = {PCTAB:sapUrMapi_PcTabs_setActiveItem,PCSEQ:sapUrMapi_PcSeq_setActiveItem}
}catch(ex){};
function debug_jumpItem(elm){
	for (var i = 0; i < elm.options.length; i++){
		if (elm.options[i].selected == true){
			sapUrMapi_jumpItem( elm.getAttribute("control"), i, elm.getAttribute('controltype'));
		}
	}
}
function sapUrMapi_Pc_togglePager(sId) {
  if (ur_get(sId+"-pag")!=null) {
    var sPagerId=ur_get(sId+"-pag").firstChild.id;
  } else {
    return;
  }
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
  var arrButtonArray = new Array();
	var arrStateArray = new Array();
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.BEGIN;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.PREVIOUS_PAGE;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.PREVIOUS_ITEM;
	if (firsttab!=0) {
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	} else {
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	}
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.END;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.NEXT_PAGE;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.NEXT_ITEM;
	if (lasttab!=tabcount-1) {
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	} else {
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	}
  sapUrMapi_Paginator_setStates(sPagerId,arrButtonArray,arrStateArray);
}
//** PatternContainerSequence.nn7 **

function ur_PcSeq_Resize(sId) {
	sapUrMapi_Resize_AddItem(sId, "ur_PcSeq_Draw('" + sId + "')");
}
function ur_PcSeq_RegisterCreate(sId) {
	ur_PcSeq_Create(sId);
	sapUrMapi_Create_AddItem(sId, "ur_PcSeq_Draw('" + sId + "')");
}
var ur_PcSeq_Registry = new Array();
function ur_PcSeq_Create(sId) {
	ur_PcSeq_Registry[sId] = false;
	
	var bCollapsed = ur_get(sId).getAttribute("collapsed");
	var tbl = ur_get(sId + "-tbd").parentNode;
	if (bCollapsed == "true"){
		tbl.setAttribute("sized", "false");
	}
	else{
		tbl.setAttribute("sized", "true");
	}
	
	sapUrMapi_Resize_AddItem(sId, "ur_PcSeq_Draw('" + sId + "')");
	ur_PcSeq_Registry[sId] = true;
}
function ur_PcSeq_Draw() {
	var divlist = new Array();
	var tbdylist = new Array();
	var iIdx = "null";
	for (var ctls in ur_PcSeq_Registry) {
		if (ctls.indexOf("_") == 0) {continue;}
		var tbdy = ur_get(ctls + "-tbd");
		tbdylist[ctls] = tbdy;
		divlist[ctls] = null;
		if (tbdy.style.display == "none") {
			continue;
		}
		iIdx = ur_get(ctls + "-tbl").getAttribute("selectedtab");
		if (iIdx == -9999) {
			iIdx = "Title";
		}
		var div = ur_get(ctls + "-cnt-" + iIdx);
		if (div==null) return;
		divlist[ctls] = div;
		for (i = 0; i < div.childNodes.length; i++) {
			if (div.childNodes[i].nodeType == 1) {div.childNodes[i].style.display = "none";}
		}
	}
	for (var ctls in ur_PcSeq_Registry) {
		if ((ctls.indexOf("_") == 0) || (tbdylist[ctls].style.display == "none")) {
			continue;
		}
		var div = divlist[ctls];
		var maxWidth = parseInt(div.offsetWidth);
		for (var i = 0; i < div.childNodes.length; i++) {
			if (div.childNodes[i].nodeType == 1) {div.childNodes[i].style.width = (maxWidth - 1) + "px";}
		}
	}
	for (var ctls in ur_PcSeq_Registry) {
		if ((ctls.indexOf("_") == 0) || (tbdylist[ctls].style.display == "none")) {
			continue;
		}
		var div = divlist[ctls];
		for (var i = 0; i < div.childNodes.length; i++) {
			if (div.childNodes[i].nodeType == 1) {
			if (div.childNodes[i].style.display == "none") {
				div.childNodes[i].style.display = "";
				}
			}
		}
	}
}
function ur_PcSeq_toggle(sId, sCtlType, e) {
	if ((e.type!="click") && (!sapUrMapi_checkKey(e,"keydown",new Array("32","30")))) return false;
	e.cancelBubble=true;
	var tbdy = ur_get(sId+"-tbd");
	var tbl = tbdy.parentNode;
	var tbar = ur_get(sId+"-tbar");
	var thead = ur_get(sId+"-hd");
	var ico = ur_get(sId+"-exp");
	if ( tbdy != null && ico != null ) {
		if ( tbdy.style.display == "none" ) {
			if (tbar) tbar.style.display = "";
			tbdy.style.display = "";
			
			if (tbl.getAttribute("sized") != "true"){
				sapUrMapi_Pc_Create(sId, tbl.getAttribute("scrolltype"), false );
			}
			if (ico.className.indexOf("urPcExpClosedIco") != -1){ ico.className = ico.className.replace("urPcExpClosedIco", "urPcExpOpenIco");}
			if (thead != null && thead.className == "urPcHdBgClosedIco" ){ thead.className = "urPcHdBgOpenIco";}
			if (ur_system.is508) {
				ico.title=getLanguageText(sCtlType + "_COLLAPSE",new Array(thead.innerText,sCtlType + "_COLLAPSE_KEY"));
			}
		} else {
			if (tbar){ tbar.style.display = "none";}
			var helper = tbdy.parentNode.offsetWidth;
			tbdy.style.display = "none";
			tbdy.parentNode.style.width=helper+"px";
			if (ico.className.indexOf("urPcExpOpenIco") != -1 ){ ico.className = ico.className.replace("urPcExpOpenIco", "urPcExpClosedIco");}
			if (thead != null && thead.className == "urPcHdBgOpenIco" ){ thead.className = "urPcHdBgClosedIco";}
			if (ur_system.is508) {
				ico.title=getLanguageText(sCtlType + "_EXPAND",new Array(thead.innerText, sCtlType + "_EXPAND_KEY"));
			}
	}
		
		sapUrMapi_focusElement(sId+"-exp")
}
	return true;
}
function ur_PcSeq_showOptionMenu(sId,e) {
  var sTrayId=sId;
  var sTriggerId=sId+"-menu";
  var sMenuContentId=ur_get(sTriggerId).getAttribute("mid");
 	if (ur_system.direction=="rtl")
	  var enumPositionBehavior=sapPopupPositionBehavior.MENULEFT;
	else
	  var enumPositionBehavior=sapPopupPositionBehavior.MENURIGHT;
  var sControlType=sapUrMapi_getControlTypeFromObject(ur_get(sId));
	if(sControlType =="PCSEQ") 
	{
		if (e.type!="click") {
			if (sapUrMapi_checkKey(e,"keydown",new Array("32","40","13"))){
				sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
			}
			else if (sapUrMapi_checkKey(e,"keydown",new Array("39","37"))) {
				var intTabCount = parseInt(ur_get(sTrayId + "-tbl").getAttribute("tabcount"));
				if (ur_system.direction=="rtl") {
					sapUrMapi_PcSeq_focusItem(sTrayId,null,null,e.keyCode==37,e.keyCode==39);
				} else {
					sapUrMapi_PcSeq_focusItem(sTrayId,null,null,e.keyCode==39,e.keyCode==37);
				}
				return;
			}
			else {
				return false;
			}
		}
		else {
			sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
		}
	}
}
function sapUrMapi_PcSeq_setActiveItem(sId, iIdx, iOldIdx, bIsTitle) {
	with(document) {
		var maxwidth = 0;
		var oTbl = getElementById(sId+"-tbl");
		var tbdy = getElementById(sId+"-tbd");
		var iOldIdx = parseInt(oTbl.getAttribute("selectedtab"));
		var iTabLength = parseInt(oTbl.getAttribute("tabcount"));
		var iNewIdx = parseInt(oTbl.getAttribute("starttab"));
		var iVisTabs = parseInt(oTbl.getAttribute("vistabs"));
		
		
		if (isNaN(iIdx)){return;}
		if ((iTabLength==1) || (iOldIdx==iIdx)){ return true; }
		
		
		if (iIdx != -9999){
			
			var oClkCell = getElementById(sId + "-itm-" + iIdx);
			if (oClkCell.getAttribute("dsbl")=="true" || oClkCell.className.indexOf("Term") != -1){ return false; }
		}
		
		if (iOldIdx == -9999){
			
			
			var oCurTxt = getElementById(sId + "-tit-txt");
			var oCurCon = getElementById(sId + "-itm-tit-cn");
			var oCurContent  = getElementById(sId+"-cnt-tit");
			maxwidth = parseInt(oCurContent.clientWidth);
			
			if (oCurTxt != null){
				oCurTxt.className = "urPcTitTxt";
			}
			
			if (oCurCon != null){
				oCurCon.className = "urPcConOff";
			}
			
			oCurContent.className = "urPcSeqDsp";
		}
		else if (iOldIdx >=0 && iOldIdx < iTabLength){
			
			
			var oCurTxt = getElementById(sId + "-itm-" + iOldIdx + "-txt");
			var oCurCell = getElementById(sId + "-itm-" + iOldIdx);
			var oCurCon = getElementById(sId + "-itm-" + iOldIdx + "-c");
			var oCurStpCell = getElementById(sId + "-itm-" + iOldIdx + "-n");
			var oCurStpTxt = getElementById(sId + "-itm-" + iOldIdx + "-na");
			var oCurContent  = getElementById(sId+"-cnt-"+iOldIdx);
			maxwidth = parseInt(oCurContent.clientWidth);
			if (oCurCell != null){
				
				oCurCell.className="urPcSeqLabelOff";
				oCurTxt.className = "urPcSeqTxtOff";
				if (oCurStpCell != null){
					var re = /On/gi;
					var clsNm = oCurStpCell.className;
					
					oCurStpCell.className = clsNm.replace(re, "Off");
					oCurStpTxt.className = "urPcSeqStpTxtOff";
				}
				
				if (oCurCon != null){
					oCurCon.className = "urPcConOff";
				}
			}
			
			oCurContent.className = "urPcSeqDsp";
		}
		
		
		var newHt = 0;
		if (iIdx == -9999){
			
			
			var oClkTxt  = getElementById(sId + "-tit-txt");
			var oClkCon = getElementById(sId + "-itm-tit-cn");
			var oClkContent  = getElementById(sId+"-cnt-tit");
			
			if (oClkCon != null){
				oClkCon.className = "urPcConOn";
			}
			
			if (tbdy.style.display != "none") {
				for (var i = 0; i < oClkContent.childNodes.length; i++){
					oClkContent.childNodes[i].style.width = (maxwidth - 1) + "px";
					}
				}
			oClkContent.className = "urPcSeqDspSel";
		}
		else{
			
			
			var oClkCell = getElementById(sId + "-itm-" + iIdx);
			var oClkTxt  = getElementById(sId + "-itm-" + iIdx + "-txt");
			var oClkCon = getElementById(sId + "-itm-" + iIdx + "-c");
			var oClkStpCell = getElementById(sId + "-itm-" + iIdx + "-n");
			var oClkStpTxt = getElementById(sId + "-itm-" + iIdx + "-na");
			var oClkContent  = getElementById(sId+"-cnt-"+iIdx);
			if (oClkCell != null){
				
				oClkCell.className="urPcSeqLabelOn";
				oClkTxt.className = "urPcSeqTxtOn";
				if (oClkStpCell != null){
					var re = /Off/gi;
					var clsNm = oClkStpCell.className;
					
					oClkStpCell.className = clsNm.replace(re, "On");
					oClkStpTxt.className = "urPcSeqStpTxtOn";
				}
			}
			
			if (oClkCon != null){
				oClkCon.className = "urPcConOn";
			}
			
			if (tbdy.style.display != "none") {
				for (var i = 0; i < oClkContent.childNodes.length; i++){
					oClkContent.childNodes[i].style.width = (maxwidth - 1) + "px";
					}
				}
			oClkContent.className = "urPcSeqDspSel";
		}
		
		if (iOldIdx != -9999){
			if (iOldIdx == iNewIdx){
				var img = getElementById(sId+"-itm-"+(iOldIdx)+"-a");
				if ( img != null) {
					if (img.style.display == "none") {
					  img.className="urPcSeqAngOffOff";
						img.style.display = "none";
					}
					else {
					  img.className="urPcSeqAngOffOff";
					}
				}
				var td = getElementById(sId+"-itm-"+(iOldIdx+1)+"-a");
				if (td.className.indexOf("Term") == -1){
					td.className="urPcSeqAngOffOff";
				}
				else{
					 td.className="urPcSeqAngOffTerm";
				}
			}
			else if (iOldIdx >=0 && iOldIdx < iTabLength){
				getElementById(sId+"-itm-"+(iOldIdx)+"-a").className="urPcSeqAngOffOff";
				if (iOldIdx < iTabLength){
					var td = getElementById(sId+"-itm-"+(iOldIdx+1)+"-a");
					if (td != null) {
					        if (td.className.indexOf("Term") == -1){
						        td.className="urPcSeqAngOffOff";
					        }
					        else{
						        td.className="urPcSeqAngOffTerm";
						}
					}
				}
			}
		}
		
		if (iIdx==iNewIdx){
				var td = getElementById(sId+"-itm-"+(iIdx+1)+"-a");
				if (getElementById(sId+"-itm-"+(iIdx)+"-a") != null) {
				  getElementById(sId+"-itm-"+(iIdx)+"-a").className="urPcSeqAngOffOn";
				}
				if (td.className.indexOf("Term") == -1){
					td.className="urPcSeqAngOnOff";
				}
				else{
					td.className="urPcSeqAngOnTerm";
				}
		}
		else{
			if (iIdx != -9999){
				getElementById(sId+"-itm-"+(iIdx)+"-a").className="urPcSeqAngOffOn";
			}
			if (iIdx != -9999 && iIdx != iTabLength - 1) {
				var td = getElementById(sId+"-itm-"+(iIdx+1)+"-a");
				if (td.className.indexOf("Term") == -1){
					td.className="urPcSeqAngOnOff";
				}
				else{
					td.className="urPcSeqAngOnTerm";
				}
			}
		}
		
		var oFirstImage  = getElementById(sId+"-p");
		var oLastImage   = getElementById(sId+"-n");
		
		if (iNewIdx != 0){
			
			if (iIdx!=iNewIdx){oFirstImage.className="urPcSeqFirstAngOffPrevon";}
			
			else{oFirstImage.className="urPcSeqFirstAngOnPrevon";}
		}
		else{
			
			if (iIdx!=iNewIdx){oFirstImage.className="urPcSeqFirstAngOffPrevoff";}
			
			else{oFirstImage.className="urPcSeqFirstAngOnPrevoff";}
		}
		
		if (iNewIdx + iVisTabs >= iTabLength){
			
			if (iIdx != (iNewIdx + iVisTabs - 1) && iIdx != iTabLength - 1){
				if (oLastImage.className.indexOf("Branch") != -1){
					oLastImage.className="urPcSeqLastOffBranchOn";
				}
				else if (oLastImage.className.indexOf("Term") != -1){
					
				}
				else{
					oLastImage.className="urPcSeqLastOffNextOn";
				}
			}
			else{ 
				if (oLastImage.className.indexOf("Branch") != -1){
					oLastImage.className="urPcSeqLastOnBranchOn";
				}
				else if (oLastImage.className.indexOf("Term") != -1){
					
				}
				else{
					oLastImage.className="urPcSeqLastOnNextOn";
				}
			}
		}
		else{
			
			if (iIdx != (iNewIdx + iVisTabs - 1) && iIdx != iTabLength - 1){
				if (oLastImage.className.indexOf("Branch") != -1){
					oLastImage.className="urPcSeqLastOffBranchOn";
				}
				else if (oLastImage.className.indexOf("Term") != -1){
				}
				else{
					oLastImage.className="urPcSeqLastOffNextOn";
				}
			}
			else{
				if (oLastImage.className.indexOf("Branch") != -1){
					oLastImage.className="urPcSeqLastOnBranchOn";
				}
				else if (oLastImage.className.indexOf("Term") != -1){
				}
				else{
					oLastImage.className="urPcSeqLastOnNextOn";
				}
			}
		}
		
		oTbl.setAttribute("selectedtab",iIdx);
		
		if (iIdx != -1){
			sapUrMapi_PcSeq_focusItem(sId,iIdx);
		}
		if (ur_system.is508) {
			oClkTxt.title = getLanguageText("SAPUR_PCSEQ_ITEM",new Array(oClkTxt.innerText,"SAPUR_PCSEQ_ITEM_SELECTED"));
			if (oCurTxt != null) {
				oCurTxt.title = getLanguageText("SAPUR_PCSEQ_ITEM",new Array(oCurTxt.innerText,"SAPUR_PCSEQ_ITEM_ENABLED"));
			}
		}
	}
}
function sapUrMapi_PcSeq_focusItem(sSeqId, iIdx, iTabCount, bNext, bPrev) {
	var oTabTable 	= ur_get(sSeqId+"-tbl");
	if (isNaN(iIdx)) {iIdx = parseInt(oTabTable.getAttribute("selectedtab"));}
	if (isNaN(iTabCount)) {iTabCount = parseInt(oTabTable.getAttribute("tabcount"));}
	var ico = ur_get(sSeqId + "-menu");
	
	if (iIdx == -9999) {return false;}
	var iNewIndex=iIdx;
	if (ico != null && ico.getAttribute("hasfocus") == "true") {
		if (bNext) {
			iNewIndex = parseInt(oTabTable.getAttribute("starttab"));
		}
		if (bPrev) {
			iNewIndex = parseInt(oTabTable.getAttribute("starttab")) - 1 + parseInt(oTabTable.getAttribute("vistabs"));
			if (ur_get(sSeqId+"-itm-"+iNewIndex+"-txt").getAttribute("design") == "term") {
				iNewIndex--;
			}
		}
	}
	else {
		if (bNext) {
			
			if (iIdx<iTabCount-1){ iNewIndex=iIdx+1;}
			else {iNewIndex=0;}
		}
		if (bPrev) {
			if (iIdx>0) {iNewIndex=iIdx-1;}
			else {iNewIndex=iTabCount-1;}
		}
	}
	oFocusedTab = ur_get(sSeqId+"-itm-"+iNewIndex);
	if (oFocusedTab.style.display != "none") {
		var iOldFoc = parseInt(oTabTable.getAttribute("focusedtab"));
		if (!isNaN(iOldFoc)) {
			if (iOldFoc == -9999) {
			  sapUrMapi_setTabIndex(ur_get(sSeqId+"-tit-txt"),-1);
			}
			else {
			sapUrMapi_setTabIndex(ur_get(sSeqId+"-itm-"+iOldFoc+"-txt"),-1);
			}
		}
		var oFoc = ur_get(sSeqId+"-itm-"+iNewIndex+"-txt");
		if (oFoc.getAttribute("design") != "term") {
			sapUrMapi_setTabIndex(oFoc,0);
			
			sapUrMapi_focusElement(sSeqId+"-itm-"+iNewIndex+"-txt");
			oTabTable.setAttribute("focusedtab",iNewIndex);
			if (ico != null) {
				ico.setAttribute("hasfocus", "false");
			}
			if ((oFocusedTab.getAttribute("dsbl")=="true")&&(!ur_system.is508)) {
				sapUrMapi_PcSeq_focusItem(sSeqId,iNewIndex,iTabCount,bNext,bPrev);
				return;
			}
		}
		else {
			if (ico != null && ico.getAttribute("hasfocus") != "true") {
				sapUrMapi_setTabIndex(ico,0);
				ico.setAttribute("hasfocus", "true");
				
				sapUrMapi_focusElement(ur_get(sSeqId + "-menu"));
			}
			else {
				sapUrMapi_PcSeq_focusItem(sSeqId,iNewIndex,iTabCount,bNext,bPrev);
				return;
			}
		}
	}
	else {
	    if (ico != null) {
			sapUrMapi_setTabIndex(ico,0);
			ico.setAttribute("hasfocus", "true");
			
			sapUrMapi_focusElement(ur_get(sSeqId + "-menu"));
	    }
	}
}
function sapUrMapi_PcSeq_keySelect(sId, iSelectedIdx, iTabCount,e) {
	if (sapUrMapi_checkKey(e,"keydown",new Array("39","37"))){
	  if (ur_system.direction=="rtl") {
	    sapUrMapi_PcSeq_focusItem(sId,iSelectedIdx,iTabCount,e.keyCode==37,e.keyCode==39);
		return;
	  } else {
		sapUrMapi_PcSeq_focusItem(sId,iSelectedIdx,iTabCount,e.keyCode==39,e.keyCode==37);
		return;
	  }
	}
	if (sapUrMapi_checkKey(e,"keydown",new Array("32"))){
		sapUrMapi_PcSeq_setActiveItem(sId,iSelectedIdx,0,false);
		return;
	}
}
function ur_PcSeq_scrollItem( sId, iDir, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	if (iDir != -1 && iDir != 1){
		return false;
	}
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
	var diff = vistabs;
	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs - 1;}
	}
	if (lasttab != firsttab + vistabs - 1){
		diff = lasttab - firsttab;
	}
	if (iDir == 1){
		
		if (lasttab == tabcount - 1){return false;}
		
		showItem(sId, firsttab, false, true, false);
		
		firsttab += 1;
		showItem(sId, firsttab, true, true, false);
		if (diff > 2) {
			
			showItem(sId, lasttab, true, false, false);
		}
		if (diff != 1) {
		
		lasttab += 1;
		showItem(sId, lasttab, true, false, true);
	}
	else{
		
		lasttab = firsttab;
		showItem(sId, lasttab, true, true, true);
		}
	}
	else{
		
		if (firsttab == 0){return false;}
		
		
		if (diff >= vistabs - 1){
			
			showItem(sId, lasttab, false, false, true);
			
			lasttab -= 1;
			showItem(sId, lasttab, true, false, true);
		}
		if (diff > 1) {
		
		showItem(sId, firsttab, true, false, false);
		
		firsttab -= 1;
		showItem(sId, firsttab, true, true, false);
	}
		else {
		
    showItem(sId, firsttab, true, false, true);
		firsttab -= 1;
		showItem(sId, firsttab, true, true, true);
		}
	}
	
	setSeqIcons( sId, firsttab, lasttab, tabcount );
	
	var newtabpage = Math.floor(firsttab / vistabs);
	oTabs.setAttribute("starttab", firsttab);
	oTabs.setAttribute("lasttab", lasttab);
	ur_PcSeq_togglePager(sId)
}
function ur_PcSeq_pageItem( sId, iDir, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	if (iDir != 1 && iDir != -1){
		return false;
	}
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs-1;}
	}
	
	if ((iDir == -1 && firsttab == 0) || ( iDir == 1 && lasttab == tabcount -1)){
		return false;
	}
	
	if (((iDir == 1) && ((tabpage + iDir) * vistabs) < (tabcount)) ||
		((iDir == -1) && (tabpage + iDir >= 0) )){
		tabpage = tabpage + iDir;
	}
	
	var lbound = Math.floor(tabpage * vistabs);
	var ubound = lbound + vistabs - 1;
	
	if (ubound > tabcount - 1){
		ubound = tabcount -1;
	}
	
	for (var i = 0; i < tabcount; i++){
		
		if (i < lbound || i > ubound){
			if (i == firsttab){
				showItem(sId, i, false, true, false);
			}
			else if (i == lasttab){
				showItem(sId, i, false, false, true);
			}
			else{
			   showItem(sId, i, false, false, false);
			}
		}
		else{
		   if (i == lbound){
				showItem(sId, i, true, true, false);
		   }
		   else if (i == tabcount -1 || i == ubound){
				showItem(sId, i, true, false, true);
		   }
		   else{
				showItem(sId, i, true, false, false);
		   }
		}
	}
	
	setSeqIcons( sId, lbound, ubound, tabcount );
	
	oTabs.setAttribute("starttab", lbound);
	oTabs.setAttribute("lasttab", ubound);
	oTabs.setAttribute("tabpage", tabpage);
	ur_PcSeq_togglePager(sId)
}
function ur_PcSeq_jumpItem( sId, iTab, sCtlType ){
	sCtlType=sCtlType.toUpperCase();
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
	var seltab = parseInt(oTabs.getAttribute("selectedtab"));
	if (isNaN(lasttab)){
		if (firsttab + vistabs >= tabcount){lasttab = tabcount - 1;}
		else{lasttab = firsttab + vistabs-1;}
	}
	
	if (iTab >= tabcount || iTab < 0){
		return false;
	}
	
	var tabpage = Math.floor(iTab / vistabs);
	
	var lbound = Math.floor(tabpage * vistabs);
	var ubound = lbound + vistabs - 1;
	
	if (ubound > tabcount - 1){
		ubound = tabcount -1;
	}
	
	for (var i = 0; i < tabcount; i++){
		
		if (i < lbound || i > ubound){
			if (i == firsttab){
				showItem(sId, i, false, true, false);
			}
			else if (i == lasttab){
				showItem(sId, i, false, false, true);
			}
			else{
			   showItem(sId, i, false, false, false);
			}
		}
		else{
		   if (i == lbound){
				showItem(sId, i, true, true, false);
		   }
		   else if (i == tabcount -1 || i == ubound){
				showItem(sId, i, true, false, true);
		   }
		   else{
				showItem(sId, i, true, false, false);
		   }
		}
	}
	
	oTabs.setAttribute("starttab", lbound);
	oTabs.setAttribute("lasttab", ubound);
	oTabs.setAttribute("tabpage", tabpage);
	ur_PcSeq_togglePager(sId)
	
	
	sapUrMapi_PcSeq_setActiveItem(sId, iTab, seltab, false);
	
	setSeqIcons( sId, lbound, ubound, tabcount );
}
function showItem( sId, iIdx, bShow, bIsFirst, bIsLast ){
	
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var tabimg = ur_get(sId + "-itm-" + iIdx + "-a");
	var tabstat = ur_get(sId + "-itm-" + iIdx + "-n");
	var tabcell = ur_get(sId + "-itm-" + iIdx);
	
	var conimg = ur_get(sId + "-itm-" + iIdx + "-ca");
	var constat = ur_get(sId + "-itm-" + iIdx + "-cn");
	var concell = ur_get(sId + "-itm-" + iIdx + "-c");
	if (bShow){
		
		var statdisp = "";
		if (tabstat.getAttribute("design") == "INT"){
			statdisp = "none";
		}
		if (!bIsFirst && !bIsLast){
			tabimg.style.display = "";
			tabcell.style.display = "";
			tabstat.style.display = statdisp;
			if (concell != null){
				concell.style.display = "";
				conimg.style.display = "";
				constat.style.display = statdisp;
			}
		}
		else if (bIsFirst){
			tabimg.style.display = "none";
			tabcell.style.display = "";
			tabstat.style.display = statdisp;
			if (concell != null){
				concell.style.display = "";
				conimg.style.display = "none";
				constat.style.display = statdisp;
			}
		}
		else if (bIsLast){
			tabimg.style.display = "";
			tabcell.style.display = "";
			tabstat.style.display = statdisp;
			if (concell != null){
				concell.style.display = "";
				conimg.style.display = "";
				constat.style.display = statdisp;
			}
		}
	}
	else{
		
		tabimg.style.display = "none";
		tabcell.style.display = "none";
		tabstat.style.display = "none";
		if (concell != null){
			concell.style.display = "none";
			conimg.style.display = "none";
			constat.style.display = "none";
		}
	}
}
function setSeqIcons( sId, firsttab, lasttab, tabcount ){
	var prev = ur_get(sId + "-p");
	var next = ur_get(sId + "-n");
	var first = ur_get(sId + "-itm-" + firsttab);
	var last = ur_get(sId + "-itm-" + lasttab);
	var prevtmp = prev.className;
	var nexttmp = next.className
	
	if (firsttab == 0){
		if (first.className == "urPcSeqLabelOn"){
			prev.className = "urPcSeqFirstAngOnPrevOff";
		}
		else{
			prev.className = "urPcSeqFirstAngOffPrevOff";
		}
	}
	else{
		if (first.className == "urPcSeqLabelOn"){
			prev.className = "urPcSeqFirstAngOnPrevOn";
		}
		else{
			prev.className = "urPcSeqFirstAngOffPrevOn";
		}
	}
	
	if (lasttab == tabcount - 1){
		var lastdesign = last.getAttribute("design").toUpperCase();
		
		
		if (lastdesign == "TERM") {
			next.className = "urPcSeqLastTerm";
		}
		
		else if (lastdesign == "BRANCH") {
			if (last.className == "urPcSeqLabelOn"){
				next.className = "urPcSeqLastOnBranchOn";
			}
			else{
				next.className = "urPcSeqLastOffBranchOn";
			}
		}
		else {
		    if (last.className == "urPcSeqLabelOn") {
				next.className = "urPcSeqLastOnNextOn";
			}
			else {
			    next.className = "urPcSeqLastOffNextOn";
			}
		}
	}
	else{
		if (last.className == "urPcSeqLabelOn"){
			next.className = "urPcSeqLastOnNextOn";
		}
		else{
			next.className = "urPcSeqLastOffNextOn";
		}
	}
	
	prev.childNodes[0].className = "urPcSeqPreFirstAng";
	
	if (next.className.indexOf("Term") != -1){
		next.childNodes[0].className = "urPcSeqAfterLastAng";
	}
	else if (next.className.indexOf("Branch") != -1){
		next.childNodes[0].className = "urPcSeqBranchAng";
	}
	else{
		next.childNodes[0].className = "urPcSeqAfterLastAng";
	}
}
function ur_PcSeq_togglePager(sId) {
  if (ur_get(sId+"-pag")!=null) {
    var sPagerId=ur_get(sId+"-pag").firstChild.id;
  } else {
    return;
  }
	var oTabs = ur_get(sId + "-tbl");
	var tabcount = parseInt(oTabs.getAttribute("tabcount"));
	var firsttab = parseInt(oTabs.getAttribute("starttab"));
	var tabpage = parseInt(oTabs.getAttribute("tabpage"));
	var vistabs = parseInt(oTabs.getAttribute("vistabs"));
	var lasttab = parseInt(oTabs.getAttribute("lasttab"));
  var arrButtonArray = new Array();
	var arrStateArray = new Array();
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.BEGIN;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.PREVIOUS_PAGE;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.PREVIOUS_ITEM;
	if (firsttab!=0) {
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	} else {
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	}
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.END;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.NEXT_PAGE;
  arrButtonArray[arrButtonArray.length]=UR_PAGINATOR_BUTTON.NEXT_ITEM;
	if (lasttab!=tabcount-1) {
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	  arrStateArray[arrStateArray.length]=true;
	} else {
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	  arrStateArray[arrStateArray.length]=false;
	}
  sapUrMapi_Paginator_setStates(sPagerId,arrButtonArray,arrStateArray);
}
//** PhaseIndicator.ie5 **
function sapUrMapi_PhInPhaseSelect(sId,sPhaseId,bSelected,e){}
var arrValuesOfPhases = new Array();
function sapUrMapi_PhaseIndicator_create(sId){
	var o = ur_get(sId);
	var iItemSel = parseInt(o.getAttribute('sel'));
	if(document.getElementById(sId+"-itm-0")==null)return;
	if(isNaN(iItemSel))document.getElementById(sId+"-itm-0").tabIndex=0;
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_PhaseIndicator_init('"+sId+"')");
	}
function sapUrMapi_PhaseIndicator_init(sId){
	var oVisblPhases = ur_get(sId);
	var iWidth = oVisblPhases.offsetWidth;
	if (iWidth>0) {
	  sapUrMapi_PhaseIndicator_setAllValues(sId);
	} else {
	 	return;
  }
  sapUrMapi_PhaseIndicator_draw(sId);
	
	sapUrMapi_Resize_AddItem(sId, "sapUrMapi_PhaseIndicator_draw('" + sId + "')");
}
function sapUrMapi_PhaseIndicator_setAllValues(sId){
		arrValuesOfPhases[sId] = new Array();
        var iItemCount = parseInt(ur_get(sId).getAttribute('ai'));
		for(var i = 0; i <= iItemCount; i++){
			arrValuesOfPhases[sId][i] = new Array();
			arrValuesOfPhases[sId][i][0] = sId + '-itm-' + i;
			arrValuesOfPhases[sId][i][1] = ur_get(sId + '-itm-' + i).offsetWidth;
		}
		arrValuesOfPhases[sId][iItemCount + 1] = new Array();
		done = true;
	}
function sapUrMapi_PhaseIndicator_draw(sId) {
    var o=ur_get(sId);
	if (o == null) return;
	var iItemCount = parseInt(o.getAttribute('ai'));
	var iFirstIdxOld = parseInt(o.getAttribute('fv'));
	ur_get(sId + '-cnt-scrl').style.width = '1px';
	sapUrMapi_PhaseIndicator_make(sId,iFirstIdxOld,iItemCount);
	ur_PhInd_setInitialTabIndex(sId);
}
function sapUrMapi_PhaseIndicator_make(sId,iStart,iEnd,sDir){
  var o=ur_get(sId);
	var iLastIdxOld = parseInt(o.getAttribute('lv'));
	var iFirstIdxOld = parseInt(o.getAttribute('fv'));
	var iAvailWdth = ur_get(sId + '-cnt').offsetWidth;
	var iItemCount = parseInt(o.getAttribute('ai'));
	var iVisblWdth = 0;
	var iFirstIdx = 0;
	var iLastIdx = 0;
	var ii=0;
	for(var i=0;i<=iItemCount;i++) {
	  arrValuesOfPhases[sId][i][2]=false;
	}
  
  
	if(sDir == 'FURTHER' || typeof(sDir)=="undefined"){
    for (i=iStart;i<=iEnd;i++) {
			if(iAvailWdth > 0 && iAvailWdth >= arrValuesOfPhases[sId][i][1]){
				arrValuesOfPhases[sId][i][2]=true;
				iAvailWdth = iAvailWdth - arrValuesOfPhases[sId][i][1];
				iVisblWdth = iVisblWdth + arrValuesOfPhases[sId][i][1];
			}else{
				break;
			}
		ii=i;
    }
	}
	if(sDir == 'BACK'){
    for (i=iStart;i>=iEnd;i--) {
			if(iAvailWdth > 0 && iAvailWdth >= arrValuesOfPhases[sId][i][1]){
				arrValuesOfPhases[sId][i][2]=true;
				iAvailWdth = iAvailWdth - arrValuesOfPhases[sId][i][1];
				iVisblWdth = iVisblWdth + arrValuesOfPhases[sId][i][1];
			}else{
				break;
			}
		  ii=i;
    }
  }
	if(ii == 0 && iAvailWdth > iVisblWdth && iAvailWdth >= arrValuesOfPhases[sId][iStart + 1][1]){
		iAvailWdth = ur_get(sId + '-cnt').offsetWidth;
		for(i = (iStart + 1); i<= iItemCount; i++){
				iVisblWdth = iVisblWdth + arrValuesOfPhases[sId][i][1];
			if(iAvailWdth >= iVisblWdth && iAvailWdth >= arrValuesOfPhases[sId][i][1]){
				arrValuesOfPhases[sId][i][2]=true;
				iStart = i;
			}else{
				break;
			}
		}
	}
	for(var i=0;i<=iItemCount;i++) {
	  if (arrValuesOfPhases[sId][i][2]==false) {
		  ur_get(arrValuesOfPhases[sId][i][0]).childNodes[0].style.display = "none";
	  } else {
		  ur_get(arrValuesOfPhases[sId][i][0]).childNodes[0].style.display = "block";
	  }
	}
	if(sDir == 'BACK'){
		ur_get(sId).setAttribute('fv',ii);
		ur_get(sId).setAttribute('lv',iStart);
		iFirstIdx = ii;
		iLastIdx = iStart;
	} else {
		ur_get(sId).setAttribute('fv',iStart);
		ur_get(sId).setAttribute('lv',ii);
		iFirstIdx = iStart;
		iLastIdx = ii;
	}
	var oLastIdx = ur_get(sId + '-itm-img-' + iLastIdx);
	if(iFirstIdx == 0 && iLastIdx != iItemCount && oLastIdx != null){
		ur_get(sId + '-cnt-scrl').style.width = iVisblWdth;
		if(!isNaN(iLastIdxOld) && iLastIdxOld != iItemCount){
			ur_get(sId + '-itm-img-' + iLastIdxOld).className = 'urPhInFurtherArrow';
			}
		ur_get(sId + '-p').style.display = 'none';
		ur_get(sId + '-itm-img-' + iLastIdx).className = 'urPhInMoreAfter';
	}
	if(iFirstIdx != 0 && iLastIdx != iItemCount){
		ur_get(sId + '-p').style.display = 'block';
		ur_get(sId + '-cnt-scrl').style.width = iVisblWdth;
		if(iLastIdxOld != iItemCount){
			if(!isNaN(iLastIdxOld)){
				ur_get(sId + '-itm-img-' + iLastIdxOld).className = 'urPhInFurtherArrow';
			}
		}
		if(iLastIdx!=null){
			ur_get(sId + '-itm-img-' + iLastIdx).className = 'urPhInMoreAfter';
		}
	}
	if(iFirstIdx != 0 && iLastIdx == iItemCount){
		ur_get(sId + '-p').style.display = 'block';
		ur_get(sId + '-cnt-scrl').style.width = iVisblWdth;
		if(!isNaN(iLastIdxOld) && iLastIdxOld != iItemCount){
			ur_get(sId + '-itm-img-' + iLastIdxOld).className = 'urPhInFurtherArrow';
		}
	}
	if(iFirstIdx == 0 && iLastIdx == iItemCount){
		ur_get(sId + '-cnt-scrl').style.width = iVisblWdth;
		ur_get(sId + '-p').style.display = 'none';
		if(!isNaN(iLastIdxOld) && iLastIdxOld != iItemCount){
			ur_get(sId + '-itm-img-' + iLastIdxOld).className = 'urPhInFurtherArrow';
		}
	}
	ur_get(sId + '-cnt-scrl').scrollLeft = 0;
	sapUrMapi_PhaseIndicator_setPagingButtons(sId);
}
function sapUrMapi_PhaseIndicator_paging(sId,sDir){
	var iItemCount = parseInt(ur_get(sId).getAttribute('ai'));
	var iFirstIdxOld = parseInt(ur_get(sId).getAttribute('fv'));
	var iLastIdxOld = parseInt(ur_get(sId).getAttribute('lv'));
		if(sDir == 'FURTHER'){
				iFirstIdxOld = iLastIdxOld + 1;
				sapUrMapi_PhaseIndicator_make(sId,iFirstIdxOld,iItemCount,sDir);
		} else if(sDir== 'BACK'){
			iLastIdxOld = iFirstIdxOld - 1;
			if(iLastIdxOld != 0){
				sapUrMapi_PhaseIndicator_make(sId,iLastIdxOld,0,sDir);
				}else{
					ur_get(sId).setAttribute('fv',0);
					sapUrMapi_PhaseIndicator_draw(sId);
				}
		} else {
		  	iLastIdxOld = parseInt(sDir.substring(sDir.lastIndexOf("-")+1));
				ur_get(sId).setAttribute('fv',iLastIdxOld);
				sapUrMapi_PhaseIndicator_draw(sId);
			}
	}
function sapUrMapi_PhaseIndicator_setPagingButtons(sId){
	var iItemCount = parseInt(ur_get(sId).getAttribute('ai'));
	if(ur_get(sId+"-pag").hasChildNodes()){
		sPagerId = ur_get(sId+"-pag").childNodes.item(0).id;
		
		ur_get(sPagerId + "-btn-2").tabIndex = -1;
		ur_get(sPagerId + "-btn-3").tabIndex = -1;
		
		var arrButtonArray = new Array();
		arrButtonArray[0]=UR_PAGINATOR_BUTTON.PREVIOUS_ITEM;
		arrButtonArray[1]=UR_PAGINATOR_BUTTON.NEXT_ITEM;
		var arrStateArray = new Array();
		arrStateArray[0]=true; 
		arrStateArray[1]=true; 
		var iFirstIdxOld = parseInt(ur_get(sId).getAttribute('fv'));
		var iLastIdxOld = parseInt(ur_get(sId).getAttribute('lv'));
		if(iFirstIdxOld == 0){
				arrStateArray[0]=false; 
		}
		if(iLastIdxOld == iItemCount || isNaN(iLastIdxOld)){
				arrStateArray[1]=false; 
		}
		sapUrMapi_Paginator_setStates(sPagerId,arrButtonArray,arrStateArray);
	} else {
	  return;
	}
}
function ur_PhInd_setInitialTabIndex(sId) {
	var oPhInd = ur_get(sId),
		iSelItem = oPhInd.getAttribute("sel");
	if (iSelItem == null) {
		var oItem = ur_get(sId +"-itm-0");
		
		if (!ur_system.is508) {
			
			var iItemCount = parseInt(ur_get(sId).getAttribute('ai'));
			for (var i = 0; i < iItemCount; i++) {
				var oItem = ur_get(sId + "-itm-" + i);
				if (oItem.getAttribute("st").indexOf("d") < 0) {
					break;
				}
			}
			
			if (oItem.getAttribute("st").indexOf("d") > -1) return;
		}
		
	} else {
		var oItem =  ur_get(sId +"-itm-" + iSelItem);	
	}
	
	oItem = oItem.getElementsByTagName("SPAN")[0];
	oItem.setAttribute("tabIndex", 0);
	oItem.setAttribute("ti", 0);
}
function ur_PhIn_getItems(sId){
	var oPhInd = ur_get(sId + "-cnt"),
		oCollection = oPhInd.getElementsByTagName("SPAN");
		
	return oCollection;
}
function ur_PhInd_getNavIndex(sId, sItemIdx, bToNext) {
	
	var aItems = ur_PhIn_getItems(sId),
		sItemId = sId + "-itm-",
	 	iItemIdx = parseInt(sItemIdx);
	if (!ur_system.is508) {
		
		do {
			
			if (bToNext) {
				iItemIdx ++;
					
				if (iItemIdx >= aItems.length) {
					iItemIdx = null;
					break;
				}
			}
			else {
				iItemIdx --;
				
				if (iItemIdx < 0) {
					iItemIdx = null;
					break;
				}
			}
			
			if (iItemIdx == parseInt(sItemIdx)) {
				iItemIdx = null;
				break;
			}
			oItem = ur_get(sItemId + iItemIdx);
		}
		while (oItem.getAttribute("st").indexOf("u") > -1 || oItem.getAttribute("st").indexOf("d") > -1)
		
	}
	else {
		if (bToNext) {
			iItemIdx++;
			
			if (iItemIdx >= aItems.length) {
				iItemIdx = null;
			}
			
		} else {
			iItemIdx--;
			
			if (iItemIdx < 0) {
				iItemIdx = null;
			}
		}
	}
	
	return iItemIdx;
}
function ur_PhInd_navigate(sId, sItemIdx, iKey) {
	var aItems = ur_PhIn_getItems(sId),
		iOldIdx = parseInt(sItemIdx);	
	
	
	if(iKey == 39 || iKey == 40) {
		var iNewIdx = ur_PhInd_getNavIndex(sId, sItemIdx, true);
		
		if (iNewIdx == null) return;
		
		var sDir = (iNewIdx == 0) ? "BACK" : "FURTHER";
		
		ur_PhIn_scroll(sId, iNewIdx, sDir);
	} 
	else if (iKey == 37 || 38) {
		var iNewIdx = ur_PhInd_getNavIndex(sId, sItemIdx, false);
		
		if (iNewIdx == null) return;
		
		var sDir = (iNewIdx == aItems.length - 1) ? "FURTHER" : "BACK";
		
		ur_PhIn_scroll(sId, iNewIdx, sDir);
	}
	else if(iKey==9){
		var oPhIn = ur_get(sId);
		var iSel = oPhIn.getAttribute("sel");
		if(iSel==null)iSel=0;
		var oSel = ur_get(sId+"-itm-"+iSel);
		ur_PhIn_setFocus(oSel,oItm);
	 }
	
	if (iNewIdx != null) {
		ur_PhIn_setFocus(aItems[iNewIdx], aItems[iOldIdx]);
	}
	
	
}
function ur_PhIn_scroll(sId, iNewIdx, sDir) {
	var oNewItem = ur_get(sId + "-itm-" + iNewIdx).firstChild;
	if (oNewItem.style.display == "" || oNewItem.style.display == "block") {
		return;
	}
	
	sapUrMapi_PhaseIndicator_paging(sId,sDir);
	sapUrMapi_PhaseIndicator_setPagingButtons(sId)
}
function sapUrMapi_PhaseIndicator_keydownStep(sId, sItemIdx, bSel, e){
	var iKey = e.keyCode;
	
	
	if (iKey == 37 || iKey == 39 || iKey == 39 || iKey == 40) {
		ur_PhInd_navigate(sId, sItemIdx, iKey);
		ur_EVT_cancelBubble(e);
		ur_EVT_cancel(e);
	}
		
	   
	
	
	
}
function ur_PhIn_setFocus(oNew,oOld){
		sapUrMapi_setTabIndex(oOld,-1);
		sapUrMapi_setTabIndex(oNew,0);
		ur_focus(oNew);
}
function sapUrMapi_PhaseIndicator_getFirstVisible(o){
	return o.getAttribute("fv");
}

//** PopIn.ie5 **

function sapUrPopIn_close(sId, oEvt){
	if ( oEvt.keyCode == 32 || oEvt.type == "click" ) {
		ur_EVT_fire(ur_get(sId + "-cl"),"ocl");
	}
}
//** PopupMenu.nn6 **

var _ur_POMN = {all:new Array(),menus:new Array(),level:0};
var	_ur_POMN_triggerId="";
var mnu = new Object();
mnu.intv = null;
mnu.active = false;
mnu.delay = 250;
mnu.cancel = false;
mnu.mnuWin = null;
mnu.mnuE = null;
var sapPopupMenuLevel = 0;
var subMenus = new Array(null,null,null,null,null,null);
var subMenuItems = new Array(null,null,null,null,null,null);
var itemsArray = new Array(null,null,null,null,null,null,null,null);
var urOldFocus = window.onfocus;
var baseMenu = null;
var oPopup;
me=window;
var initMenus = new Array();
function sapUrMapi_PopupMenu_init(id,e) {
	if (me.menuObject) {
		sapUrMapi_PopupMenu_exit(id,e);
	}
	if (!me.menuObject) {
		var items = window.document.getElementById(id+"-r").childNodes[1].childNodes;
		var menu = new sapUrMapi_PopupMenu(items);
		me.menuObject = menu;
		me.menuObject.standalone=true;
	}
}
function sapUrMapi_PopupMenu_exit(id,e) {
	if (e.target.id==id) {
		if (me.menuObject) {
			sapUrMapi_PopupMenu_hideAll();
			sapUrMapi_PopupMenu_setItemActive(me,-1, id);
			me.menuObject = null;
		}
	} else {
		if (me.menuObject) {
			if (me.menuObject.out) {
		    sapUrMapi_PopupMenu_setItemActive(me,-1, id);
		  }
		}
	}
}
function sapUrMapi_PopupMenu_hoverItem(mywindow,id,e) {
	
	if(e==null) return;
	
	var o=e.target;
  	if(o.parentNode.className=="urMnuDvdr"){
    	iIdx = "dvdr"
		sapUrMapi_PopupMenu_setItemActive(mywindow,iIdx, id);
		if (mywindow.mylevel<=sapPopupMenuLevel) {
        	for (var n=mywindow.mylevel+1;n<=sapPopupMenuLevel;n++) {
            	subMenus[n].hide();
			}
		}
      	return;
  	}
	if(typeof o.tagName=="undefined") o=o.parentNode;
	if (o.tagName=="IMG" || o.tagName=="NOBR" || o.tagName=="SPAN")o=o.parentNode;
	if (o.tagName=="TD") {
		iIdx = parseInt(o.parentNode.getAttribute("Idx"));
		if (mywindow.menuObject==null) {
	    	sapUrMapi_PopupMenu_init(id,e);
	  	}
		var items = mywindow.document.getElementById(id+"-r").childNodes[1].childNodes;
		mywindow.menuObject = sapUrMapi_PopupMenu(items);
		if (mywindow.menuObject.activeItem==iIdx) return;
		if(o.getAttribute("isscroll")=="true") {
			e.stopPropagation();
			return false;
		}
		sapUrMapi_PopupMenu_setItemActive(mywindow,iIdx, id);
		if (mywindow.mylevel<=sapPopupMenuLevel) {
			for (var n=mywindow.mylevel+1;n<=sapPopupMenuLevel;n++) {
				subMenus[n].hide();
			}
		}
		ur_focus(mywindow);
		if (ur_getAttD(mywindow.menuObject.items[mywindow.menuObject.activeItem],"st","").indexOf("d")==-1) {
			sapUrMapi_PopupMenu_setItemActive(mywindow,"opensub", id);
		}
	}
	e.cancelBubble=true;
}
function sapUrMapi_PopupMenu_hideAll() {
  for (var n=0;n<sapPopupMenuLevel+1;n++) {
	 if (subMenus[n]!=null) {
    subMenus[n].hide();
   }
  }
  if (baseMenu!=null) {baseMenu.hide();}
  baseMenu=null;
  if(oPopup!=null){
	    try {
          
          
          var oSrc = oPopup.source.object;
          if (oSrc && oSrc.tagName=="TD") {
            if (oSrc.firstChild && oSrc.firstChild.nodeType == 1) 
                ur_focus(oSrc.firstChild);
          } else {
            ur_focus(oSrc);
          }
	    } catch(e) {}	
  }
  oPopup=null;
  sapPopupMenuLevel=0;
  
}
function sapUrMapi_PopupMenu_showMenu(idTrigger,idContent,enumAlignment,e ) {
	var styles = document.getElementsByTagName("LINK");
	var arrUrls;
	_ur_POMN_triggerId=idTrigger;
	arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
	
	for (var i=0;i<subMenus.length;i++) {
  		if (subMenus[i]!=null) {
  			subMenus[i].hide();
  		}
  	}
	var o = ur_get(idContent);
	if (!o) return;
	if (o.hasChildNodes() && o.firstChild.tagName=="XMP") {
		o.innerHTML=o.firstChild.innerHTML; 
	}
	
	if (o.firstChild.firstChild.offsetWidth!=0)
		o.firstChild.style.width = o.firstChild.firstChild.offsetWidth;
	
	sapUrMapi_PopupMenu_drawInit(idContent);
	oPopup = new sapPopup(window,arrUrls,o,ur_get(idTrigger),e,0);
	oPopup.onblur=oPopup.hide;
  	if (!enumAlignment)
    	if (ur_system.direction== "rtl")
      		enumAlignment= sapPopupPositionBehavior.MENURIGHT;
    else
		enumAlignment= sapPopupPositionBehavior.MENULEFT;
	oPopup.positionbehavior = enumAlignment;
	oPopup.show();
	baseMenu=oPopup;
	window.onfocus=sapUrMapi_PopupMenu_hideAll;
	var items = oPopup.frame.window.document.body.childNodes[0].childNodes[0].childNodes[1].childNodes;
	oPopup.frame.window.document.body.style.overflow = "hidden";
	var menu = new sapUrMapi_PopupMenu(items);
	oPopup.frame.window.menuObject = menu;
	oPopup.frame.window.document.body.onkeydown = function (e) {
		  	var id = idContent;
		  	sapUrMapi_PopupMenu_keyDown(null,id,e);
		  }
		  
	try {
		if (e.type=="keydown") {
	  	sapUrMapi_PopupMenu_setItemActive(oPopup.frame.window,"first", idContent);
	}
	} catch (exc) {}
	sapUrMapi_setTabIndex(oPopup.frame.window.document.body.childNodes[0],0);
	oPopup.frame.window.focus(); 
	setTimeout("sapUrMapi_PopupMenu_setSizeOfFrame(0)",0);
	oPopup.frame.window.document.body.childNodes[0].focus();
}
function sapUrMapi_PopupMenu_setSizeOfFrame(idx) {
	sapPopupStore[idx].frame.object.style.width = sapPopupStore[idx].frame.window.document.childNodes[0].scrollWidth + "px"; 
	sapPopupStore[idx].frame.object.style.height = sapPopupStore[idx].frame.window.document.childNodes[0].scrollHeight + "px";
}
function sapUrMapi_PopupMenu_setItemActive(win,newActive, sId) {
	if (sId=="blank") return;
	var remActive = newActive;
	if (!win.menuObject) {
	  var items=win.document.getElementsByTagName("TBODY")[0].childNodes;
	  win.menuObject = sapUrMapi_PopupMenu(items);
	}
	
	var menuObj=win.menuObject;
	if (newActive==menuObj.activeItem) return;
	menuObj.out=false;
	if ((newActive=="opensubkey")||(newActive=="opensub")) {
		if (!menuObj.items[menuObj.activeItem]) return;
		if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) return;
		var sSubMenuId = ur_getAttD(menuObj.items[menuObj.activeItem],"smnu","");
		if (sSubMenuId!="") {
		  if (!oPopup) {
		  	var iStartLevel=-1;
		  } else {
		  	var iStartLevel=win.mylevel;
		  }
		  if (iStartLevel<sapPopupMenuLevel) {
				for (var n=iStartLevel+1;n<sapPopupMenuLevel+1;n++) {
				  if (subMenus[n]!=null) {
  				  subMenus[n].hide();
  		      
  				}
				}
			  sapPopupMenuLevel=iStartLevel;
			}
			var arrUrls;
			arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
			if (!oPopup) {
			   subwindow = window;
  			 sapPopupMenuLevel = 0;
			} else {
			  subwindow = win;
			  sapPopupMenuLevel = win.mylevel+1;
			}
			var src = menuObj.items[menuObj.activeItem];
			var o = ur_get(sSubMenuId);
			if (o.hasChildNodes() && o.firstChild.tagName=="XMP") {
				o.innerHTML=o.firstChild.innerHTML; 
			}
		  
		  o.firstChild.style.width=o.firstChild.firstChild.offsetWidth;
		  
		  sapUrMapi_PopupMenu_drawInit(sSubMenuId);
		  subMenu = new sapPopup(window,arrUrls,o,src,subwindow.event,sapPopupMenuLevel);
		  subMenu.onblur=subMenu.hide;
		  subMenu.positionbehavior = sapPopupPositionBehavior.SUBMENU;
		  subMenu.show();
		  subMenus[sapPopupMenuLevel] = subMenu;
		  subMenuItems[sapPopupMenuLevel] = menuObj.items[menuObj.activeItem];
		  var items = subMenu.frame.window.document.getElementsByTagName("TBODY")[0].childNodes;
		  var menu = new sapUrMapi_PopupMenu(items);
		  var wnd = subMenu.frame.window;
		  var oDiv = wnd.document.body.firstChild;
		  wnd.menuObject = menu;
		  oDiv.onkeydown = function (e) {
		  	var id = sId;
		  	sapUrMapi_PopupMenu_keyDown(null,id,e);
		  }
		  wnd.document.body.style.overflow = "hidden";
		  sapUrMapi_setTabIndex(oDiv,0);
		  oDiv.focus();
		  setTimeout("sapUrMapi_PopupMenu_setSizeOfFrame("+sapPopupMenuLevel+")",0);
		  if (!oPopup) {
			 oPopup= subMenus[sapPopupMenuLevel];
		  }
		  if (win.mylevel>1) {
			sapUrMapi_PopupMenu_setItemActive(subMenus[win.mylevel-1].frame.window,subMenus[win.mylevel-1].frame.window.menuObject.activeItem, sId)
		  } else {
			  if (!oPopup) {
				sapUrMapi_PopupMenu_setItemActive(subMenus[sapPopupMenuLevel].frame.window,subMenus[sapPopupMenuLevel].frame.window.menuObject.activeItem, sId)
			  } else {
				sapUrMapi_PopupMenu_setItemActive(oPopup.frame.window,oPopup.frame.window.menuObject.activeItem, sId)
			  }
		  }
		subMenu.frame.window.document.body.childNodes[0].focus();
		if (newActive=="opensubkey") {
				sapUrMapi_PopupMenu_setItemActive(subMenus[sapPopupMenuLevel].frame.window,"first", sId);
		  }
		}
	  return;
	}
	if (newActive=="closesub"){
		if (win.mylevel) {
			subMenus[win.mylevel].hide();
			if (win.mylevel>1) {
				subMenus[win.mylevel-1].frame.window.focus(); 
				subMenus[win.mylevel-1].frame.window.document.body.childNodes[0].focus();
			} else {
				oPopup.frame.window.focus(); 
				oPopup.frame.window.document.body.childNodes[0].focus();
			}
		}
	  return;
	}
	if (newActive=="first") {
	  newActive=menuObj.activeItem+1;
	  if (newActive>menuObj.items.length-1) newActive=0;
	}
	var bDown = "true";
	if (newActive=="next") {
	  newActive=menuObj.activeItem+1;
		if (newActive>menuObj.items.length-1){
			if (menuObj.items[0].style.display != "none"){
				newActive=0;
			}
			else{
			   newActive = menuObj.items.length-1;
			   return;
			}
		}
	}
	if (newActive=="prev") {
		newActive=menuObj.activeItem-1;
		if (newActive<0){
			if (menuObj.items[menuObj.items.length-1].style.display != "none"){
				newActive=menuObj.items.length-1;
			}
			else{
			   newActive = 0;
			   return;
			}
	}
		bDown = "false";
	}
  if (newActive=="dvdr") {
             if (menuObj.activeItem>-1) {
                  if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) {
                  menuObj.items[menuObj.activeItem].className="urMnuRowDsbl";
                  } else {
                          menuObj.items[menuObj.activeItem].className="urMnuRowOff";
                  }
             }
  }
	if (newActive>-1) {
		if (menuObj.activeItem>-1) {
			if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) {
			  menuObj.items[menuObj.activeItem].className="urMnuRowDsbl";
		  } else {
			  menuObj.items[menuObj.activeItem].className="urMnuRowOff";
		  }
		}
		menuObj.activeItem =  newActive;
		if (menuObj.activeItem>-1) {
			while (menuObj.items[menuObj.activeItem].style.display == "none"){
				sapUrMapi_PopupMenu_manualScroll(win, sId, bDown, true);
			}
		  	
		
     if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) {
			  menuObj.items[menuObj.activeItem].className="urMnuRowDsblOn";
		  } else {
			  menuObj.items[menuObj.activeItem].className="urMnuRowOn";
		  }
		}
	} else {
		if (newActive==-1) {
		  if (menuObj) {
			  if (menuObj.items.length>0) {
			  	if (menuObj.items[menuObj.activeItem]) {
						if (ur_getAttD(menuObj.items[menuObj.activeItem],"st","").indexOf("d")>-1) {
						  menuObj.items[menuObj.activeItem].className="urMnuRowDsbl";
					  } else {
						  menuObj.items[menuObj.activeItem].className="urMnuRow";
					  }
					}
				}
			}
		}
	}
}
function sapUrMapi_PopupMenu(items) {
	this.activeItem = -1;
	this.items = new Array();
	for (var i=0;i<items.length;i++) {
		if (items.item(i).childNodes[0].className!="urMnuDvdr") {
			this.items[this.items.length]=items.item(i);
			if (this.items[this.items.length-1].className.indexOf("On")>-1) {
				this.activeItem=this.items.length-1;
			}
			this.items[this.items.length-1].setAttribute("Idx",this.items.length-1);
		}
	}
	return this;
}
function sapUrMapi_PopupMenu_keyDown(mywindow,id,e) {
	if (!mywindow) mywindow = e.view;
	if (e.keyCode==27) {
		if (mywindow.menuObject) {
			if (mywindow.menuObject.standalone) {
				sapUrMapi_PopupMenu_exit(id,e);
		    ur_focus(me.menuObject.items[me.menuObject.activeItem].parentNode.parentNode.parentNode);
		  } else {
		  	try {
		  		window.focus(); 
			    ur_focus(oPopup.source.object);
			  } catch(e) {
			  }
			  hidePopupMenu();
		  }
		}
		return;
	}
	if (e.keyCode==40) { 
	  sapUrMapi_PopupMenu_setItemActive(mywindow,"next", id);
	  ur_EVT_cancel(e);
	}
	if (e.keyCode==38) { 
	  sapUrMapi_PopupMenu_setItemActive(mywindow,"prev", id);
	  ur_EVT_cancel(e);
	}
	if (e.keyCode==39) { 
	  if (ur_system.direction == "rtl") {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"closesub", id);
		ur_EVT_cancel(e);
		return;
	  } else {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"opensubkey", id);
	  }
    }
	if (e.keyCode==37) { 
	  if (ur_system.direction == "rtl") {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"opensubkey", id);
	  } else {
	    sapUrMapi_PopupMenu_setItemActive(mywindow,"closesub", id);
		ur_EVT_cancel(e);
		return;
	  }
	}
	if (e.keyCode==13) { 
	  ur_PopupMenu_click(mywindow,id,e);
	}
	if (e.keyCode!=9) {
	  e.cancelBubble=true;
	  e.returnValue=false;
	} else {
		if (mywindow.menuObject) {
			mywindow.menuObject.out=true;
		}
		if(oPopup.source.object!=null){
			try {
		  		window.focus(); 
			    ur_focus(oPopup.source.object);
			} catch(e) {}	
		}	
		hidePopupMenu();
	  e.cancelBubble=false;
	  e.returnValue=true;
	}
	return false;
}
function sapUrMapi_PopupMenu_ExecuteLink(id) {
  oItem = window.document.getElementById(id);
  sTarget = oItem.getAttribute("target");
  sHref   = oItem.getAttribute("href");
  oTarget = top.frames[sTarget];
  if (oTarget) {
  	oTarget.location.href=sHref;
  } else {
    window.open(sHref,sTarget,"");
	}
  }
function sapUrMapi_PopupMenu_drawInit( sId,oSubWindow ){
    var tbl = window.document.getElementById(sId+"-r");
	var rows = tbl.childNodes[1].rows;
	var visIdx = tbl.getAttribute("visidx") - 0;
    var visCnt = tbl.getAttribute("viscnt") - 0;
	var maxVisCnt = rows.length - visIdx;
  tbl.style.width = tbl.offsetWidth + "px";
	
	var maxHt = window.document.body.offsetHeight;
	var mnuHt = tbl.offsetHeight;
	var visBtns = true;
	if (visCnt==0){visCnt=rows.length}
	var oHead,oFoot;
	oHead=tbl.getElementsByTagName("THEAD")[0];
	oFoot=tbl.getElementsByTagName("TFOOT")[0];
  oHead.style.display = "";		
	oFoot.style.display = "";		
		
	
	if ((visIdx == 0) && (visCnt >= rows.length)){
		oHead.style.display = "none";
		oFoot.style.display = "none";
		
		for (var i = 0; i < rows.length; i++){
			if (rows[i].cells[0].className == "urMnuDvdr"){
				rows[i].cells[0].style.fontSize="5px";
			}
		}
		}
	
	for (var i = 0; i < rows.length; i++){
        for (var z = 0; z < rows[i].cells.length; z++){
			rows[i].cells[z].width = rows[i].cells[z].offsetWidth;
            rows[i].cells[z].style.width = rows[i].cells[z].offsetWidth +"px";
        }
    }
	if (visCnt <= 0){
		
		return false;
	}
	if (visCnt > maxVisCnt) {
	    
		visCnt = maxVisCnt;
		
	}
	var resetVisCnt = false;
	var upOn = false;
	var dnOn = false;
    for (var n = 0; n < rows.length; n++){
		
        if (n < visIdx){
			rows[n].style.display = "none";
			upOn = true;
        }
		else if (n == visIdx){
				
		}
		
		else if (n > visIdx && n < (visIdx + visCnt)){
				
		}
		else if (n >= (visIdx + visCnt)){
			rows[n].style.display = "none";
			dnOn = true;
	}
}
	
	if (visBtns) {
	  if (!oSubWindow) {
	    sapUrMapi_PopupMenu_setButtons( sId, false, upOn );
	    sapUrMapi_PopupMenu_setButtons( sId, true, dnOn );
	  } else {
		sapUrMapi_PopupMenu_setButtons( sId, false, upOn, oSubWindow );
		sapUrMapi_PopupMenu_setButtons( sId, true, dnOn, oSubWindow );
	  }
    }
	  }
function sapUrMapi_PopupMenu_timeScroll(oWindow, sId, bDown, bCancel, e) {
    
    mnu.mnuWin = oWindow;
	e.stopPropagation();
    if (bCancel & mnu.intv == null){
        mnu.active = false;
        return false;
    }
    else if (bCancel){
        mnu.cancel = true;
        mnu.mnuWin.parent.clearInterval(mnu.intv);
        mnu.intv = null;
        
        if (mnu.active == false){
            sapUrMapi_PopupMenu_scrollItem(sId, bDown);
        }
        mnu.active = false;
    }
    else{
        mnu.cancel = false;
		mnu.intv = mnu.mnuWin.parent.setInterval("sapUrMapi_PopupMenu_scrollItem('" + sId + "', '" + bDown + "')", mnu.delay);
    }
}
function sapUrMapi_PopupMenu_manualScroll(oWindow, sId, bDown, bCancel, e ){
    
    mnu.mnuWin = oWindow;
    
	if (bCancel){
        mnu.cancel = true;
        mnu.mnuWin.parent.clearInterval(mnu.intv);
        mnu.intv = null;
        
        if (mnu.active == false){
            sapUrMapi_PopupMenu_scrollItem(sId, bDown);
        }
        mnu.active = false;
	}
	else{
    return false;
}
}
function sapUrMapi_PopupMenu_scrollItem(sId, bDown) {
    mnu.active = true;
    
	var tbl = mnu.mnuWin.document.getElementById(sId+"-r");
    var tbody = tbl.childNodes[1];
    
    var rIdx = tbl.getAttribute("visidx") - 0;
    var visCnt = tbl.getAttribute("viscnt") - 0;
    
    if (bDown == "true"){
        if ((rIdx + visCnt) >= tbody.rows.length){
            mnu.cancel = true;
        }
        else{
			tbody.rows[rIdx].style.display = "none";
			tbody.rows[rIdx + visCnt].style.display = "";
			++rIdx;
            tbl.setAttribute("visidx", rIdx);
            mnu.cancel = false;
        }
    }
    else{
       if (rIdx <= 0){
           mnu.cancel = true;
       }
       else{
           tbody.rows[rIdx + visCnt - 1].style.display = "none";
		   --rIdx;
		   tbody.rows[rIdx].style.display = "";
		   tbl.setAttribute("visidx", rIdx);
           mnu.cancel = false;
       }
    }
    
    if(mnu.cancel){
        mnu.mnuWin.parent.clearInterval(mnu.intv);
        mnu.intv = null;
        return;
    }
    else{
       
       if ((rIdx + visCnt - 0) >= tbody.rows.length){
           sapUrMapi_PopupMenu_setButtons(sId, true, false);
       }
       else{
           sapUrMapi_PopupMenu_setButtons(sId, true, true);
      }
       if (rIdx - 0 <= 0){
          sapUrMapi_PopupMenu_setButtons(sId, false, false);
	  }
       else{
          sapUrMapi_PopupMenu_setButtons(sId, false, true);
	  }
	}
}
function sapUrMapi_PopupMenu_setButtons( sId, bUp, bOn, oMenuWin ){
    var x;
    var node;
    (bUp)? x = 2 : x = 0;
		try {
			if (oMenuWin) {
			  node = oMenuWin.document.getElementById(sId+"-r").childNodes.item(x).childNodes[0].childNodes[0];
			} else {
	        if (mnu.mnuWin != null){
	         node = mnu.mnuWin.document.getElementById(sId+"-r").childNodes.item(x).childNodes[0].childNodes[0];
	        } else {
	         node = window.document.getElementById(sId+"-r").childNodes.item(x).childNodes[0].childNodes[0];
	        }
			}
			if (!bOn){
			  node.className = node.className.split("Dsbl")[0] + "Dsbl";
			} else {
		      node.className = node.className.split("Dsbl")[0];
			}
		}
		catch(e){
		}
}
function sapUrMapi_PopupMenuItem_setDisabled( sPopupMenuId, iIdx){
  var tbl = window.document.getElementById(sPopupMenuId+"-r");
	if (isNaN(iIdx)) { return; }
	var rows = tbl.childNodes[1].rows;
	rows(iIdx).className="urMnuRowDsbl";
	rows(iIdx).setAttribute("dsbl","true");
	rows(iIdx).cells(1).oldTitle=rows(iIdx).cells(1).title;
       
}
function sapUrMapi_PopupMenuItem_setEnabled( sPopupMenuId, iIdx){
  var tbl = window.document.getElementById(sPopupMenuId+"-r");
	if (isNaN(iIdx)) { return; }
	var rows = tbl.childNodes[1].rows;
	rows(iIdx).className="urMnuRowOff";
	rows(iIdx).setAttribute("dsbl","false");
	rows(iIdx).cells(1).title=rows(iIdx).cells(1).oldTitle;
}
function sapUrMapi_ToolbarButton_openMenu( sButtonId, e){
	var sPopupId=document.getElementById(sButtonId+"-r").getAttribute("popup");
	if ((e.type!="click")&&(e.type!="contextmenu")) {
		if (!sapUrMapi_checkKey(e,"keydown",new Array("32","40"))) {
	    e.cancelBubble=true;
	    e.returnValue=true;
		  return false;
		}
	}
	if (ur_system.direction=="rtl") {
	  sapUrMapi_PopupMenu_showMenu(sButtonId+"-r",sPopupId,sapPopupPositionBehavior.MENURIGHT,e);
	} else {
	  sapUrMapi_PopupMenu_showMenu(sButtonId+"-r",sPopupId,sapPopupPositionBehavior.MENULEFT,e);
	}
  e.cancelBubble=false;
	if ((e.type=="contextmenu")) {
    e.returnValue=false;
  } else {
    e.returnValue=true;
  }
}
function sapUrMapi_PopupMenu_selectItem(oWnd,sItemId,bChecked,oEvt) {
   oWnd.me.sapUrMapi_ToolbarButton_setFunctionFromMenuItem(sItemId);  
   oWnd.me.sapUrMapi_PopupMenu_hideAll();
   ur_EVT_cancel(oEvt);
}
function mf_PopupMenu_getObj(sId,hWnd) {
	
	if (typeof(hWnd)=="undefined") hWnd=window;
	var o=hWnd.document.getElementById(sId);
	if (o.hasChildNodes() && o.firstChild.tagName=="XMP") {
	  o.innerHTML=o.firstChild.innerHTML; 
	}
	
  if (o==null) return;
  if (hWnd._ur_POMN.all[sId]==null) {
    
		var oPMn={id:sId,
		          ref:o,
		          evtref:o.childNodes[0],
		          items:new Array(),
		          shown:false,
		          frame:null};
		var oRows=o.getElementsByTagName("TBODY")[0].getElementsByTagName("TR");
		var iIdx=0;
		for (var i=0;i<oRows.length;i++) {
			var bHasSep=false;
			var oSepRef=null;
			if (oRows[i].firstChild.className.indexOf("urMnuDvdr")>-1) {
				bHasSep=true; 
				oSepRef=oRows[i];
				i++;
			}
			var oRow=oRows[i];
			var sSt=ur_getAttD(oRow,"st","");
			var sAtt=ur_getAttD(oRow,"att","");
			var sSmnu=ur_getAttD(oRow,"smnu","");
			oPMn.items.push({ref:oRow,
			                 sepref:oSepRef,
			                 idx:iIdx,
			                 Id:oRow.id,
			                 Enabled:sSt.indexOf("d")==-1,
			                 HasSubMenu:sSmnu!="",
											 SubMenuId:sSmnu,
			                 HasSeparator:sAtt.indexOf("s")>-1,
			                 Text:ur_getAttD(oRow,"t",""),
			                 CanCheck:(sSt.indexOf("n")>-1 || sSt.indexOf("s")>-1),
			                 GroupId:ur_getAttD(oRow,"gid",""),
			                 Checked:sSt.indexOf("s")>-1,
			                 HasIcon:sAtt.indexOf("i")>-1,
			                 IsLink:sAtt.indexOf("l")>-1,
			                 EnabledIconSrc:ur_getAttD(oRow,"eis",""),
			                 DisabledIconSrc:ur_getAttD(oRow,"dis",""),
			                 HasEllipsis:sAtt.indexOf("e")>-1,
			                 POPUPMENUITEMSELECT:ur_getAttD(oRow,"ocl",""),
			                 POPUPMENUITEMLINKCLICK:ur_getAttD(oRow,"olc",""),
			                 Hovered:false,
			                 Hidden:false,
			                 Menu:oPMn});
			iIdx++;
		}
		hWnd._ur_POMN.all[sId]=oPMn;
	}
	return hWnd._ur_POMN.all[sId];
}
function mf_PopupMenu_getTriggerId() {
	return _ur_POMN_triggerId.split("-")[0];
}
function ur_PopupMenu_render(oPMn) {
  var oTBdy=oPMn.ref.getElementsByTagName("TBODY")[0];
  var oTable=oPMn.ref.getElementsByTagName("TABLE")[0];
  while (oTBdy.childNodes.length>0) oTBdy.removeChild(oTBdy.lastChild);
  for (var i=0;i<oPMn.items.length;i++) {
    var oItm=oPMn.items[i];
    var oH=document.createElement("TR");
    var oHTxtTd=document.createElement("TD");
    var oHTxtSpan=document.createElement("SPAN");
 
    var oHIcoTd=document.createElement("TD");
    var oHChkTd=document.createElement("TD");
    var oHTd=document.createElement("TD");
    var oHSubTd=document.createElement("TD");
    
    
    if (oItm.Enabled) oH.className="urMnuRowOff";
    else oH.className="urMnuRowDsbl";
    
    
    if (oItm.CanCheck) {
      if(oItm.GroupId!='')
        if (oItm.Checked) oHChkTd.className="urMnuChkRbgOn";
        else oHChkTd.className="urMnuChkRbg";
      else if (oItm.Checked) oHChkTd.className="urMnuChkOn";
      else oHChkTd.className="urMnuChk";
    } else {
     oHTxtTd.className="urMnuTxt";
    } 
    if (oItm.CanCheck) oHChkTd.innerHTML="&nbsp;&nbsp;&nbsp;";
    else oHChkTd.innerHTML="&nbsp;";
    
    if (oItm.HasIcon) {
      oHIcoTd.className="urMnuTxt";
      if (ur_system.direction=="RTL") oHIcoTd.style.paddingLeft="3px";
      else oHIcoTd.style.paddingRight="3px";
      oImg=document.createElement("IMG");
      if (oItm.Enabled) oImg.src=oItm.EnabledIconSrc;
      else oImg.src=oItm.DisabledIconSrc;		
      oImg.border="0";
      oHIcoTd.appendChild(oImg);
    } else {
      oHIcoTd.innerHTML="&nbsp;";
    }
    
    
    var sEll="";
    if (oItm.HasEllipsis) sEll="\u2026";
    var oHTxt=document.createTextNode(oItm.Text+sEll);
    oHTxtTd.className="urMnuTxt";
    oHTxtTd.appendChild(oHTxtSpan);
    oHTxtSpan.style.whiteSpace="nowrap";
    
    
    
    if (oItm.HasSubMenu) { oHSubTd.className="urMnuSubOn";oHSubTd.innerHTML="&nbsp;&nbsp;&nbsp;";
    } else {oHSubTd.className="urMnuSub";oHSubTd.innerHTML="&nbsp;";}
    
    
    oH.appendChild(oHChkTd);
    oH.appendChild(oHIcoTd);
    oH.appendChild(oHTxtTd);
    oH.appendChild(oHSubTd);
    oHTxtSpan.appendChild(oHTxt);
    if (oItm.HasSeparator) {
      var oHSep=document.createElement("TR");
      oHSep.setAttribute("class","urMnuRowOff");
      var oHSepTd=document.createElement("TD");
      oHSepTd.className="urMnuDvdr";
      oHSepTd.colSpan="4";
      var oHSepTmp=document.createElement("DIV")
      oHSepTmp.innerHTML="&nbsp;";
      oHSepTd.appendChild(oHSepTmp);
      oHSep.appendChild(oHSepTd);
	    oTBdy.appendChild(oHSep);
    }
    
    oH.setAttribute("id",oItm.Id);
    
    var sAtt="";
    sAtt+=oItm.HasSeparator?"s":"";
    sAtt+=oItm.HasEllipsis?"e":"";
    sAtt+=oItm.HasIcon?"i":"";
    sAtt+=oItm.IsLink?"l":"";
    oH.setAttribute("att",sAtt);
    var sSt="";
    if (!oItm.Enabled) sSt+="d";
    if (oItm.CanCheck) {
      if (oItm.Checked) sSt+="s";
      else sSt+="n";
    } 
    oH.setAttribute("st",sSt);
    oH.setAttribute("ocl",oItm.POPUPMENUITEMSELECT);
    oH.setAttribute("olc",oItm.POPUPMENUITEMLINKCLICK);
    
    if (oItm.HasSubMenu && oItm.SubMenuId!='') oH.setAttribute("smnu",oItm.SubMenuId);
    oH.setAttribute("t",oItm.Text);
    if (oItm.HasIcon) {
      oH.setAttribute("eis",oItm.EnabledIconSrc);
      oH.setAttribute("dis",oItm.DisabledIconSrc);
    }
	  oTBdy.appendChild(oH);
  }
  
  var sId=oPMn.id;
  _ur_POMN.all[sId]=null;
  if (!initMenus)  initMenus=new Array();
  if (initMenus[sId]) initMenus[sId]=null;
  mf_PopupMenu_getObj(sId);
}
function mf_PopupMenu_addItem (oPMn,oItm) {
  oPMn.items[oPMn.items.length]=oItm;
}
function mf_PopupMenu_removeItem (oPMn,oItm) {
  var j=0;
  var items=new Array();
  for (var i=0;i<oPMn.items.length;i++) 
    if (oItm.Id!=oPMn.items[i].Id) items.push(oPMn.items[i]);
  oPMn.items=items
}
function mf_PopupMenu_replaceItem (oPMn,oOldItm,oNewItm) {
  var j=0;
  var oNewItems=new Array();
  for (var i=0;i<oPMn.items.length;i++) 
    if (oOldItm.Id==oPMn.items[i].Id) oPMn.items[i].Id=oNewItm;
}
function mf_PopupMenu_removeAllItems (oPMn) {
  oPMn.items=new Array();
  var oTable=oPMn.ref.getElementsByTagName("TABLE")[0];
  oTable.style.width="50px";
  return oPMn;
}
function mf_PopupMenu_apply (oPMn) {
  ur_PopupMenu_render(oPMn);
  oPMn.ref.firstChild.style.width="";
}
function mf_PopupMenu_getItemById (oPMn,sItemId) {
  for (var i=0;i<oPMn.items.length;i++) 
    if (sItemId==oPMn.items[i].Id) return oPMn.items[i];
  return null;
}
function mf_PopupMenu_getItemByIdx (oPMn,iIdx) {
  return oPMn.items[iIdx];
}
function mf_PopupMenu_createItem (sId) {
  return {Id:sId,Enabled:true,HasSubMenu:false,SubMenuId:"",HasSeparator:false,Text:"",CanCheck:false,GroupId:"",Checked:false,HasIcon:false,EnabledIconSrc:"",DisabledIconSrc:"",HasEllipsis:false,TextDirection:"ltr",POPUPMENUITEMSELECT:"",POPUPMENUITEMLINKCLICK:"",Menu:null};
}
function ur_PopupMenu_click(hWnd,sId,oEvt) {
    var oItm=ur_EVT_src(oEvt);
  if (oItm.tagName=="BODY" || oItm.tagName=="DIV") {
		var aItems = hWnd.document.getElementsByTagName("TR");
    for (var i=0;i<aItems.length;i++) {
			if (aItems[i].className.indexOf("urMnuRowOn")>-1) {
				oItm = aItems[i];
			}
    }
  } else {
		while (oItm && ur_getAttD(oItm,"ocl","")=="" && ur_getAttD(oItm,"olc","")=="") {
			if (oItm.className=="urMnuDvdr") return;
			if (ur_getAttD(oItm,"smnu","")!="") return;
			if (oItm.tagName == "TFOOT" || oItm.tagName == "TBODY") return;
			else oItm=oItm.parentNode;
		}
	}
  if (oItm == null || oItm.tagName=="BODY" || oItm.tagName=="DIV") return;
  if (ur_getAttD(oItm,"st","").indexOf("d")>-1) return
  if (ur_getAttD(oItm,"ocl","")!="")  ur_EVT_fire(oItm,"ocl",oEvt,hWnd);  
  if (ur_getAttD(oItm,"olc","")!="") ur_EVT_fire(oItm,"olc",oEvt,hWnd);	
  ur_EVT_cancel(oEvt);
}
function mf_PopupMenu_setScrollSettings(iFirstVisibleItem,iMaxVisibleItems) {
  var o=ur_get(sId+"-r");
  o.setAttribute("viscnt",iMaxVisibleItems);
  o.setAttribute("visidx",iFirstVisibleItem);
}
function mf_PopupMenu_getTriggeredUserData() {
  var o=ur_get(_ur_POMN_triggerId);
  if (o && o.getAttribute && o.getAttribute("ud")) {
	  return ur_getAttD(o,"ud","");
  }
  return _ur_POMN_triggerId;
}

//** PopupTrigger.ie5 **

function sapUrMapi_PopupTrigger_hover(sId,oEv) {
	var oT=ur_get(sId);
	var sIa=oT.getAttribute("ia");
	if (oEv.type=="mouseover") {
		oT.className = "urPopUpTrgWhl urPopUpTrHover urPopUpTrgIndHover";
	}
	
	else if (oEv.type=="mouseout"){
		if (sIa == "t") {
     		oT.className = "urPopUpTrgWhl";
		}
		else {
			oT.className = "urPopUpTrgWhl urPopUpTrgInd";
		}
	}
}
function sapUrMapi_PopupTrigger_openMenu(sId,sMenuId,e) {
	var o=ur_get(sId);
	var bOpen=false;
	var eConMenu=false;
	var eClick=false;
	
	if(ur_system.is508 ) var oChild=sapUrMapi_findFirstFocus(o);
	
	if(oChild && oChild.getAttribute("id") != null &&oChild.getAttribute("id") != "") {
		var sChildId = oChild.getAttribute("id");
	}
	else {
		var sChildId = sId;
	}
	
	var oBtn=ur_get(sId+"-btn");
	if((o && o.oncontextmenu) || (oBtn && oBtn.oncontextmenu)) {
	  eConMenu=true;
	  eClick=true;
	}
	if (sapUrMapi_checkKey(e,"keydown",new Array("121")) && eConMenu==true){
		bOpen=true;
	} else if (e.altKey && sapUrMapi_checkKey(e,"keydown",new Array("40")) && eClick==true){
		bOpen=true;
	} else if(e.type=="contextmenu" ||e.type=="click") {
		bOpen=true;
	}else if(sapUrMapi_checkKey(e,"keydown",new Array("115"))) {
		bOpen=true;
	}else if(e.keyCode==32 && e.srcElement.getAttribute("id").indexOf("_selmenu")>-1){
		bOpen=true;
		e.cancelBubble=true;
	}
	
	if (bOpen) {
		if (ur_system.direction=="rtl")
		  sapUrMapi_PopupMenu_showMenu(sChildId,sMenuId,sapPopupPositionBehavior.MENULEFT,e);
		else
	 	  sapUrMapi_PopupMenu_showMenu(sChildId,sMenuId,sapPopupPositionBehavior.MENURIGHT,e);
		  if (sapUrMapi_checkKey(e,"keydown",new Array("115","121")))return ur_EVT_cancel(e);
		  if (e.type=="contextmenu") {
		  	  ur_EVT_cancel(e);
		  } else {
			ur_EVT_cancelBubble(e);
		    e.returnValue=true;
		  }
	}
    
}
function sapUrMapi_PopupTrigger_focus(sId,oEv){
}
function sapUrMapi_PopupTrigger_RegisterCreate(sId) {
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_PopupTrigger_init('" + sId + "')");
}
function sapUrMapi_PopupTrigger_init(sId){
	   if (ur_get(sId) == null || ur_get(sId).firstChild == null) return;
	   var value = ur_get(sId).firstChild.style.width;
	   var percent = value.lastIndexOf('%');
	   if(percent < 3 && percent > -1)
	   {
	     ur_get(sId).style.width = value;
	     ur_get(sId).firstChild.style.width = '100%';
	   }
}

//** RadioButton.ie5 **

function sapUrMapi_RadioButton_registerCreate(sId) {
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_RadioButton_create('"+sId+"')");
}
function sapUrMapi_RadioButton_create(sId) {
	var aGroup = sapUrMapi_RadioButton_getGroup(sId),
		bSelected = false; 
	for (var i=aGroup.length-1;i>=0;i--) {
		if (aGroup[i].getAttribute("initialized") == "true") return;
		aGroup[i].setAttribute("initialized","true");
		
		if (aGroup[i].checked && !bSelected && (!aGroup[i].disabled || ur_system.is508)) {
			if (!aGroup[i].disabled) {
				sapUrMapi_RadioButton_toggle(aGroup[i].id,{type:""},true);
			} else {
				ur_get(aGroup[i].id+"-r").tabIndex=0;
			}
			bSelected = true;
				
		}
	}
	if (bSelected) return;
	var i = 0;
	while (i<aGroup.length && aGroup[i].disabled && !ur_system.is508) i++;
	if (i>=aGroup.length) return;
	ur_get(aGroup[i].id + "-r").tabIndex = "0";}
function sapUrMapi_RadioButton_toggle(sId,e,create) {
	if(e.type=="keydown" && (e.ctrlLeft || e.ctrlRight)) return;
	var oIn=ur_get(sId),
		oImg=ur_get(sId+"-img"),
		oRoot = ur_get(sId+"-r");
	var newClass = "";
	if (ur_isSt(oRoot,new Array(ur_st.DISABLED)) || ur_isSt(oRoot,new Array(ur_st.READONLY))) return false;
	var oInGrp=sapUrMapi_RadioButton_getGroup(sId);
	ur_setSt(oRoot,ur_st.SELECTED,true);
	ur_setSt(oRoot,ur_st.NOTSELECTED,false);
	oRoot.tabIndex="0";
	if (!create) ur_focus(oRoot);
	oImg.className=oImg.className.replace("Off","On");
	for(var i=0;i<oInGrp.length;i++){
		oImg=ur_get(oInGrp[i].id+"-img");
		oInGrp[i].checked = false;
		oThisRoot=ur_get(oInGrp[i].id+"-r")
		if (oImg==null || oIn==oInGrp[i]) continue; 
		if(ur_isSt(oThisRoot,ur_st.SELECTED)){ 
			oImg.className=oImg.className.replace("On","Off");
			ur_setSt(oThisRoot,ur_st.SELECTED,false);
			ur_setSt(oThisRoot,ur_st.NOTSELECTED,true);			
			oThisRoot.tabIndex = "-1";
		}
	}
	
	
	newClass=oImg.className;
	oImg.className="";
	oImg.className=newClass;
	
	oIn.checked=true;
	if (ur_system.is508 && !create) oIn.fireEvent("onactivate");
	return true;
}
function sapUrMapi_RadioButton_setDisabled(sId) {
	sapUrMapi_CheckBox_setDisabled(sId);
}
function sapUrMapi_RadioButton_setEnabled(sId) {
	sapUrMapi_CheckBox_setEnabled(sId); 	
}
function sapUrMapi_RadioButton_setReadonly(sId,bSet){
	sapUrMapi_CheckBox_setReadonly(sId,bSet);
}
function sapUrMapi_RadioButton_setInvalid(sId){
	sapUrMapi_CheckBox_setInvalid(sId);
}
function sapUrMapi_RadioButton_getGroup(sId) {
	var oIn=ur_get(sId),
		oInGrp = [],
		oRadioButtonsGrp = [],
		j=0;
	if(oIn.name!="") 
		oInGrp=document.getElementsByName(oIn.name);
	else
		oInGrp[0]=oIn;
	for(var i=0; i<oInGrp.length; i++){
		if(oInGrp[i].getAttribute("ct") == "R") {
			oRadioButtonsGrp[j]=oInGrp[i];
			j++;
		}
	}
	return oRadioButtonsGrp;
}
function sapUrMapi_RadioButton_focus(sId,oEvt) {
	sapUrMapi_DataTip_show(sId,"focus");
}
function sapUrMapi_RadioButton_blur(sId,oEvt) {
	
	
	sapUrMapi_RadioButton_reset(sId);
	
	sapUrMapi_DataTip_hide(sId);
}
function sapUrMapi_RadioButton_reset(sId) { 
	var o = ur_get(sId);
	if (!o.checked) {
		o.tabIndex = "-1";
	}
	var aGroup = sapUrMapi_RadioButton_getGroup(sId),
		bSelected = false; 
	for (var i=0;i<aGroup.length;i++) {
		if (aGroup[i].checked && !bSelected && (!aGroup[i].disabled || ur_system.is508)) {
			ur_get(aGroup[i].id + "-r").tabIndex = "0";
			bSelected = true;	
		} else {
			ur_get(aGroup[i].id + "-r").tabIndex = "-1";
		}
	}
	if (bSelected) return;
	var i = 0;
	while (i<aGroup.length-1 && aGroup[i].disabled && !ur_system.is508) i++;
	if (i==aGroup.length) return;
	ur_get(aGroup[i].id + "-r").tabIndex = "0";
}
function sapUrMapi_RadioButton_keydown(sId,oEvt) {
	var iKey=oEvt.keyCode;	
	if(iKey==37)
		iKey==ur_system.direction!="rtl"?37:39;
	else if(iKey==39)
		iKey==ur_system.direction!="rtl"?39:37;
	
	if( oEvt.keyCode==73 && oEvt.shiftKey && sapUrMapi_bCtrl(oEvt) && !oEvt.altKey){
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
		return ur_EVT_cancel(oEvt);
	}
	
	
	else if(oEvt.keyCode == "32"){
		
		ur_get(sId).click();
		return ur_EVT_cancel(oEvt);		
	}
	
	else if(oEvt.keyCode == "27"){
		sapUrMapi_DataTip_hide(sId);
		return ur_EVT_cancel(oEvt);		
	}
	
	else if(iKey==37 || iKey==38){		 
		var oIn=ur_get(sId),
			oInGrp=sapUrMapi_RadioButton_getGroup(sId),
			i = 0;
		for(var n=0; n<oInGrp.length;n++) {
			if (oInGrp[n]==oIn) i=n;
			if (oInGrp[n].checked) {
				ur_get(oInGrp[n].id + "-r").tabIndex = "-1";
			}
		}
		i = i-1;
		while(oInGrp[i] && (oInGrp[i].disabled && !ur_system.is508)) i = i-1;
		if (i>-1) {
			if (oEvt.shiftKey || (oInGrp[i].disabled && ur_system.is508) ) {
				var thisRoot = ur_get(oInGrp[i].id + "-r");
				thisRoot.tabIndex="0";
				thisRoot.setAttribute("ti","0");
				thisRoot.focus();
			} else if (!oInGrp[i].disabled) {
				sapUrMapi_RadioButton_toggle(oInGrp[i].id,oEvt);
				ur_get(oInGrp[i].id).click();
			}
		}
		return ur_EVT_cancel(oEvt);
	}
	
	else if(iKey==39 || iKey==40){
		var oIn=ur_get(sId),
			oInGrp=sapUrMapi_RadioButton_getGroup(sId),
			i = 0;
		for(var n=0; n<oInGrp.length;n++) {
			if (oInGrp[n]==oIn) i=n;
			if (oInGrp[n].checked) {
				ur_get(oInGrp[n].id + "-r").tabIndex = "-1";
			}
		}
		i = i+1;
		while(oInGrp[i] && (oInGrp[i].disabled && !ur_system.is508)) i = i+1;
		if (i<oInGrp.length)  {
			if (oEvt.shiftKey || (oInGrp[i].disabled && ur_system.is508) ) {
				var thisRoot = ur_get(oInGrp[i].id + "-r");
				thisRoot.tabIndex="0";
				thisRoot.setAttribute("ti","0");
				thisRoot.focus();
			} else if (!oInGrp[i].disabled) {
				sapUrMapi_RadioButton_toggle(oInGrp[i].id,oEvt);
				ur_get(oInGrp[i].id).click();
			}
		}
		return ur_EVT_cancel(oEvt);
	}
}

//** RichTextEdit.nn6 **

var rteChanged = {};
function ur_RTE_Create(sId,sText,Evt)
{
	rteChanged[sId] = false;
	var oRef = ur_get(sId);
	if (oRef && oRef.getAttribute("readonly") == "true") {
		oRef.innerHTML = sText;	
	}
}
function ur_RTE_IframeLoad(sId,sText)
{
	rteChanged[sId] = false;
	try{
	var oIfrm = ur_get(sId+'-frm'),
	    oDoc = oIfrm.contentWindow.document;
	oDoc.body.setAttribute("id",sId);
	if(sText == "")
		sText = "<p>&nbsp;</p>";
	sText = sText.replace(/<\/br>/g, "");
	var oLink = oDoc.getElementsByTagName("LINK")[0],
	    cssUrl = ur_system.stylepath+"ur_"+ur_system.browser_abbrev+".css";
        
	oLink.href = ur_RTE_relativeToAbsolutePath(cssUrl, location.href);
	
	oDoc.body.dir = ur_system.direction;
	oDoc.body.className = "urBdyStd urTrcBodyBox urFTxtV";
	oDoc.body.innerHTML = sText;
	
	oDoc.designMode = 'On'; 
	oDoc.execCommand("useCSS",false,true); 
	oDoc.addEventListener("keypress",ur_RTE_keyHandler,true);
	oDoc.addEventListener("keydown",ur_RTE_keyHandler,true);
	oDoc.addEventListener("keyup",ur_RTE_keyHandler,true);
	oDoc.addEventListener("click",ur_RTE_handleClick,true);
	oDoc.addEventListener("blur",ur_RTE_blur,true);
	}catch(ex){};
}
function ur_RTE_blur(evt)
{
	var sId = ur_RTE_getIdFromEvent(evt);
	if (rteChanged[sId]) {
		ur_EVT_fire(ur_get(sId),"ochg");
	}
	
}
function ur_RTE_getIdFromEvent(evt)
{
	var sId ="", oTarget = evt.target, oBody;
	
	while(oTarget.parentNode != null) {
		oTarget = oTarget.parentNode;
	}
	
	oBody = oTarget.getElementsByTagName("body")[0];
	return oBody.getAttribute("id");
}
function ur_RTE_keyHandler(evt)
{
	var sId = ur_RTE_getIdFromEvent(evt);
	if(evt.keyCode == 9 && evt.type=="keydown")
	{
		evt.preventDefault();
		evt.stopPropagation();
		var oFocusElement = null;
		if (evt.shiftKey) {
			oFocusElement = ur_findPreviousFocusableElement(ur_get(sId+"-frm"));
		} else {
			oFocusElement = ur_findNextFocusableElement(ur_get(sId+"-frm"));
		}
		if (oFocusElement) {
			ur_focus(oFocusElement);
		}
	}
	if (sapUrMapi_bCtrl(evt)) {
		var key = String.fromCharCode(evt.charCode).toLowerCase();
		var cmd = '';
		switch (key) {
			case 'b': cmd = "bold"; break;
			case 'i': cmd = "italic"; break;
			case 'u': cmd = "underline"; break;
		};
		
		if (cmd) {
			ur_RTE_frmt(sId,"",cmd);
			
			evt.preventDefault();
			evt.stopPropagation();
		}
 	}
    	rteChanged[sId] = true;
	ur_RTE_queryState(sId);
}
function ur_RTE_handleClick(evt)
{
	if(evt.target.tagName == "HTML") return;
	
	var sId = evt.target.getAttribute("id");
	
	if(!sId && (evt.target).tagName != "BODY")
	{
		
		var elm = evt.target;
		while(elm.tagName != "BODY")
		{
			elm  = elm.parentNode;
		}
		
		sId = elm.getAttribute("id");
		
	}
	
	ur_RTE_queryState(sId);
}
function ur_RTE_btnClk(sId,Evt)
{
	
	if (!sId) return;
	var oCtrl = sapUrMapi_getRootControl(ur_get(sId).parentNode);
	var sIdCtrl = oCtrl.id;
	if(sId.indexOf('-bld')> -1){
		ur_RTE_frmt(sIdCtrl,"","Bold");
	}
	else if(sId.indexOf('-itl')> -1)
	{
		ur_RTE_frmt(sIdCtrl,"","italic");
	}
	else if(sId.indexOf('-und')> -1)
	{
		ur_RTE_frmt(sIdCtrl,"","Underline");
	}
	else if(sId.indexOf('-head1')> -1)
	{
		if(ur_get(sIdCtrl+"-tbar-head1").className == "urBtnStdD")
			ur_RTE_frmt(sIdCtrl,"<p>","formatblock");
		else
			ur_RTE_frmt(sIdCtrl,"<h1>","formatblock");
	}
	else if(sId.indexOf('-head2')> -1)
	{
		if(ur_get(sIdCtrl+"-tbar-head2").className == "urBtnStdD")
			ur_RTE_frmt(sIdCtrl,"<p>","formatblock");
		else
			ur_RTE_frmt(sIdCtrl,"<h2>","formatblock");
	}
	else if(sId.indexOf('-head3')> -1)
	{		
		if(ur_get(sIdCtrl+"-tbar-head3").className == "urBtnStdD")
			ur_RTE_frmt(sIdCtrl,"<p>","formatblock");
		else
			ur_RTE_frmt(sIdCtrl,"<h3>","formatblock");
	}	else if(sId.indexOf('-idnt')> -1)
	{
		ur_RTE_frmt(sIdCtrl,"","Indent");
	}
	else if(sId.indexOf('-odnt')> -1)
	{
		ur_RTE_frmt(sIdCtrl,"","Outdent");
	}
	else if(sId.indexOf('-olist')> -1)
	{
		ur_RTE_frmt(sIdCtrl,"","InsertOrderedList");
	}
	else if(sId.indexOf('-unolist')> -1)
	{
		ur_RTE_frmt(sIdCtrl,"","InsertUnorderedList");
	}
	rteChanged[sIdCtrl] = true;
	ur_RTE_queryState(sIdCtrl);
}
function ur_RTE_frmt(sId,format,selName)
{	
	var oCtrl = ur_get(sId+"-frm");
	oCtrl.contentWindow.document.execCommand(selName,false,format);
	oCtrl.contentWindow.focus();
	ur_RTE_queryState(sId);
	
}
function ur_RTE_queryState(sId)
{
	
	var oIfrm = ur_get(sId+"-frm");
	
	if(ur_get(sId+"-tbar-itl"))
	{
		var bI = oIfrm.contentWindow.document.queryCommandState("Italic");
		if(bI)
			ur_TB_toggleDownState(sId+"-tbar-itl","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-itl","up");
	}
	if(ur_get(sId+"-tbar-bld"))
	{
		var bB = oIfrm.contentWindow.document.queryCommandState('Bold');
		if(bB)
			ur_TB_toggleDownState(sId+"-tbar-bld","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-bld","up");
	}
	if(ur_get(sId+"-tbar-und"))
	{
		var bU = oIfrm.contentWindow.document.queryCommandState('Underline');
		if(bU)
			ur_TB_toggleDownState(sId+"-tbar-und","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-und","up");
	}
	if(ur_get(sId+"-tbar-head1"))
	{
		var sH1 = oIfrm.contentWindow.document.queryCommandValue('formatblock');
		if(sH1 == "h1")
			ur_TB_toggleDownState(sId+"-tbar-head1","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-head1","up");
	}
	if(ur_get(sId+"-tbar-head2"))
	{
		var sH2 = oIfrm.contentWindow.document.queryCommandValue('formatblock');
		if(sH2 == "h2")
			ur_TB_toggleDownState(sId+"-tbar-head2","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-head2","up");
	}
	if(ur_get(sId+"-tbar-head3"))
	{
		var sH3 = oIfrm.contentWindow.document.queryCommandValue('formatblock');
		if(sH3 == "h3")
			ur_TB_toggleDownState(sId+"-tbar-head3","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-head3","up");
	}
	
	if(ur_get(sId+"-tbar-olist"))
	{
		var bOlist = oIfrm.contentWindow.document.queryCommandState("InsertOrderedList");
		if(bOlist)
			ur_TB_toggleDownState(sId+"-tbar-olist","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-olist","up");
	}
	if(ur_get(sId+"-tbar-unolist"))
	{
		var bOlist = oIfrm.contentWindow.document.queryCommandState("InsertUnorderedList");
		if(bOlist)
			ur_TB_toggleDownState(sId+"-tbar-unolist","dn");
		else
			ur_TB_toggleDownState(sId+"-tbar-unolist","up");
	}	
	
}
function ur_TB_toggleDownState(sId,bSt)
{
	
	var oBtn = ur_get(sId);
	var oBtnR = ur_get(sId+"-r");
	if(bSt == "dn")
	{
		oBtn.className = "urBtnStdD";
		oBtnR.setAttribute("down","true");
	}
	else if(bSt == "up")
	{
		oBtn.className = "urBtnStd";
		oBtnR.setAttribute("down","false");
	}
	else
	{
		if(oBtn.className == "urBtnStd")
			oBtn.className == "urBtnStdD"
		else
			oBtn.className == "urBtnStd"
	}
}
var ur_RTE_iSerializeCounter = 0;
function ur_RTE_getHTMLText(sId,oEvt)
{
   var node = ur_get(sId+'-frm').contentWindow.document.body,
       buffer = [],
       html;
   
   ur_RTE_iSerializeCounter++;    
   ur_RTE_serializeXHTML(buffer, node);
   html = buffer.join("");
   return html;
}
var ur_RTE_oValidTags = {
	"abbr":{empty:false},
	"acronym":{empty:false},
	"address":{empty:false},
	"blockquote":{empty:false},
	"br":{empty:true},
	"cite":{empty:false},
	"code":{empty:false},
	"dfn":{empty:false},
	"div":{empty:false},
	"em":{empty:false},
	"h1":{empty:false},
	"h2":{empty:false},
	"h3":{empty:false},
	"h4":{empty:false},
	"kbd":{empty:false},
	"p":{empty:false},
	"pre":{empty:false},
	"q":{empty:false},
	"samp":{empty:false},
	"span":{empty:false},
	"strong":{empty:false},
	"var":{empty:false},
	"dt":{empty:false},
	"dd":{empty:false},
	"ol":{empty:false},
	"ul":{empty:false},
	"li":{empty:false},
	"a":{empty:false, attrs:["href"]},
	"img":{empty:true, attrs:["src"]},
	
	"b":{mapped:"strong"},
	"i":{mapped:"em"}
};
var ur_RTE_oOmitContentTags = {
	"script": true,
	"noscript": true,
	"style": true,
	"select": true,
	"button": true,
	"link": true,
	"iframe": true,
	"object": true
};
function ur_RTE_serializeXHTML(aBuffer, oNode) {
	switch(oNode.nodeType) {
		case 1: 
			var sTagName = oNode.tagName.toLowerCase(),
				oTagInfo = ur_RTE_oValidTags[sTagName];
			if (oTagInfo) {
				
				
				
				if (oNode.cnt == ur_RTE_iSerializeCounter) {
					break;
				}
				oNode.cnt = ur_RTE_iSerializeCounter;
				
				if (oTagInfo.mapped) {
					sTagName = oTagInfo.mapped;
					oTagInfo = ur_RTE_oValidTags[sTagName];
				}
				
				aBuffer.push("<");
				aBuffer.push(sTagName);
				if (oTagInfo.attrs) {
					var aAttributes = oTagInfo.attrs,
						sName,
						sValue;
					for (var i = 0; i < aAttributes.length; i++) {
						sName = aAttributes[i];
						sValue = oNode.getAttribute(sName);
						if (sValue) {
							aBuffer.push(" ");
							aBuffer.push(sName); 
							aBuffer.push("=\""); 
							aBuffer.push(ur_RTE_sXmlEscape(sValue));
							aBuffer.push("\""); 
						}
					}
				}
				if (oTagInfo.empty) {
					aBuffer.push(" />");
				}	
				else {
					aBuffer.push(">");
				}
			}
			
			if (!ur_RTE_oOmitContentTags[sTagName]) {
				var childNodes = oNode.childNodes;
				if (childNodes) {
					for (var i = 0; i < childNodes.length; i++) {
						ur_RTE_serializeXHTML(aBuffer, childNodes[i]);
					}
				}
			}
			
			if (oTagInfo && !oTagInfo.empty) {
				aBuffer.push("</" + sTagName + ">");			
			}
			break;
		case 3: 
			aBuffer.push(ur_RTE_sXmlEscape(oNode.nodeValue));
			break;
		default: 
			
	}
};
function ur_RTE_sXmlEscape(sText) {
	sText = sText.replace(/\&/g, "&amp;");
	sText = sText.replace(/\</g, "&lt;");
	sText = sText.replace(/\"/g, "&quot;");
	return sText;
};
function ur_RTE_relativeToAbsolutePath(strRel,strAbs) {
  if (strRel.lastIndexOf("./")==-1) return strRel; 
  var strRelDots      = strRel.substring(0,strRel.lastIndexOf("./")+2);
  var strAbsPath      = strAbs.substring(0,strAbs.lastIndexOf("/")); 
  while(strRelDots.lastIndexOf("..")>-1) { 
    strAbsPath = strAbsPath.substring(0,strAbsPath.lastIndexOf("/")); 
    strRelDots = strRelDots.substring(0,strRelDots.lastIndexOf(".."))+"/";
  }
  if (strRelDots.lastIndexOf("./")>-1) {
    strRelDots = strRelDots.substring(0,strRelDots.lastIndexOf("./"))+"/";
    if (strRelDots.lastIndexOf("./")>-1) { 
      showError (strRel+" is not a valid relative url.");
    }
  }
  
  strNewAbsPath = strAbsPath + strRelDots + strRel.substring(strRel.lastIndexOf("./")+2,strRel.length);
  return strNewAbsPath;
}  

//** RoadMap.nn6 **

function ur_RM_RegisterCreate(sId)
{
	 var oRm = ur_get(sId);
	if(parseInt(oRm.getAttribute("ic"))==0)return;
 	
  	if(!oRm.getAttribute('selectedstep'))
		oRm.setAttribute("selectedstep","-1");
	 if(oRm.getAttribute('scrl') == "1")
		sapUrMapi_Create_AddItem(sId, "ur_RM_create('" + sId + "')");
	else
		ur_get(sId+"-scrl").className = "";
}
function sapUrMapi_RoadMap_hoverEdges(sId,edgeType,e){
	var oS= ur_get(sId + "-itm-start");
	var sBts=oS.childNodes[0].className;
	var oE= ur_get(sId + "-itm-end");
	var sBte=oE.childNodes[0].className;
	
	if(e.type=="mouseover" && sBts=="urRMMoreBefore" && edgeType=="start"){
		oS.childNodes[0].className="urRMMoreBeforeHover";
	}
	else if(e.type=="mouseout" && sBts=="urRMMoreBeforeHover" && edgeType=="start"){
		oS.childNodes[0].className="urRMMoreBefore";
	}
	else if(e.type=='mouseover' && sBte=='urRMMoreAfter' && edgeType=="end"){
		oE.childNodes[0].className='urRMMoreAfterHover';
	}
	else if(e.type=='mouseout' && sBte=='urRMMoreAfterHover'&& edgeType=="end"){
		oE.childNodes[0].className='urRMMoreAfter';
	}
}
function sapUrMapi_RoadMap_hoverStep(sId,iStepNr,e){
	var iSel = parseInt(ur_get(sId).getAttribute("selectedstep"));
	var oTitle = ur_get(sId + "-itm-" + iStepNr).childNodes[1];
	
	if( iSel == iStepNr || oTitle.className == "urRMNoItem")return;
		if(e.type=="mouseover"){
		oTitle.className = "urRMStepItem urRMItemHover";
			}
		else if(e.type=="mouseout"){
			oTitle.className = "urRMStepItem";
			}
}
function ur_RM_create(sId)
{
	ur_get(sId+'-itm-start').setAttribute("stDsgn",ur_get(sId+'-itm-start').firstChild.className);
	ur_get(sId+'-itm-end').setAttribute("endDsgn",ur_get(sId+'-itm-end').firstChild.className);
	
	ur_IScr_getObj(sId);
	ur_IScr_create(sId);
	sapUrMapi_Resize_AddItem(sId, "ur_IScr_resize('"+sId+"')");
}
function sapUrMapi_RoadMap_keydownStep(sId,iItmIdx,e){
	var oRm = ur_get(sId);
	var oItm=ur_get(sId+"-itm-"+iItmIdx);
	var oPrev=null;
	var oNext=null;
	var bScroll=oRm.getAttribute("scrl");
	var oRmScrl = ur_IScr[sId];
	if(ur_system.direction!="rtl"){
		oPrev=oItm.previousSibling;
		oNext = oItm.nextSibling;
		}else{
		oNext=oItm.previousSibling;
		oPrev = oItm.nextSibling;
		}
	if(e.keyCode == 39 && oNext!=null) {
		if(bScroll=="1" && iItmIdx == oRmScrl.last)
		   ur_IScr_toNextPage(sId);
		   ur_focus_Itm(oNext,oItm);
		   ur_EVT_cancel(e);
	    }
	else if(e.keyCode == 37 && oPrev!=null){
		if(bScroll=="1" && iItmIdx ==oRmScrl.first)
   	       ur_IScr_toPrevPage(sId);
		   ur_focus_Itm(oPrev,oItm);
		   ur_EVT_cancel(e);
	}
	else if(e.keyCode==9){
		var iSel = oRm.getAttribute("selectedstep");
		if(iSel=="-1")iSel=0;
		var oSel = ur_get(sId+"-itm-"+iSel);
		ur_focus_Itm(oSel,oItm);
	}
	else if(e.keyCode==32)oItm.click();
	 ur_EVT_cancelBubble(e);
}
function ur_RM_oadi(sId,oEvt)
{
	var o = ur_IScr[sId];
	if(o.first!= 0)
		ur_get(sId+'-itm-start').firstChild.className = "urRMMoreBefore";
	else
		ur_get(sId+'-itm-start').firstChild.className = ur_get(sId+'-itm-start').getAttribute("stDsgn");
	if(o.last != o.items.length-1)
	{
		ur_get(sId+'-itm-end').firstChild.className = "urRMMoreAfter";
				
	}
	else
	{
		ur_get(sId+'-itm-end').firstChild.className = ur_get(sId+'-itm-end').getAttribute("endDsgn");
	}
}
function ur_RM_select(sId,iNr,oEv){
	var o = ur_get(sId + "-itm-" + iNr);
	var iSelectedIdx = parseInt(ur_get(sId).getAttribute("selectedstep"));
	
	
	if( o.getAttribute("st") && o.getAttribute("st").indexOf("d") > -1  ||
		iSelectedIdx == iNr ||
		o.className == "urRMNotInterActive") return;
	
	var oStepN = o.getElementsByTagName("TD")[1];
	var oTitleN = o.childNodes[1];
	var oRm = ur_get(sId);
		
	oStepN.className = oStepN.className + "Sel";
	oTitleN.className = "urRMStepItem";
	oTitleN.className = oTitleN.className + "Sel";
		
		
	
	if (ur_system.is508) {
		ur_setSt(o,ur_st.NOTSELECTED,false);
		ur_setSt(o,ur_st.SELECTED,true);
		sapUrMapi_refocusElement(ur_get(sId + "-itm-" + iNr));
	}
	
	if (iSelectedIdx != -1) {
		var o = ur_get(sId + "-itm-" + iSelectedIdx);
		var oStepO = o.getElementsByTagName("TD")[1];
		var oTitleO = o.childNodes[1];
		
		oStepO.className = oStepO.className.split("Sel")[0];
		oTitleO.className = oTitleO.className.split("Sel")[0];
		sapUrMapi_setTabIndex(oStepO,-1);
		
		ur_setSt(o,ur_st.NOTSELECTED,true);
		ur_setSt(o,ur_st.SELECTED,false);
	}
	
	
	sapUrMapi_setTabIndex(oStepN,0);
	oRm.setAttribute("focusedstep", iNr);
	oRm.setAttribute("selectedstep",iNr);
	
	
	if ( oRm.scroll == 1 ){
		ur_EVT_addParam(oEv,"FirstVisibleItemIdx",ur_IScr[sId].first);
    	var bVisible = ur_IScr[sId].items[iNr].visible;
		
	    if ( bVisible ) 
			ur_IScr_draw(sId);
	    else {
	      ur_IScr[sId].first = iNr;
	      ur_IScr[sId].last = -1;
	      ur_IScr_draw(sId);
	}
     }
}
function ur_RM_Scrl(sId,edgeType,oEvt)
{
	var iRmItms = parseInt(ur_get(sId).getAttribute("ic"));	
	if(iRmItms==0)return;
	var oRmStart = ur_get(sId+'-itm-start');
	var oRmEnd = ur_get(sId+'-itm-end');
	var oRmScrl = ur_IScr[sId];
	if( oRmStart.firstChild.className.indexOf("Before") > -1 && edgeType == "start" && oRmScrl.first != 0)
	{
		ur_IScr_toPrevPage(sId);
	}
	else if( oRmEnd.firstChild.className.indexOf("After") && edgeType == "end" && oRmScrl.last != ( iRmItms - 1) )
	{
		ur_IScr_toNextPage(sId);
	}
	else if( oRmStart.firstChild.className.indexOf("Before") > -1 || oRmScrl.first == 0 && edgeType == "start") 
			 ur_EVT_fire(oRmStart,"onscrl");
	else if( oRmEnd.firstChild.className.indexOf("After") > -1 || oRmScrl.last == iRmItms-1 && edgeType == "end")
			ur_EVT_fire(oRmEnd,"onscrl");
			
	ur_EVT_addParam(oEvt,"FirstVisibleItemIdx",ur_IScr[sId].first);
}

//** SapTable.ie5 **

function ur_contains(oDomRefContainer, oDomRefChild) {
	var oDomRef = oDomRefChild;
	
	if(oDomRefContainer == oDomRefChild) return true;
	
	while(oDomRef != null) {
		if(oDomRef == oDomRefContainer) return true;
		oDomRef = oDomRef.parentNode;
	}
	
	return false;
};
function sapUrMapi_SapTable_getClickedRowIndex(e)
{
   var o=ur_evtSrc(e);
   while (o!=null && o.getAttribute("rr")==null) o=o.parentElement;
   if(o==null) return;
   try {
     var iRIdx=parseInt(o.rr);
     if (isNaN(iRIdx)) return null;
     else return iRIdx;
   } catch (e) {
     return null;
   }
}
function sapUrMapi_SapTable_getClickedColIndex(e)
{
   var o=ur_evtSrc(e);
   while (o!=null && o.getAttribute("cc")==null) o=o.parentElement;
   if(o==null) return;
   try {
     var iCIdx=parseInt(o.cc);
     if (isNaN(iCIdx)) return null;
     else return iCIdx;
   } catch (e) {
     return null;
   }
}
function sapUrMapi_SapTable_getClickedCellId(e)
{
   var o=ur_evtSrc(e);
   while ( o!=null && o.getAttribute("cc")==null ) o=o.parentElement;
   if(o==null) return;
   try {
     var sId=o.id;
     return sId;
   } catch (e) {
     return null;
   }
}
function sapUrMapi_SapTable_getClickedRow(sTableId,e) {
   var idx=sapUrMapi_SapTable_getClickedRowIndex(e);
   if(idx==null) return;
   return sapUrMapi_SapTable_getRow(sTableId,idx);
}
function sapUrMapi_SapTable_getRow(sTableId, iRowIdx) {
	var oTable=ur_Table_create(sTableId),
		aRows = oTable.rows,
		iRowIndex = -1,
		sRowIndex = null;
	for (var i=0;i<aRows.length;i++) {
		sRowIndex = aRows[i].ref.getAttribute("rr");
		iRowIndex = -1;
		if(sRowIndex) {
			iRowIndex = parseInt(sRowIndex);
			if(isNaN(iRowIndex)) continue;
		} else continue;
		if (iRowIndex==iRowIdx) return aRows[i].ref;
	}
	return null;
}
function sapUrMapi_SapTable_correctSelectionBorder(oRow){}
function sapUrMapi_SapTable_correctSelectionBorder4Table(id){}
function sapUrMapi_SapTable_isSecondarySelected(oButton) {
  return oButton.className=="urSTRowSelSecIcon";
}
function sapUrMapi_SapTable_isPrimarySelected(oButton) {
  return oButton.className=="urSTRowSelIcon";
}
function sapUrMapi_SapTable_toggleSecondarySelection(oRow) {
  var oButton = oRow.getElementsByTagName("DIV").item(0);
  sapUrMapi_SapTable_selectRowByObject(oRow, !sapUrMapi_SapTable_isSecondarySelected(oButton), true);
}
var UR_FOCUS_APPEARANCE = {
  NONE:0,
  CLASS:1,
  FAST:2
};
var eUrFocusAppearance = UR_FOCUS_APPEARANCE.FAST;
function sapUrMapi_SapTable_setFocusAppearance(eLocalUrFocusAppearance) {
	eUrFocusAppearance = eLocalUrFocusAppearance;
};
var UR_SELECTION_STATE = {
  NOT_SELECTED:0,
  PRIMARY:1,
  SECONDARY:2
};
function sapUrMapi_SapTable_setSelection(oRow, eState) {
  if(eState == UR_SELECTION_STATE.NOT_SELECTED) {
    sapUrMapi_SapTable_selectRowByObject(oRow, false, false);
  } else if(eState == UR_SELECTION_STATE.PRIMARY) {
    sapUrMapi_SapTable_selectRowByObject(oRow, true, false);
  } else if(eState == UR_SELECTION_STATE.SECONDARY) {
    sapUrMapi_SapTable_selectRowByObject(oRow, true, true);
  }
}
function sapUrMapi_SapTable_setCellSelection(oCell, eState) {
  if(eState == UR_SELECTION_STATE.NOT_SELECTED) {
    sapUrMapi_SapTableSelectCell(oCell, false, false, false);
  } else if(eState == UR_SELECTION_STATE.PRIMARY) {
    sapUrMapi_SapTableSelectCell(oCell, false, true, false);
  } else if(eState == UR_SELECTION_STATE.SECONDARY) {
    sapUrMapi_SapTableSelectCell(oCell, false, true, true);
  }
}
var oUrFastTableSelectionInfo = null;
function ur_initFastTableSelectionInfo() {
	oUrFastTableSelectionInfo = {
		bValid: false
	};
	oUrFastTableSelectionInfo.oSelectorNames = {
		sPrimary: ".urST4Sel",
		sPrimaryReadOnly: ".urST4SelRo",
		sSecondary: ".urST4Sel2",
		sSecondaryReadOnly: ".urST4Sel2Ro",
		sFocus: ".urSTFoc"
	};
	
	oUrFastTableSelectionInfo.oClassNames = {
		sPrimary: "urST4Sel",
		sPrimaryReadOnly: "urST4SelRo",
		sSecondary: "urST4Sel2",
		sSecondaryReadOnly: "urST4Sel2Ro",
		sReadOnly: "urSTTDRo2",
		sFocus: "urSTFoc"
	};
	
	oUrFastTableSelectionInfo.oColors = {
		sPrimary: null,
		sPrimaryReadOnly: null,
		sSecondary: null,
		sSecondaryReadOnly: null,
		sFocus: null
	};	
	if(window.document.styleSheets) {
		for(var j=0; j<window.document.styleSheets.length; j++) {
			var oStyleSheet = window.document.styleSheets[j];
			if(oStyleSheet.href && oStyleSheet.href.indexOf("/ur_ie") >=0 ) {
		
				var oRules = oStyleSheet.rules,
					oRule = null;
				
				oUrFastTableSelectionInfo.bValid = true;
				
				for(var i=0; i<oRules.length; i++) {
					oRule = oRules[i];
					
					if(oRule.selectorText == oUrFastTableSelectionInfo.oSelectorNames.sPrimary) {
						oUrFastTableSelectionInfo.oColors.sPrimary = oRule.style.backgroundColor;
						continue;
					}
					
					if(oRule.selectorText == oUrFastTableSelectionInfo.oSelectorNames.sPrimaryReadOnly) {
						oUrFastTableSelectionInfo.oColors.sPrimaryReadOnly = oRule.style.backgroundColor;
						continue;
					}
					
					if(oRule.selectorText == oUrFastTableSelectionInfo.oSelectorNames.sSecondary) {
						oUrFastTableSelectionInfo.oColors.sSecondary = oRule.style.backgroundColor;
						continue;
					}
					
					if(oRule.selectorText == oUrFastTableSelectionInfo.oSelectorNames.sSecondaryReadOnly) {
						oUrFastTableSelectionInfo.oColors.sSecondaryReadOnly = oRule.style.backgroundColor;
						continue;
					}
					
					if(oRule.selectorText == oUrFastTableSelectionInfo.oSelectorNames.sFocus) {
						oUrFastTableSelectionInfo.oColors.sFocus = oRule.style.backgroundColor;
						continue;
					}
								
				}
			}
		}
	}
	return oUrFastTableSelectionInfo.bValid? oUrFastTableSelectionInfo: null;
}
function ur_getFastTableSelectionInfo() {
	return (oUrFastTableSelectionInfo)? (oUrFastTableSelectionInfo.bValid? oUrFastTableSelectionInfo: null) : ur_initFastTableSelectionInfo();
}
function ur_fastTableSelectionModeEnabled() {
	return ur_getFastTableSelectionInfo() != null;
}
function ur_fastTableCellSelect(oCell, bReadOnly, bSelect, bSecondary) {
	var oSelectionInfo = ur_getFastTableSelectionInfo();
	
	if(!oSelectionInfo) return false;
	
	
	if(oCell.firstChild && oCell.firstChild.className && 	
		(oCell.firstChild.className.indexOf("urEdf2WhlDsbl") >= 0 || oCell.firstChild.className.indexOf("urEdf2WhlRo") >= 0)
	){
	 return false;
	}
	if(!(oCell.urFastSelectionClean || bSelect)) {
		if(oCell.className.indexOf(oSelectionInfo.oClassNames.sPrimary) >= 0)
	  	oCell.className = oCell.className.replace(oSelectionInfo.oClassNames.sPrimary, "");
	  if(oCell.className.indexOf(oSelectionInfo.oClassNames.sPrimaryReadOnly) >= 0)
	  	oCell.className = oCell.className.replace(oSelectionInfo.oClassNames.sPrimaryReadOnly, "");
	  if(oCell.className.indexOf(oSelectionInfo.oClassNames.sSecondary) >= 0)
	  	oCell.className = oCell.className.replace(oSelectionInfo.oClassNames.sSecondary, "");
		if(oCell.className.indexOf(oSelectionInfo.oClassNames.sSecondaryReadOnly) >= 0)
	  	oCell.className = oCell.className.replace(oSelectionInfo.oClassNames.sSecondaryReadOnly, "");
	  
	  oCell.urFastSelectionClean = true;
	}
  if (bSelect) {
    if (bSecondary) {
			if(oCell.runtimeStyle.backgroundColor) {
				oCell.runtimeStyle.cssText = oCell.runtimeStyle.cssText.replace(oCell.runtimeStyle.backgroundColor, ((bReadOnly? oSelectionInfo.oColors.sSecondaryReadOnly: oSelectionInfo.oColors.sSecondary) + " !important") );
			} else {
	    	oCell.runtimeStyle.cssText += "background-color:" + (bReadOnly? oSelectionInfo.oColors.sSecondaryReadOnly: oSelectionInfo.oColors.sSecondary) + " !important";
	    }
    } else {
			if(oCell.runtimeStyle.backgroundColor) {
				oCell.runtimeStyle.cssText = oCell.runtimeStyle.cssText.replace(oCell.runtimeStyle.backgroundColor, ((bReadOnly? oSelectionInfo.oColors.sPrimaryReadOnly: oSelectionInfo.oColors.sPrimary) + " !important") );
			} else {
	    	oCell.runtimeStyle.cssText += "background-color:"+ (bReadOnly? oSelectionInfo.oColors.sPrimaryReadOnly: oSelectionInfo.oColors.sPrimary) +" !important";
	    }
    }
  } else {
  	oCell.runtimeStyle.backgroundColor = "";
  }
  
  return true;
};
function ur_fastTableCellFocus(oCell, bFocus) {
	if(eUrFocusAppearance != UR_FOCUS_APPEARANCE.FAST) return false;
	
	var oSelectionInfo = ur_getFastTableSelectionInfo();
	
	if(!oSelectionInfo) return false;
	
	if (bFocus) {
		if(!oCell.bIsFocusColorized) {
			if(oCell.runtimeStyle.backgroundColor) {
				oCell.setAttribute("sOldBgColor", oCell.runtimeStyle.backgroundColor);
				
				oCell.runtimeStyle.cssText = oCell.runtimeStyle.cssText.replace(oCell.runtimeStyle.backgroundColor, oSelectionInfo.oColors.sFocus + " !important");
			
			} else {
	    	oCell.runtimeStyle.cssText += "background-color:"+ oSelectionInfo.oColors.sFocus + " !important";
	    }
	    
	    oCell.bIsFocusColorized = true;
		}	
	} else {
		if(oCell.bIsFocusColorized) {
			
			var sOldBgColor = oCell.getAttribute("sOldBgColor");
			if(sOldBgColor) {
				oCell.runtimeStyle.cssText = oCell.runtimeStyle.cssText.replace(oSelectionInfo.oColors.sFocus, sOldBgColor + " !important");
				oCell.setAttribute("sOldBgColor", "");
			} else oCell.runtimeStyle.backgroundColor = "";
			
			oCell.bIsFocusColorized = false;
		}
	}
	return true;
};
function sapUrMapi_SapTable_selectRowByObject(oRow,bSelect,bSecondary)
{
  var oButton = oRow.getElementsByTagName("DIV").item(0),
    bHasSelectionButton = bHasSelectionButton = (oButton && oButton.className && oButton.className.indexOf("urSTRow") == 0)? true: false;
  if(bHasSelectionButton) {
    if(!sapUrMapi_SapTable_isSelButtonSelectable(oButton)) return;
    
    if(!bSelect && oButton.getAttribute("selMust")) return;
    if(!bSelect)
      oButton.className="urSTRowUnSelIcon";
    else if(bSecondary)
      oButton.className="urSTRowSelSecIcon";
    else
      oButton.className="urSTRowSelIcon";
  }
  for (var n=0;n<oRow.childNodes.length;n++) {
    oItem=oRow.childNodes[n];
    sapUrMapi_SapTableSelectCell(oItem,false,bSelect,bSecondary);
  }
  if(ur_system.is508 && bHasSelectionButton){
    if(bSelect){
      ur_setSt(oButton,ur_st.SELECTED,true);
      ur_setSt(oButton,ur_st.NOTSELECTED,false);
    }
    else{
      ur_setSt(oButton,ur_st.SELECTED,false);
      ur_setSt(oButton,ur_st.NOTSELECTED,true);
    }
    oButton.fireEvent("onactivate");
  }
}
function sapUrMapi_SapTable_selectRow(sTableId,sRowIdx,iCol,iGroup,e,bSecondary)
{
  if (typeof(bSecondary)=="undefined") bSecondary=false;
  var oRow = ur_EVT_src(e).parentNode.parentNode;
  while (oRow.tagName!="TR") oRow=oRow.parentNode;
  var oButton = oRow.getElementsByTagName("DIV").item(0);
  if(!sapUrMapi_SapTable_isSelButtonSelectable(oButton)) return oRow;
  var bSelect = sapUrMapi_SapTable_isSecondarySelected(oButton)||sapUrMapi_SapTable_isPrimarySelected(oButton)?false:true;
 
  sapUrMapi_SapTable_selectRowByObject(oRow,bSelect,bSecondary);
  return oRow;
}
function sapUrMapi_SapTableSelectCell(oCell,bEdit,bSelect,bSecondary)
{
  var bEdit=false;
  if (oCell.getAttribute("urRowSpan") &&  parseInt(oCell.getAttribute("urRowSpan")) > 1) return;
  if (typeof(bSelect)=="undefined") bSelect=true;
  if (typeof(bSecondary)=="undefined") bSecondary=false;
  if (oCell.className.indexOf("Ico")>-1) return;
  var bIsReadOnly = oCell.className.indexOf("urSTTDRo2") >= 0;
  if(!ur_fastTableCellSelect(oCell, bIsReadOnly, bSelect, bSecondary)) {
	  if (bSelect) {
	    if (bSecondary)
	      oCell.className = oCell.className + " urST4Sel2" + (bIsReadOnly? "Ro": "");
	    else
	      oCell.className = oCell.className + " urST4Sel" + (bIsReadOnly? "Ro": "");
	  } else {
	  	if(bIsReadOnly) {
	  		oCell.className=oCell.className.replace(" urST4Sel2Ro","");
		    oCell.className=oCell.className.replace(" urST4SelRo","");
	  	} else {
	  		oCell.className=oCell.className.replace(" urST4Sel2","");
		    oCell.className=oCell.className.replace(" urST4Sel","");
	  	}
	  }
  }
  if(ur_system.is508){
    var sSemanticColor = oCell.getAttribute("s")?  oCell.getAttribute("s"): "";
    sSemanticColor = sSemanticColor.replace("s","");
    if(bSelect){
      sSemanticColor += "s";
    }
    oCell.setAttribute("s", sSemanticColor);
  }
}
function sapUrMapi_SapTable_isSelButtonSelectable(oSelButton){
  if(oSelButton) {
    var sClassName = oSelButton.className;
    if(sClassName=="urSTRowUnSelIcon" || sClassName=="urSTRowSelIcon" || sClassName=="urSTRowSelSecIcon") return true;
  }
  return false;
}
function sapUrMapi_SapTable_isSelectable(oRow){
  var oButtons = oRow.getElementsByTagName("DIV");
  if(oButtons.length > 0) {
    return sapUrMapi_SapTable_isSelButtonSelectable(oButtons.item(0));
  }
  return false;
}
function sapUrMapi_SapTable_clickSelButton(oRow,oEvt){
  while(oRow.tagName!="TR") oRow = oRow.parentNode;
  if(oRow.tagName!="TR")return;
  var sButtons = oRow.getElementsByTagName("DIV");
  for(var i=0;i<sButtons.length;i++){
    if(sapUrMapi_SapTable_isSelButtonSelectable(sButtons[i])){
      sButtons[i].fireEvent("onclick",oEvt);
      return;
    }
  }
}
function sapUrMapi_SapTable_getModelCellOfCnt(sId,o) {
  var oTbl=ur_Table_create(sId);
  var oCell=o;
  
	while( (oCell.tagName != "TD" && oCell.tagName != "TH") || (oCell.className.indexOf("urSTT")==-1 || oCell.className.search(/urSTTHL.Txt/)>=0) ){
    if(oCell.id==sId) break;
    oCell = oCell.parentNode;
  }
  
  oCell=oTbl.lookup[oCell.id];
  return oCell;
}
var UR_SEARCH_DIRECTION = {
    NONE: 0,
    ACCENDING: 1,
    DECENDING: 2,
    LAST: 3,
    FIRST: 4
  };
function sapUrMapi_SapTable_focusDown(sId,o){
  return ur_SapTable_sNavigate(sId, o, UR_SEARCH_DIRECTION.ACCENDING, false);
}
function sapUrMapi_SapTable_focusUp(sId,o){
  return ur_SapTable_sNavigate(sId, o, UR_SEARCH_DIRECTION.DECENDING, false);
}
function sapUrMapi_SapTable_focusNext(sId,o){
  return ur_SapTable_sNavigate(sId, o, UR_SEARCH_DIRECTION.ACCENDING, true);
}
function sapUrMapi_SapTable_focusPrevious(sId,o){
  return ur_SapTable_sNavigate(sId, o, UR_SEARCH_DIRECTION.DECENDING, true);
}
function ur_SapTable_sNavigate(sTableId, oDomRefCell, eSearchDirection, bHorizontal){
  var oTable=ur_Table_create(sTableId),
    oCell = oTable.focusedCell,
    oResultCell = null;
  if (oCell==null) oCell=sapUrMapi_SapTable_getModelCellOfCnt(sTableId,oDomRefCell);
  if (oCell==null) return "UNDEFINED";
  oResultCell = ur_SapTable_oSearchFocusableCell(oTable, oCell, eSearchDirection, bHorizontal);
  if(oResultCell == oCell) return "END";
  if(oResultCell == null) return "UNDEFINED";
  sapUrMapi_SapTable_focusCell(oResultCell, sTableId);
  return "";
}
function ur_SapTable_oSearchFocusableCell(oTable, oCellReference, eSearchDirection, bHorizontal){
  var iCurrRowIndex = -1, iCurrColIndex = -1, oCurrCell = null, oOrgCell = null;
  oOrgCell = oCellReference.oOrgCell;
  iCurrRowIndex = oOrgCell.rowIdx;
  iCurrColIndex = oOrgCell.colIdx;
  if(bHorizontal) {
    if(eSearchDirection == UR_SEARCH_DIRECTION.LAST) {
      iCurrColIndex = oOrgCell.parentRow.cells.length-1;
    } else if (eSearchDirection == UR_SEARCH_DIRECTION.FIRST) {
      iCurrColIndex = 0;
    } else if (eSearchDirection == UR_SEARCH_DIRECTION.ACCENDING) {
      iCurrColIndex = iCurrColIndex + oOrgCell.iColSpan;
    } else if (eSearchDirection == UR_SEARCH_DIRECTION.DECENDING) {
      iCurrColIndex = iCurrColIndex -1;
    }
  } else {
    if(eSearchDirection == UR_SEARCH_DIRECTION.LAST) {
      iCurrRowIndex = oOrgCell.parentCol.cells.length-1;
    } else if (eSearchDirection == UR_SEARCH_DIRECTION.FIRST) {
      iCurrRowIndex = 0;
    } else if (eSearchDirection == UR_SEARCH_DIRECTION.ACCENDING) {
      iCurrRowIndex = iCurrRowIndex + oOrgCell.iRowSpan;
    } else if (eSearchDirection == UR_SEARCH_DIRECTION.DECENDING) {
      iCurrRowIndex = iCurrRowIndex -1;
    }
  }
  if(oTable.rows[iCurrRowIndex]) {
    oCurrCell = oTable.rows[iCurrRowIndex].cells[iCurrColIndex];
  }
  if(oCurrCell == null) return oCellReference;
  
  if(oCurrCell.ref.fi) {
    var oRecursionResult = null;
    if(eSearchDirection == UR_SEARCH_DIRECTION.LAST)
      oRecursionResult = ur_SapTable_oSearchFocusableCell(oTable, oCurrCell, UR_SEARCH_DIRECTION.DECENDING, bHorizontal);
    else if(eSearchDirection == UR_SEARCH_DIRECTION.FIRST)
      oRecursionResult = ur_SapTable_oSearchFocusableCell(oTable, oCurrCell, UR_SEARCH_DIRECTION.ACCENDING, bHorizontal);
    else {
      oRecursionResult = ur_SapTable_oSearchFocusableCell(oTable, oCurrCell, eSearchDirection, bHorizontal);
    }
    if(oRecursionResult.ref.fi) return oCellReference;
    else return oRecursionResult;
  } else return oCurrCell;
};
var UR_SCROLL_UI = {
  NONE:0,
  PAGINATOR:1,
  SCROLLBAR:2
}
var UR_SCROLL_DIR = {
  VERTICAL:0,
  HORIZONTAL:1
}
var UR_SCROLL_BY = {
  NEXT_ITEM:0,
  NEXT_PAGE:1,
  END:2,
  PREVIOUS_ITEM:3,
  PREVIOUS_PAGE:4,
  BEGIN:5
}
function sapUrMapi_SapTable_canScrollV(sTableId, oTable) {
  if(!oTable) oTable=ur_get(sTableId);
  return (ur_get(oTable.getAttribute("pv")) || ur_get(sTableId+"-scrollV"))? true: false;
}
function sapUrMapi_SapTable_canScrollH(sTableId, oTable) {
  if(!oTable) oTable=ur_get(sTableId);
  return (ur_get(oTable.getAttribute("ph")) || ur_get(sTableId+"-scrollH"))? true: false;
}
function sapUrMapi_SapTable_scroll(sTableId, oEvt, iScrollDir, iScrollBy) {
  var oTable=ur_get(sTableId), sSclId = null, oScl=null, scrollUi=UR_SCROLL_UI.PAGINATOR;
  if (iScrollDir == UR_SCROLL_DIR.VERTICAL) {
    sSclId=oTable.getAttribute("pv");
    oScl=ur_get(sSclId);
    if (!oScl) {
      sSclId=sTableId+"-scrollV";
      oScl=ur_get(sSclId);
      scrollUi=UR_SCROLL_UI.SCROLLBAR;
    }
  } else if (iScrollDir == UR_SCROLL_DIR.HORIZONTAL) {
    sSclId=oTable.getAttribute("ph");
    oScl=ur_get(sSclId);
    if (!oScl) {
      sSclId=sTableId+"-scrollH";
      oScl=ur_get(sSclId);
      scrollUi=UR_SCROLL_UI.SCROLLBAR;
    }
  } else return false;
  if (!oScl) return false;
  if (scrollUi == UR_SCROLL_UI.PAGINATOR) {
    switch (iScrollBy) {
      case 0:
        if (ur_Paginator_triggerClick(sSclId, UR_PAGINATOR_BUTTON.NEXT_ITEM)) return true;
      case 1:
        if (ur_Paginator_triggerClick(sSclId, UR_PAGINATOR_BUTTON.NEXT_PAGE)) return true;
      case 2:
        if (ur_Paginator_triggerClick(sSclId, UR_PAGINATOR_BUTTON.END)) return true;
        break;
      case 3:
        if (ur_Paginator_triggerClick(sSclId, UR_PAGINATOR_BUTTON.PREVIOUS_ITEM)) return true;
      case 4:
        if (ur_Paginator_triggerClick(sSclId, UR_PAGINATOR_BUTTON.PREVIOUS_PAGE)) return true;
      case 5:
        if (ur_Paginator_triggerClick(sSclId, UR_PAGINATOR_BUTTON.BEGIN)) return true;
        break;
      default:
        return false;
    }
  } else if (scrollUi == UR_SCROLL_UI.SCROLLBAR) {
    var oSclInfoObject=ur_Scrollbar_getObj(sSclId);
    switch (iScrollBy) {
      case 0:
        ur_Scrollbar_scroll(oSclInfoObject, "down", oEvt);
        ur_Scrollbar_fireChange(oSclInfoObject, oEvt);
        break;
      case 1:
        ur_Scrollbar_page(oSclInfoObject, "down", oEvt);
        ur_Scrollbar_fireChange(oSclInfoObject, oEvt);
        break;
      case 2:
        ur_Scrollbar_bounce(oSclInfoObject, "down", oEvt);
        ur_Scrollbar_fireChange(oSclInfoObject, oEvt);
        break;
      case 3:
        ur_Scrollbar_scroll(oSclInfoObject, "up", oEvt);
        ur_Scrollbar_fireChange(oSclInfoObject, oEvt);
        break;
      case 4:
        ur_Scrollbar_page(oSclInfoObject, "up", oEvt);
        ur_Scrollbar_fireChange(oSclInfoObject, oEvt);
        break;
      case 5:
        ur_Scrollbar_bounce(oSclInfoObject, "up", oEvt);
        ur_Scrollbar_fireChange(oSclInfoObject, oEvt);
        break;
      default:
        return false;
    }
  }
  return false;
}
function sapUrMapi_SapTable_keydown(sId,e) {
  var o=ur_evtSrc(e);
  var sTag=o.tagName;
  var iKey=e.keyCode;
  var bS=e.shiftKey;
  var bA=e.altKey;
  var bC=sapUrMapi_bCtrl(e);
  var sCt=sapUrMapi_getControlTypeFromObject(o);
  var oT=ur_get(sId); 
	
  
  var bCanScrollV=sapUrMapi_SapTable_canScrollV(sId, oT);
  var bCanScrollH=sapUrMapi_SapTable_canScrollH(sId, oT);
  
  var sPhId=oT.getAttribute("ph");
  var oPh=ur_get(sPhId);
  
  var sPvId=oT.getAttribute("pv");
  var oPv=ur_get(sPvId);
  
  if(iKey==32 && sCt!="I" && sCt!="TE" && sCt!="CB" && sCt!="C" && sCt!="R" && sCt!="TRI"){
    try{
      o.fireEvent("onclick",e);
    } catch(ex){ }
    ur_EVT_cancel(e);
    return true;
  }
  
  if((bC || bS) && (iKey==40 || iKey==38)){
    if(sapUrMapiSapTable_sort(o))
      return ur_EVT_cancel(e);
  }
  
  if(iKey==40 && sCt!="TE"){
    sResult=sapUrMapi_SapTable_focusDown(sId,o);
    if (sResult=="END" && bCanScrollV) {
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.VERTICAL, UR_SCROLL_BY.NEXT_ITEM);
    }
    ur_EVT_cancel(e);
    return true;
  }
  
  if(iKey==38 && sCt!="TE"){
    sResult=sapUrMapi_SapTable_focusUp(sId,o);
    if (sResult=="END" && bCanScrollV) {
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.VERTICAL, UR_SCROLL_BY.PREVIOUS_ITEM);
    }
    ur_EVT_cancel(e);
    return true;
  }
  
  if(iKey==39 && (sCt!="I" && sCt!="TE")){
    var sResult="";
    if (ur_system.direction=="rtl")
      sResult=sapUrMapi_SapTable_focusPrevious(sId,o);
    else
      sResult=sapUrMapi_SapTable_focusNext(sId,o);
    if (sResult=="END" && bCanScrollH) {
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.HORIZONTAL, (ur_system.direction=="rtl")? UR_SCROLL_BY.PREVIOUS_ITEM: UR_SCROLL_BY.NEXT_ITEM);
    }
    ur_EVT_cancel(e);
    return true;
  }
  
  if(iKey==37 && (sCt!="I" && sCt!="TE")){
    var sResult="";
    if (ur_system.direction=="rtl")
      sResult=sapUrMapi_SapTable_focusNext(sId,o);
    else
      sResult=sapUrMapi_SapTable_focusPrevious(sId,o);
    if (sResult=="END" && bCanScrollH) {
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.HORIZONTAL, (ur_system.direction=="rtl")? UR_SCROLL_BY.NEXT_ITEM: UR_SCROLL_BY.PREVIOUS_ITEM);
    }
    ur_EVT_cancel(e);
    return true;
  }
  else if(iKey==9){
    var oTableInfoObject=ur_Table_create(sId);
    oTableInfoObject.focusedCell=null;
  }
  
  
  
  
  if (bCanScrollH && bA && !bS && !bC && sCt!="TE") {
    
    if(iKey==33){
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.HORIZONTAL, UR_SCROLL_BY.PREVIOUS_PAGE);
      ur_EVT_cancel(e);
      return;
    }
    
    if(iKey==34){
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.HORIZONTAL, UR_SCROLL_BY.NEXT_PAGE);
      ur_EVT_cancel(e);
      return;
    }
  }
  
  if (bCanScrollV && !bA && !bS && sCt!="I" && sCt!="TE") {
    
    if(iKey==36 && bC){
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.VERTICAL, UR_SCROLL_BY.BEGIN);
      ur_EVT_cancel(e);
      return;
    }
    
    if(iKey==35 && bC){
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.VERTICAL, UR_SCROLL_BY.END);
      ur_EVT_cancel(e);
      return;
    }
    
    if(iKey==33 && !bC){
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.VERTICAL, UR_SCROLL_BY.PREVIOUS_PAGE);
      ur_EVT_cancel(e);
      return;
    }
    
    if(iKey==34 && !bC){
      sapUrMapi_SapTable_scroll(sId, e, UR_SCROLL_DIR.VERTICAL, UR_SCROLL_BY.NEXT_PAGE);
      ur_EVT_cancel(e);
      return;
    }
  }
  
  return sapUrMapi_skip(sId,e);
}
function ur_SapTable_getCell(o){
  var oCell=o;
  while(oCell.getAttribute("tp")!="HIC"){
    if(oCell.getAttribute("ct")=="ST") return null;
    oCell=oCell.parentNode;
  }
  return oCell;
}
function sapUrMapi_SapTable_HiCell_he(o,oEvt) {
  var o=ur_evtSrc(oEvt);
  var oCell=ur_SapTable_getCell(o);
  var sCt=sapUrMapi_getControlTypeFromObject(o);
  var sFunc="";
  var oFunc=null;
  
  if(o==null || oCell==null) return;
  
  if( (sCt=="FU" || sCt=="I" || sCt=="CB" || sCt=="TE" || sCt=="TGL") && !(sapUrMapi_bCtrl(oEvt) && oEvt.type=="keydown" && (oEvt.keyCode==107 || oEvt.keyCode==109)) )
      return;
  
	if( oEvt.type!="click" && !(oEvt.type=="keydown" && (oEvt.keyCode==32 || (oEvt.keyCode==107) || (oEvt.keyCode==109) )))
		return;
		
	if (oEvt.type=="keydown" && o.tagName != "IMG") o = oCell.getElementsByTagName("IMG")[0];
		
	var sStc=o.getAttribute("stc"); 
	if(sStc) {
		if (oEvt.type=="keydown") {
			if (sStc=="oex" && oEvt.keyCode==107)
				ur_EVT_fire(oCell,sStc,oEvt);
			else if (sStc=="oco" && oEvt.keyCode==109)
        ur_EVT_fire(oCell,sStc,oEvt);
      else if (oEvt.keyCode==32)
        ur_EVT_fire(oCell,sStc,oEvt);
    } else {
      ur_EVT_fire(oCell,sStc,oEvt);
    }
  } else if (oCell.getAttribute("oc"))
    ur_EVT_fire(oCell,"oc",oEvt);
  return ur_EVT_cancel(oEvt);
}
function sapUrMapiSapTable_sort(oCell,bAsc){
  var aBtn;
  var oBtn=null;
  var sTp=oCell.getAttribute("tp");
  if(sTp==null || sTp.indexOf("HDR")<0) return false;
  aBtn=oCell.getElementsByTagName("button");
  for(var i=0;i<aBtn.length;i++)
    if(aBtn[i].className.indexOf("urSTIconSor")>=0 || aBtn[i].className=="urSTIconUnsorted")oBtn=aBtn[i];
  if(oBtn!=null) oBtn.click();
  return true;
}
function sapUrMapi_SapTable_activate(sId,e){
  var o=ur_evtSrc(e);
  var oTab=ur_Table_create(sId);
  if(oTab) {
    var oCell=sapUrMapi_SapTable_getModelCellOfCnt(sId,o);
    oTab.focusedCell=oCell;
  }
}
function sapUrMapi_SapTable_deactivate(oEvt){
}
function sapUrMapi_SapTable_focusCell(oCell, sTableId){
  var oFocus = null;
  
  if(oCell==null) return null; 
  
  if( oCell.ref.firstChild!=null && oCell.ref.firstChild.nodeType!=3 && (oCell.ref.firstChild).getAttribute('ct')!="PI")
    oFocus=sapUrMapi_findFirstFocus(oCell.ref.firstChild);
  
  if(oFocus!=null){
    ur_focus(oFocus);
  }
  
  else {
    var sCellType=oCell.ref.getAttribute("tp"),
      oDomRefToFocus = oCell.ref.firstChild;
    if(sCellType!=null && sCellType=="ER") return false;
    sapUrMapi_setTabIndex(oDomRefToFocus,"0");
    sapUrMapi_setTabIndexAutoReset(oDomRefToFocus);
    if(sTableId && !oDomRefToFocus.id) oDomRefToFocus.id = sapUrMapi_SapTable_sGenerateMatrixId(sTableId, oCell.rowIdx, oCell.colIdx);
    ur_focus(oDomRefToFocus);
  }
  return true;
}
function sapUrMapi_SapTable_sGenerateMatrixId(sRootId, iRowIndex, iColIndex){ 
  return sRootId + "-mtx_" + iRowIndex + "_" + iColIndex + "_mtx-";
}
function sapUrMapi_SapTable_bIsMatrixId(sId){
  return sId && sId.indexOf("-mtx_") > 0 && sId.indexOf("_mtx-") == sId.length-5;
}
function sapUrMapi_SapTable_focusMatrixItem(sMatrixId){
  var iPosBeginIndex = sMatrixId.indexOf("-mtx_"),
    sRootId = sMatrixId.substring(0, iPosBeginIndex),
    sPos = sMatrixId.substring(iPosBeginIndex+5, sMatrixId.length - 5),
    aPos = sPos.split("_"),
    iRowIndex = parseInt(aPos[0]),
    iColIndex = parseInt(aPos[1]);
  sapUrMapi_SapTable_focusTableCellByPos(sRootId, iRowIndex, iColIndex);
}
function sapUrMapi_SapTable_focusTableCellByPos(sTableId, iRowIndex, iColIndex){
  var oTable = ur_Table_create(sTableId),
    oCell = (oTable.rows[iRowIndex])? oTable.rows[iRowIndex].cells[iColIndex]: null;
  if(oCell) {
    sapUrMapi_SapTable_focusCell(oCell, sTableId);
    oTable.focusedCell = oCell;
  }
}
function sapUrMapi_SapTable_sGetMatrixIdByContentDomRef(sTableId, oContentDomRef){
  var oDomRefTable=ur_get(sTableId),
    oTableInfo = (oDomRefTable.ct == "ST")? ur_Table_create(sTableId): null,
    oCurrDomRef = oContentDomRef;
  if(oTableInfo) {
    while(oCurrDomRef != null && oCurrDomRef != oDomRefTable && oCurrDomRef.tagName!="BODY") {
      if(oCurrDomRef.parentNode && oCurrDomRef.parentNode.rr && oCurrDomRef.id){
        var oCellInfo = oTableInfo.lookup[oCurrDomRef.id];
        if(oCellInfo) return sapUrMapi_SapTable_sGenerateMatrixId(sTableId, oCellInfo.rowIdx, oCellInfo.colIdx);
      }
      oCurrDomRef = oCurrDomRef.parentNode;
    }
  }
  return "";
}
function sapUrMapi_SapTable_bIsTableId(sTableId){
  var oDomRefTable=ur_get(sTableId);
  return oDomRefTable && oDomRefTable.ct == "ST";
}
function sapUrMapi_SapTable_getTooltip(o,oCell,oTab){
  
}
var _ur_tables=new Array();
function ur_Table_create(sId) {
  if (_ur_tables[sId]==null) {
    var oRows = new Array();
    var oRefCells = new Array();
    var oBdy = null;
    var iR=0;
    var oTab=ur_get(sId);
    var bHasTb=false;
    var oTb=null;
    while(oBdy==null){
      if (oTab.rows[iR].cells[0]==null){iR++;continue;}
      var oTmp=oTab.rows[iR].cells[0].firstChild;
      if (oTmp==null) {iR++;continue;}
      if (oTmp.tagName=="TABLE") {
		    if (oTmp.getAttribute("bd")=="1") {
					oBdy=oTmp;
					
					if (oBdy.ur_firstTBodyOnly && oBdy.tBodies && oBdy.tBodies.length && oBdy.tBodies.length > 0)
						oBdy=oBdy.tBodies[0];
					
					break;
		    }	  
		    if (oTmp.firstChild.firstChild.firstChild.getAttribute("ct")=="T") {
					oTb=oTmp.firstChild.firstChild.firstChild;
					bHasTb=true;
		    }	  
      }
      iR++;
    }
    if (oBdy==null) return null;
    var oTRows = oBdy.rows;
    var oDCells = null;
    var oRowSpanedCells = new Array();
    var iMaxCols=0;
    for (var iRowCount=0;iRowCount<oTRows.length;iRowCount++)  {
      for (var iColCount=0;iColCount<oTRows[iRowCount].cells.length;iColCount++) {
        var iColSpan=parseInt(oTRows[iRowCount].cells[iColCount].colSpan);
        if (isNaN(iColSpan)) iColSpan=1;
        iMaxCols=iMaxCols+iColSpan;
      }
      break;
    }
    for (var iRowCount=0;iRowCount<oTRows.length;iRowCount++)  {
      oRows.push({irowidx:iRowCount,ref:null,cells:new Array(iMaxCols)});
    }
    for (var iRowCount=0;iRowCount<oTRows.length;iRowCount++)  {
      var oCells = oRows[iRowCount].cells;
      var iColCount=0, oOrgCell = null, oTmpCell = null;
      oDCells=oTRows[iRowCount].cells;
      for (var iCol = 0; iCol<oDCells.length; iCol++) {
        while (oCells[iColCount]) iColCount++;
        oRows[iRowCount].cells[iColCount] = {ref:oDCells[iCol]};
        var iColSpan=parseInt(oDCells[iCol].colSpan);
        if (isNaN(iColSpan)) iColSpan=1;
        var iRowSpan=parseInt(oDCells[iCol].rowSpan);
        if (isNaN(iRowSpan)) iRowSpan = 1;
        for (var x=1;x<=iColSpan;x++) {
          for (var iRowSpanCount = 1 ; iRowSpanCount <= iRowSpan; iRowSpanCount++) {
            oTmpCell = {ref:oDCells[iCol],cspan:iColSpan>1,rspan:iRowSpan>1};
            if(x == 1 && iRowSpanCount == 1) {
              oOrgCell = oTmpCell;
              oOrgCell.iRowSpan = iRowSpan;
              oOrgCell.iColSpan = iColSpan;
            }
            oTmpCell.oOrgCell = oOrgCell;
            oRows[iRowCount+iRowSpanCount-1].cells[iColCount] = oTmpCell;
          }
          iColCount++;
        }
      }
      iColCount++;
      oRows[iRowCount].ref=oTRows[iRowCount];
    }
    var oCols=new Array();
    for (var i=0; i<oRows.length; i++){
      for (var j=0; j<oRows[i].cells.length; j++) {
        if (oRows[i].cells[j] == null) {
          oRows[i].cells[j]={ref:oRows[i].cells[j-1].ref,empty:true};
          oRows[i].cells[j-1].last=true;
        } else {
          oRows[i].cells[j].empty=false;
          oRows[i].cells[j].last=j==oRows[i].cells.length-1?true:false;
        }
        if (i>0) oRows[i].previousRow=oRows[i-1];
        if (i<oRows.length-1) oRows[i].nextRow=oRows[i+1];
        oRows[i].irowidx=i;
        var oCell=oRows[i].cells[j];
        oRows[i].sel=-1;
        oCell.foc=false;
        oCell.sel=-1;
        oCell.type="te";
        oCell.parentRow=oRows[i];
        oCell.first=j==0?true:false;
        oCell.isTH=oCell.ref.tagName=="TH";
        oCell.rowIdx=i;
        oCell.colIdx=j;
        if (i==0) {
          oCols.push({icolidx:j,cells:new Array()});
        }
        oCell.parentCol=oCols[j];
        oCols[j].cells.push(oCell);
        oCols[j].sel=-1;
        if (oCell.ref.id==null || oCell.ref.id=="") {
          oCell.ref.setAttribute("id",sId+"-cell-"+i+"-"+j);
        }
        oRefCells[oCell.ref.id]=oCell;
      }
    }
    _ur_tables[sId]={rows:oRows,cols:oCols,lookup:oRefCells,ref:oTab,hasToolbar:bHasTb,toolbar:oTb};
    var debugMode="";
    if (debugMode=="table") {
      var sRenderTable = "<table border='1'>";
      for (var y=0;y<_ur_tables[sId].rows.length;y++) {
        sRenderTable+="<tr>";
        for (var x=0;x<_ur_tables[sId].rows[y].cells.length;x++) {
          sRenderTable+="<td>"+_ur_tables[sId].rows[y].cells[x].rspan + x+" "+y+" "+_ur_tables[sId].rows[y].cells[x].ref.innerText+"</td>";
        }
        sRenderTable+="</tr>";
      }
      sRenderTable+="</table>";
      var oDiv = document.createElement("DIV");
      document.body.appendChild(oDiv);
      oDiv.innerHTML = sRenderTable;
    }
  }
  return _ur_tables[sId];
}
function ur_table_getCellHeaders(s) {
	var result=null;
	if (s!=null && s!="") {
		result=new Array();
		var arrHdr=s.split(",");
		for (var iH=0;iH<arrHdr.length;iH++) {
			var oHdr=ur_get(arrHdr[iH]);
			result.push({ref:oHdr,text:""});
			
		}
	}
	return result;
}
function sapUrMapi_SapTable_Scrollbar_scroll(sId,oEvt) {
  var o=document.getElementById(sId.split("-")[0]);
  if (!o) return;
  if (oEvt.ur_param && oEvt.ur_param["dir"]) {
    var dir=oEvt.ur_param["dir"];
    if (dir=="v") {
      if (ur_getAttD(o,"o"+dir+"scrl","")!="") ur_EVT_fire(o,"o"+dir+"scrl",oEvt);
    } else if (dir=="h") {
      if (ur_getAttD(o,"o"+dir+"scrl","")!="") ur_EVT_fire(o,"o"+dir+"scrl",oEvt);
    }
  }
}
function ur_SapTable_applySortCursor(oEvt) {
  var o=ur_evtSrc(oEvt);
  o = ur_getNextHtmlParentByAttribute(o, "stasc");
  o.style.cursor="url(" + ur_system.mimepath + "saptable/sort.cur)";
  o.onmouseover=null;
  return false;
}

//** Scrollbar.nn6 **
var ur_SCB_obj;      
var ur_SCB_handle;   
var ur_SCB_mousePos; 
var ur_SCB_max;      
var ur_SCB_margin;   
var ur_SCB_timer;    
var ur_SCB_pixelStop;  
var ur_SCB_src;      
var ur_SCB_arr = new Array(); 
var ur_SCB_evt; 
var ur_SCB_showst=false; 
function sapUrMapi_Scrollbar_handler(oEvt) {
  ur_SCB_evt=oEvt;
  ur_SCB_src=ur_EVT_src(oEvt);  
  
  
  
  if (ur_SCB_src.className=="urSCBBtn") ur_SCB_src=ur_SCB_src.parentNode;
	
	
	var o=ur_getRootObj(ur_SCB_src);
  sArea=ur_getAttD(ur_SCB_src,"area",""); 
  if(o && o.id && oEvt.type!="mousemove" && oEvt.type!="mouseup") {
    ur_SCB_obj=ur_Scrollbar_getObj(o.id);
    if(ur_Scrollbar_isDisabled(ur_SCB_obj)) return false;
  }
	
  
  if (oEvt.type=="mousedown" && oEvt.button==0) { 
    
    ur_SCB_obj=ur_Scrollbar_getObj(o.id);
    
    if (ur_SCB_src.id.indexOf("-h")>-1) { 
      ur_SCB_handle=ur_SCB_src;
      
      
      
      window.captureEvents(Event.MOUSEMOVE);
      window.captureEvents(Event.MOUSEUP);
      window.captureEvents(Event.MOUSEOUT);
      window.addEventListener("mousemove",sapUrMapi_Scrollbar_handler,true);
      window.addEventListener("mouseup",sapUrMapi_Scrollbar_handler,true);
      window.addEventListener("mouseout",sapUrMapi_Scrollbar_handler,true);
      ur_SCB_handle.className=ur_SCB_handle.className.replace("urSCBBtn","urSCBBtnDrag");
      if (ur_SCB_obj.sdir=="v") {
        ur_SCB_margin=parseInt(ur_SCB_src.style.marginTop);
        ur_SCB_mousePos=oEvt.clientY-ur_SCB_margin;
        ur_SCB_max=ur_SCB_src.parentNode.offsetHeight - ur_SCB_src.offsetHeight;
      } else {
        if (ur_system.direction=="rtl") {
          ur_SCB_margin=parseInt(ur_SCB_src.style.marginRight);
          ur_SCB_mousePos=oEvt.clientX - ur_SCB_margin;
        } else {
          ur_SCB_margin=parseInt(ur_SCB_src.style.marginLeft)
          ur_SCB_mousePos=oEvt.clientX-ur_SCB_margin;
        }
        ur_SCB_max = ur_SCB_src.parentNode.offsetWidth - ur_SCB_src.offsetWidth;
      }
      ur_EVT_cancel(oEvt);
    
    } else if (sArea == "bar") {
      ur_SCB_handle=ur_get(o.id+"-h");
      ur_SCB_handle.className=ur_SCB_handle.className.replace("urSCBBtn","urSCBBtnDrag");
      var iPos=0;
      
      if (ur_SCB_obj.sdir=="v") {
        var iEvtPos=oEvt.layerY;
        iPos=parseInt(ur_SCB_handle.style.marginTop);
        ur_SCB_pixelStop=ur_SCB_obj.range/ur_SCB_obj.totalPixels*iEvtPos+ur_SCB_obj.min;
        if (iEvtPos<iPos) {
          ur_Scrollbar_page(ur_SCB_obj,"up");
          ur_scrollDir="up";
          ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'up')",300);
        } else if (iEvtPos>iPos) {
          ur_Scrollbar_page(ur_SCB_obj,"down");
          ur_scrollDir="down";
          ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'down')",300);
        }
      } else {
        var iEvtPos=oEvt.layerX;
        if (ur_system.direction=="rtl") {
          iPos=parseInt(ur_SCB_src.firstChild.style.marginRight);
          ur_SCB_pixelStop=ur_SCB_obj.range/ur_SCB_obj.totalPixels*iEvtPos+ur_SCB_obj.min;
          if (iEvtPos>iPos) {
            ur_Scrollbar_page(ur_SCB_obj,"up");
            ur_scrollDir="up";
            ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'up')",300);
          } else if (iEvtPos<iPos) {
            ur_Scrollbar_page(ur_SCB_obj,"down");
            ur_scrollDir="down";
            ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'down')",300);
          }
        } else {
          iPos=parseInt(ur_SCB_src.firstChild.style.marginLeft);
          ur_SCB_pixelStop=ur_SCB_obj.range/ur_SCB_obj.totalPixels*iEvtPos+ur_SCB_obj.min;
          if (iEvtPos<iPos) {
            ur_Scrollbar_page(ur_SCB_obj,"up");
            ur_scrollDir="up";
            ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'up')",300);
          } else if (iEvtPos>iPos) {
            ur_Scrollbar_page(ur_SCB_obj,"down");
            ur_scrollDir="down";
            ur_SCB_timer=setInterval("ur_Scrollbar_pageStart(ur_SCB_obj,'down')",300);
          }
        }
      }
      ur_SCB_src.addEventListener("mouseup",ur_Scrollbar_stopButton,true);
      ur_SCB_src.addEventListener("mousemove",ur_Scrollbar_correctStopValue,true);
    
    } else if ("ebudpn".indexOf(sArea)>-1) {
      ur_SCB_handle=ur_get(o.id+"-h");
      
      
      ur_SCB_src.addEventListener("mouseup",ur_Scrollbar_stopButton,true);
      ur_SCB_src.addEventListener("mouseout",ur_Scrollbar_stopButton,true);
      ur_SCB_src.className=ur_SCB_src.className.replace("urSCBBtn","urSCBBtnPressed");
      ur_SCB_handle.className=ur_SCB_handle.className.replace("urSCBBtn","urSCBBtnDrag");
      
      
      if (sArea=="e") {
        ur_Scrollbar_bounce(ur_SCB_obj,"down");
      
      } else if (sArea=="b") {
        ur_Scrollbar_bounce(ur_SCB_obj,"up");
      
      } else if (sArea=="u" || sArea=="p") {
        ur_Scrollbar_scroll(ur_SCB_obj,"up");
        ur_SCB_timer=setInterval("ur_Scrollbar_scrollStart(ur_SCB_obj,'up')",180);
      
      } else if (sArea=="d" || sArea=="n") {
        ur_Scrollbar_scroll(ur_SCB_obj,"down");
        ur_SCB_timer=setInterval("ur_Scrollbar_scrollStart(ur_SCB_obj,'down')",180);
      }
    }
  
  } else if (oEvt.type=="mousemove") {
  	
  	
    if (ur_SCB_handle)
      if (ur_SCB_obj.sdir=="v")
        iNewPos=oEvt.clientY - ur_SCB_mousePos;
      else
        iNewPos=oEvt.clientX - ur_SCB_mousePos;
      if (iNewPos<0) iNewPos=0;
      if (iNewPos>ur_SCB_max) iNewPos=ur_SCB_max;
      ur_SCB_margin=iNewPos;
      if (ur_SCB_obj.sdir=="v")
        ur_SCB_handle.style.marginTop=iNewPos;
      else
        if (ur_system.direction=="rtl")
          ur_SCB_handle.style.marginRight=iNewPos;
        else
          ur_SCB_handle.style.marginLeft=iNewPos;
    ur_SCB_showst=true;
    ur_Scrollbar_showScrollTip(ur_SCB_obj,Math.floor(ur_SCB_obj.range/ur_SCB_max*ur_SCB_margin+ur_SCB_obj.min));
    ur_EVT_cancel(oEvt);
  
  } else if (oEvt.type=="mouseup" || (oEvt.type=="mouseout" && oEvt.target==window.document.documentElement)) {
    
    window.releaseEvents(Event.MOUSEMOVE);
    window.releaseEvents(Event.MOUSEUP);
    window.releaseEvents(Event.MOUSEOUT);
    window.removeEventListener("mousemove",sapUrMapi_Scrollbar_handler,true);
    window.removeEventListener("mouseup",sapUrMapi_Scrollbar_handler,true);
    window.removeEventListener("mouseout",sapUrMapi_Scrollbar_handler,true);
    ur_SCB_handle.className=ur_SCB_handle.className.replace("urSCBBtnDrag","urSCBBtn");
    ur_SCB_handle=null;
    
    ur_SCB_obj.newvalue=Math.floor(ur_SCB_obj.range/ur_SCB_max*ur_SCB_margin+ur_SCB_obj.min);
    ur_Scrollbar_applyHandlePos(ur_SCB_obj);
    
    ur_Scrollbar_fireChange(ur_SCB_obj, ur_SCB_evt);
  }
}
function ur_Scrollbar_fireChange(ur_SCB_obj, oEvt) {
  ur_Scrollbar_hideScrollTip();
  ur_SCB_showst=false;
  var iMod=ur_SCB_obj.newvalue%ur_SCB_obj.smallChange;
  if (Math.abs(iMod)>0) {
    if (ur_SCB_obj.smallChange/2>iMod) ur_SCB_obj.newvalue=ur_SCB_obj.newvalue-iMod;
    else ur_SCB_obj.newvalue=ur_SCB_obj.newvalue+ur_SCB_obj.smallChange-iMod;
  }
  if (ur_SCB_obj.newvalue!=ur_SCB_obj.value) {
    ur_SCB_obj.value=ur_SCB_obj.newvalue;
    ur_SCB_obj.ref.setAttribute("val",ur_SCB_obj.value);
    oEvt.ur_param=new Array();
    oEvt.ur_param["pos"]=ur_SCB_obj.value;
    oEvt.ur_param["dir"]=ur_SCB_obj.sdir;
    ur_EVT_fire(ur_SCB_obj.ref,"oscrlf",oEvt);
  }
}
function ur_Scrollbar_pageStart(o,sDir) {
  clearInterval(ur_SCB_timer);
  ur_Scrollbar_page(o,sDir);
  ur_SCB_showst=true;
  ur_SCB_timer=setInterval("ur_Scrollbar_page(ur_SCB_obj,'"+sDir+"')",100)
}
function ur_Scrollbar_scrollStart(o,sDir) {
  clearInterval(ur_SCB_timer);
  ur_Scrollbar_scroll(o,sDir);
  ur_SCB_showst=true;
  ur_SCB_timer=setInterval("ur_Scrollbar_scroll(ur_SCB_obj,'"+sDir+"')",50)
}
function ur_Scrollbar_correctStopValue(oEvt) {
  if (ur_SCB_obj.sdir=="v") {
    var newValue=ur_SCB_obj.range / ur_SCB_obj.totalPixels * oEvt.offsetY + ur_SCB_obj.min;
    var iPos=parseInt(ur_SCB_handle.style.marginTop);
    if (ur_scrollDir=="up" && newValue<iPos) ur_SCB_pixelStop=newValue;
    if (ur_scrollDir=="down" && newValue>iPos) ur_SCB_pixelStop=newValue;
  } else {
    var newValue=ur_SCB_obj.range / ur_SCB_obj.totalPixels * oEvt.clientX + ur_SCB_obj.min;
    var iPos=parseInt(ur_SCB_handle.style.marginLeft);
    if (ur_scrollDir=="up" && newValue<iPos) ur_SCB_pixelStop=newValue;
    if (ur_scrollDir=="down" && newValue>iPos) ur_SCB_pixelStop=newValue;
  }
}
function ur_Scrollbar_stopButton(oEvt) {
  ur_SCB_evt=oEvt;
  if (ur_SCB_timer) window.clearInterval(ur_SCB_timer);
  
  if (ur_SCB_src) {
    ur_SCB_src.className=ur_SCB_src.className.replace("urSCBBtnPressed","urSCBBtn");
    
    ur_SCB_src.removeEventListener("mouseup",ur_Scrollbar_stopButton,true);
    ur_SCB_src.removeEventListener("mouseout",ur_Scrollbar_stopButton,true);
    ur_SCB_src.removeEventListener("mousemove",ur_Scrollbar_correctStopValue,true);
    ur_SCB_handle.className=ur_SCB_handle.className.replace("urSCBBtnDrag","urSCBBtn");
    
    ur_SCB_src=null;
  }
  ur_Scrollbar_fireChange(ur_SCB_obj, ur_SCB_evt);
  ur_SCB_handle=null;
}
function sapUrMapi_Scrollbar_registerCreate(sId) {
  sapUrMapi_Create_AddItem(sId, "ur_Scrollbar_init('"+sId+"')");
  
}
function ur_Scrollbar_resize(oEvt) {
  if (!oEvt) return;
  var sId = ur_EVT_src(oEvt).id;
  ur_SCB_arr[sId]=null;
  ur_callDelayed("ur_Scrollbar_init('"+sId+"')",0);
}
function ur_Scrollbar_EnvironmentCleanUp() {
  ur_SCB_arr=null;
  ur_iScrollbarResizeProcessObject = null;
}
function ur_Scrollbar_EnvironmentInit() {
  ur_SCB_arr = new Array();
  ur_iScrollbarResizeProcessObject = {};
}
function ur_Scrollbar_getObj(sId) {
  var o = ur_get(sId);
  if (!o) return null;
  if (!ur_SCB_arr[sId]) {
    var obj = {id:sId,
         sid:ur_getAttD(o,"sid",""),
         sdir:ur_getAttD(o,"sdir",""),
         value:parseInt(ur_getAttD(o,"val","0")),
         newvalue:parseInt(ur_getAttD(o,"val","0")),
         max:parseInt(ur_getAttD(o,"max","")),
         min:parseInt(ur_getAttD(o,"min","")),
         smallChange:parseInt(ur_getAttD(o,"sml","")),
         largeChange:parseInt(ur_getAttD(o,"lrg","")),
         showscrolltip:ur_getAttD(o,"scs","")=="1",
         scrolltipdefault:ur_getAttD(o,"scd",""),
         sScrolltips:ur_getAttD(o,"sct",""),
         scrolltips:null,
         ref:o,
         handle:ur_get(sId+"-h")};
         
    
    
    
    if(obj.value > 1 && o.min >= o.max) obj.max=obj.value;     
         
    if (obj.sdir == "v") {
      obj.ref.style.height = obj.ref.parentNode.offsetHeight;
      obj.totalPixels = obj.handle.parentNode.offsetHeight;
    } else {
      obj.totalPixels = obj.handle.parentNode.offsetWidth;
    }
    if (obj.showscrolltip) {
      if (!document.getElementById("ur-scrolltip")) {
        var oScrollTip=document.createElement("SPAN");
        oScrollTip.setAttribute("id","ur-scrolltip");
        oScrollTip.style.position="absolute";
        oScrollTip.style.visibility="hidden";
        oScrollTip.style.top="0";
        oScrollTip.style.left="0";
        document.getElementsByTagName("BODY")[0].appendChild(oScrollTip);
      }
      obj.scrolltip=document.getElementById("ur-scrolltip");
      while ( obj.sScrolltips.indexOf("_")>0) obj.sScrolltips=obj.sScrolltips.replace("_","'");
      if(obj.sScrolltips) obj.scrolltips =eval("result=" + obj.sScrolltips +";");
    }
    if (obj.value < obj.min) obj.value = obj.min;
    obj.range = obj.max-obj.min;
    obj.handlesize=ur_Scrollbar_getHandleSize(obj);
    
    
    if (obj.sdir == "v") {
    	obj.handle.style.width = (obj.handle.parentNode.offsetWidth-2) + "px";
      obj.handle.style.height = obj.handlesize;
    } else {
      obj.handle.style.width = obj.handlesize;
      obj.handle.style.height = (obj.handle.parentNode.offsetHeight-2) + "px";
    }
    
    ur_SCB_arr[sId] = obj;
    ur_get(sId).addEventListener("resize",ur_Scrollbar_resize,true);
    if (ur_Scrollbar_isDisabled(obj)) {
      
    } else {
      
    }
    return obj;
  } else {
    return ur_SCB_arr[sId];
  }
}
function ur_Scrollbar_page(o,dir,oEvt) {
  if (!oEvt) oEvt=ur_SCB_evt;
  if (dir=="up") o.newvalue=o.newvalue-o.largeChange;
  else o.newvalue=o.newvalue+o.largeChange;
  if (o.newvalue>o.max) o.newvalue=o.max;
  if (o.newvalue<o.min) o.newvalue=o.min;
  
  
  o.newvalue=Math.ceil(o.newvalue);
  ur_Scrollbar_applyHandlePos(o);
  ur_Scrollbar_showScrollTip(o,o.newvalue);
}
function ur_Scrollbar_scroll(o,dir,oEvt) {
  if (!oEvt) oEvt=ur_SCB_evt;
  if (dir=="up") o.newvalue=o.newvalue-o.smallChange;
  else o.newvalue=o.newvalue+o.smallChange;
  if (o.newvalue>o.max) o.newvalue=o.max;
  if (o.newvalue<o.min) o.newvalue=o.min;
  ur_Scrollbar_applyHandlePos(o);
  ur_Scrollbar_showScrollTip(o,o.newvalue);
}
function ur_Scrollbar_bounce(o,dir,oEvt) {
  if (!oEvt) oEvt=ur_SCB_evt;
  if (dir=="up") o.newvalue=o.min;
  else o.newvalue=o.max;
  ur_Scrollbar_applyHandlePos(o);
}
function ur_Scrollbar_getHandleSize(o) {
  if(ur_Scrollbar_isDisabled(o)) return 0;
  var iTotal = 0;
  var elemCount = o.range + o.largeChange;
  var iSize=Math.floor(o.totalPixels / elemCount * o.largeChange);
  if (iSize<6) iSize=6;
  if (o.totalPixels <= iSize) iSize=0;
  o.totalPixels = o.totalPixels;
  return iSize;
}
function ur_Scrollbar_applyHandleSize(o) {
  if(ur_Scrollbar_isDisabled(o)) {
    o.handle.style.display = "none";
  } else if (o.sdir == "v") {
    o.handle.style.height = o.handlesize+"px";
    o.handle.firstChild.style.height = (o.handlesize-2)+"px";
  } else {
    o.handle.style.width = o.handlesize+"px";
    o.handle.firstChild.style.width = (o.handlesize-2)+"px";
  }
}
function ur_Scrollbar_isDisabled(o) {
  return (o)? o.min >= o.max: false;
}
function ur_Scrollbar_applyHandlePos(o) {
  if(ur_Scrollbar_isDisabled(o)) return;
  var iVal = o.newvalue - o.min;
  iVal = Math.floor((o.totalPixels / o.range) * iVal);
  
  if (o.totalPixels == 0) return;
  iVal=iVal - Math.ceil((o.handlesize / o.totalPixels) * iVal);
  if (iVal != 0) {
    if (iVal + o.handlesize >= o.totalPixels) iVal = o.totalPixels - o.handlesize - 1;
  }
  var iBorderWidth=parseInt(document.defaultView.getComputedStyle(o.handle, '').getPropertyValue("border-top-width"));
  if(iVal>o.totalPixels-o.handlesize-2) iVal=o.totalPixels-o.handlesize-(iBorderWidth*2);
  if (o.sdir == "v") {
    o.handle.style.marginTop = iVal;
  } else {
    if (ur_system.direction=="rtl")
      o.handle.style.marginRight = iVal;
    else
      o.handle.style.marginLeft = iVal;
  }
}
function ur_Scrollbar_init(sId) {
   var o = ur_Scrollbar_getObj(sId);
   if (!o) return;
   ur_Scrollbar_applyHandleSize(o);
   ur_Scrollbar_applyHandlePos(o);
}
function sapUrMapi_Scrollbar_scroll(sId,oEvt) {
   var o = ur_get(sId);
   var oScr=ur_Scrollbar_getObj(ur_getRootObj(ur_EVT_src(oEvt).id));
   if (o && o.style.overflow=="hidden") {
      if (oScr.sdir=="v")
        o.scrollTop=(o.scrollHeight/oScr.range)*(oScr.value-oScr.min); 
      else
        o.scrollleft=(o.scrollWidth/oScr.range)*(oScr.value-oScr.min); 
   }
}
function ur_Scrollbar_hideScrollTip() {
  if (oPopup)
    oPopup.hide();
}
var myLock=false;
function ur_Scrollbar_showScrollTip(obj,val) {
	
	if(myLock) return;
	myLock=true;
  
  
  if (obj.showscrolltip && ur_SCB_showst) {
    var oScrollTip=ur_get('ur-scrolltip');
    var s="<table class=\"urDataTipStd urDataTipTxt\" style=\"text-align:right;padding:1px 3px;height:16px;width:1px;\">";
    
    if (obj.scrolltips) { 
      var lastMatchValue;
      s += "<tr><td nowrap><b>";
      for(var n in obj.scrolltips) { 
        if (n>val) break;
        else lastMatchValue=n;
      }
      
      var sDomObjIndex = obj.scrolltips[lastMatchValue];
      
      var sHTML = ur_get(obj.id + "-sct-" + sDomObjIndex).innerHTML;
      s += sHTML + "</b></td></tr>";
    }
    
    var fromIndex=val, toIndex=fromIndex+obj.largeChange-1, ofCount=obj.max+obj.largeChange-1;
    if (obj.sdir=="v" && obj.scrolltipdefault=="ROW") {
      s += "<tr><td nowrap>" + getLanguageText("SAPUR_PG_ROW") + " " + fromIndex + " - " + toIndex + " " + getLanguageText("SAPUR_PG_INDEX") + " " + ofCount + "</td></tr>";
    } else if (obj.sdir=="h" && obj.scrolltipdefault=="COL") {
      s += "<tr><td nowrap>" + getLanguageText("SAPUR_PG_COLUMN") + " " + fromIndex + " - " + toIndex + " " + getLanguageText("SAPUR_PG_INDEX") + " " + ofCount + "</td></tr>";
    }
    oScrollTip.innerHTML= s + "</table>";
    if (obj.sdir=="v") {
      oScrollTip.firstChild.style.textAlign="right";
    } else
      oScrollTip.firstChild.style.textAlign="left";
    var arrUrls = new Array(ur_system.stylepath+"ur_pop_"+ur_system.browser_abbrev+".css");
    oPopup = new sapPopup(window,arrUrls,oScrollTip,obj.handle,null,0);
    oPopup.positionbehavior = sapPopupPositionBehavior.MENURIGHT;
    if (obj.sdir=="v") {
      oPopup.position.left-=obj.ref.offsetWidth;
      oPopup.position.top-=obj.handle.offsetHeight;
    } else {
      oPopup.position.left-=obj.handle.offsetWidth-oScrollTip.offsetWidth;
      oPopup.position.top-=obj.handle.offsetHeight+oScrollTip.offsetHeight;
    }
    oPopup.show(true);
  } else {
    if (oPopup)
      oPopup.hide();
  }
  
  myLock=false;
  
}
//** SelectableLinkBar.nn6 **

function sapUrMapi_SelectableLinkBar_RegisterCreate(sId) {
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_SelectableLinkBar_create('" + sId + "')");
}
function sapUrMapi_SelectableLinkBar_create(sId) {
	
	ur_IScr_getObj(sId);
	ur_IScr_create(sId);
	sapUrMapi_Resize_AddItem(sId, "ur_IScr_resize('"+sId+"')");
	ur_IScr_resize(sId);
	
}
function ur_SLB_oadi(sId)
{
	var oScrl = ur_IScr[sId];
	if(oScrl.first == 0)
		ur_get(sId+'-SrlLt').className= "urLnkBarScrlLeftDsbl";
	else
		ur_get(sId+'-SrlLt').className= "urLnkBarScrlLeft";
	if(oScrl.last == oScrl.items.length -1)
		ur_get(sId+'-SrlRt').className= "urLnkBarScrlRightDsbl";
	else
		ur_get(sId+'-SrlRt').className= "urLnkBarScrlRight";
}
var oSelectableLinkBarContents= new Array();
function sapUrMapi_SelectableLinkBar_draw(sId) {
  var oLinkBar = ur_get(sId);
  var iWidth = oLinkBar.offsetWidth;
  var iOrgWidth=iWidth;
  var oLinkBarContent = ur_get(sId+"-cnt");
  var iFirstVisible=sapUrMapi_SelectableLinkBar_getFirstVisibleItem(sId);
  var iLastVisible=parseInt(ur_get(sId).getAttribute("lastitemidx"));
  if (oSelectableLinkBarContents[sId]==null) {
  	oSelectableLinkBarContents[sId]=oLinkBarContent;
  } else {
    if (iFirstVisible>=oSelectableLinkBarContents[sId].childNodes.length) return;
  	oParent = oLinkBarContent.parentNode;
  	oParent.removeChild(oLinkBarContent);
  	oSave = oSelectableLinkBarContents[sId].cloneNode(true);
  	oParent.appendChild(oSelectableLinkBarContents[sId]);
  	oSelectableLinkBarContents[sId]=oSave;
  	oLinkBarContent=ur_get(sId+"-cnt");
  }
  var oLinkBarScrollPrev = ur_get(sId+"-p");
  var oLinkBarScrollNext = ur_get(sId+"-n");
  iWidth-=oLinkBarScrollPrev.offsetWidth;
  iWidth-=oLinkBarScrollNext.offsetWidth;
  var nWidth=0;
  var xWidth=0;
  var xHeight=oLinkBarScrollNext.offsetHeight;
  var collItems = oLinkBarContent.childNodes;
  for (var n=0;n<collItems.length;n++) {
		  collItems.item(n).style.width="50px";
  }
  var ix=0;
  if (iWidth==0) {
  	oLinkBar.style.width="100%";
  	return;
  }
  if (iFirstVisible==-1) {
	  for (var n=0;n<iLastVisible+1;n++) {
		  if (n>=collItems.length) break;
	    nWidth+=collItems.item(n).offsetWidth;
	    if (nWidth<iWidth) {
	      xWidth=nWidth;
	    }
 	    if (nWidth>iWidth) {
	      collItems.item(ix).style.display="none";
	      ix++;
	      iFirstVisible=ix;
	    }
    }
    if (nWidth<iWidth) {
		  for (var n=iLastVisible+1;n<collItems.length;n++) {
		   	collItems.item(n).style.display="inline-table";
  	    iLastVisible=n-1;
		    if (nWidth<iWidth) {
		      xWidth=nWidth;
		    }
 	      nWidth+=collItems.item(n).offsetWidth;
	 	    if (nWidth>iWidth) {
	 	   	  collItems.item(n).style.display="none";
	 	    	break;
		    }
	    }
    }
  } else {
    var iLastVisible=-1;
	  for (var n=0;n<collItems.length;n++) {
		   if (n<iFirstVisible) {
		   	 collItems.item(n).style.display="none";
		    continue;
		   } else {
		   	collItems.item(n).style.display="inline-table";
		   }
		   nWidth+=collItems.item(n).offsetWidth;
		   if (nWidth<iWidth) {
		     xWidth=nWidth;
		   }
		   if (nWidth>iWidth) {
		     collItems.item(n).style.display="inline-table";
		     if (iLastVisible==-1) {
		     	 iLastVisible=n-1;
		     }
		   }
		   if (nWidth<iWidth) {
		     xWidth=nWidth;
		   }
	  }
  }
  if (iLastVisible==-1) {
  	 iLastVisible=collItems.length-1;
  }
  if (iFirstVisible==-1) {
  	 iFirstVisible=0;
  }
  oLinkBar.setAttribute("lastitemidx",iLastVisible);
  oLinkBar.setAttribute("firstitemidx",iFirstVisible);
  if (iLastVisible>=collItems.length-1) {
    oLinkBarScrollNext.className="urLnkBarScrlRight urLnkBarScrlRightDsbl";
  } else {
    oLinkBarScrollNext.className="urLnkBarScrlRight";
  }
  if (iFirstVisible==0) {
    oLinkBarScrollPrev.className="urLnkBarScrlLeft urLnkBarScrlLeftDsbl";
  } else {
    oLinkBarScrollPrev.className="urLnkBarScrlLeft";
  }
  var oLinkBarDiv = ur_get(sId+"-div");
  oLinkBarDiv.style.width=xWidth;
  oLinkBar.style.width=xWidth;
}
function sapUrMapi_SelectableLinkBar_getFirstVisibleItem(sLinkBarId) {
	return parseInt(ur_get(sLinkBarId).getAttribute("firstitemidx"));
}
function sapUrMapi_SelectableLinkBar_resize(sLinkBarId,e) {
  sapUrMapi_SelectableLinkBar_create(sLinkBarId);
}
function sapUrMapi_SelectableLinkBar_scroll(sLinkBarId,sDirection) {
  var iFirstVisible=sapUrMapi_SelectableLinkBar_getFirstVisibleItem(sLinkBarId);
  var iLastVisible=parseInt(ur_get(sLinkBarId).getAttribute("lastitemidx"));
  var iPageSize=iLastVisible-iFirstVisible;
	var oLinkBarContent = ur_get(sLinkBarId+"-cnt");
  var collItems = oLinkBarContent.childNodes;
  if (sDirection=="PREV") {
		iLastVisible=iFirstVisible-1;
		iFirstVisible=-1;
  } else {
		iFirstVisible=iLastVisible+1;
		iLastVisible=-1;
	}
	ur_get(sLinkBarId).setAttribute("firstitemidx",iFirstVisible)
	ur_get(sLinkBarId).setAttribute("lastitemidx",iLastVisible)
  sapUrMapi_SelectableLinkBar_draw(sLinkBarId);
}
function sapUrMapi_SelectableLinkBar_keydown(sId,e) {
	var o=e.target;
	
	if(e.keyCode=="32"){
		if(o.tagName=="A")o.click();
	}
	
	if(e.keyCode=="39"){
		if(o.tagName == "TABLE"){
			o=o.firstChild.firstChild.firstChild;
		}
		else{
			while(o.tagName != "TD") o=o.parentNode;
			sapUrMapi_setTabIndex(o.firstChild,-1);
			o=o.nextSibling;
			if(o==null) return;
		}
		if(o.firstChild.className == "urLnkBarLnkDsbl" && ur_system.is508 == false )o=o.nextSibling;
		if(o==null) return;
		if(o.style.display=="none")
			sapUrMapi_SelectableLinkBar_scroll(sId,"NEXT");
		sapUrMapi_setTabIndex(o.firstChild,0);
		ur_focus(o.firstChild);
		return true;
	}
	
	if(e.keyCode=="37"){
		if(o.tagName == "TABLE"){
			o=o.firstChild.firstChild.firstChild;
		}
		else{
			while(o.tagName != "TD") o=o.parentNode;
			sapUrMapi_setTabIndex(o.firstChild,-1);
			o=o.previousSibling;
			if(o==null) return;
		}
		if(o.firstChild.className == "urLnkBarLnkDsbl" && ur_system.is508 == false )o=o.previousSibling;
		if(o==null) return;
		if(o.style.display=="none")
			sapUrMapi_SelectableLinkBar_scroll(sId,"PREV");
		sapUrMapi_setTabIndex(o.firstChild,0);
		ur_focus(o.firstChild);
		return true;
	}
}

//** Skip.ie5 **

function sapUrMapi_skip(sId,oEvt) 
{
	var sCt=sapUrMapi_getControlType(sId);
	if(sCt=="AX" || sCt=="AP" || sCt=="IF" || sCt=="T" )
		sId+="-r";
	var oR=ur_get(sId);
	var oN=null;
	var oF=null;
	
	
	if( oEvt.shiftKey && oEvt.keyCode == 117 )
	{
		while(oR!=null && oF==null){
			while(oR!=null && oR.previousSibling==null)
				oR=oR.parentNode;
			if(oR==null)
				break;
			oN=oR.previousSibling;
			while(oN!=null && oF==null){
				oF=sapUrMapi_findFirstFocus(oN,true);
				if(oF==null)
					oN=oN.previousSibling;
			}
			if(oF==null)
				oR=oR.parentNode;
			else
				break;
		}
	}	 
	
	else if( oEvt.keyCode == 117 ){
		while(oR!=null && oF==null){
			while(oR!=null && oR.nextSibling==null)
				oR=oR.parentNode;
			if(oR==null)
				break;				
			oN=oR.nextSibling;
			while(oN!=null && oF==null){
				oF=sapUrMapi_findFirstFocus(oN);
				if(oF==null)
					oN=oN.nextSibling;
			}
			if(oF==null)
				oR=oR.parentNode;
			else
				break;
		}
	}	
	if(oF!=null)
	{
		ur_focus(oF);
		return ur_EVT_cancel(oEvt);
	}
    if(oEvt.keyCode== 13)
	 {
		if(oR.getAttribute("dbid")!=null)
		 {
			 sapUrMapi_triggerDefaultButton(sId,oEvt);
		 }
	 }	 
}

//** Status.ie5 **

function ur_setSt(sId,aSt,bOn){
	var o=null;
	if(typeof(sId)=="string") o=ur_get(sId);
	else o=sId;
	if (!o) return 
	var sSt=o.getAttribute("st");
	
	if(sSt==null) sSt="";
	if(typeof(aSt)=="string")
		aSt=new Array(aSt);
	
	for(var i=0; i<aSt.length;i++){
		if(sSt=="" || sSt.indexOf(aSt[i])==-1){
			if(bOn) sSt+=aSt[i];
		}
		else{
			if(!bOn) sSt=sSt.replace(aSt[i],"");
		}
	}
	
	o.setAttribute("st",sSt);
}
function ur_isSt(sId,aSt){
	var o=null;
	if(typeof(sId)=="string") o=ur_get(sId);
	else o=sId;
	if (!o) return false; 
	var sSt=o.getAttribute("st");
	var bRet=true;
	if(sSt==null) return false;
	
	if(typeof(aSt)=="string")
		aSt=new Array(aSt);
	
	for(var i=0; i<aSt.length;i++)
		if(sSt.indexOf(aSt[i])==-1)
			bRet=false;
	return bRet;
}
function ur_getRootObj(o) {
  while(o.getAttribute!=null && (o.getAttribute("ct")==null || o.getAttribute("ct")==""))
    o=o.parentNode;
  if (o.getAttribute!=null && o.getAttribute("ct")!=null && o.getAttribute("ct")!="")
    return o;
}

//** TableView.ie5 **

function sapUrMapi_Table_selectRow(sTableId,iRow,e) 
{
  var oInput = ur_get(sTableId+'-itm-'+iRow);
  var oInputGrp = document.getElementsByName(oInput.name);
  var srcElement = ur_EVT_src(e);
  if ((oInputGrp.length==1)&&(oInput.type!="radio"))
  {
    if (srcElement.tagName=="IMG") oInput.checked = (!oInput.checked);
		var oImg = ur_get(oInput.id + "-img");
		oImg.className = "urImgCbgImg";
		if (oInput.checked) oImg.className = "urImgCbgImgChk";
		
		var oRow = oInput.parentNode;
		while(!oRow.getAttribute("rr"))
		{
			oRow=oRow.parentNode;
		}
		for (var n=0;n<oRow.cells.length;n++)
		{
			var oCell = oRow.cells[n];
			if (oInput.checked)
			{
			  oCell.setAttribute("unselectedclass",oCell.className);
			  
			}
			else
			{
	  		  
			}
		}
		if(oInput.checked)
	    {
			ur_setSt(oInput,ur_st.NOTSELECTED,false);
			ur_setSt(oInput,ur_st.SELECTED,true);
		}
		else
		{
			ur_setSt(oInput,ur_st.NOTSELECTED,true);
			ur_setSt(oInput,ur_st.SELECTED,false);
		}
  } 
   else
  {
	  for (var i = 0; i < oInputGrp.length; i++)
	  {
	    var oImg = ur_get(oInputGrp[i].id + "-img");
	    if (oInputGrp[i]==oInput)
		{
			  if (srcElement.tagName=="IMG") oInput.checked=true;
			  if (srcElement.tagName=="IMG") ur_focus(oInputGrp[i]);
		      oImg.className = "urImgRbgImgChk";
			  ur_setSt(oInput,ur_st.NOTSELECTED,false);
			  ur_setSt(oInput,ur_st.SELECTED,true);
	    } 
		else
		{
			 if (oImg.onclick)
			 {
				oInputGrp[i].checked=false;
				oImg.className = "urImgRbgImg";
				ur_setSt(oInputGrp[i],ur_st.NOTSELECTED,true);
				ur_setSt(oInputGrp[i],ur_st.SELECTED,false);
			 }
	    }
	 }
	
  }
  e.cancelBubble=true;
  e.returnValue=true;
}
function sapUrMapi_Table_getClickedRowIndex(sId) {
 	 oSrc = window.event.srcElement;
   var obj = event.srcElement;
   while ( (obj!=null) && (obj.tagName!='TD') )
      obj = obj.parentNode;
   if(obj==null) return;
   var parent = obj.parentNode;
   var rowIndex = parent.getAttribute("rr");
   return parseInt(rowIndex);
}
function sapUrMapi_Table_getClickedColIndex(sId) {
 	 oSrc = window.event.srcElement;
   var obj = event.srcElement;
   while ( (obj!=null) && (obj.tagName!='TD') )
      obj = obj.parentNode;
   oCell = obj;
   while ( (obj!=null) && (obj.tagName!='TABLE') )
      obj = obj.parentNode;
   if ( obj==null ) return;
   var colidx =  oCell.cellIndex - parseInt( obj.nmi );
   return colidx;
}
function sapUrMapi_Table_getClickedCellId(sId) {
 	 oSrc = window.event.srcElement;
   var obj = event.srcElement;
   while ( (obj!=null) && (obj.tagName!='TD') )
      obj = obj.parentNode;
   oCell = obj;
   var cellid =  oCell.id;
   return cellid;
}
function sapUrMapi_Table_clickSelButton(o){
	var oRow = o;
	while(oRow.tagName!="TR") oRow = oRow.parentNode;
	if(oRow.tagName!="TR")return;
	var sButtons = oRow.getElementsByTagName("BUTTON");
	for(var i=0;i<sButtons.length;i++)
		if(sButtons[i].className=="urSTRowUnSelIcon" || sButtons[i].className=="urSTRowSelIcon")
			if(o.id != sButtons[i].id)
				sButtons[i].click();
}
function sapUrMapi_Table_getCellIndex(oCell){
	var i=0;
	var o=oCell;
	var oRow=oCell.parentNode;
	var oTab=oRow.parentNode.parentNode;
	
	while(o.previousSibling!=null){
		for(var j=oRow.rowIndex-1;j>=0;j--){
			if(oTab.rows[j].cells.length<=o.cellIndex) continue;
			if(oTab.rows[j].cells[o.cellIndex].rowSpan>1 && oTab.rows[j].rowIndex+oTab.rows[j].cells[o.cellIndex].rowSpan-1>=oRow.rowIndex){
				i+=oTab.rows[j].cells[o.cellIndex].rowSpan-1;
				break;
			}
		}
		if(o.previousSibling!=null) o=o.previousSibling;
		i+=o.colSpan;
	}
	return i;
}
function sapUrMapi_Table_getCell(oRow,iIdx){
	var o=oRow.firstChild;
	var oTab=oRow.parentNode.parentNode;
	var i=0;
	
	while(i<iIdx){
		for(var j=oRow.rowIndex-1;j>=0;j--){
			if(oTab.rows[j].cells.length<=o.cellIndex) continue;
			if(oTab.rows[j].cells[o.cellIndex].rowSpan>1 && oTab.rows[j].rowIndex+oTab.rows[j].cells[o.cellIndex].rowSpan-1>=oRow.rowIndex){
				iIdx-=oTab.rows[j].cells[o.cellIndex].rowSpan-1;
				break;
			}
		}
		if(o.nextSibling!=null && i<iIdx) o=o.nextSibling;
		else break;
		i+=o.colSpan;
	}
	return o;
}
function sapUrMapi_Table_focusUp(sId,o){
	var oCell = o;
	var iCellIdx=0;
	
	while(oCell.tagName != "TD" && oCell.tagName != "TH") oCell = oCell.parentNode;
	iCellIdx=sapUrMapi_Table_getCellIndex(oCell);
	
	var oCurrRow = oCell.parentNode;
	var oRow=oCurrRow.parentNode.firstChild;
	while(oRow.nextSibling!=oCurrRow){
		oCell=sapUrMapi_Table_getCell(oRow,iCellIdx);
		if(oRow.rowIndex+oCell.rowSpan >= oCurrRow.rowIndex)
			break;
		oRow=oRow.nextSibling;
	}
	
	if(oCurrRow.previousSibling==null && oRow.parentNode.previousSibling!=null)
		oRow=oRow.parentNode.previousSibling.firstChild;
	
	oCell=sapUrMapi_Table_getCell(oRow,iCellIdx);
	if(oCell!=null) sapUrMapi_Table_focusContent(oCell);
}
function sapUrMapi_Table_focusDown(sId,o){
	var oCell=o;
	var bLastRow=false;
	
	while(oCell.tagName != "TD" && oCell.tagName != "TH") oCell = oCell.parentNode;
	
	var oRow=oCell.parentNode;
	for(var i=0; i<oCell.rowSpan;i++){
		if(oRow.nextSibling!=null)
			oRow=oRow.nextSibling;
		else{
			bLastRow=true;
			break;
		}
	}
	
	if(bLastRow && oRow.parentNode.nextSibling!=null && oRow.parentNode.nextSibling.tagName!="TFOOT")
	 oRow=oRow.parentNode.nextSibling.firstChild;
	else if(bLastRow) return;
	
	oCell=sapUrMapi_Table_getCell(oRow,sapUrMapi_Table_getCellIndex(oCell));
	if(oCell!=null) sapUrMapi_Table_focusContent(oCell);
}
function sapUrMapi_Table_focusPrevious(sId,o){
	var oCell = o;
	var oPCell = null;
	var oTab = null;
	while(!(oCell.className.substr(0,4)=="urST"&& (oCell.tagName=="TD"||oCell.tagName=="TH"))){
		oCell=oCell.parentNode;
		if(oCell==null||oCell.id==sId) return false;
	}
	oTab = oCell;
	while(oTab.tagName!="TABLE") oTab = oTab.parentNode;
	for(var i=0; i<oCell.parentNode.rowIndex; i++){
		for(var j=0; j<=oCell.cellIndex; j++){
			if(oTab.rows[i].cells.length > j)
			if( oTab.rows[i].rowIndex+parseInt(oTab.rows[i].cells[j].rowSpan)-1>=oCell.parentNode.rowIndex && oCell.cellIndex==oTab.rows[i].cells[j].cellIndex)
				oPCell=oTab.rows[i].cells[j];
		}
	}
	if(oPCell==null && oCell.previousSibling!=null) oPCell=oCell.previousSibling;
	if(oPCell!=null) sapUrMapi_Table_focusContent(oPCell);
}
function sapUrMapi_Table_focusNext(sId,o){
	var oCell = o;
	var oTab;
	while(!(oCell.className.substr(0,4)=="urST"&& (oCell.tagName=="TD"||oCell.tagName=="TH"))){
		oCell=oCell.parentNode;
		if(oCell==null||oCell.id==sId) return false;
	}
	oTab = oCell;
	while(oTab.tagName!="TABLE") oTab = oTab.parentNode;
	if(oTab.parentNode.parentNode.parentNode.parentNode.id!=sId)
		sapUrMapi_Table_focusNext(sId,oTab.parentNode);
	else
		if( oCell.nextSibling != null ) sapUrMapi_Table_focusContent(oCell.nextSibling);
}
function sapUrMapi_Table_tabBack(sId,o){
	var oCell = o;
	var oTab;
	if( o.tagName == "TABLE" || o.tagName == "TBODY" ) return false;
	while(oCell.tagName != "TD" && oCell.tagName != "TH"){
		oCell = oCell.parentNode;		
	}
	if(oCell.tagName != "TD" && oCell.tagName != "TH") return false;
	var sRootType = sapUrMapi_getControlTypeFromObject(oCell);
	if (sRootType!="TBV") return false;
	oTab = oCell;
	while(oTab.tagName!="TABLE") oTab = oTab.parentNode;
	if(oTab.parentNode.parentNode.parentNode.parentNode.id!=sId) return false;
	if( oCell.previousSibling != null && oCell.previousSibling.getAttribute("ti")=="0"){
		sapUrMapi_Table_focusContent(oCell.previousSibling);
		return true;
	} else {
		var oRow = oCell.parentNode.previousSibling;
		if ( oRow ){
			sapUrMapi_Table_focusContent(oRow.lastChild);
			return true;
		}
		else{
			oRow = oCell.parentNode;
			
			if(oRow.previousSibling==null && oRow.parentNode.previousSibling!=null) {
				oRow=oRow.parentNode.previousSibling.firstChild;
				sapUrMapi_Table_focusContent(oRow.lastChild);
				return true;
			}
		}
	}
	
	return false;
}
function sapUrMapi_Table_tabForward(sId,o){
	var oCell = o;
	var oTab;
	if( o.tagName == "TABLE" || o.tagName == "TBODY" ) return false;
	while(oCell.tagName != "TD" && oCell.tagName != "TH"){
		oCell = oCell.parentNode;
	}
	var sRootType = sapUrMapi_getControlTypeFromObject(oCell);
	if (sRootType!="TBV") return false;
	if(oCell.tagName != "TD" && oCell.tagName != "TH") return false;
	oTab = oCell;
	while(oTab.tagName!="TABLE") oTab = oTab.parentNode;
	if(oTab.parentNode.parentNode.parentNode.parentNode.id!=sId) return false;
	if( oCell.nextSibling != null){
		sapUrMapi_Table_focusContent(oCell.nextSibling);
		return true;
	}
	else {
		var oRow = oCell.parentNode.nextSibling;
		if ( oRow ){
			sapUrMapi_Table_focusContent(oRow.firstChild);
			return true;
		}
		else{
			oRow = oCell.parentNode;
			
			if(oRow.nextSibling==null && oRow.parentNode.nextSibling!=null) {
				oRow=oRow.parentNode.nextSibling.firstChild;
				sapUrMapi_Table_focusContent(oRow.firstChild);
				return true;
			}
		}
	}
	return false;
}
function sapUrMapi_Table_keydown(sId,e){
  var o=ur_EVT_src(e);
	var iKey=e.keyCode;
	var sCt=sapUrMapi_getControlTypeFromObject(o);
	if(sId.indexOf("-skipstart")==-1) sId+="-skipstart";
	
	if(e.keyCode == "40" && o.tagName != "SELECT"){
		sapUrMapi_Table_focusDown(sId,e.srcElement);
		ur_EVT_cancel(e);
		return true;
	}
	
	if(e.keyCode == "38" && o.tagName != "SELECT"){
		sapUrMapi_Table_focusUp(sId,e.srcElement);
		ur_EVT_cancel(e);
		return true;
	}
	
	if(e.keyCode == "39" && (o.tagName != "INPUT" || o.type.toUpperCase()=="CHECKBOX" || o.type.toUpperCase()=="RADIO")){
		if (ur_system.direction=="rtl")
			sapUrMapi_Table_focusPrevious(sId,o);
		else
			sapUrMapi_Table_focusNext(sId,o);
		ur_EVT_cancel(e);
		return true;
	}
	
	if(e.keyCode == "37" && (o.tagName != "INPUT" || o.type.toUpperCase()=="CHECKBOX" || o.type.toUpperCase()=="RADIO")){
		if (ur_system.direction=="rtl")
			sapUrMapi_Table_focusNext(sId,o);
		else
			sapUrMapi_Table_focusPrevious(sId,o);
		ur_EVT_cancel(e);
		return true;
	}
	
	if(e.keyCode == "9" && e.shiftKey){
		if( sapUrMapi_Table_tabBack(sId,o) ){
			ur_EVT_cancel(e);
			return true;
		}
	} else if (e.keyCode == 9) {
		
		if( sapUrMapi_Table_tabForward(sId,o) ){
			ur_EVT_cancel(e);
			return true;
		}
	}
  
  if(ur_get(sId).getElementsByTagName("TFOOT")[0]!=null){
  var o=e.srcElement;
  var sTag=o.tagName;
	var iKey=e.keyCode;
	var bS=e.shiftKey;
	var bA=e.altKey;
	var bC=sapUrMapi_bCtrl(e);
  var sTag=o.tagName;
	var aBtns=ur_get(sId).getElementsByTagName("TFOOT")[0].getElementsByTagName("IMG");
	if (aBtns.length!=null) {
			
			if(iKey==36 && !bA && !bS && bC && sTag!="INPUT" && sTag!="TEXTAREA"){
				for (var i=0;i<aBtns.length;i++) {
				  if (aBtns[i].className.indexOf("Top")>-1 && aBtns[i].className.indexOf("Dsbl")==-1) {
				    aBtns[i].click();
				    ur_EVT_cancel(e);
						break;
				  }
				}
				return;
			}
			
			if(iKey==35 && !bA && !bS && bC && sTag!="INPUT" && sTag!="TEXTAREA"){
				for (var i=0;i<aBtns.length;i++) {
				  if (aBtns[i].className.indexOf("Bottom")>-1 && aBtns[i].className.indexOf("Dsbl")==-1) {
				    aBtns[i].click();
				    ur_EVT_cancel(e);
						break;
				  }
				}
				return;
			}
			
			if(iKey==33 && !bA && !bS &&!bC && sTag!="INPUT" && sTag!="TEXTAREA"){
				for (var i=0;i<aBtns.length;i++) {
				  if (aBtns[i].className.indexOf("PgUp")>-1 && aBtns[i].className.indexOf("Dsbl")==-1) {
				    aBtns[i].click();
				    ur_EVT_cancel(e);
						break;
				  }
				}
				return;
			}
			
			if(iKey==34 && !bA && !bS &&!bC && sTag!="INPUT" && sTag!="TEXTAREA"){
				for (var i=0;i<aBtns.length;i++) {
				  if (aBtns[i].className.indexOf("PgDown")>-1 && aBtns[i].className.indexOf("Dsbl")==-1) {
				    aBtns[i].click();
				    ur_EVT_cancel(e);
						break;
				  }
				}
				return;
			}
	}
	}
	
	return sapUrMapi_skip(sId,e);
}
function sapUrMapi_Table_activate(sId,e){
	var o = ur_EVT_src(e);
	sapUrMapi_Table_focusContent(o);
}
function sapUrMapi_Table_focusContent(o){
	var oCell = o;
	var isCell = o.tagName == "TD" || o.tagName == "TH";
	
	
	if(!isCell) return;
	var o = o.firstChild;
	
	if(o!=null) {
		var oChild = o.firstChild;
		var oFocus = null;
		
		while(oFocus==null){
			while(oFocus==null){
				if(o==null) break;
				if(o.nodeType!=3 && (sapUrMapi_Focus_canFocus(o)==true||o.type=="radio")){
					if (o.tagName=="INPUT" && (o.type=="radio"||o.type=="checkbox") && ur_system.browser_abbrev.indexOf("ie")==-1) {
						o.style.height = "1px";
						o.style.width = "1px";
					}
					oFocus=o;
					break;
				}
				o = o.firstChild;
			}
			if(oChild==null) break;
			oChild=oChild.nextSibling;
			o=oChild;
		}
		
		if(oFocus!=null) {
			if (ur_system.is508) sapUrMapi_Table_getTooltip(oFocus);
		  	setTimeout(function(){ur_focus(oFocus);},0);
			return;
		} else {
			
			if (oCell) {
			ur_focus(oCell);
			}			
		}
	} 
    
    
	if (ur_system.is508) {
	    var oFocus = ur_EVT_src(e);
		sapUrMapi_Table_getTooltip(oFocus, true);
		setTimeout(function(){ur_focus(oFocus);},0);
	}	
}
function sapUrMapi_Table_getTooltip(oF, isEmptyCell){
	 
		var sTooltip="";
		var sSep=" "+getLanguageText("SAPUR_SEPARATOR")+" ";
		var o = oF;
		
		if(!isEmptyCell) {
			o = oF.parentNode;
			while(o.tagName!="TD") o=o.parentNode;
		}
		
		var row = parseInt(o.getAttribute("rowIndex"))+1;
		var col = parseInt(o.getAttribute("colIndex"))+1;
	    
		var aHeaders;
		var sHeaders=o.getAttribute("headers");
		var oHeader;
		
		if(isNaN(row)) return;
		
		if (sHeaders==null || sHeaders=="") {
			if(isNaN(col)) return;
			sTooltip = getLanguageText("SAPUR_TBV_CELL",new Array(row,col));
		} else {
			aHeaders=sHeaders.split(" ");
			sHeaders="";
			for(var i=0;i<aHeaders.length;i++)
			{
				oHeader=ur_get(aHeaders[i]);
				if(oHeader!=null)sHeaders+=oHeader.innerText;
				if(i<aHeaders.length) sHeaders+=" ";
			}
			sTooltip = getLanguageText("SAPUR_TBV_CELL",new Array(row,sHeaders));
		}
		
		if(isEmptyCell) {
			sTooltip = getLanguageText("SAPUR_EMPTY") + sSep + sTooltip;
			oF.setAttribute("noCntanrAnnouce","X");
		}
		
		if(o.className.indexOf("urSTbvCellNeg")>0) sTooltip+=sSep+getLanguageText("SAPUR_NEGATIVE");
		else if(o.className.indexOf("urSTbvCellTot")>=0) sTooltip+=sSep+getLanguageText("SAPUR_TOTAL");
		else if(o.className.indexOf("urSTbvCellSubtot")>=0) sTooltip+=sSep+getLanguageText("SAPUR_SUBTOTAL");
		else if(o.className.indexOf("urSTbvCellBad")>=0) sTooltip+=sSep+getLanguageText("SAPUR_BADVALUE");
		else if(o.className.indexOf("urSTbvCellCrit")>=0) sTooltip+=sSep+getLanguageText("SAPUR_CRITICALVALUE");
		else if(o.className.indexOf("urSTbvCellPos")>=0) sTooltip+=sSep+getLanguageText("SAPUR_POSITIVE");
		if(o.className.indexOf("urSTbvCellSel")>=0) sTooltip+=sSep+getLanguageText("SAPUR_SELECTED");
	  oF.setAttribute("tttbl",sTooltip);
	  oF.setAttribute("intbl","true");
		
	  var oActiveElement = document.activeElement;
	  
	  if(oActiveElement != null && oActiveElement != oF) {
	  	oActiveElement.setAttribute("tttbl",sTooltip);
	  	oActiveElement.setAttribute("intbl","true");
	  	oActiveElement.setAttribute("noCntanrAnnouce","X");
	  }
		
}

//** TabStrip.ie5 **

function sapUrMapi_TabStrip_RegisterCreate(sId,iCount,iActive) {
	if(!sId || iCount==0 || iActive<0) return;
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_TabStrip_create('" + sId + "','" + iCount + "','" + iActive + "')");
}
function sapUrMapi_TabStrip_create(sId,iCount,iActive) {
	
	var oTabTable=ur_get(sId);
	var curTab = ur_get(sId + "-cnt-" + iActive);
	if (curTab == null) return;
	var iHeight=0
	var iWidth=0;
	
	if (curTab.childNodes[0] != null && sapUrMapi_getCurrentStyle(curTab.childNodes[0],"overflow")!="visible") {
	  var oContent=ur_TS_drawScrollContent(sId);
		var iHeight = oContent.height;
		var iWidth = oContent.width;
	}
	
	
		
		if(ur_get(sId).getAttribute("scrl")=="1") 
		{
			ur_IScr_getObj(sId);
			ur_IScr[sId].scrl.style.width = "auto";
			
			if ( oTabTable.style.width == "" && iWidth != 0 ) {
					oTabTable.style.width = iWidth;
			}
			ur_IScr_create(sId);
			
			
			var oPag = ur_get(sId+"-pg");
			sapUrMapi_Paginator_removeFromTabChain(sId+"-pg");
			var oScr = ur_IScr[sId];
			var iSelIdx = parseInt(oTabTable.getAttribute('sidx'));
		        var iTabWidth = 0;
			for (var n=0;n<oScr.items.length;n++) {
			  if (oScr.items[n].width>iTabWidth) iTabWidth=oScr.items[n].width;
			}
			var iPagWidth=oPag.parentNode.offsetWidth;
			if (iWidth==0) iWidth=oTabTable.offsetWidth;
			
			
			
			
			try{
			if(iWidth  < (iPagWidth+iTabWidth+(iTabWidth/2)))
			{
				oTabTable.style.width=iPagWidth+iTabWidth+(iTabWidth/2);
				ur_IScr_draw(sId);
				ur_TS_drawScrollContent(sId);
				}
			}catch(ex){};
			
			
			
			
			if(!oScr.items[iSelIdx].visible)
			{
				
				
				
								
				ur_get(sId+"-scrl").setAttribute("fsrl",iSelIdx);
				oScr.first = iSelIdx;
				ur_IScr_create(sId);
				oTabTable.setAttribute("fidx",iSelIdx);
				sapUrMapi_setTabIndex(oScr.items[iSelIdx][1],0);
			}
			else
			{
				sapUrMapi_setTabIndex(oScr.items[iSelIdx][1],0);
				oTabTable.setAttribute("fidx",iSelIdx);
			}
		}
	oTabTable.onresize = new Function("event","sapUrMapi_TabStrip_resize('"+sId+"',"+iWidth+","+iHeight+")"); 
	
}
function ur_TS_drawScrollContent(sId) {
	var curTab = ur_get(sId + "-cnt-" + ur_get(sId).getAttribute("sidx"));
	if (sapUrMapi_getCurrentStyle(curTab.childNodes[0],"overflow")!="visible") {
	  var oBorders=curTab.parentNode;
		var iBl=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderBottomWidth"));
		var iBr=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderRightWidth"));
		var iBt=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderTopWidth"));
		var iBb=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderBottomWidth"));
	  curTab.childNodes[0].style.height=curTab.parentNode.offsetHeight-iBt-iBb;
	  curTab.childNodes[0].style.width=curTab.parentNode.offsetWidth-iBl-iBr;
	  curTab.style.overflow="visible";
	  return {height:curTab.parentNode.offsetHeight-iBt-iBb,width:curTab.parentNode.offsetWidth-iBl-iBr};
	} else {
	  return {height:curTab.offsetHeight,width:curTab.offsetWidth};
	}
}
function sapUrMapi_TabStrip_resize(sId,iWidth,iHeight) {
	var o = ur_get(sId);
	if(!o) return;
	if(o.getAttribute("scrl") == 1) {
	var iWidth = o.offsetWidth;
		if (ur_IScr[sId].iWidth && ur_IScr[sId].iWidth == iWidth ) return;
		ur_IScr_resize(sId);
		ur_IScr[sId].iWidth = iWidth;
	}
  	ur_TS_drawScrollContent(sId);
}
function sapUrMapi_TabStrip_getSelectedItemId(sTabStripId) {
  var oTabTable = ur_get(sTabStripId);
	var iSelTab	= parseInt(oTabTable.getAttribute("sidx"));
	return sTabStripId+"-itm-"+iSelTab;
}
function sapUrMapi_TabStrip_keySelect(strId, intSelectedIdx, intTabCount,e) {
	if(e.keyCode == 9)
	{	
		var oTabScrl = ur_get(strId);
		var iSelIdx = parseInt(ur_get(strId).getAttribute("sidx"));
		var iFocIdx = parseInt(ur_get(strId).getAttribute("fidx"));
		if(ur_get(strId).getAttribute("scrl")!="1")
		{
			sapUrMapi_setTabIndex(ur_get(strId+"-itm-"+iFocIdx),-1);
			sapUrMapi_setTabIndex(ur_get(strId+"-itm-"+iSelIdx),0);
			oTabScrl.setAttribute("fidx",iSelIdx);
		}
		else
		{
			var oScrl = ur_IScr[strId];
			
			if(!oScrl.items[iSelIdx].visible)
			{
				sapUrMapi_setTabIndex(oScrl.items[oScrl.first][1],0);
				sapUrMapi_setTabIndex(oScrl.items[iSelIdx][1],-1);
				if(oScrl.first != iFocIdx)
					sapUrMapi_setTabIndex(oScrl.items[iFocIdx][1],-1);
				oTabScrl.setAttribute("fidx",oScrl.first);
			}
			else
			{
				if(intSelectedIdx != iSelIdx){
				sapUrMapi_setTabIndex(oScrl.items[iSelIdx][1],0);
				sapUrMapi_setTabIndex(oScrl.items[intSelectedIdx][1],-1);
				oTabScrl.setAttribute("fidx",iSelIdx);
				}
			}
		}
			
	}
	if (sapUrMapi_checkKey(e,"keydown",new Array("39","37","33","34","35","36"))){
		if (ur_system.direction == "rtl") {
			if(e.keyCode == 35 || e.keyCode == 36)
			{
				sapUrMapi_TabStrip_focusItem(strId,intSelectedIdx,intTabCount,e.keyCode==36,e.keyCode==35,e);
				ur_EVT_cancel(e);
				return;
			
			}
			if(e.keyCode == 33 || e.keyCode == 34)
			{
				sapUrMapi_TabStrip_focusItem(strId,intSelectedIdx,intTabCount,e.keyCode==33,e.keyCode==34,e);
				ur_EVT_cancel(e);
				return;
			
			}
			else{
			sapUrMapi_TabStrip_focusItem(strId,intSelectedIdx,intTabCount,e.keyCode==37,e.keyCode==39,e);
			ur_EVT_cancel(e);
			return;
			}
		} else {
			if(e.keyCode == 35 || e.keyCode == 36)
			{
				sapUrMapi_TabStrip_focusItem(strId,intSelectedIdx,intTabCount,e.keyCode==35,e.keyCode==36,e);
				ur_EVT_cancel(e);
				return;
			
			}
		
			if(e.keyCode == 33 || e.keyCode == 34)
			{
				sapUrMapi_TabStrip_focusItem(strId,intSelectedIdx,intTabCount,e.keyCode==34,e.keyCode==33,e);
				ur_EVT_cancel(e);
				return;
			
			}else{
			sapUrMapi_TabStrip_focusItem(strId,intSelectedIdx,intTabCount,e.keyCode==39,e.keyCode==37,e);
			ur_EVT_cancel(e);
			return;
			}
		}
  }
  
  if (sapUrMapi_checkKey(e,"keydown",new Array("32"))){
  	ur_evtSrc(e).click();
	ur_EVT_cancel(e);
  	return;
  }
  
}
function sapUrMapi_TabStrip_focusItem(sTabStripId,iFocusIdx,iTabCount,bNext,bPrev,evt) {
  var oTabTable = ur_get(sTabStripId);
 	if(ur_IScr[sTabStripId] == null || oTabTable != ur_IScr[sTabStripId])
		ur_IScr_getObj(sTabStripId);
  	var objTab = ur_IScr[sTabStripId];
	if (isNaN(iFocusIdx)) iFocusIdx = parseInt(ur_get(sTabStripId).getAttribute("fidx"));
	var iNewIndex=iFocusIdx;
	if (bNext) {
		if(oTabTable.getAttribute("scrl") != "1") {
			if (iNewIndex < iTabCount-1) {
				iNewIndex=iFocusIdx+1;
			} else 
			  iNewIndex=0;
		} else { 
			if(evt.keyCode == 33 || evt.keyCode == 34) 
			{
				if(iNewIndex < objTab.items.length - 1)
					ur_IScr_toNextPage(sTabStripId);
				iNewIndex = objTab.first;
			}
			else if(evt.keyCode == 36 || evt.keyCode == 35)
			{
				if(iNewIndex < objTab.items.length - 1)
					ur_IScr_toEnd(sTabStripId);
				iNewIndex = objTab.last;
			}
			else{
				if(iNewIndex < objTab.items.length - 1) {
					iNewIndex=iFocusIdx+1;
				} 
				if(iNewIndex > objTab.last) {
					ur_IScr_toNextItem(sTabStripId);
				}
			}
		}
	}
	if (bPrev) {
		if(oTabTable.getAttribute("scrl") != "1") { 
			if (iNewIndex > 0) {
				iNewIndex=iFocusIdx-1;
			} else iNewIndex=objTab.items.length - 1;
		} else {
			if(evt.keyCode == 33 || evt.keyCode == 34)
			{
				if(iNewIndex > 0)
					ur_IScr_toPrevPage(sTabStripId);
				iNewIndex = objTab.first;
			}
			else if(evt.keyCode == 36 || evt.keyCode == 35)
			{
				if(iNewIndex > 0)
					ur_IScr_toBegin(sTabStripId);
				iNewIndex = objTab.first;
			}
			else
			{
				if(iNewIndex > 0) {
					iNewIndex=iFocusIdx-1;
				}
				if(iNewIndex < objTab.first){
					ur_IScr_toPrevItem(sTabStripId);
				}
			}
		}
	}
	var iOldFoc     = parseInt(ur_get(sTabStripId).getAttribute("fidx"));
	var oFoc = objTab.items[iNewIndex][1];
	var iSelIdx = parseInt(ur_get(sTabStripId).getAttribute("sidx"));
	
	
	if(oTabTable.getAttribute("scrl") != "1")
	{
		sapUrMapi_setTabIndex(ur_get(sTabStripId+"-itm-"+iOldFoc),-1);
		sapUrMapi_setTabIndex(ur_get(sTabStripId+"-itm-"+iNewIndex),0);
		ur_get(sTabStripId).setAttribute("fidx",iNewIndex);
		oFoc.focus();
		
	}
	else
		ur_TS_setTabIdx(sTabStripId,iFocusIdx,iNewIndex);
	try{
		ur_EVT_addParam(evt,"FirstVisibleItemIdx",objTab.first);
	}catch(ex){};
}
function ur_TS_setTabIdx(sId,iOldFocIdx,iNewIndex)
{
	var oTabScrl = ur_get(sId);
	var iselIdx = oTabScrl.getAttribute("sidx");
	if (ur_IScr[sId] == null) ur_IScr_getObj(sId);
	var oScrl = ur_IScr[sId];
	
	if(!isNaN(iOldFocIdx))
	{
		
		if(iNewIndex == -1) 
		{
			iNewIndex  = iselIdx;
			if(!oScrl.items[iselIdx].visible)
			{
				sapUrMapi_setTabIndex(oScrl.items[oScrl.first][1],0);
				if(oScrl.first != iOldFocIdx)
					sapUrMapi_setTabIndex(oScrl.items[iOldFocIdx][1],-1);
				oTabScrl.setAttribute("fidx",oScrl.first);
			}
			else
			{
				sapUrMapi_setTabIndex(oScrl.items[iNewIndex][1],0);
				sapUrMapi_setTabIndex(oScrl.items[iOldFocIdx][1],-1);
				oTabScrl.setAttribute("fidx",iNewIndex);	
			}
			
		}
		else{
			sapUrMapi_setTabIndex(oScrl.items[iOldFocIdx][1],-1);
			sapUrMapi_setTabIndex(oScrl.items[iNewIndex][1],0);
			oTabScrl.setAttribute("fidx",iNewIndex);
			oScrl.items[iNewIndex][1].focus();
		}
	}
}
function sapUrMapi_TabStrip_enter (sId,e) {
	if (ur_evtSrc(e).id==sId+"-skipstart") {
		if (sapUrMapi_skip(sId+'-skipstart',sId+'-skipend',e)) return;
    if (!e.shiftKey) { 
		  if (sapUrMapi_checkKey(e,"keydown",new Array("9","39","37"))){
	        sapUrMapi_TabStrip_focusItem(sId);
	   
				ur_EVT_cancelBubble(e);
		  }
	  }
	}
}
function sapUrMapi_TabStrip_setActiveItem(sId,iIdx) {
		if (isNaN(iIdx)) return;
		
		if(ur_IScr[sId] == null)
			ur_IScr_getObj(sId);
			
		var oScrl = ur_IScr[sId];
		var obj	= ur_get(sId);
		
		if (obj != oScrl.Ref) {
			ur_IScr_getObj(sId);
			oScrl = ur_IScr[sId]
		}
			
		var iSelTab	= parseInt(obj.getAttribute("sidx"));
		var iTabLength	= parseInt(obj.getAttribute("ic"));
		
		if (oScrl.items[iIdx][1].getAttribute("st")!=null && oScrl.items[iIdx][1].getAttribute("st").indexOf("d")>-1) return false; 
		if ((iTabLength==1) || (iSelTab==iIdx)) return true; 
		
		var oCurrentTxt  = oScrl.items[iSelTab][1].firstChild;
		var oCurrentCell = oScrl.items[iSelTab][1];
		var oClickedTxt  = oScrl.items[iIdx][1].firstChild;
		var oClickedCell = oScrl.items[iIdx][1];
		
		var oCurrentContent  = ur_get(sId+"-cnt-"+iSelTab);
	  	var oClickedContent  = ur_get(sId+"-cnt-"+iIdx);
		
		var oCloseCurrent = ur_get(sId + "-itm-cl-" + iSelTab);
		var oCloseClicked = ur_get(sId + "-itm-cl-" + iIdx);
		
		var oBorders=oClickedContent.parentNode;
		var iBl=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderBottomWidth"));
		var iBr=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderRightWidth"));
		var iBt=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderTopWidth"));
		var iBb=parseInt(sapUrMapi_getCurrentStyle(oBorders,"borderBottomWidth"));
		
		oCurrentCell.className="urTbsLabelOff"; 
		oCurrentTxt.className = "urTbsTxtOff";  
		oClickedTxt.className = "urTbsTxtOn";   
	  oClickedCell.className="urTbsLabelOn";  
	  
		if (oCloseCurrent != null) oCloseCurrent.className = "urTbsCloseUnSel";
		if (oCloseClicked != null) oCloseClicked.className = "urTbsCloseSel";
		
	  sapUrMapi_setTabIndex(oCurrentCell,-1);
	  sapUrMapi_setTabIndex(oClickedCell,0);
	  	
	  obj.setAttribute("sidx",iIdx);
	  obj.setAttribute("fidx",iIdx); 
	  
    if (sapUrMapi_getCurrentStyle(oClickedContent.childNodes[0],"overflow")!="visible") {
  		oClickedContent.childNodes[0].style.height=oClickedContent.parentNode.offsetHeight-iBt-iBb;
  		oClickedContent.childNodes[0].style.width=oClickedContent.parentNode.offsetWidth-iBl-iBr;
		} else {
			if ( obj.getAttribute("exact") == "1") {
		    oClickedContent.style.height=oClickedContent.parentNode.offsetHeight-iBt-iBb;
		    	if ( !oClickedContent.style.width == "100%" )
		    oClickedContent.style.width=oClickedContent.parentNode.offsetWidth-iBl-iBr;
		  }
		}
		
		with ( oCurrentContent.style ) {
			overflow="hidden";
			position="absolute";
			top = "-1000";
			left = "0";
			visibility="hidden";
		}
		
		with ( oClickedContent.style ) {
			overflow="visible";
			position="static";
			visibility="inherit";
		}
		if(ur_get(sId+"-itm-cl-"+iIdx))
		{
			ur_get(sId+"-itm-cl-"+iIdx).className = "urTbsCloseSel";
	}	
		if(ur_get(sId+"-itm-cl-"+iSelTab))
		{
			ur_get(sId+"-itm-cl-"+iSelTab).className = "urTbsCloseUnSel";
		}
	
	
	ur_setSt(oCurrentCell,ur_st.NOTSELECTED,true);
	ur_setSt(oCurrentCell,ur_st.SELECTED,false);
	ur_setSt(oClickedCell,ur_st.NOTSELECTED,false);
	ur_setSt(oClickedCell,ur_st.SELECTED,true);
	
	
  if (obj.getAttribute("exact")=="1")
	  ur_TS_oadi(sId);
  else {
    var bVisible=oScrl.items[iIdx].visible;
    if (bVisible) ur_IScr_draw(sId);
    if (!oScrl.items[iIdx].visible || !bVisible) {
      oScrl.first=iIdx;
      oScrl.last=-1;
      ur_IScr_draw(sId);
    }
  }
  
  if (ur_system.is508) {
	if(oClickedCell.style.display == "inline"){
	   sapUrMapi_refocusElement(oClickedCell.id);
	}else{
		sapUrMapi_refocusElement(oScrl.items[oScrl.first][1]);
	}
}
	return true;
}
function ur_TS_cl(sId,evt)
  {
	var sElm = ur_evtSrc(evt);
	var bIdPresent = false;
	while(!bIdPresent)
	{		
		if(sElm.getAttribute('idx') !=null)
		{		
			if (oScrl.items[param[1]][1].getAttribute("st")!=null && oScrl.items[param[1]][1].getAttribute("st").indexOf("d")>-1) return false; 
			ur_EVT_fire(ur_get(sId+'-scrl'),"otc");
			bIdPresent = true;
		}
		else{
			sElm = sElm.parentNode;
			}
		
	} 	   
	
  }
	
function ur_TS_oadi(sId) {
  var oScrl = ur_IScr[sId];
	
	var iFirst = oScrl.first;
	
	var iLast = oScrl.last;
  if (oScrl.ref.getAttribute("scrl")!="1") {
    iFirst=0;
    iLast=parseInt(oScrl.ref.getAttribute("ic"))-1;
  }
  
	
	var iSel = parseInt(ur_get(oScrl.ref.id).getAttribute('sidx')); 
	
	for(i=iFirst;i<=iLast;i++) {
		var arrItems = oScrl.items[i];
		var oItemImage = arrItems[0];
		
		if(iFirst == i ) {
			if(iFirst != 0) { 
				if(iSel== i) 
					oItemImage.className = "urTbsFirstAngOnPrevOn";
				else
					oItemImage.className = "urTbsFirstAngOffPrevOn";
			} else {
				if(iSel== i) 
					oItemImage.className = "urTbsFirstAngOnPrevOff";
				else
					oItemImage.className = "urTbsFirstAngOffPrevoff";
			}
		} else { 
			if((i!=0 && iSel== i-1)) 
			  oItemImage.className = "urTbsAngOnOff"; 
			else if(iSel == i) 
				oItemImage.className = "urTbsAngOffOn";
			else 
				oItemImage.className = "urTbsAngOffOff";
		}
		
		if(iLast == i ) {
			var oLastImg=ur_get(oScrl.ref.id+"-n");
			if(iLast != (oScrl.items.length -1)) { 
				if(iSel== i) 
					oLastImg.className = "urTbsLastOnNextOn";
				else 
					oLastImg.className = "urTbsLastOffNextOn";
			} else {
				if(iSel== i)
					oLastImg.className = "urTbsLastOnNextOff";
				else 
					oLastImg.className = "urTbsLastOffNextOff";
			}
		}
	}
	
	if(ur_get(sId).getAttribute("scrl") == "1")
		ur_TS_setPagiButtonState(iFirst,iLast,sId);
	
}
function ur_TS_setPagiButtonState(iFirst,iLast,sId) {
  var oScrl = ur_IScr[sId];
	
	sapUrMapi_Paginator_setStates(sId+'-pg',new Array("","",UR_PAGINATOR_BUTTON.PREVIOUS_ITEM,UR_PAGINATOR_BUTTON.NEXT_ITEM,"",""),new Array("","",true,true,"",""));
	
	
	if(ur_IScr[sId].last == oScrl.items.length -1 || ur_IScr[sId].last == -1)
	{
		
		var arrBtn = new Array();
		arrBtn[3] = UR_PAGINATOR_BUTTON.NEXT_ITEM;
				
		var arrBtnState = new Array();
		arrBtnState[3] = false;
		
		sapUrMapi_Paginator_setStates(sId+'-pg',arrBtn,arrBtnState);
	}
    
	
	if(ur_IScr[sId].first == 0)
	{
		
		sapUrMapi_Paginator_setStates(sId+'-pg', new Array("","",UR_PAGINATOR_BUTTON.PREVIOUS_ITEM), new Array("","",false));
	}
}
function sapUrMapi_TabStripItem_keydown(sId,evt)
{
	if(evt.keyCode== 13)
	{
		var oR = ur_get(sId);
		if(oR.getAttribute("dbid")!=null)
		 {
			 sapUrMapi_triggerDefaultButton(sId,evt);
		 }
	 }	 
}

//** TextEdit.ie5 **

function sapUrMapi_TextEdit_focus(sId,oEvt){
	sapUrMapi_DataTip_show(sId,"focus");
}
function sapUrMapi_TextEdit_blur(sId,oEvt) {
	if(ur_get(sId).getAttribute("chgFire") == "1")
	{
		ur_EVT_fire(ur_get(sId),'notifyChange',oEvt);
		ur_get(sId).setAttribute("chgFire","0");
	}
	sapUrMapi_DataTip_hide(sId);
}
function sapUrMapi_TextEdit_keydown(sId,oEvt) {
	
	if( oEvt.keyCode==73 && oEvt.shiftKey && sapUrMapi_bCtrl(oEvt) && !oEvt.altKey ){
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
		ur_EVT_cancel(oEvt);
	}
	if( (ur_get(sId).getAttribute('rc')) == '1') 
	{
		var iMaxLength = parseInt(ur_get(sId).getAttribute('cc'));
		
		if(ur_TE_getCorrectLength(ur_get(sId).value) == iMaxLength)
		{
			
			if(oEvt.keyCode == 8 
			|| (oEvt.keyCode==86 && sapUrMapi_bCtrl(oEvt)) 
			|| (oEvt.keyCode==88 && sapUrMapi_bCtrl(oEvt)) 
			|| (oEvt.keyCode==89 && sapUrMapi_bCtrl(oEvt)) 
			|| (oEvt.keyCode==90 && sapUrMapi_bCtrl(oEvt))
			|| (oEvt.keyCode==65 && sapUrMapi_bCtrl(oEvt))
			|| (document.selection && document.selection.createRange().text.length>0)
			) {
  		
				if (oEvt.keyCode==90 && sapUrMapi_bCtrl(oEvt)) { 
					ur_callDelayed("ur_TE_restrictChar('"+sId+"')",0);
				}
			return true;
		        }
		}
		
		
		if(oEvt.keyCode==13){
		  iMaxLength = iMaxLength -1;
		}		
		
		if(ur_TE_getCorrectLength(ur_get(sId).value) >= iMaxLength && ur_TE_checkValidKey(oEvt))
		{
				ur_EVT_cancel(oEvt);
		}
		
	}
	if(oEvt.keyCode == "27"){
		sapUrMapi_DataTip_hide(sId);
		ur_EVT_cancel(oEvt);
	}
}
function ur_TE_checkValidKey(oEvt)
{
	switch(oEvt.keyCode)
	{
		case 37: 
		case 39: 
		case 38: 
		case 40: 
		case 46: 
		case 45: 
		case 16: 
		case 17: 
		case 9: 
		case 33:
		case 34:
		case 35:
		case 36:
			return false;
			break;
		default:
			return true;
	}
}
function ur_TE_KeyUp(sId,oEvt)
{
	ur_EVT_fire(ur_get(sId),'notifyKeyUp',oEvt);
}
function ur_TE_Change(sId, oEvt)
{
	ur_EVT_fire(ur_get(sId),'notifyChange',oEvt);
}
function ur_TE_onPaste(sId,oEvt)
{
	
	if( (ur_get(sId).getAttribute('rc')) == '1') 
	{
		ur_callDelayed("ur_TE_restrictChar('"+sId+"')",0);
		ur_get(sId).setAttribute("chgFire","1");
	}
}
function ur_TE_getCorrectLength(txtValue)
{
	  if (txtValue.indexOf('\r\n')!=-1)
	    ; 
	  else if (txtValue.indexOf('\r')!=-1)
	    txtValue=txtValue.replace ( /\r/g, "\r\n" ); 
	  else if (txtValue.indexOf('\n')!=-1)
	     txtValue=txtValue.replace ( /\n/g, "\r\n" ); 
		return txtValue.length;
}
function ur_TE_restrictChar( sId )
{
	var oTextEdt = ur_get(sId), 
		txtValue=oTextEdt.value,
		lineBreakCount = 0,
		charCount = parseInt(oTextEdt.getAttribute('cc'));
	if(txtValue != "" && ur_TE_getCorrectLength(txtValue) >= charCount) {
		txtValue = txtValue.substr(0,charCount);
		
		
		
	  if (txtValue.indexOf('\r\n')!=-1)
	    lineBreakCount = 0; 
	  else if (txtValue.indexOf('\r')!=-1)
	    lineBreakCount = (txtValue.split(/\r/g).length - 1); 
	  else if (txtValue.indexOf('\n')!=-1)
	    lineBreakCount = (txtValue.split(/\n/g).length - 1); 
		if (lineBreakCount > 0 ) txtValue = txtValue.substr(0,charCount-lineBreakCount);
		oTextEdt.value = txtValue;
	}	
}

//** TextView.ie5 **

function sapUrMapi_TextView_menuActivate(sTextViewId,e) {
	var o=ur_get(sTextViewId);
	if (sapUrMapi_checkKey(e,"keydown",new Array("32","40"))) {
		if(o.onclick) {o.onclick();return false;} 
		if(o.oncontextmenu) {o.oncontextmenu();return false;} 
		if(o.onmouseover) {o.onmouseover();return false;} 
	}
  return false;
}
//** Toolbar.nn6 **

function sapUrMapi_Toolbar_toggleItems(sControlId,e) {
  if((e.type == "keydown" && e.keyCode==32) || e.type == "click") {
	  var oToggleButton = ur_get(sControlId+"-tgl");
	  var oToolbar = ur_get(sControlId);
	  var colItems = oToolbar.childNodes;
	  var bShowAllState = oToggleButton.getAttribute("showall")=="true";
	  for (var n=0;n<colItems.length;n++) {
		var oItem=colItems.item(n);
		if (oItem.getAttribute("cancollapse")=="true") {
		  if (bShowAllState) {
			  oItem.style.display="none";
			  oItem.setAttribute("show","false");
	      } else {
		  oItem.style.display="inline";
			  oItem.setAttribute("show","true");
		}
	    }
	    if (oItem==oToggleButton) break;
	  }
	  if (bShowAllState) {
	    oToggleButton.setAttribute("showall","false");
	    oToggleButton.className="urBtnStd urTBtnCol";
	  } else {
	    oToggleButton.setAttribute("showall","true");
	    oToggleButton.className="urBtnStd urTBtnExp";
	  }
  }
  else {
  	return;
  }
}

//** ToolbarButton.nn6 **
var ur_replace_function=false;
var ur_replace_function_button_id="";
function sapUrMapi_ToolbarButton_openMenu( sButtonId, e){
	var sPopupId=ur_get(sButtonId+"-r").getAttribute("popup");
	if (ur_get(sPopupId)==null) return;
	if (ur_get(sButtonId+"-r").getAttribute("replaceable")=="true") {
	  ur_replace_function=true;
	  ur_replace_function_button_id=sButtonId;
	}
	if ((e.type!="click")&&(e.type!="contextmenu")) {
		if (!sapUrMapi_checkKey(e,"keydown",new Array("32","40"))) {
			ur_EVT_cancelBubble(e);
    	e.returnValue=true;
		  return false;
		}
	}
	if (ur_system.direction=="rtl") {
	  sapUrMapi_PopupMenu_showMenu(sButtonId+"-r",sPopupId,sapPopupPositionBehavior.MENURIGHT,e);
	} else {
	  sapUrMapi_PopupMenu_showMenu(sButtonId+"-r",sPopupId,sapPopupPositionBehavior.MENULEFT,e);
	}
  e.cancelBubble=false;
	if ((e.type=="contextmenu")) {
    e.returnValue=false;
  } else {
    e.returnValue=true;
  }
}
function sapUrMapi_ToolbarButton_setFunctionFromMenuItem(sMenuItemId) {
  if (ur_replace_function) {
  	var clickedItem = ur_get(sMenuItemId);
    var sImgSrc=""
    if (clickedItem.getElementsByTagName("img").length>0) {
      sImgSrc=clickedItem.getElementsByTagName("img").item(0).src;
    }
    var sText=clickedItem.getElementsByTagName("nobr").item(0).innerText;
    var effectedButtonId=ur_replace_function_button_id;
    ur_replace_function_button_id="";
    ur_replace_function=false;
    sapUrMapi_ToolbarButton_applyFunction( effectedButtonId, sText, sImgSrc, clickedItem.onclick)
  }
}
function sapUrMapi_ToolbarButton_applyFunction( sButtonId, sNewText, sNewImageSrc, fNewClickHandler){
  var effectedButton=ur_get(sButtonId);
  effectedButton.onclick=fNewClickHandler;
  effectedButton.onkeydown=fNewClickHandler;
  var sButtonContent=effectedButton.getElementsByTagName("nobr").item(0).innerHTML;
  if (effectedButton.getElementsByTagName("nobr").item(0).getElementsByTagName("img").length>0) {
    if (sNewImageSrc=="") {
      effectedButton.getElementsByTagName("nobr").item(0).innerHTML="<img height=\"12\" width=\"1\" border=\"0\" align=\"absmiddle\" src=\""+ur_system.mimepath+"1x1.gif\">"+sNewText
    } else {
      effectedButton.getElementsByTagName("nobr").item(0).innerHTML="<img border=\"0\" align=\"absmiddle\" src=\""+sNewImageSrc+"\">&nbsp;"+sNewText;
  }
  } else {
    effectedButton.getElementsByTagName("nobr").item(0).innerHTML=sNewText;
  }
 }

//** ToolbarInputField.ie5 **

function sapUrMapi_ToolbarInputField_blur(sId,event){
	sapUrMapi_InputField_Blur(sId,event);
}
function sapUrMapi_ToolbarInputField_keydown(sId,oEvt) {
	
	if( oEvt.keyCode==73 && oEvt.shiftKey && sapUrMapi_bCtrl(oEvt) && !oEvt.altKey ){
		ur_EVT_cancel(oEvt);
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
	}
	if(oEvt.keyCode == "27"){
		ur_EVT_cancel(oEvt);
		sapUrMapi_DataTip_hide();
	}
}

//** Tray.nn6 **

function sapUrMapi_Tray_handle(oEvt) {
	var oSrc= ur_EVT_src(oEvt);
	var oTray = sapUrMapi_getRootControl(oSrc);
	var sType = sapUrMapi_getControlTypeFromObject(oTray);
	if (sType != "TY") return; 
	var sId = oTray.id;
	var sCommand = "";
	if (oEvt.type == "focus") {
		var oOptionMenu = ur_get(sId + "-menu");
		oOptionMenu.tabIndex="-1";
		oTray.focus();
	} else if (oEvt.type == "click") {
		
		if (oSrc && oSrc.id && oSrc.id.indexOf("-menu")>0) sCommand = "openMenu";
		else sCommand = "toggle" 
	} else if (oEvt.type == "keydown") {
		var iKey = oEvt.keyCode || oEvt.which;  
		if ((iKey == ur_KY.DOWN && oEvt.altKey) || iKey == 115) {
			var oOptionMenu = ur_get(sId + "-menu");
			if (oOptionMenu) sCommand = "openMenu";
			oOptionMenu.tabIndex="0"; 
		} else if (iKey == 107 && !ur_isSt(oTray,ur_st.DISABLED) && ur_isSt(oTray,ur_st.COLLAPSED)){
			sCommand = "toggle";
		} else if (iKey == 109 && !ur_isSt(oTray,ur_st.DISABLED) && ur_isSt(oTray,ur_st.EXPANDED)) {
			sCommand = "toggle";
		} else if (iKey == 13 && !ur_isSt(oTray,ur_st.COLLAPSED)) {
			sapUrMapi_triggerDefaultButton(sId,oEvt);
			return;
		} else {
			return sapUrMapi_skip(sId,oEvt);
		}
	}
	
	if (sCommand == "openMenu") {
		ur_EVT_fire(oTray,"oopt",oEvt);
			ur_EVT_cancel(oEvt);
	} else if (sCommand == "toggle") {
		ur_EVT_fire(oTray,"oexp",oEvt);
		ur_EVT_cancel(oEvt);
	}
};
function sapUrMapi_Tray_RegisterCreate(sId, bScroll, bCollapsed) {
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_Tray_create('" + sId + "',"+bScroll+","+bCollapsed+")");
}
function sapUrMapi_Tray_create(sId,bScroll,bCollapsed) {
 	var oTray = ur_get(sId);
 
 	if (oTray == null) return;
 
	var sStatus = oTray.getAttribute("st"); 
 	var bCollapsible =  sStatus == "+" || sStatus == "-" || sStatus == "+d" || sStatus == "-d";
 	
  	if (bCollapsible && bCollapsed==true) {
    	sapUrMapi_Tray_toggle(sId);
  	}
  
}
function sapUrMapi_Tray_showOptionMenu2(sTrayId,sMenuContentId,oEvt) {
 	if (ur_system.direction=="rtl")
	  sapUrMapi_Tray_showOptionMenu(sTrayId,sTrayId+"-menu",sMenuContentId,sapPopupPositionBehavior.MENULEFT,oEvt) 
	else
	  sapUrMapi_Tray_showOptionMenu(sTrayId,sTrayId+"-menu",sMenuContentId,sapPopupPositionBehavior.MENURIGHT,oEvt) 
}
function sapUrMapi_Tray_showOptionMenu(idTray,idTrigger,idContent,pos,e) {
	sapUrMapi_PopupMenu_showMenu(idTrigger,idContent,pos,e);
}
ur_trayBody=new Array();
ur_trayValues = new Array();
var tywd = -1;
var tyht = -1;
function sapUrMapi_Tray_toggle( idTray,e)
{
	sCtlType="SAPUR_TRAY";
	if(typeof(e)!="undefined")
	{
		if ((e.type!="click") && (!sapUrMapi_checkKey(e,"keydown",new Array("32","30","107","109")))) return false;
		ur_EVT_cancelBubble(e);
	}
	var elBody = ur_get(idTray+"-tbd");
	var sTitle = ur_get(idTray+"-hd");
	var elExpander = ur_get(idTray+"-exp");
	var elHeader = ur_get(idTray+"-hd");
	var oSkip=ur_get(idTray);
	var elExpandState = ur_get(idTray+"-es");
	if (elBody && elBody.getAttribute("col") == 1)
	{
		elBody.removeAttribute('style');
		elBody.style.visibility="static";
		elBody.style.height=tyht;
		elBody.style.width=tywd;
		elBody.setAttribute("col","0");
		ur_get(idTray+"-bd").style.display ="block"; 
		ur_trayBody[idTray]=null;
		if ( elExpander && elExpander.className.indexOf("Closed") != -1)
		{
			var re = /Closed/gi;
			var clsNm = elExpander.className;
			elExpander.className = clsNm.replace(re, "Open");
			ur_setSt(oSkip,ur_st.COLLAPSED,false);
			ur_setSt(oSkip,ur_st.EXPANDED,true);
		}
		if ( elHeader && elHeader.className == "urTrcHdBgClosedIco" )
			elHeader.className = "urTrcHdBgOpenIco";
		if ( elExpandState )
			elExpandState.value = "1";
		if (ur_system.is508)
		{
			if (elExpander)
				elExpander.title=getLanguageText("SAPUR_TY_BTNE");
		} 
		else
		{
			if (elExpander)
				elExpander.title=getLanguageText("SAPUR_TY_BTNE");		
		}
	}
	else
	{
		ur_trayBody[idTray]=elBody.innerHTML;
		ur_Tray_CollectValues(elBody);
		
		if(tywd == -1)
		tywd =elBody.offsetWidth;
		if(tyht == -1)
		tyht = elBody.offsetHeight;
		elBody.style.position ="absolute";
		elBody.style.overflow="hidden";
		ur_get(idTray+"-bd")
		elBody.style.visibility="hidden";
	
		elBody.style.height= "0px"; 
		elBody.style.width= "0px";
		elBody.style.top= "-9000px";
		elBody.style.left= "-9000px";			
		
		elBody.setAttribute("col","1");
		ur_get(idTray+"-bd").style.display ="none";
		if ( elExpander && elExpander.className.indexOf("Open") != -1)
		{
			var re = /Open/gi;
			var clsNm = elExpander.className;
			elExpander.className = clsNm.replace(re, "Closed");
			ur_setSt(oSkip,ur_st.COLLAPSED,true);
			ur_setSt(oSkip,ur_st.EXPANDED,false);
		}
			if ( elHeader && elHeader.className == "urTrcHdBgOpenIco" )
				elHeader.className = "urTrcHdBgClosedIco";
			if ( elExpandState )
				elExpandState.value = "0";
			if (ur_system.is508)
			{
				if (elExpander)
					elExpander.title=getLanguageText("SAPUR_TY_BTNC");
			}
			else
			{
				if (elExpander)
					elExpander.title=getLanguageText("SAPUR_TY_BTNC");		
			}
	  }
          return true;
}
function ur_Tray_restoreValues(obj)
{
	
	var oInpColl = obj.getElementsByTagName("INPUT");
	var oTaColl = obj.getElementsByTagName("textarea");
	 for(i=0 ; i<oInpColl.length;i++)
    {	
		if(oInpColl[i].getAttribute("id"))
		oInpColl[i].value = ur_trayValues[oInpColl[i].getAttribute("id")] ;
		
    }
    for(i=0 ; i<oTaColl.length;i++)
    {
		if(oTaColl[i].getAttribute("id")){
		var sId = oTaColl[i].getAttribute("id");
		oTaColl[i].value = ur_trayValues[sId]  ;
		}
    }
}
function ur_Tray_CollectValues(obj)
{
	var oInpColl = obj.getElementsByTagName("INPUT");
	var oTaColl = obj.getElementsByTagName("textarea");
	
    for(i=0 ; i<oInpColl.length;i++)
    {	
		if(oInpColl[i].getAttribute("id"))
		ur_trayValues[oInpColl[i].getAttribute("id")] = oInpColl[i].value;
		
    }
    
    for(i=0 ; i<oTaColl.length;i++)
    {
		if(oTaColl[i].getAttribute("id")){
		var sId = oTaColl[i].getAttribute("id");
		ur_trayValues[sId] = oTaColl[i].value;
		}
    }
    
}

//** Tree.ie5 **

function sapUrMapi_Tree_collapseAll(sTreeId) {
    var eRootNode = ur_get(sTreeId + "-r");
    var eNodes = eRootNode.getElementsByTagName("DIV");
    
    for (var i =  eNodes.length-1; i >-1; i--){
      if (ur_getAttD(eNodes[i],"tp","").indexOf("F")>-1) {
        sapUrMapi_Tree_toggle( sTreeId, eNodes[i].id, true, true)
      }
    }
}
function sapUrMapi_Tree_expandAll(sTreeId) {
    var eRootNode = ur_get(sTreeId + "-r");
    var eNodes = eRootNode.getElementsByTagName("DIV");
    
    for (var i =  eNodes.length-1; i >-1; i--){
      if (ur_getAttD(eNodes[i],"tp","").indexOf("F")>-1) {
        sapUrMapi_Tree_toggle( sTreeId, eNodes[i].id, false, true)
      }
    }
}
function sapUrMapi_Tree_toggle( sTreeId, sNodeId, bClose, bKey) {
	var nodeDiv = ur_get(sNodeId);
  var oMainContainerNode = ur_get(sTreeId+"-r");
  var oEvt = window.event;
  if (oEvt) ur_EVT_cancelBubble(oEvt);
  if (ur_isSt(nodeDiv,ur_st.DISABLED)) return;
  if (!bKey) {
    oMainContainerNode.setAttribute("focuced_id",sNodeId);
    try { sapUrMapi_Tree_focusNode(sTreeId,sNodeId); } catch (e) {};
	}
  var childrenDiv = ur_get( nodeDiv.id + "-child" );
  if (!childrenDiv) return;
	var expander = ur_get( nodeDiv.id + "-exp" );
	if ((ur_isSt(nodeDiv,ur_st.COLLAPSED) && !bKey)||(bKey && !bClose && ur_isSt(nodeDiv,ur_st.COLLAPSED)))
	{
	  nodeDiv.className = nodeDiv.className+" urTreNlExp";
		childrenDiv.style.display="block";
		
		
		eLength = expander.className.length;
		expander.className = expander.className.substr(0,eLength-3) + "Op";
    nodeDiv.setAttribute("st",nodeDiv.getAttribute("st").replace("-","+"));
    try { sapUrMapi_Tree_focusNode(sTreeId,sNodeId); } catch (e) {};
    return;
	}
	if ((ur_isSt(nodeDiv,ur_st.EXPANDED)&&!bKey)||(bKey && bClose && ur_isSt(nodeDiv,ur_st.EXPANDED)))
	{
		if (nodeDiv.className.lastIndexOf(" ")>-1) {
		  nodeDiv.className = nodeDiv.className.substring(0,nodeDiv.className.lastIndexOf(" "));
		}
		childrenDiv.style.display="none";
		eLength = expander.className.length;
		expander.className = expander.className.substr(0,eLength-2) + "Clo";
    nodeDiv.setAttribute("st",nodeDiv.getAttribute("st").replace("+","-"));
    try { sapUrMapi_Tree_focusNode(sTreeId,sNodeId); } catch (e) {};
		return;
	}
}
function sapUrMapi_Tree_focusNode(sTreeId,sNodeId,bInit,bNoFocus) {
	var oMainContainerNode = ur_get(sTreeId+"-r");
	var oR=ur_get(sTreeId+"-skipstart");
	if (sNodeId=="") return;
	if (sNodeId.indexOf("-skipstart")>0) return;
	var oNode = ur_get(sNodeId);
	if (bInit) oMainContainerNode.setAttribute("focuced_id",null);
	var sOldNode = oMainContainerNode.getAttribute("focuced_id");
	try {
		if (sOldNode) {
		  sapUrMapi_setTabIndex(ur_get(sOldNode),-1);
		}
  } catch (ex) {
  }
	oMainContainerNode.setAttribute("focuced_id",oNode.id);
	if(ur_system.is508) {
		var sTtTree=oMainContainerNode.getAttribute("tt");
		var sTt=oNode.getAttribute("tt");	
		var sAccTt="";
		}
	sapUrMapi_setTabIndex(oNode,0);
  try {
    if (!bNoFocus) ur_focus(oNode);
  } catch (ex) {}
  sapUrMapi_Focus_showFocusRect();
}
function sapUrMapi_TreeNode_keyDown(sTreeId,sNodeId,e) {
	if (sapUrMapi_checkKey(e,"keydown",new Array("32"))) {
		 
		 if (ur_isSt(ur_get(sNodeId),ur_st.DISABLED)) return;
		 oNodeEvents = ur_get(sNodeId);
		 if (oNodeEvents.onclick) {
		 	  oNodeEvents.onclick(e);
		 	  return true;
		 } else {
		 	
		 	ur_EVT_cancel(e);
		 }
	}
	if (sapUrMapi_checkKey(e,"keydown",new Array("121")) && e.shiftKey) { 
		oNodeEvents = ur_get(sNodeId);
		 if (oNodeEvents.oncontextmenu) {
		 	  oNodeEvents.oncontextmenu(e);
		 	  return true;
		 } else {
		 	
		 	ur_EVT_cancel(e);
		 }
	}
	if (sapUrMapi_checkKey(e,"keydown",new Array("38","39","40","37","9","107","109","106"))) {
		sapUrMapi_Tree_keyDown(sTreeId,e)
  }
}
function sapUrMapi_TreeNode_hover(sTreeId,sNodeId,bIn,e) {
	if ((ur_EVT_src(e).getAttribute("level")) && (!ur_EVT_src(e).getAttribute("container"))) {
	  var sClass="urTreNoEnbl";
	  if (ur_EVT_src(e).getAttribute("clickable")=="true") {
	    sClass+="Clk";
	  }
    if (bIn) ur_EVT_src(e).className=sClass+" urTreNoEnblClkHover"
    else ur_EVT_src(e).className=sClass;
  }
}
function sapUrMapi_TreeNode_mouseover(sTreeId,sNodeId,e) {
	sapUrMapi_TreeNode_hover(sTreeId, sNodeId, true, e);
}
function sapUrMapi_TreeNode_mouseout(sTreeId,sNodeId,e) {
	sapUrMapi_TreeNode_hover(sTreeId, sNodeId, false, e);
}
function sapUrMapi_Tree_enter (sTreeId,e) {
	
	
	var oFocusedNode=null;
	if (ur_EVT_src(e).id==sTreeId+"-skipstart") {
	  var oMainContainerNode = ur_get(sTreeId+"-r");
		
		
		if (ur_get(sTreeId+"-skipstart").getAttribute("exit")=="true") {
			ur_get(sTreeId+"-skipstart").setAttribute("exit","false");
			var sFocusedNode= oMainContainerNode.getAttribute("focuced_id");
		  if (sFocusedNode!="") {
		  	 oFocusedNode=ur_get(sFocusedNode);
			   sapUrMapi_setTabIndex(oFocusedNode.lastChild,-1);
		  }
		} else {
			
		  var sFocusedNode= oMainContainerNode.getAttribute("focuced_id");
		  if (sFocusedNode) {
				 oFocusedNode=ur_get(sFocusedNode);
		  } else {
		  	 var nodelist= oMainContainerNode.getElementsByTagName("DIV");
		  	 for (var nlc=0;nlc<nodelist.length;nlc++) {
		  	   if (nodelist.item(nlc).getAttribute("sellevel")=="1") {
		  	     oFocusedNode=nodelist.item(nlc);
		  	     break;
		  	   }
		  	 }
		     if (oFocusedNode==null) {
		       var nodelist=oMainContainerNode.getElementsByTagName("DIV");
		  	   oFocusedNode=nodelist.item(0);
		  	   if (oFocusedNode.id.indexOf("-")>0) {
		  	     oFocusedNode=oFocusedNode.childNodes.item(0);
		  	   }
			}
			}
			sapUrMapi_Tree_focusNode(sTreeId,oFocusedNode.id,true);
	  }
	} else {
		
		var oLastElement=ur_get(sTreeId+"-skipend")
		if (oLastElement.getAttribute("exit")=="true") {
			
			
			oLastElement.setAttribute("exit","false");
		} else {
			ur_focus(ur_get(sTreeId+"-skipstart"));
	  }
	}
}
function sapUrMapi_Tree_expandNode(sTreeId,o,sMainContainerNode) {
	if (o && ur_getAttD(o,"tp","").indexOf("F")>-1 && ur_isSt(o,ur_st.COLLAPSED) && !ur_isSt(o,ur_st.DISABLED)) {
		sapUrMapi_Tree_toggle(sTreeId,o.id,false,true);
  }
}
function sapUrMapi_Tree_collapseNode(sTreeId,o, sMainContainerNode) {
	if (o && ur_getAttD(o,"tp","").indexOf("F")>-1 && !ur_isSt(o,ur_st.COLLAPSED) && !ur_isSt(o,ur_st.DISABLED)) {
		sapUrMapi_Tree_toggle(sTreeId,o.id,true,true);
  }
}
function sapUrMapi_Tree_keyDown(sTreeId,e) {
  var oFocusedNode=null;
  var oMainContainerNode = ur_get(sTreeId+"-r");
  var sFocusedNode= oMainContainerNode.getAttribute("focuced_id");
  if (sFocusedNode!="") {
  	 oFocusedNode=ur_get(sFocusedNode);
  }
  if (sapUrMapi_checkKey(e,"keydown",new Array("38","39","40","37","9","32","107","109","106"))) {
  	if (e.keyCode==9) { 
  		if (!e.shiftKey) {
  			oLastElement = ur_get(sTreeId+"-skipend");
  			oLastElement.setAttribute("exit","true");
  			ur_focus(oLastElement);
	  		ur_EVT_cancel(e);
	  		return;
  		} else {
  			oFirstElement = ur_get(sTreeId+"-skipstart");
  			oFirstElement.setAttribute("exit","true");
  			ur_focus(oFirstElement);
	  		ur_EVT_cancel(e);
	  		return;
  		}
  	}
  	if (e.keyCode==40) { 
		  if (!oFocusedNode) {
	  	  oFocusedNode=oMainContainerNode.childNodes.item(0);
		  } else {
		  	if (ur_isSt(oFocusedNode,ur_st.EXPANDED) || ur_getAttD(oFocusedNode,"tp","").indexOf("L")>-1) { 
		  	  oNextContainer = ur_get(oFocusedNode.id+"-child");
		  	  if (oNextContainer && oFocusedNode.nextSibling.firstChild) oFocusedNode=oFocusedNode.nextSibling.childNodes.item(0);
          else if (oNextContainer && oFocusedNode.nextSibling.nextSibling) oFocusedNode=oFocusedNode.nextSibling.nextSibling; 
          else if (!oNextContainer && oFocusedNode.nextSibling) oFocusedNode=oFocusedNode.nextSibling; 
          else if (oFocusedNode.parentNode !=oMainContainerNode)
			  	     { 
				  	     	oParent = oFocusedNode.parentNode.previousSibling;
				  	     	while ((!oParent.nextSibling.nextSibling) && (oParent.parentNode!=oMainContainerNode)) {
				  	     		 oParent=oParent.parentNode.previousSibling;
				  	     	}
				  	     	if (oParent.nextSibling.nextSibling) {
				  	     		oFocusedNode=oParent.nextSibling.nextSibling;
				  	     	}
			  	     }
			  } else {
		  		if (ur_isSt(oFocusedNode,ur_st.COLLAPSED) || ur_getAttD(oFocusedNode,"tp","").indexOf("L")) {
			  		if (oFocusedNode.nextSibling.nextSibling) {
				  	  oFocusedNode=oFocusedNode.nextSibling.nextSibling;
			  		} else { 
		  	     	oParent = oFocusedNode;
		  	     	while ((!oParent.nextSibling.nextSibling) && (oParent.parentNode!=oMainContainerNode)) {
		  	     		 oParent=oParent.parentNode.previousSibling;
		  	     	}
		  	     	if (oParent.nextSibling.nextSibling) {
		  	     		oFocusedNode=oParent.nextSibling.nextSibling;
		  	     	}
			  		}
		  		}
		  	}
		  }
		}
		if (e.keyCode==39) { 
		  if (ur_system.direction=="rtl") {
		    sapUrMapi_Tree_collapseNode(sTreeId,oFocusedNode,oMainContainerNode);
		  } else {
		    sapUrMapi_Tree_expandNode(sTreeId,oFocusedNode,oMainContainerNode)
		  }
		}
		if (e.keyCode==37) { 
		  if (ur_system.direction=="rtl") {
		    sapUrMapi_Tree_expandNode(sTreeId,oFocusedNode,oMainContainerNode)
		  } else {
		    sapUrMapi_Tree_collapseNode(sTreeId,oFocusedNode,oMainContainerNode);
		  }
		}
		if (e.keyCode==109) { 
		  sapUrMapi_Tree_collapseNode(sTreeId,oFocusedNode,oMainContainerNode);
		}
		if (e.keyCode==107) { 
		  sapUrMapi_Tree_expandNode(sTreeId,oFocusedNode,oMainContainerNode);
		}
		if (e.keyCode==106) { 
			sapUrMapi_Tree_collapseAll(sTreeId);
			return;
		}
		if (e.keyCode==38) { 
		  if (!oFocusedNode) {
			  oFocusedNode=oMainContainerNode.childNodes.item(0);
		  } else {
			  oParent = oFocusedNode.parentNode;
	    	if (oFocusedNode != oMainContainerNode.childNodes.item(0)) {
		    	if (oFocusedNode==oParent.childNodes[0]) {
		    		if (oParent==oMainContainerNode) {
		    			oFocusedNode=oParent.lastChild;
				  		while ((oFocusedNode.id.indexOf("-child")>-1)&&(ur_isSt(oFocusedNode.previousSibling,ur_st.COLLAPSED)||ur_getAttD(oFocusedNode.previousSibling,"tp","").indexOf("L")>-1)) {
				  		  oFocusedNode=oFocusedNode.previousSibling;
				  		}
				  		while ((oFocusedNode.id.indexOf("-child")>-1)&&(ur_isSt(oFocusedNode.previousSibling,ur_st.EXPANDED)||ur_getAttD(oFocusedNode.previousSibling,"tp","").indexOf("L")>-1)) {
				  		  oFocusedNode=oFocusedNode.lastChild;
				  		}
		    		} else {
			  		  oFocusedNode=oParent.previousSibling;
						}
					} else {
							oFocusedNode=oFocusedNode.previousSibling;
							while ((oFocusedNode.id.indexOf("-child")>-1)&&(ur_isSt(oFocusedNode.previousSibling,ur_st.COLLAPSED) || !oFocusedNode.lastChild)) {
								oFocusedNode=oFocusedNode.previousSibling;
							}
							while ((oFocusedNode.id.indexOf("-child")>-1)&&(ur_isSt(oFocusedNode.previousSibling,ur_st.EXPANDED)) && oFocusedNode.lastChild) {
								oFocusedNode=oFocusedNode.lastChild;
							}
					}
				}
			}
	  }
		ur_EVT_cancel(e);
  		
	  	if (sTreeId && oFocusedNode) {
			sapUrMapi_Tree_focusNode(sTreeId,oFocusedNode.id);
		}
		
		if (ur_system.is508 && oFocusedNode) {
			  sapUrMapi_refocusElement(oFocusedNode.id);
		}
  }
}
function sapUrMapi_Tree_controlExit(sTreeId, sNodeId,e) {
	var oContainer = ur_get(sNodeId+"-cnt-start");
  sapUrMapi_setTabIndex(oContainer,-1); 
  oContainer.onkeydown=null;  
  														
  oContainer.title = ""
  var oNode=ur_get(sNodeId);  														
	sapUrMapi_setTabIndex(oNode.lastChild,0);
	sapUrMapi_setTabIndex(ur_get(sNodeId+"-cnt-end"),-1);
	ur_get(sNodeId+"-cnt-end").title="";
	sapUrMapi_Tree_focusNode(sTreeId,sNodeId)
	ur_EVT_cancel(e);
}
function sapUrMapi_Tree_ignoreControlEvents() {
	ur_EVT_cancel(event);
}
function sapUrMapi_Tree_controlEnter(sTreeId, sNodeId,e) {
	var oControlExitPoint = ur_get(sNodeId+"-cnt-end");
	var oControlEventer   = ur_get(sNodeId+"-cnt-start");
	var sAllowTag=",INPUT,SELECT,TEXTAREA,";
	var sEvType = ur_EVT_src(e).type;
	if (sAllowTag.indexOf(","+ur_EVT_src(e).tagName+",")>-1) {
	  
		sapUrMapi_Tree_focusNode(sTreeId,sNodeId,true,true);
		sapUrMapi_setTabIndex(oControlExitPoint,0);
		sapUrMapi_setTabIndex(oControlEventer,0);
		if(sEvType.indexOf("select")>-1){
			ur_focus(ur_EVT_src(e).options[0]);
		}else{
			ur_focus(ur_EVT_src(e));
		}
		oControlEventer.onkeydown=sapUrMapi_Tree_ignoreControlEvents; 
		return true;
	}
	if (oControlExitPoint) {
		sapUrMapi_setTabIndex(oControlExitPoint,0);
		sapUrMapi_setTabIndex(oControlEventer,0);
		oControlExitPoint.title = getLanguageText("SAPUR_TREE_ITEM_CONTAINER_END");
		oControlEventer.title   = getLanguageText("SAPUR_TREE_ITEM_CONT_SELECTED");
		ur_focus(oControlEventer);
		oControlEventer.onkeydown=sapUrMapi_Tree_ignoreControlEvents; 
		ur_EVT_cancelBubble(e);
		
		return true;
	}
	return false;
}
function sapUrMapi_Tree_getNodeId(sId) {
	var o=ur_get(sId);
	while (o.tagName!="BODY") {
		if (o.tagName=="DIV" && ((String(o.getAttribute("tp")).indexOf("F")>-1) || (String(o.getAttribute("tp")).indexOf("L")>-1))) return o.id;
		o=o.parentNode;
	}
	return "";
}
function sapUrMapi_Tree_selectNode(sTreeId, sNodeId, iSelLevel) {
	var oNode   = ur_get(sNodeId);
	var bExp    = oNode.className.indexOf("urTreNlExp")>0;
	var sClass = oNode.className.substring(0,oNode.className.indexOf(" "));
	if (sClass=="") var sClass = oNode.className;
	oNode.setAttribute("sellevel",""+iSelLevel);
	ur_get(sNodeId+"-cnt-start").setAttribute("sellevel",""+iSelLevel);
	if (iSelLevel==1) sClass+=" urTreNSel";
	if (iSelLevel==2) sClass+=" urTreNSel2";
	if (bExp) sClass+=" urTreNlExp";
	oNode.className=sClass;
}
function sapUrMapi_Tree_deselectAll(sTreeId) {
	var colNodes   = document.getElementsByTagName("DIV");
	for (var n=0;n<colNodes.length;n++) {
		if (colNodes.item(n).sellevel) sapUrMapi_Tree_selectNode(sTreeId,colNodes.item(n).id,0);
	}
}
function sapUrMapi_Tree_showMenu(sTreeId,sNodeId,sPopupMenuId,oEvt) {
	sapUrMapi_Tree_focusNode(sTreeId,sNodeId);
	o=ur_get(sNodeId);
   
  if (oEvt.type=="keydown") {
	  sapUrMapi_PopupMenu_showMenu(sNodeId,sPopupMenuId,sapPopupPositionBehavior.MENULEFT,oEvt);
	  if (oPopup) {
	    oPopup.frame.object.style.top=parseInt(oPopup.frame.object.style.top)-7+"px";
	    oPopup.frame.object.style.left=parseInt(oPopup.frame.object.style.left)+o.firstChild.offsetLeft+14+"px";
	    
	  }
  } else { 
	sapUrMapi_PopupMenu_showMenu(sNodeId,sPopupMenuId,sapPopupPositionBehavior.EVENT,oEvt);
	}
	ur_EVT_cancel(oEvt);
}

//** TriStateCheckBox.ie5 **

function sapUrMapi_TriStateCheckBox_toggle(sId,e) {
  var o=ur_get(sId),
  	  oRoot = ur_get(sId + "-r");
  var oImg=ur_get(sId+"-img");
  if (ur_isSt(oRoot,ur_st.DISABLED) || ur_isSt(oRoot,ur_st.READONLY) || (e.type=="keydown" && e.keyCode!=32)) 
		return false;
	if (ur_isSt(oRoot,ur_st.SELECTED)){
		ur_setSt(oRoot,ur_st.SELECTED,false);
		ur_setSt(oRoot,ur_st.UNDEFINED,true);
		oImg.className=oImg.className.replace("On","Ind");
	}
	else if (ur_isSt(oRoot,ur_st.NOTSELECTED)){
		ur_setSt(oRoot,ur_st.NOTSELECTED,false);
		ur_setSt(oRoot,ur_st.SELECTED,true);
		oImg.className=oImg.className.replace("Off","On");	
	}
	else{
		ur_setSt(oRoot,ur_st.UNDEFINED,false);
		ur_setSt(oRoot,ur_st.NOTSELECTED,true);
		oImg.className=oImg.className.replace("Ind","Off");	
	}
	ur_focus(oRoot);
	if (ur_system.is508) oRoot.fireEvent("onactivate");
	return ur_EVT_cancel(e);
}
function sapUrMapi_TriStateCheckBox_setDisabled(sId) {
	sapUrMapi_CheckBox_setDisabled(sId);
}
function sapUrMapi_TriStateCheckBox_setEnabled(sId) {
	sapUrMapi_CheckBox_setEnabled(sId);
}
function sapUrMapi_TriStateCheckBox_setReadonly(sId,bSet){
	sapUrMapi_CheckBox_setReadonly(sId,bSet);
}
function sapUrMapi_TriStateCheckBox_setInvalid(sId){
	sapUrMapi_CheckBox_setInvalid(sId);
}

//** ViewSwitch.ie5 **

function ur_VS_sel(oEvt) {
  var o=ur_VS_getObj(oEvt).ref;
  oItm=ur_EVT_src(oEvt);
  while (oItm.getAttribute && (oItm.getAttribute("idx")==null || oItm.getAttribute("idx")=="")) {
    oItm=oItm.parentNode;
    if (oItm.tagName=="TR") return;
  }
  var iIdx=parseInt(oItm.getAttribute("idx"));
  var sSt=oItm.getAttribute("st");
  if (sSt.indexOf("d")==-1) { 
	  	ur_EVT_fire(oItm,"osel",oEvt);
	}
}
function ur_VS_getObj(oEvt) {
  var o={ref:ur_getRootObj(ur_EVT_src(oEvt))};
  var items=new Array();
  for (var i=0;i<o.ref.firstChild.childNodes.length;i++)
    items.push(o.ref.firstChild.childNodes[i].firstChild);
  o["items"]=items;
  o["selected"]=o.ref.getAttribute("sidx");
  return o;
}
function ur_VS_cl(oEvt)
{
    if (!oEvt) oEvt=event; 
    ur_VS_sel(oEvt); 
}
function ur_VS_kd(oEvt) {
  if (!oEvt) oEvt=event;
  if (oEvt.keyCode==32 || oEvt.keyCode==13) {
    ur_VS_sel(oEvt);
    ur_EVT_cancel(oEvt);
  }
  else if(oEvt.keyCode==38 || oEvt.keyCode==40){
  	ur_VS_ac(oEvt);
  }
 var o=ur_VS_getObj(oEvt);
   ur_KY_nav(oEvt,o);
}
function ur_VS_ac(oEvt) 
{
   var o=ur_VS_getObj(oEvt);
   var aItms=o.ref.getElementsByTagName("TR");
   
   var oCur=ur_EVT_src(oEvt);
   var iIdx= parseInt(oCur.getAttribute("idx"));
   if(oEvt.keyCode==38) 
   	  iIdx=iIdx-1;
   	else if(oEvt.keyCode==40) 
   	  iIdx=iIdx+1;
   if(iIdx<0 || iIdx>aItms.length)return;
   if(aItms[iIdx]==null)return;
   
   ur_focus_Itm(aItms[iIdx].firstChild,oCur);
}
function ur_VS_mm(oEvt) {
  
}
