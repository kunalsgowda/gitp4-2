
SAP Java Resource Adapter
_________________________


General
-------

This archive contains the SAP Java Resource Adapter add-on package
for SAP Java Connector


Installation
------------

Uncompress the archive into an arbitrary directory <sapjra-install-path>.
Load <sapjra-install-path>/docs/jra/intro.html into your browser and follow
the description under the link Installation.


Notes for SAPJRA
----------------

For details to implementation please see <sapjra-install-path>/docs/jra/FAQ.pdf
and <sapjra-install-path>/docs/index.html

To run examples please read <sapjra-install-path>/examples/Readme.txt

To run tests please read <sapjra-install-path>/tests/Readme.txt


Thanks for using the SAP Java Connector and the SAP Java Resource Adapter (SAPJRA)


