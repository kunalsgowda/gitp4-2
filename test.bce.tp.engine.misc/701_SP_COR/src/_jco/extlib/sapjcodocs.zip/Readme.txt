
SAP Java Connector 2.1.10
_________________________


General
-------

This archive contains JCo 2.1.10.


Installation
------------

Uncompress the archive into an arbitrary directory <sapjco-install-path>.

Load <sapjco-install-path>/docs/jco/intro.html into your browser and follow
the description under the link Installation.


Thanks for using JCo.


