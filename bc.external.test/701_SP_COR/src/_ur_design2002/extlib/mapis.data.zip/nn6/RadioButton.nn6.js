//* ************************************************************************
//* RadioButton
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_registerCreate
//* parameter   : sId - Id of the radiobutton 
//* return      : 
//*	description	: register the radiobutton cretae function
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_registerCreate(sId) {
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_create
//* parameter   : sId - Id of the radiobutton 
//* return      : 
//*	description	: Special handling for inerHtml exchange to enable
//*								correct keyboard navigation with arrow keys for
//*								the radiobuttons.
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_create(sId) {
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_toggle
//* parameter   : sId - string Id of the radiobuttom to toggle
//* return      : true if the radiobutton was toggeled
//*	description	: checks the radiobutton specified by sId (and unchecks all others)
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_toggle(sId,e) {
	if(e.type=="keydown" && (e.ctrlLeft || e.ctrlRight)) return;
  var oIn=ur_get(sId);
  var oImg=ur_get(sId+"-img");
  if (ur_isSt(oIn,new Array(ur_st.DISABLED)) || ur_isSt(oIn,new Array(ur_st.READONLY))) return false;
  var oInGrp=new Array();
  if(oIn.name!="") 
		oInGrp=document.getElementsByName(oIn.name);
	else
		oInGrp[0]=oIn;
  oIn.checked=true;
  ur_setSt(oIn,ur_st.SELECTED,true);
  ur_setSt(oIn,ur_st.NOTSELECTED,false);
  oImg.className=oImg.className.replace("Off","On");
  ur_focus(oIn);
  for(var i=0;i<oInGrp.length;i++){
	  oImg=ur_get(oInGrp[i].id+"-img");
	  if (oImg==null || oIn==oInGrp[i]) continue; 
	  if(ur_isSt(oInGrp[i],ur_st.SELECTED)){ 
			oImg.className=oImg.className.replace("On","Off");
			ur_setSt(oInGrp[i],ur_st.SELECTED,false);
			ur_setSt(oInGrp[i],ur_st.NOTSELECTED,true);			
		}
  }
  return true;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_setDisabled
//* parameter   : sId - string Id of the radiobutton
//* description	: sets an enabled radiobutton to disabled and also the connected
//								label
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_setDisabled(sId) {
	sapUrMapi_CheckBox_setDisabled(sId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_setEnabled
//* parameter   : sId - string Id of the radiobutton
//* description	: sets an disabled radiobutton to enabled and also the connected
//								label
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_setEnabled(sId) {
	sapUrMapi_CheckBox_setEnabled(sId); 	
		}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_setReadonly
//* parameter   : sId - Id of the checkbox
//*								bSet - set/unset the checkbox readonly
//*	description	: sets/unsets a radiobutton readonly and the connected
//								label enabled
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_setReadonly(sId,bSet){
	sapUrMapi_CheckBox_setReadonly(sId,bSet);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_setInvalid
//* parameter   : sId - Id of the radio button
//*	description	: sets the invalid state
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_setInvalid(sId){
	sapUrMapi_CheckBox_setInvalid(sId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_focus
//* parameter   : sId - string Id of the checkbox
//*								oEvt - event object
//*	description	: show data tip
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_focus(sId,oEvt) {
	sapUrMapi_DataTip_show(sId,"focus");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_blur
//* parameter   : sId - string Id of the checkbox
//*								oEvt - event object
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_blur(sId,oEvt) {
	sapUrMapi_DataTip_hide();
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_keydown
//* parameter   : sId - string Id of the checkbox
//*								oEvt - event object
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_keydown(sId,oEvt) {
}

