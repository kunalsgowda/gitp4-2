//* ************************************************************************
//* TabStrip
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_RegisterCreate
//* parameter   : sId - string - Id of the TabStrip
//* description : Registers the tabstrip with the create item registry to be
//*				  initialized when the page loads
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_TabStrip_RegisterCreate(sId,iCount,iActive) {
	  if(!sId || iCount==0 || iActive<0) return;
	  sapUrMapi_Create_AddItem(sId, "sapUrMapi_TabStrip_create('" + sId + "','" + iCount + "','" + iActive + "')");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_create
//* parameter   : none
//* return      : none
//*	description	: initally the tabstrip height was not set, therefore
//								the height of the tabstrip is set maximum height of its items
//								content. this can only be done after the elements where parsed and calculated
//								this function is set to the onreadystatechange event of the document
//								if the readystate is complete(right before the display of the page)
//                the height of all tabstrips that have no height applied will be recalculated
//								This is an internal function and not to be called from outside
//* ------------------------------------------------------------------------
var aTabValues=new Array();

function sapUrMapi_TabStrip_create(sId,iCount,iActive) {

	var oTabTable = ur_get(sId);
	var bExact = (oTabTable.getAttribute("exact") == "1") ? true : false;
	var bScroll = (oTabTable.getAttribute("scrl")=="1") ? true : false;
	var activeTab = ur_get(sId + "-cnt-" + iActive);
	
	if (activeTab == null) return;
	
	var iHeight_atr = parseInt(activeTab.style.height);
	var iWidth_atr = parseInt(oTabTable.style.width);
	var iWidth = 0;
	var iHeight = 0;
	aTabValues[sId] = new Array();
		
   if (!bExact && iHeight_atr != "" && iHeight_atr < activeTab.childNodes[0].scrollHeight) {
		activeTab.removeAttribute("style");
		activeTab.style.height="auto";
		activeTab.style.width="auto";
	}

	/*if (bExact) {
		var arrTabs = new Array();
			
		for (i = 0;i < iCount;i++){
			var curTab = ur_get(sId + "-cnt-" + i);
			
			if( curTab.scrollHeight > iHeight) {
				iHeight = curTab.scrollHeight;
				aTabValues[sId]["highest"] = iHeight;
			}
			if (curTab.scrollWidth > iWidth){
				iWidth=curTab.scrollWidth;
				aTabValues[sId]["widest"]=iWidth;
			}
		}
		
		if (iHeight_atr > aTabValues[sId]["highest"]){
			activeTab.style.height = iHeight_atr;
		} else {
			activeTab.style.height = aTabValues[sId]["highest"];
		}
  		activeTab.style.width=aTabValues[sId]["widest"];
	}*/
		
	if(bScroll) {
		ur_IScr_getObj(sId);
		//scrolling broke in FF3 ur_IScr[sId].scrl.style.width = "auto";
			
		if ( oTabTable.style.width == "" && iWidth != 0 ) {
			oTabTable.style.width = aTabValues[sId]["widest"];
		}
			
		ur_IScr_create(sId);
			
		var oPag = ur_get(sId+"-pg");
        var oScr = ur_IScr[sId];
		var iSelIdx = parseInt(oTabTable.getAttribute("sidx"));
		var iTabWidth=0
		var iPagWidth=oPag.parentNode.offsetWidth;
			
		for (var n = 0; n < oScr.items.length; n++) {
		  if (oScr.items[n].width > iTabWidth) 
		  	iTabWidth = oScr.items[n].width;
		}
			
		if (iWidth == 0)
			iWidth=oTabTable.offsetWidth;
			
		if (iPagWidth+iTabWidth > iWidth) {
			oTabTable.style.width = iPagWidth + iTabWidth + 25;
		}
		ur_IScr_draw(sId);
		// Re-create the Scroll part if the Selected Tab is not visible.
		// An issue from WDP end, as they are not setting the VisibleIndex.
		// This is just an exception handling from our end. Can later be removed
		// once the WDP starts setting the VisibleIndex properly. @Sri
		
		if (!oScr.items[iSelIdx].visible) {
			ur_get(sId+"-scrl").setAttribute("fsrl",iSelIdx);
			oScr.first = iSelIdx;
			ur_IScr_create(sId);
		}
		oTabTable.setAttribute("fidx",iSelIdx);
	}
	sapUrMapi_Resize_AddItem(sId, "sapUrMapi_TabStrip_resize('"+sId+"')");
}

function sapUrMapi_TabStrip_resize(sId) {
	var o = ur_get(sId);
	if(!o) return;
	
	if(o.getAttribute("scrl") == 1) {
		var iWidth = o.offsetWidth;
		if (ur_IScr[sId].iWidth && ur_IScr[sId].iWidth == iWidth ) return;
		ur_IScr_resize(sId);
		ur_IScr[sId].iWidth = iWidth;
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_getSelectedItemId
//* parameter   : sTabStripId
//* return      : the item id of the selected tabstrip. this is the id of
//                the td (cell).
//                the id is a concatination of sTabStripId the index of the
//                selected item and a string -itm-.
//*	sample			: ur_get(sapUrMapi_TabStrip_getSelectedItemId("yourid")
//* ------------------------------------------------------------------------
function sapUrMapi_TabStrip_getSelectedItemId(sTabStripId) {
  var oTabTable = ur_get(sTabStripId);
	var iSelTab	= parseInt(oTabTable.getAttribute("sidx"));
	return sTabStripId+"-itm-"+iSelTab;
}
//* ------------------------------------------------------------------------

function sapUrMapi_TabStrip_keySelect(strId, intSelectedIdx, intTabCount,e) {}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_focusItem
//* parameter   : sTabStripId - Id of the TabStrip (required)
//							: iFocusIdx   - Index of the Item to focus (optional),
//														  if not set the selectedItem will be focused
//							: iTabCount - set if you bNext and bPrev use Count of all TabStrips - optional
//							: bNext - if set the next Item gets the focus - optional
//							: bPrev - if set the previous Item gets the focus - optional
//* return      : false
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_TabStrip_focusItem(sTabStripId,iFocusIdx,iTabCount,bNext,bPrev) {}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_triggerScroll
//* parameter   : sTabStripId - Id of the TabStrip (required)
//							: iFocusIdx   - Index of the Item to focus (optional),
//														  if not set the selectedItem will be focused
//							: iTabCount - set if you bNext and bPrev use Count of all TabStrips - optional
//							: bNext - if set the next Item gets the focus - optional
//							: bPrev - if set the previous Item gets the focus - optional
//* return      : false
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_TabStrip_triggerScroll(sTabStripId,iFocusIdx,iTabCount,bNext,bPrev,oFrom,evt) {
  	var oTabTable 	= ur_get(sTabStripId);
  	var objTab = ur_IScr[sTabStripId];
	if (isNaN(iFocusIdx)) iFocusIdx = parseInt(ur_get(sTabStripId).getAttribute("fidx"));
	if (bNext) {
		if(evt.keyCode == 33 || evt.keyCode == 34) 
		{
			if(iFocusIdx < objTab.items.length - 1)
				ur_IScr_toNextPage(sTabStripId);
		}
		else if(evt.keyCode == 36 || evt.keyCode == 35)
		{
			if(iFocusIdx < objTab.items.length - 1)
				ur_IScr_toEnd(sTabStripId);
		}
		else if(evt.keyCode==39 || evt.keyCode==37) {
			if(iFocusIdx > objTab.last || oFrom=="last"){
				if(iFocusIdx >= objTab.items.length || oFrom == "last")
					ur_IScr_toBegin(sTabStripId);
				else
					ur_IScr_toNextItem(sTabStripId);
			}
		}
	}
	if (bPrev) {
		if(evt.keyCode == 33 || evt.keyCode == 34)
		{
			if(iFocusIdx > 0)
				ur_IScr_toPrevPage(sTabStripId);
		}
		else if(evt.keyCode == 36 || evt.keyCode == 35)
		{
			if(iFocusIdx > 0)
				ur_IScr_toBegin(sTabStripId);
		}
		else if(evt.keyCode==39 || evt.keyCode==37){
			if(iFocusIdx < objTab.first || oFrom=="first"){
			   if(oFrom=="first" || iFocusIdx<0)
			      ur_IScr_toEnd(sTabStripId);
			   else
			   	ur_IScr_toPrevItem(sTabStripId);
			}
		}
	}
	try{
		ur_EVT_addParam(evt,"FirstVisibleItemIdx",objTab.first);
	}catch(ex){};
}

function ur_TS_setTabIdx(sId,iOldFocIdx,iNewIndex)
{}
//* ------------------------------------------------------------------------
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_enter
//* parameter   : sId - Id of the TabStrip
//* description : with the 508 flag turned on this function will check for
//*               keydowns and skip the tabstrip or lead the user to
//								the selected tab item in case of tab, left or right arrow is pressed
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_TabStrip_enter (sId,e) {}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TabStrip_setActiveItem
//* parameter   : sId  - Id of the TabStrip
//  							iIdx - Index of the Item to activate (select)
//* description : selects an item of the tabstrip with the id sId
//* return      : true if the item was selected, else false
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_TabStrip_setActiveItem(sId,iIdx) {
	with (document) {
      		if(ur_IScr[sId] == null)
		        ur_IScr_getObj(sId);
		var oTabScrl 	= getElementById(sId+"-scrl");
		var obj			= ur_get(sId);
		var oScrl = ur_IScr[sId];

		if (obj != oScrl.Ref) {
			ur_IScr_getObj(sId);
			oScrl = ur_IScr[sId]
		}

		var iSelTab			=	parseInt(obj.getAttribute("sidx"));
		var iTabLength	=	parseInt(obj.getAttribute("ic"));
		if (isNaN(iIdx)) return;
		if (oScrl.items[iIdx][1].getAttribute("st")!=null && oScrl.items[iIdx][1].getAttribute("st").indexOf("d")>-1) return false; 

		
		if ((iTabLength==1) || (iSelTab==iIdx)) return true; 
		var oCurrentTxt  = oScrl.items[iSelTab][1].firstChild;
		var oCurrentCell = oScrl.items[iSelTab][1];
		var oClickedTxt  = oScrl.items[iIdx][1].firstChild;
		var oClickedCell = oScrl.items[iIdx][1];
		var oCurrentContent  = getElementById(sId+"-cnt-"+iSelTab);
	  	var oClickedContent  = getElementById(sId+"-cnt-"+iIdx);
		var oCloseCurrent = ur_get(sId + "-itm-cl-" + iSelTab);
		var oCloseClicked = ur_get(sId + "-itm-cl-" + iIdx);
		
		oCurrentCell.className="urTbsLabelOff"; 
		oCurrentTxt.className = "urTbsTxtOff";  
		oClickedTxt.className = "urTbsTxtOn";   
	    oClickedCell.className="urTbsLabelOn";  
		
		if (oCloseCurrent != null) oCloseCurrent.className = "urTbsCloseUnSel";
		if (oCloseClicked != null) oCloseClicked.className = "urTbsCloseSel";
		
		obj.setAttribute("sidx",iIdx); 
		
	  //switch the content of the tabs
	  if (obj.getAttribute("exact")!="1") {
		if(oClickedContent.style.height!="" && parseInt(oClickedContent.style.height)<parseInt(oClickedContent.childNodes[0].scrollHeight)){
				oClickedContent.removeAttribute("style");
				oClickedContent.style.height="auto";
				oClickedContent.style.width="auto";
			}
		}else{
			if(parseInt(oClickedContent.style.height) > aTabValues[sId]["highest"]){
			}else{
  			oClickedContent.style.height=aTabValues[sId]["highest"];
			}
			oClickedContent.style.width=aTabValues[sId]["widest"];
		}
		oCurrentContent.style.overflow="hidden";
		oCurrentContent.style.position="absolute";
		oCurrentContent.style.visibility="hidden";
		oClickedContent.style.overflow="visible";
		oClickedContent.style.position="static";
		oClickedContent.style.visibility="inherit";
	}
	
	/* set status for the current cell and the clicked cell */
	ur_setSt(oCurrentCell,ur_st.NOTSELECTED,true);
	ur_setSt(oCurrentCell,ur_st.SELECTED,false);
	ur_setSt(oClickedCell,ur_st.NOTSELECTED,false);
	ur_setSt(oClickedCell,ur_st.SELECTED,true);
	
	if (ur_get(sId).getAttribute("exact")=="1")
	  ur_TS_oadi(sId);
  	else {
    	var bVisible=oScrl.items[iIdx].visible;
   		 if (bVisible) ur_IScr_draw(sId);
    if (!oScrl.items[iIdx].visible || !bVisible) {
      oScrl.first=iIdx;
      oScrl.last=-1;
      ur_IScr_draw(sId);
    }
  }
}
/**************************************************/
//  Generic handler of OnClick and delegates it for specific handling
//
/*************************************************/
function ur_TS_cl(sId,evt)
  {
	var sElm = evt.target;
	var bIdPresent = false;
	while(!bIdPresent)
	{	
		
		if(sElm.getAttribute('idx') !=null)
		{
			
			if (oScrl.items[param[1]][1].getAttribute("st")!=null && oScrl.items[param[1]][1].getAttribute("st").indexOf("d")>-1) return false; 
			ur_EVT_fire(ur_get(sId+'-scrl'),"otc");
			bIdPresent = true;
		}
		else{
			sElm = sElm.parentNode;
			}
		
	} 
	   
	
  }
	
/************************************************/
//   Item Display
//
/************************************************/

function ur_TS_oadi(sId) {
  var oScrl = ur_IScr[sId];
	// Currently displayed first Scroll Index
	var iFirst = oScrl.first;
	// Currently displayed last Scroll Index
	var iLast = oScrl.last;
  if (oScrl.ref.getAttribute("scrl")!="1") {
    iFirst=0;
    iLast=parseInt(oScrl.ref.getAttribute("ic"))-1;
  }
  
	// The Selected Item Index
	var iSel = parseInt(ur_get(oScrl.ref.id).getAttribute('sidx')); 
	
	for(i=iFirst;i<=iLast;i++) {
		var arrItems = oScrl.items[i];
		var oItemImage = arrItems[0];
		// Condition: First Item front Image
		if(iFirst == i ) {
			if(iFirst != 0) { // Condition: The current first scroll item not the first TabItem (we still have items to the left)
				if(iSel== i) // Condition: The Current Item is selected
					oItemImage.className = "urTbsFirstAngOnPrevOn";
				else
					oItemImage.className = "urTbsFirstAngOffPrevOn";
			} else {//  No items to the left of this item
				if(iSel== i) // The first item is selected
					oItemImage.className = "urTbsFirstAngOnPrevOff";
				else
					oItemImage.className = "urTbsFirstAngOffPrevoff";
			}
		} else { // Not the first Scroll item
			if((i!=0 && iSel== i-1)) 
			  oItemImage.className = "urTbsAngOnOff"; // Set the scroll img for prev item
			else if(iSel == i) // NOT the first scroll item but selected
				oItemImage.className = "urTbsAngOffOn";
			else // NOT the first scroll item and NOT selected either....
				oItemImage.className = "urTbsAngOffOff";
		}
		// handling the last image scroll
		if(iLast == i ) {
			var oLastImg=ur_get(oScrl.ref.id+"-n");
			if(iLast != (oScrl.items.length -1)) { // the current last scroll item IS NOT the last TabItem
				if(iSel== i) //the current last scroll item IS NOT the last TabItem but selected
					oLastImg.className = "urTbsLastOnNextOn";
				else //the current last scroll item IS NOT the last TabItem but NOT selected
					oLastImg.className = "urTbsLastOffNextOn";
			} else {// the current last scroll item IS the last TabItem
				if(iSel== i)// the current last scroll item IS the last TabItem but selected
					oLastImg.className = "urTbsLastOnNextOff";
				else // the current last scroll item IS the last TabItem but NOT Selected
					oLastImg.className = "urTbsLastOffNextOff";
			}
		}
	}
	// set the Paginator Button states
	if(ur_get(sId).getAttribute("scrl") == "1")
		ur_TS_setPagiButtonState(iFirst,iLast,sId);
	
}
function ur_TS_setPagiButtonState(iFirst,iLast,sId) {
  var oScrl = ur_IScr[sId];

	// set all the buttons initially to enabled
	sapUrMapi_Paginator_setStates(sId+'-pg',new Array("","",UR_PAGINATOR_BUTTON.PREVIOUS_ITEM,UR_PAGINATOR_BUTTON.NEXT_ITEM,"",""),new Array("","",true,true,"",""));
	
	// condition to set the 'Next Item' paginator button disabled
	if(ur_IScr[sId].last == oScrl.items.length -1 || ur_IScr[sId].last == -1)
	{
		
		var arrBtn = new Array();
		arrBtn[3] = UR_PAGINATOR_BUTTON.NEXT_ITEM;
				
		var arrBtnState = new Array();
		arrBtnState[3] = false;
		
		sapUrMapi_Paginator_setStates(sId+'-pg',arrBtn,arrBtnState);
	}
    
	// condition to set the  'Previous Item' paginator button disabled
	if(ur_IScr[sId].first == 0)
	{
		
		sapUrMapi_Paginator_setStates(sId+'-pg', new Array("","",UR_PAGINATOR_BUTTON.PREVIOUS_ITEM), new Array("","",false));
	}
	}
//* ------------------------------------------------------------------------


function sapUrMapi_TabStripItem_keydown(sId,evt)
{	 
}
