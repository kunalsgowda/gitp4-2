var ur_IScr = {};
	
function ur_IScr_visFirst(o,x){
	var oItm=o.items[x];
	var iWidth=oItm.width;
	if ( o.availwidth > o.newwidth+iWidth ) {
              oItm.visible = true;
              o.first=x;
        } else {
           oItm.visible=false; 
           o.tmpwidth = o.newwidth+iWidth;
           return true;
         }
	o.newwidth+=iWidth;
	return false;
}
	
function ur_IScr_visLast(o,x){
	var oItm=o.items[x];
	var iWidth=oItm.width;
	if (o.availwidth > o.newwidth+iWidth) {
            oItm.visible = true;
            o.last = x;
         } else {
             oItm.visible = false;
             o.tmpwidth = o.newwidth + iWidth;
             return true;
        }
	o.newwidth+=iWidth;
	return false;
}
	
function ur_IScr_getObj(sId) {
		
		if ( ur_IScr[sId] != null && (ur_IScr[sId].ref == ur_get(sId)) ) {
			return;
		}
		
		ur_IScr[sId]=new Array();
		ur_IScr[sId].availwidth=0;
		ur_IScr[sId].ref=ur_get(sId);
		ur_IScr[sId].scrl=ur_get(sId+"-scrl");
		ur_IScr[sId].items = new Array();

		oCntItms = ur_IScr[sId].scrl.getElementsByTagName("TD");
		
		for (var i=0;i<oCntItms.length;i++) {
			var oItm=oCntItms[i];
			if (oItm && oItm.getAttribute("idx")!=null && oItm.getAttribute("idx")!="") {
				var iIdx=parseInt(oItm.getAttribute("idx"));
				
				if (ur_IScr[sId].items[iIdx]!=null) {
					ur_IScr[sId].items[iIdx][ur_IScr[sId].items[iIdx].length]=oItm;
				}	else {
					ur_IScr[sId].items[iIdx]=new Array();
					ur_IScr[sId].items[iIdx].width=0;
					ur_IScr[sId].items[iIdx][0]=oItm;
					sT=oItm.getAttribute("st");
					
					if (sT != null && sT.indexOf("s") > -1) ur_IScr[sId].items[iIdx]["forcevisible"]=true;
				}
				
				ur_IScr[sId].items[iIdx].width+=oItm.offsetWidth;
		}
	} 
		ur_IScr[sId].first=parseInt(ur_IScr[sId].scrl.getAttribute("fsrl"));
		ur_IScr[sId].last=parseInt(ur_IScr[sId].scrl.parentNode.getAttribute("lsrl"));
}

function ur_IScr_fireEvent(sEvtName,o,idx) {
	if (o.scrl.getAttribute(sEvtName)) {
		var tmpFunc=new Function("event",o.scrl.getAttribute(sEvtName));
		if (sEvtName=="ohi" || sEvtName=="osi")
			ur_EVT_fire(o.scrl,"osi");
		if (sEvtName=="oadi") {
			ur_EVT_fire(o.scrl,"oadi");
		}
	}
	return true;
}
	
function ur_IScr_draw(sId) {

		var o = ur_IScr[sId];
		
		//o.scrl.style.width = 0;
		
		//o.availwidth=o.scrl.offsetWidth+o.scrl.parentNode.parentNode.lastChild.offsetWidth-1;
		if(o.ref.getAttribute("scrl") != "1"){
			var noScrlWdth = 0;
			for( var i = 0 ; i < o.items.length ; i++) {
				noScrlWdth = noScrlWdth + o.items[i].width;
			}
			noScrlWdth = noScrlWdth + o.items[o.items.length -1].width;
			o.availwidth =noScrlWdth ;
		}
		else
			o.availwidth=o.scrl.offsetWidth+ur_get(sId+'-lscrl').offsetWidth-1;

	o.newwidth=0;
	o.tmpwidth=0;

	for (var i = 0; i < o.items.length; i++) {
		o.items[i].visible=false;
	}
		
	if (o.last==-1) { 
		//the last item has to be calculated according to the available width
			for (var i = o.first; i < o.items.length; i++) {
				//make items at the end visible step by step
				if ( ur_IScr_visLast(o, i) ) break; 
		}
		if (o.availwidth>o.tmpwidth) { 
			//there is still some space left, lets try to make some more items visible at the beginning
				for (var i = o.first - 1; i >= 0; i--) 
					if (ur_IScr_visFirst(o,i)) break;
		}
	} else {
		//the first item has to be calculated according to the available width
		for (var i = o.last; i >= 0; i--) 
			//make items at the beginning visible step by step
			if (ur_IScr_visFirst(o, i)) break; 
			
		if (o.availwidth>o.tmpwidth) { 
			//there is still some space left, lets try to make some more items visible at the end
			for (var x=o.last+1;x<o.items.length;x++) 
				if (ur_IScr_visLast(o,x)) break;
		}
	}
		//loop over the items and make them visible or hide them
		//callback to control for special handling
	for (var x=0;x<o.items.length;x++) {
	if (o.items[x].visible){
		if (ur_IScr_fireEvent("osi",o,x)) {
				for (var n=0;n<o.items[x].length;n++) {
					o.items[x][n].removeAttribute("style");
					o.items[x][n].style.display="";
				}
			}
	} else {
			if (ur_IScr_fireEvent("ohi",o,x)) {
				for (var n=0;n<o.items[x].length;n++) {
				o.items[x][n].removeAttribute("style");
				o.items[x][n].style.display="none";
				}
			}
	}
	}

		if(ur_get(sId).getAttribute("scrl") != "1") {
			o.first = 0;
			o.last = o.items.length -1;
	}
		//callback to the control now and pass the items array
	if (o.ref.getAttribute("ct") == "TS") {
		ur_TS_oadi(sId);
		/*FF Hack: After initializing the tabstrip the last cell
		is drawn at first position unless its dom is manipulated by any means
		*/
		if (o != null) {
		    var oLastImg = ur_get(o.ref.id + "-n");
		    if (oLastImg != null) {
		        oLastImg.style.height = "18px";
		    }
		}
	}else{
	ur_IScr_fireEvent("oadi",o);
             }
	o.scrl.style.minWidth=o.newwidth + "px";
}

function ur_IScr_toBegin(sId) {
	ur_IScr[sId].first = 0;
	ur_IScr[sId].last = -1;
	ur_IScr_draw(sId);
}

function ur_IScr_toEnd(sId) {
	ur_IScr[sId].first = -1;
	ur_IScr[sId].last = ur_IScr[sId].items.length-1;
	ur_IScr_draw(sId);
}

function ur_IScr_toPrevPage(sId) {
	if (ur_IScr[sId].first > 0) {
		ur_IScr[sId].last = ur_IScr[sId].first - 1;
		ur_IScr[sId].first = -1;
	ur_IScr_draw(sId);
	}
}

function ur_IScr_toPrevItem(sId) {
	
		if ( ur_IScr[sId].first > 0) {
			ur_IScr[sId].first--;
		
			ur_IScr[sId].last = -1;
		ur_IScr_draw(sId);
	}
}

function ur_IScr_toNextPage(sId) {
		if (ur_IScr[sId].last < ur_IScr[sId].items.length - 1) {
			ur_IScr[sId].first = ur_IScr[sId].last + 1;
			ur_IScr[sId].last = - 1;
		ur_IScr_draw(sId);
	}
}

function ur_IScr_toNextItem(sId) {
	
		if (ur_IScr[sId].first < ur_IScr[sId].items.length - 1) {
			ur_IScr[sId].first ++;
			ur_IScr[sId].last = -1;
		ur_IScr_draw(sId);
	}
}
	
	function ur_IScr_resize(sId) {
		ur_IScr[sId].last=-1;
	ur_IScr_draw(sId);
}
	
function ur_IScr_create(sId){
	ur_IScr_resize(sId);			
}
function ur_IScr_getFirstVisibleIndex(sId){
		if (ur_IScr[sId].first > 0) {
			return parseInt(ur_IScr[sId].first);
	}
	return 0;
}
