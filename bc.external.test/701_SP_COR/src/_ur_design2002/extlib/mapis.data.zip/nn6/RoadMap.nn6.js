//* ************************************************************************
//* RoadMap
//* ************************************************************************

//* ------------------------------------------------------------------------
//* function    : ur_RM_RegisterCreate
//* parameter   : sId - string - Id of the RoadMap
//* description : Registers the RoadMap with the create item registry to be
//*				  initialized when the page loads
//* return      : none
//* ------------------------------------------------------------------------
function ur_RM_RegisterCreate(sId)
{
	 var oRm = ur_get(sId);
	if(parseInt(oRm.getAttribute("ic"))==0)return;
 	
  	if(!oRm.getAttribute('selectedstep'))
		oRm.setAttribute("selectedstep","-1");

	 if(oRm.getAttribute('scrl') == "1")
		sapUrMapi_Create_AddItem(sId, "ur_RM_create('" + sId + "')");
	else
		ur_get(sId+"-scrl").className = "";
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RoadMapEdgesHover
//* parameter   : sId - string Id of the RoadMap
//*             : e   - Event Object
//* return      : none
//*	description	: hovereffect on morebefore/after icon
//* ------------------------------------------------------------------------
function sapUrMapi_RoadMap_hoverEdges(sId,edgeType,e){
	var oS= ur_get(sId + "-itm-start");
	var sBts=oS.childNodes[0].className;
	var oE= ur_get(sId + "-itm-end");
	var sBte=oE.childNodes[0].className;
	
	if(e.type=="mouseover" && sBts=="urRMMoreBefore" && edgeType=="start"){
		oS.childNodes[0].className="urRMMoreBeforeHover";
	}
	else if(e.type=="mouseout" && sBts=="urRMMoreBeforeHover" && edgeType=="start"){
		oS.childNodes[0].className="urRMMoreBefore";
	}
	else if(e.type=='mouseover' && sBte=='urRMMoreAfter' && edgeType=="end"){
		oE.childNodes[0].className='urRMMoreAfterHover';
	}
	else if(e.type=='mouseout' && sBte=='urRMMoreAfterHover'&& edgeType=="end"){
		oE.childNodes[0].className='urRMMoreAfter';
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RoadMap_hoverStep
//* parameter   : sId - string Id of the RoadMap
//*             : sStepNr   - string - index of hovered roadmap step
//*				: e - event object
//* return      : none
//*	description	: makes a hovereffect on a step
//* ------------------------------------------------------------------------

function sapUrMapi_RoadMap_hoverStep(sId,iStepNr,e){

	var iSel = parseInt(ur_get(sId).getAttribute("selectedstep"));
	var oTitle = ur_get(sId + "-itm-" + iStepNr).childNodes[1];
	
	if( iSel == iStepNr || oTitle.className == "urRMNoItem")return;

		if(e.type=="mouseover"){
		oTitle.className = "urRMStepItem urRMItemHover";
			}
		else if(e.type=="mouseout"){
			oTitle.className = "urRMStepItem";
			}

}
//* ------------------------------------------------------------------------
//* function    : ur_RM_create
//* parameter   : sId - string Id of the RoadMap
//* return      : none
//*	description	: needed to reset to its original state during scroll
//* ------------------------------------------------------------------------
function ur_RM_create(sId)
{
	ur_get(sId+'-itm-start').setAttribute("stDsgn",ur_get(sId+'-itm-start').firstChild.className);
	ur_get(sId+'-itm-end').setAttribute("endDsgn",ur_get(sId+'-itm-end').firstChild.className);
	
	ur_IScr_getObj(sId);
	ur_IScr_create(sId);
	sapUrMapi_Resize_AddItem(sId, "ur_IScr_resize('"+sId+"')");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RoadMap_keydown
//* parameter   : sId - string Id of the RoadMap
//*             : sStepName   - string - declaration of all possible roadmap steps
//*             : e   - Event Object
//* return      : none
//*	description	: delivers keyboard navigation through roadmap
//* ------------------------------------------------------------------------
function sapUrMapi_RoadMap_keydownStep(sId,iItmIdx,e){
	var oRm = ur_get(sId);
	var oItm=ur_get(sId+"-itm-"+iItmIdx);
	var oPrev=null;
	var oNext=null;
	var bScroll=oRm.getAttribute("scrl");
	var oRmScrl = ur_IScr[sId];

	if(ur_system.direction!="rtl"){
		oPrev=oItm.previousSibling;
		oNext = oItm.nextSibling;
		}else{
		oNext=oItm.previousSibling;
		oPrev = oItm.nextSibling;
		}
	if(e.keyCode == 39 && oNext!=null) {
		if(bScroll=="1" && iItmIdx == oRmScrl.last)
		   ur_IScr_toNextPage(sId);
		   ur_focus_Itm(oNext,oItm);
		   ur_EVT_cancel(e);
	    }
	else if(e.keyCode == 37 && oPrev!=null){
		if(bScroll=="1" && iItmIdx ==oRmScrl.first)
   	       ur_IScr_toPrevPage(sId);
		   ur_focus_Itm(oPrev,oItm);
		   ur_EVT_cancel(e);
	}
	else if(e.keyCode==9){
		var iSel = oRm.getAttribute("selectedstep");
		if(iSel=="-1")iSel=0;
		var oSel = ur_get(sId+"-itm-"+iSel);
		ur_focus_Itm(oSel,oItm);
	}
	else if(e.keyCode==32)oItm.click();
	 ur_EVT_cancelBubble(e);
}
//* ------------------------------------------------------------------------
//* function    : ur_RM_oadi
//* parameter   : sId - string Id of the RoadMap
//*           
//*           
//* return      : none
//*	description	: The on after draw function for RoadMap specific re-drawing of images
//* ------------------------------------------------------------------------


function ur_RM_oadi(sId,oEvt)
{
	var o = ur_IScr[sId];
	if(o.first!= 0)
		ur_get(sId+'-itm-start').firstChild.className = "urRMMoreBefore";
	else
		ur_get(sId+'-itm-start').firstChild.className = ur_get(sId+'-itm-start').getAttribute("stDsgn");
	if(o.last != o.items.length-1)
	{
		ur_get(sId+'-itm-end').firstChild.className = "urRMMoreAfter";
				
	}
	else
	{
		ur_get(sId+'-itm-end').firstChild.className = ur_get(sId+'-itm-end').getAttribute("endDsgn");
	}
}

//* ------------------------------------------------------------------------
//* function    : ur_RM_s
//* parameter   : sId - string Id of the RoadMap
//*           	  iNr - step number
//*           	  oEv - event object
//* return      : none
//*	description	: Client side step selection
//* ------------------------------------------------------------------------

function ur_RM_select(sId,iNr,oEv){
	var o = ur_get(sId + "-itm-" + iNr);
	var iSelectedIdx = parseInt(ur_get(sId).getAttribute("selectedstep"));
	
	//change design of selected step
	if( o.st && o.st.indexOf("d") > -1  ||
		iSelectedIdx == iNr ||
		o.className == "urRMNotInterActive") return;
	
	var oStepN = o.getElementsByTagName("TD")[1];
	var oTitleN = o.childNodes[1];
	var oRm = ur_get(sId);
		
	oStepN.className = oStepN.className + "Sel";
	oTitleN.className = "urRMStepItem";
	oTitleN.className = oTitleN.className + "Sel";
		
		
	//change 508 sttributes and refocus selected step
	if (ur_system.is508) {
		ur_setSt(o,ur_st.NOTSELECTED,false);
		ur_setSt(o,ur_st.SELECTED,true);
		sapUrMapi_refocusElement(ur_get(sId + "-itm-" + iNr));
	}
	//deselect previous selected, if there is one
	if (iSelectedIdx != -1) {
		var o = ur_get(sId + "-itm-" + iSelectedIdx);
		var oStepO = o.getElementsByTagName("TD")[1];
		var oTitleO = o.childNodes[1];
		
		oStepO.className = oStepO.className.split("Sel")[0];
		oTitleO.className = oTitleO.className.split("Sel")[0];
		sapUrMapi_setTabIndex(oStepO,-1);
		
		ur_setSt(o,ur_st.NOTSELECTED,true);
		ur_setSt(o,ur_st.SELECTED,false);
	}
	
	//change all according tabindex attributes
	sapUrMapi_setTabIndex(oStepN,0);
	oRm.setAttribute("focusedstep", iNr);
	oRm.setAttribute("selectedstep",iNr);


	// if selection is done programmatically by using this function, the selected step may disappear.
	// Then scroll it into view.
	if ( oRm.scroll == 1 ){
		ur_EVT_addParam(oEv,"FirstVisibleItemIdx",ur_IScr[sId].first);
    	var bVisible = ur_IScr[sId].items[iNr].visible;
		
	    if ( bVisible ) 
			ur_IScr_draw(sId);
	    else {
	      ur_IScr[sId].first = iNr;
	      ur_IScr[sId].last = -1;
	      ur_IScr_draw(sId);
	}
     }
}
//* ------------------------------------------------------------------------
//* function    : ur_RM_Scrl
//* parameter   : sId - string Id of the RoadMap
//*           	  
//* return      : none
//*	description	: Invoked when RoadMap is in Scroll mode.
//* ------------------------------------------------------------------------

function ur_RM_Scrl(sId,edgeType,oEvt)
{
	var iRmItms = parseInt(ur_get(sId).getAttribute("ic"));	
	if(iRmItms==0)return;
	var oRmStart = ur_get(sId+'-itm-start');
	var oRmEnd = ur_get(sId+'-itm-end');
	var oRmScrl = ur_IScr[sId];
	if( oRmStart.firstChild.className.indexOf("Before") > -1 && edgeType == "start" && oRmScrl.first != 0)
	{
		ur_IScr_toPrevPage(sId);
	}
	else if( oRmEnd.firstChild.className.indexOf("After") && edgeType == "end" && oRmScrl.last != ( iRmItms - 1) )
	{
		ur_IScr_toNextPage(sId);
	}
	else if( oRmStart.firstChild.className.indexOf("Before") > -1 || oRmScrl.first == 0 && edgeType == "start") 
			 ur_EVT_fire(oRmStart,"onscrl");
	else if( oRmEnd.firstChild.className.indexOf("After") > -1 || oRmScrl.last == iRmItms-1 && edgeType == "end")
			ur_EVT_fire(oRmEnd,"onscrl");
			
	ur_EVT_addParam(oEvt,"FirstVisibleItemIdx",ur_IScr[sId].first);
}
