///TOOLBAR INPUTFIELD
function sapUrMapi_ToolbarInputField_blur(sId,event){
	sapUrMapi_InputField_Blur(sId,event);
}
function sapUrMapi_ToolbarInputField_keydown(sId,oEvt) {
	// show data tip when you press ctrl+shift+i (old key ctrl+q)
	if( oEvt.keyCode==73 && oEvt.shiftKey && sapUrMapi_bCtrl(oEvt) && !oEvt.altKey ){
		ur_EVT_cancel(oEvt);
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
	}
// handle esc key
	if(oEvt.keyCode == "27"){
		ur_EVT_cancel(oEvt);
		sapUrMapi_DataTip_hide();
	}
}
