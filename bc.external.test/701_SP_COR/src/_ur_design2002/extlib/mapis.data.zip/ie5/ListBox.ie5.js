//FOCUS
function sapUrMapi_ListBox_focus(sId,e) {
    //sapUrMapi_focusElement(sId);
	sapUrMapi_DataTip_show(sId,"focus");
}
function sapUrMapi_ListBox_blur(sId,event) {
	sapUrMapi_DataTip_hide(sId);
}
function sapUrMapi_ListBox_keydown(sId,oEvt) {
	// show data tip when you press ctrl+shift+i (old key ctrl+q)
	if( oEvt.keyCode==73 && oEvt.shiftKey && sapUrMapi_bCtrl(oEvt) && !oEvt.altKey ){
		ur_EVT_cancel(oEvt);
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
	}
// handle esc key
	if(oEvt.keyCode == "27"){
		ur_EVT_cancel(oEvt);
		sapUrMapi_DataTip_hide(sId);
	}
}