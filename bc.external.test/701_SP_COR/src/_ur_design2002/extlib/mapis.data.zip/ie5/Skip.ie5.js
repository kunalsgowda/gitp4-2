//* ------------------------------------------------------------------------
//* function    : sapUrMapi_skip
//* parameter   : sId - Id of the control using skipping
//*								oEvt - event object
//* return      : true if skipping was successful
//*	description	: If the 508 flag is turned on the user will be able to skip to
//*								thr end of a control or to navigate to the beginning.
//* ------------------------------------------------------------------------
function sapUrMapi_skip(sId,oEvt) 
{
	var sCt=sapUrMapi_getControlType(sId);
	if(sCt=="AX" || sCt=="AP" || sCt=="IF" || sCt=="T" )
		sId+="-r";
	var oR=ur_get(sId);
	var oN=null;
	var oF=null;
	
	// backward
	if( oEvt.shiftKey && oEvt.keyCode == 117 )
	{
		while(oR!=null && oF==null){
			while(oR!=null && oR.previousSibling==null)
				oR=oR.parentNode;
			if(oR==null)
				break;
			oN=oR.previousSibling;
			while(oN!=null && oF==null){
				oF=sapUrMapi_findFirstFocus(oN,true);
				if(oF==null)
					oN=oN.previousSibling;
			}
			if(oF==null)
				oR=oR.parentNode;
			else
				break;
		}
	}	 
	// forward
	else if( oEvt.keyCode == 117 ){
		while(oR!=null && oF==null){
			while(oR!=null && oR.nextSibling==null)
				oR=oR.parentNode;
			if(oR==null)
				break;				
			oN=oR.nextSibling;
			while(oN!=null && oF==null){
				oF=sapUrMapi_findFirstFocus(oN);
				if(oF==null)
					oN=oN.nextSibling;
			}
			if(oF==null)
				oR=oR.parentNode;
			else
				break;
		}
	}	
	if(oF!=null)
	{
		ur_focus(oF);
		return ur_EVT_cancel(oEvt);
	}
    if(oEvt.keyCode== 13)
	 {
		if(oR.getAttribute("dbid")!=null)
		 {
			 sapUrMapi_triggerDefaultButton(sId,oEvt);
		 }
	 }	 
}


