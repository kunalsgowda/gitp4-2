//------------------------------------
//TABLEVIEW
//------------------------------------
//SELECTROW
function sapUrMapi_Table_selectRow(sTableId,iRow,e) 
{
  var oInput = ur_get(sTableId+'-itm-'+iRow);
  var oInputGrp = document.getElementsByName(oInput.name);
  if ((oInputGrp.length==1)&&(oInput.type!="radio"))
  {
    if (e.srcElement.tagName=="IMG") oInput.checked = (!oInput.checked);
		var oImg = ur_get(oInput.id + "-img");
		oImg.className = "urImgCbgImg";
		if (oInput.checked) oImg.className = "urImgCbgImgChk";
		// find corresponding row
		var oRow = oInput.parentElement;
		while(!oRow.rr)
		{
			oRow=oRow.parentElement;
		}
		for (var n=0;n<oRow.cells.length;n++)
		{
			var oCell = oRow.cells[n];
			if (oInput.checked)
			{
			  oCell.setAttribute("unselectedclass",oCell.className);
			  //oCell.className = oCell.className + " urETbvCellSel";
			}
			else
			{
	  		  //oCell.className=oCell.getAttribute("unselectedclass");
			}
		}
		if(oInput.checked)
	    {
			ur_setSt(oInput,ur_st.NOTSELECTED,false);
			ur_setSt(oInput,ur_st.SELECTED,true);
		}
		else
		{
			ur_setSt(oInput,ur_st.NOTSELECTED,true);
			ur_setSt(oInput,ur_st.SELECTED,false);
		}
  } 
   else
  {
	  for (var i = 0; i < oInputGrp.length; i++)
	  {
	    var oImg = ur_get(oInputGrp[i].id + "-img");
	    if (oInputGrp[i]==oInput)
		{
			  if (e.srcElement.tagName=="IMG") oInput.checked=true;
			  if (e.srcElement.tagName=="IMG") ur_focus(oInputGrp[i]);
		      oImg.className = "urImgRbgImgChk";
			  ur_setSt(oInput,ur_st.NOTSELECTED,false);
			  ur_setSt(oInput,ur_st.SELECTED,true);
	    } 
		else
		{
			 if (oImg.onclick)
			 {
				oInputGrp[i].checked=false;
				oImg.className = "urImgRbgImg";
				ur_setSt(oInputGrp[i],ur_st.NOTSELECTED,true);
				ur_setSt(oInputGrp[i],ur_st.SELECTED,false);
			 }
	    }
	 }
	
  }
  e.cancelBubble=true;
  e.returnValue=true;
}

function sapUrMapi_Table_getClickedRowIndex(sId) {
 	 oSrc = window.event.srcElement;
   var obj = event.srcElement;
   while ( (obj!=null) && (obj.tagName!='TD') )
      obj = obj.parentElement;
   if(obj==null) return;
   var parent = obj.parentElement;
   var rowIndex = parent.rr;
   return parseInt(parent.rr);
}

function sapUrMapi_Table_getClickedColIndex(sId) {
 	 oSrc = window.event.srcElement;
   var obj = event.srcElement;
   while ( (obj!=null) && (obj.tagName!='TD') )
      obj = obj.parentElement;
   oCell = obj;
   while ( (obj!=null) && (obj.tagName!='TABLE') )
      obj = obj.parentElement;
   if ( obj==null ) return;
   var colidx =  oCell.cellIndex - parseInt( obj.nmi );
   return colidx;
}

function sapUrMapi_Table_getClickedCellId(sId) {
 	 oSrc = window.event.srcElement;
   var obj = event.srcElement;
   while ( (obj!=null) && (obj.tagName!='TD') )
      obj = obj.parentElement;
   oCell = obj;
   var cellid =  oCell.id;
   return cellid;
}

function sapUrMapi_Table_clickSelButton(o){
	var oRow = o;
	while(oRow.tagName!="TR") oRow = oRow.parentNode;
	if(oRow.tagName!="TR")return;
	var sButtons = oRow.getElementsByTagName("BUTTON");
	for(var i=0;i<sButtons.length;i++)
		if(sButtons[i].className=="urSTRowUnSelIcon" || sButtons[i].className=="urSTRowSelIcon")
			if(o.id != sButtons[i].id)
				sButtons[i].click();
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Table_getCellIndex
//* parameter   : oCell - table cell object
//* return      :
//*	description	: get cell index
//* ------------------------------------------------------------------------
function sapUrMapi_Table_getCellIndex(oCell){
	var i=0;
	var o=oCell;
	var oRow=oCell.parentNode;
	var oTab=oRow.parentNode.parentNode;

	// get cell index an do not forget rowspan and colspan
	while(o.previousSibling!=null){
		for(var j=oRow.rowIndex-1;j>=0;j--){
			if(oTab.rows[j].cells.length<=o.cellIndex) continue;
			if(oTab.rows[j].cells[o.cellIndex].rowSpan>1 && oTab.rows[j].rowIndex+oTab.rows[j].cells[o.cellIndex].rowSpan-1>=oRow.rowIndex){
				i+=oTab.rows[j].cells[o.cellIndex].rowSpan-1;
				break;
			}
		}
		if(o.previousSibling!=null) o=o.previousSibling;
		i+=o.colSpan;
	}
	return i;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Table_getCell
//* parameter   : oRow - table row object
//								iIdx - cell index
//* return      : cell object
//*	description	: get cell[iIdx] in the given row
//* ------------------------------------------------------------------------
function sapUrMapi_Table_getCell(oRow,iIdx){
	var o=oRow.firstChild;
	var oTab=oRow.parentNode.parentNode;
	var i=0;

	// get cell[iIdx] in the row and do not forget rowspan and colspan
	while(i<iIdx){
		for(var j=oRow.rowIndex-1;j>=0;j--){
			if(oTab.rows[j].cells.length<=o.cellIndex) continue;
			if(oTab.rows[j].cells[o.cellIndex].rowSpan>1 && oTab.rows[j].rowIndex+oTab.rows[j].cells[o.cellIndex].rowSpan-1>=oRow.rowIndex){
				iIdx-=oTab.rows[j].cells[o.cellIndex].rowSpan-1;
				break;
			}
		}
		if(o.nextSibling!=null && i<iIdx) o=o.nextSibling;
		else break;
		i+=o.colSpan;
	}
	return o;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Table_focusUp
//* parameter   : o - object within a table cell or cell
//* return      :
//*	description	: go up
//* ------------------------------------------------------------------------
function sapUrMapi_Table_focusUp(sId,o){
	var oCell = o;
	var iCellIdx=0;
	// get the cell object whichs contains the focused object
	while(oCell.tagName != "TD" && oCell.tagName != "TH") oCell = oCell.parentNode;
	iCellIdx=sapUrMapi_Table_getCellIndex(oCell);
	// get the target row
	var oCurrRow = oCell.parentNode;
	var oRow=oCurrRow.parentNode.firstChild;
	while(oRow.nextSibling!=oCurrRow){
		oCell=sapUrMapi_Table_getCell(oRow,iCellIdx);
		if(oRow.rowIndex+oCell.rowSpan >= oCurrRow.rowIndex)
			break;
		oRow=oRow.nextSibling;
	}

	// check if there are more rows in a previous table section
	if(oCurrRow.previousSibling==null && oRow.parentNode.previousSibling!=null)
		oRow=oRow.parentNode.previousSibling.firstChild;
	// focus cell in the target row
	oCell=sapUrMapi_Table_getCell(oRow,iCellIdx);
	if(oCell!=null) ur_focus(oCell);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Table_focusDown
//* parameter   : o - object within a table cell or cell
//* return      :
//*	description	: go down
//* ------------------------------------------------------------------------
function sapUrMapi_Table_focusDown(sId,o){
	var oCell=o;
	var bLastRow=false;
	// get the cell object whichs contains the focused object
	while(oCell.tagName != "TD" && oCell.tagName != "TH") oCell = oCell.parentNode;
	// get the target row
	var oRow=oCell.parentNode;
	for(var i=0; i<oCell.rowSpan;i++){
		if(oRow.nextSibling!=null)
			oRow=oRow.nextSibling;
		else{
			bLastRow=true;
			break;
		}
	}
	// check if there are more more rows in a following table section
	if(bLastRow && oRow.parentNode.nextSibling!=null && oRow.parentNode.nextSibling.tagName!="TFOOT")
	 oRow=oRow.parentNode.nextSibling.firstChild;
	else if(bLastRow) return;
	// focus cell in the target row
	oCell=sapUrMapi_Table_getCell(oRow,sapUrMapi_Table_getCellIndex(oCell));
	if(oCell!=null) ur_focus(oCell);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Table_focusPrevious
//* parameter   : o - object within a table cell or cell
//* return      :
//*	description	: focus previous cell in the row if available
//* ------------------------------------------------------------------------
function sapUrMapi_Table_focusPrevious(sId,o){
	var oCell = o;
	var oPCell = null;
	var oTab = null;
	while(!(oCell.className.substr(0,4)=="urST"&& (oCell.tagName=="TD"||oCell.tagName=="TH"))){
		oCell=oCell.parentNode;
		if(oCell==null||oCell.id==sId) return false;
	}
	oTab = oCell;
	while(oTab.tagName!="TABLE") oTab = oTab.parentNode;

	for(var i=0; i<oCell.parentNode.rowIndex; i++){
		for(var j=0; j<=oCell.cellIndex; j++){
			if(oTab.rows[i].cells.length > j)
			if( oTab.rows[i].rowIndex+parseInt(oTab.rows[i].cells[j].rowSpan)-1>=oCell.parentNode.rowIndex && oCell.cellIndex==oTab.rows[i].cells[j].cellIndex)
				oPCell=oTab.rows[i].cells[j];
		}
	}

	if(oPCell==null && oCell.previousSibling!=null) oPCell=oCell.previousSibling;
	if(oPCell!=null) ur_focus(oPCell);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Table_focusNext
//* parameter   : o - object within a table cell or cell
//* return      :
//*	description	: focus next cell in the row if available
//* ------------------------------------------------------------------------
function sapUrMapi_Table_focusNext(sId,o){
	var oCell = o;
	var oTab;
	while(!(oCell.className.substr(0,4)=="urST"&& (oCell.tagName=="TD"||oCell.tagName=="TH"))){
		oCell=oCell.parentNode;
		if(oCell==null||oCell.id==sId) return false;
	}
	oTab = oCell;
	while(oTab.tagName!="TABLE") oTab = oTab.parentNode;
	if(oTab.parentNode.parentNode.parentNode.parentNode.id!=sId)
		sapUrMapi_Table_focusNext(sId,oTab.parentNode);
	else
		if( oCell.nextSibling != null ) ur_focus(oCell.nextSibling);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Table_tabBack
//* parameter   : o - object within a table cell or cell
//* return      :
//*	description	: focus previous cell if available
//* ------------------------------------------------------------------------
function sapUrMapi_Table_tabBack(sId,o){
	var oCell = o;
	var oTab;
	if( o.tagName == "TABLE" || o.tagName == "TBODY" ) return false;
	while(oCell.tagName != "TD" && oCell.tagName != "TH"){
		oCell = oCell.parentNode;
		sControl = oCell.getAttribute("ct");
		if(sControl=="T" || sControl=="PG") return;
	}
	if(oCell.tagName != "TD" && oCell.tagName != "TH") return false;
	oTab = oCell;
	while(oTab.tagName!="TABLE") oTab = oTab.parentNode;
	if(oTab.parentNode.parentNode.parentNode.parentNode.id!=sId) return false;
	if( oCell.previousSibling != null){
		ur_focus(oCell.previousSibling);
		return true;
	}
	else{
		var oRow = oCell.parentNode.previousSibling;
		if( oRow != null){
			ur_focus(oRow.lastChild);
			return true;
		}
		else{
			ur_focus(oTab.parentNode.parentNode.parentNode.parentNode);
			return true;
		}
	}
	return false;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Table_keydown
//* parameter   : sId - control id
//*               e   - event object
//* return      : none
//*	description	: handle key navigation
//* ------------------------------------------------------------------------
function sapUrMapi_Table_keydown(sId,e){
  var o=e.srcElement;
	var iKey=e.keyCode;
	var sCt=sapUrMapi_getControlTypeFromObject(o);

	if(sId.indexOf("-skipstart")==-1) sId+="-skipstart";

	// spacebar
	if(iKey==32 && sCt!="I" && sCt!="TE" && sCt!="CB"){
		try{
			o.click();
		} catch(ex){ }
		ur_EVT_cancel(e);
		return true;
	}

	// arrow down
	if(e.keyCode == "40" && e.srcElement.tagName != "SELECT"){
		sapUrMapi_Table_focusDown(sId,e.srcElement);
		ur_EVT_cancel(e);
		return true;
	}

	// arrow up
	if(e.keyCode == "38" && e.srcElement.tagName != "SELECT"){
		sapUrMapi_Table_focusUp(sId,e.srcElement);
		ur_EVT_cancel(e);
		return true;
	}

	// arrow right
	if(e.keyCode == "39" && (e.srcElement.tagName != "INPUT" || e.srcElement.type.toUpperCase()=="CHECKBOX" || e.srcElement.type.toUpperCase()=="RADIO")){
		if (ur_system.direction=="rtl")
			sapUrMapi_Table_focusPrevious(sId,e.srcElement);
		else
			sapUrMapi_Table_focusNext(sId,e.srcElement);
		ur_EVT_cancel(e);
		return true;
	}

	// arrow left
	if(e.keyCode == "37" && (e.srcElement.tagName != "INPUT" || e.srcElement.type.toUpperCase()=="CHECKBOX" || e.srcElement.type.toUpperCase()=="RADIO")){
		if (ur_system.direction=="rtl")
			sapUrMapi_Table_focusNext(sId,e.srcElement);
		else
			sapUrMapi_Table_focusPrevious(sId,e.srcElement);
		e.returnValue=false;
		e.cancelBubble=true;
		return true;
	}

	// tab + shift
	if(e.keyCode == "9" && e.shiftKey == true ){
		if( sapUrMapi_Table_tabBack(sId,e.srcElement) ){
			e.returnValue = false;
			e.cancelBubble = true;
			return true;
		}
	}

  //vertical paging
  if(ur_get(sId).getElementsByTagName("TFOOT")[0]!=null){
  var o=e.srcElement;
  var sTag=o.tagName;
	var iKey=e.keyCode;
	var bS=e.shiftKey;
	var bA=e.altKey;
	var bC=sapUrMapi_bCtrl(e);
  var sTag=e.srcElement.tagName;
	var aBtns=ur_get(sId).getElementsByTagName("TFOOT")[0].getElementsByTagName("IMG");
	if (aBtns.length!=null) {
			//Pos1 + Ctrl
			if(iKey==36 && !bA && !bS && bC && sTag!="INPUT" && sTag!="TEXTAREA"){
				for (var i=0;i<aBtns.length;i++) {
				  if (aBtns[i].className.indexOf("Top")>-1 && aBtns[i].className.indexOf("Dsbl")==-1) {
				    aBtns[i].click();
				    ur_EVT_cancel(e);
						break;
				  }
				}
				return;
			}
			//End	 + Ctrl
			if(iKey==35 && !bA && !bS && bC && sTag!="INPUT" && sTag!="TEXTAREA"){
				for (var i=0;i<aBtns.length;i++) {
				  if (aBtns[i].className.indexOf("Bottom")>-1 && aBtns[i].className.indexOf("Dsbl")==-1) {
				    aBtns[i].click();
				    ur_EVT_cancel(e);
						break;
				  }
				}
				return;
			}
			//PageUp  PgUp
			if(iKey==33 && !bA && !bS &&!bC && sTag!="INPUT" && sTag!="TEXTAREA"){
				for (var i=0;i<aBtns.length;i++) {
				  if (aBtns[i].className.indexOf("PgUp")>-1 && aBtns[i].className.indexOf("Dsbl")==-1) {
				    aBtns[i].click();
				    ur_EVT_cancel(e);
						break;
				  }
				}
				return;
			}
			//PageDown
			if(iKey==34 && !bA && !bS &&!bC && sTag!="INPUT" && sTag!="TEXTAREA"){
				for (var i=0;i<aBtns.length;i++) {
				  if (aBtns[i].className.indexOf("PgDown")>-1 && aBtns[i].className.indexOf("Dsbl")==-1) {
				    aBtns[i].click();
				    ur_EVT_cancel(e);
						break;
				  }
				}
				return;
			}
	}
	}

	// skipping
	return sapUrMapi_skip(sId,e);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Table_activate
//* parameter   : sId - control id
//*               e   - event object
//* return      : none
//*	description	: focus first focusable element in a cell if a cell is focused
//* ------------------------------------------------------------------------
function sapUrMapi_Table_activate(sId,e){
	var isCell = e.srcElement.tagName == "TD" || e.srcElement.tagName == "TH";
	
	// return if not a cell is focused
	if(!isCell) return;

	var o = e.srcElement.firstChild;
	// return if no child node exists
	if(o!=null) {
		var oChild = o.firstChild;
		var oFocus = null;
		// get first focusable child node
		while(oFocus==null){
			while(oFocus==null){
				if(o==null) break;
				if(o.nodeType!=3 && (sapUrMapi_Focus_canFocus(o)==true||o.type=="radio")){
					oFocus=o;
					break;
				}
				o = o.firstChild;
			}
			if(oChild==null) break;
			oChild=oChild.nextSibling;
			o=oChild;
		}
		// found one, than set focus
		if(oFocus!=null) {
			if (ur_system.is508) sapUrMapi_Table_getTooltip(oFocus);
		  
		  //A redirect focus can only be done delayed due to JAWS has problems with a direct focus setting
			if(oFocus.id)
				sapUrMapi_triggerFocus(oFocus.id);
			else 
				setTimeout(function(){ur_focus(oFocus);},0);
			return;
		}
	} 
    
    //Empty cell or cell without focusable content.
	if (ur_system.is508) {
	    var oFocus = e.srcElement;
		sapUrMapi_Table_getTooltip(oFocus, true);
		setTimeout(function(){ur_focus(oFocus);},0);
	}
	
}

function sapUrMapi_Table_getTooltip(oF, isEmptyCell){
	 
		var sTooltip="";
		var sSep=" "+getLanguageText("SAPUR_SEPARATOR")+" ";
		var o = oF;
		
		if(!isEmptyCell) {
			o = oF.parentElement;
			while(o.tagName!="TD") o=o.parentNode;
		}
		
		var row = parseInt(o.getAttribute("rowIndex"))+1;
		var col = parseInt(o.getAttribute("colIndex"))+1;
	    
		var aHeaders;
		var sHeaders=o.getAttribute("headers");
		var oHeader;
		
		if(isNaN(row)) return;
		
		if (sHeaders==null || sHeaders=="") {
			if(isNaN(col)) return;
			sTooltip = getLanguageText("SAPUR_TBV_CELL",new Array(row,col));
		} else {
			aHeaders=sHeaders.split(" ");
			sHeaders="";
			for(var i=0;i<aHeaders.length;i++)
			{
				oHeader=ur_get(aHeaders[i]);
				if(oHeader!=null)sHeaders+=oHeader.innerText;
				if(i<aHeaders.length) sHeaders+=" ";
			}
			sTooltip = getLanguageText("SAPUR_TBV_CELL",new Array(row,sHeaders));
		}
		
		if(isEmptyCell) {
			sTooltip = getLanguageText("SAPUR_EMPTY") + sSep + sTooltip;
			oF.setAttribute("noCntanrAnnouce","X");
		}
		
		if(o.className.indexOf("urSTbvCellNeg")>0) sTooltip+=sSep+getLanguageText("SAPUR_NEGATIVE");
		else if(o.className.indexOf("urSTbvCellTot")>=0) sTooltip+=sSep+getLanguageText("SAPUR_TOTAL");
		else if(o.className.indexOf("urSTbvCellSubtot")>=0) sTooltip+=sSep+getLanguageText("SAPUR_SUBTOTAL");
		else if(o.className.indexOf("urSTbvCellBad")>=0) sTooltip+=sSep+getLanguageText("SAPUR_BADVALUE");
		else if(o.className.indexOf("urSTbvCellCrit")>=0) sTooltip+=sSep+getLanguageText("SAPUR_CRITICALVALUE");
		else if(o.className.indexOf("urSTbvCellPos")>=0) sTooltip+=sSep+getLanguageText("SAPUR_POSITIVE");
		if(o.className.indexOf("urSTbvCellSel")>=0) sTooltip+=sSep+getLanguageText("SAPUR_SELECTED");

	  oF.setAttribute("tttbl",sTooltip);
	  oF.setAttribute("intbl","true");
		
	  var oActiveElement = document.activeElement;
	  
	  if(oActiveElement != null && oActiveElement != oF) {
	  	oActiveElement.setAttribute("tttbl",sTooltip);
	  	oActiveElement.setAttribute("intbl","true");
	  	oActiveElement.setAttribute("noCntanrAnnouce","X");
	  }
		
}