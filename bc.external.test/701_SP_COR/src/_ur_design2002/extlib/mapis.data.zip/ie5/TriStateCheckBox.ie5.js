//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TriStateCheckBox_toggle
//* parameter   : sId - string Id of the checkbox to toggle
//* return      : true if the checkbox was toggled, else false
//*	description	: checks the checkbox specified by sId if not disabled
//* ------------------------------------------------------------------------
function sapUrMapi_TriStateCheckBox_toggle(sId,e) {
  var o=ur_get(sId);
  var oImg=ur_get(sId+"-img");
  if (ur_isSt(o,ur_st.DISABLED) || ur_isSt(o,ur_st.READONLY) || (e.type=="keydown" && e.keyCode!=32)) 
		return false;
	if (ur_isSt(o,ur_st.SELECTED)){
		ur_setSt(o,ur_st.SELECTED,false);
		ur_setSt(o,ur_st.UNDEFINED,true);
		oImg.className=oImg.className.replace("On","Ind");
	}
	else if (ur_isSt(o,ur_st.NOTSELECTED)){
		ur_setSt(o,ur_st.NOTSELECTED,false);
		ur_setSt(o,ur_st.SELECTED,true);
		oImg.className=oImg.className.replace("Off","On");	
	}
	else{
		ur_setSt(o,ur_st.UNDEFINED,false);
		ur_setSt(o,ur_st.NOTSELECTED,true);
		oImg.className=oImg.className.replace("Ind","Off");	
	}
	ur_focus(o);
	if (ur_system.is508) o.fireEvent("onactivate");
	return ur_EVT_cancel(e);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TriStateCheckBox_setDisabled
//* parameter   : sId - string Id of the checkbox
//*	description	: sets an enabled checkbox to disabled also the connected
//								label
//* ------------------------------------------------------------------------
function sapUrMapi_TriStateCheckBox_setDisabled(sId) {
	sapUrMapi_CheckBox_setDisabled(sId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TriStateCheckBox_setEnabled
//* parameter   : sId - string Id of the checkbox
//*	description	: sets an enabled checkbox to disabled also the connected
//								label
//* ------------------------------------------------------------------------
function sapUrMapi_TriStateCheckBox_setEnabled(sId) {
	sapUrMapi_CheckBox_setEnabled(sId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_TriStateCheckBox_setReadonly
//* parameter   : sId - Id of the checkbox
//*								bSet - set/unset the checkbox readonly
//*	description	: sets/unsets a checkbox readonly and the connected
//								label enabled
//* ------------------------------------------------------------------------
function sapUrMapi_TriStateCheckBox_setReadonly(sId,bSet){
	sapUrMapi_CheckBox_setReadonly(sId,bSet);
}
