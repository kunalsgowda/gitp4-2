																																							// Unified Rendering Context Object
var ur_ctx=new Array();
ur_ctx._i=new Array();

// ur_ctx.get 
//    returns a value of a specified key for instance with id
ur_ctx.get = function(sId,sKey) { return ur_ctx._i[sId][sKey]; }

// ur_ctx.set
//    returns a value of a specified key for instance with id
ur_ctx.set = function(sId,sKey,sValue) { 
  if (ur_ctx._i[sId]==null) ur_ctx._i[sId]=new Array();
  ur_ctx._i[sId][sKey]=sValue;
}

// ur_ctx.write
//    returns a string representation of the context
ur_ctx.write = function() { 
  var s1="";
  for (var x in ur_ctx._i) {
    if (s1!="") s1+=",";
    s1+=x+":{";
    var s2="";
    for (var y in ur_ctx._i[x]) {
      var val=ur_ctx._i[x][y];
      if (s2!="") s2+=",";
      if (typeof(ur_ctx._i[x][y])=="string") val="'"+val+"'";
      s2+=y+":"+val;
    }
    s1+=s2+"}";
  }
  return "{"+s1+"}";
}

// ur_ctx.read
//    initalizes the context object from given string
ur_ctx.read = function(s) { 
  ur_ctx._i=new Array();
  eval("ur_ctx._i="+s);
  ur_ctx.clear();
}

// ur_ctx.push
//    stores a key value pair for an object instance with id in the context
ur_ctx.push = function(sId,sKey,sValue) {
  if (ur_ctx._i[sId]==null) ur_ctx._i[sId]=new Array();
  ur_ctx._i[sId][sKey]=sValue;
}

// ur_ctx.pop
//    pops an item with id from the context 
ur_ctx.pop = function(sId) {
	ur_ctx._i[sId]=null;
  ur_ctx.clear();
}

// ur_ctx.clear
//    clears all items in the context that are null or point to a no longer available id
ur_ctx.clear = function() {
  var a=new Array();
  for (var x in ur_ctx._i) 
    if (document.getElementById(x)!=null && ur_ctx._i[x]!=null) a[x]=ur_ctx._i[x];
  ur_ctx._i=a;
}
