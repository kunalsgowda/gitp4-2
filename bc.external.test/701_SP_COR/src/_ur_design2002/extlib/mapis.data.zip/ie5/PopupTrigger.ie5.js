//* ************************************************************************
//* PopupTrigger
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupTrigger_hover
//* parameter   : sId - string id of the trigger
//*             : e   - Event Object
//* return      : none
//* description	: hovers the trigger and displays an arrow
//* ------------------------------------------------------------------------
function sapUrMapi_PopupTrigger_hover(sId,oEv) {
	var oT=ur_get(sId);
	var sIa=oT.getAttribute("ia");

	if (oEv.type=="mouseover") {
		oT.className = "urPopUpTrgWhl urPopUpTrHover urPopUpTrgIndHover";
	}
	
	else if (oEv.type=="mouseout"){
		if (sIa == "t") {
     		oT.className = "urPopUpTrgWhl";
		}
		else {
			oT.className = "urPopUpTrgWhl urPopUpTrgInd";
		}
	}
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupTrigger_openMenu
//* parameter   : sId - string id of the trigger
//*             : e   - Event Object
//* return      : none
//* description	: hovers the trigger and displays an arrow
//* ------------------------------------------------------------------------
function sapUrMapi_PopupTrigger_openMenu(sId,sMenuId,e) {
	var o=ur_get(sId);
	var bOpen=false;
	var eConMenu=false;
	var eClick=false;
	
	if(ur_system.is508 ) var oChild=sapUrMapi_findFirstFocus(o);
	
	if(oChild && oChild.getAttribute("id") != null &&oChild.getAttribute("id") != "") {
		var sChildId = oChild.getAttribute("id");
	}
	else {
		var sChildId = sId;
	}
	
	var oBtn=ur_get(sId+"-btn");
	if((o && o.oncontextmenu) || (oBtn && oBtn.oncontextmenu)) {
	  eConMenu=true;
	  eClick=true;
	}

	if (sapUrMapi_checkKey(e,"keydown",new Array("121")) && eConMenu==true){
		bOpen=true;
	} else if (e.altKey && sapUrMapi_checkKey(e,"keydown",new Array("40")) && eClick==true){
		bOpen=true;
	} else if(e.type=="contextmenu" ||e.type=="click") {
		bOpen=true;
	}else if(sapUrMapi_checkKey(e,"keydown",new Array("115"))) {
		bOpen=true;
	}else if(e.keyCode==32 && e.srcElement.getAttribute("id").indexOf("_selmenu")>-1){
		bOpen=true;
		e.cancelBubble=true;
	}
	
	if (bOpen) {
		if (ur_system.direction=="rtl")
		  sapUrMapi_PopupMenu_showMenu(sChildId,sMenuId,sapPopupPositionBehavior.MENULEFT,e);
		else
	 	  sapUrMapi_PopupMenu_showMenu(sChildId,sMenuId,sapPopupPositionBehavior.MENURIGHT,e);
		  if (sapUrMapi_checkKey(e,"keydown",new Array("115","121")))return ur_EVT_cancel(e);
		  if (e.type=="contextmenu") {
		      e.returnValue=false;
		    } else {
			  ur_EVT_cancelBubble(e);
		      e.returnValue=true;
		    }
		  
	}
    
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupTrigger_focus
//* parameter   : sId - string - Id of the PopupTrigger
//* description : 
//*				 
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_PopupTrigger_focus(sId,oEv){
}


//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupTrigger_RegisterCreate
//* parameter   : sId - string - Id of the PopupTrigger
//* description : Registers the trigger with the create item registry to be
//*				  initialized when the page loads
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_PopupTrigger_RegisterCreate(sId) {
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_PopupTrigger_init('" + sId + "')");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_PopupTrigger_init
//* parameter   : sId - string id of the trigger
//* return      : none
//* description	: checks whether a less than 100% is given to the content object
//* ------------------------------------------------------------------------
function sapUrMapi_PopupTrigger_init(sId){

	   if (ur_get(sId) == null || ur_get(sId).firstChild == null) return;
	   var value = ur_get(sId).firstChild.style.width;
	   var percent = value.lastIndexOf('%');

	   if(percent < 3 && percent > -1)
	   {
	     ur_get(sId).style.width = value;
	     ur_get(sId).firstChild.style.width = '100%';
	   }
}
