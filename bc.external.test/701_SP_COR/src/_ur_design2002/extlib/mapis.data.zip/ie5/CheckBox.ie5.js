//* ************************************************************************
//* CheckBox
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_toggle
//* parameter   : sId - Id of the checkbox
//*								e   - event object
//* return      : true if the checkbox was toggled, else false
//*	description	: select/deselect checkbox if not disabled or read only
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_toggle(sId,e) {
	var oIn = ur_get(sId),
		oRoot = ur_get(sId + "-r");
	if ( ur_isSt(oRoot,ur_st.READONLY) || ur_isSt(oRoot,ur_st.DISABLED) ) return false;  
	var oLbl=ur_get(sId+"-lbl"),
		oImg=ur_get(sId+"-img");
 var newClass = "";
  // checkbox is selected => deselect checkbox 
	if (ur_isSt(oRoot,ur_st.SELECTED)){
		oIn.checked=false;
		ur_setSt(oRoot,ur_st.SELECTED,false);
		ur_setSt(oRoot,ur_st.NOTSELECTED,true);
		oImg.className=oImg.className.replace("On","Off");
	} else { // checkbox is not selected => select checkbox 
		oIn.checked=true;
		ur_setSt(oRoot,ur_st.NOTSELECTED,false);
		ur_setSt(oRoot,ur_st.SELECTED,true);
		oImg.className=oImg.className.replace("Off","On");
	}
	
	// csn: 1635195 bug: radiobuttons don't work in IE9 Quirks Mode	
	newClass=oImg.className;
	oImg.className="";
	oImg.className=newClass;
	
	if (ur_system.is508) oIn.fireEvent("onactivate");
	return true;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_setDisabled
//* parameter   : sId - Id of the checkbox
//*	description	: sets an disabled checkbox to enabled and also the connected
//								label
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_setDisabled(sId) {
	var oIn=ur_get(sId),
		oRoot = ur_get(sId + "-r"),
		oLbl=ur_get(sId+"-lbl"),
		oImg=ur_get(sId+"-img"),
		sClass = "",
		newClass = "";
	if (ur_isSt(oRoot,ur_st.DISABLED)) return;
	if (ur_isSt(oRoot,ur_st.INVALID)){
		sClass = "Inv";
	}
	oLbl.className=oLbl.className.replace("Lbl" + sClass,"LblDsbl");
	if (ur_isSt(oRoot,ur_st.READONLY)){
		sClass += "Ro";
	}
	if (ur_isSt(oRoot,ur_st.SELECTED))
		oImg.className=oImg.className.replace("On" + sClass,"OnDsbl");
	else if(ur_isSt(oRoot,ur_st.UNDEFINED))
		oImg.className=oImg.className.replace("Ind" + sClass,"IndDsbl");
	else
		oImg.className=oImg.className.replace("Off" + sClass ,"OffDsbl");	
	
	// csn: 1635195 bug: radiobuttons don't work in IE9 Quirks Mode	
	newClass=oImg.className;
	oImg.className="";
	oImg.className=newClass;
	
	if (ur_system.is508) {
		sapUrMapi_setTabIndex(oRoot,"0");
	} else {
		sapUrMapi_setTabIndex(oRoot,"-1");
	}
  oIn.disabled=true;	
	ur_setSt(oRoot,ur_st.DISABLED,true);
	if (ur_isSt(oRoot,ur_st.INVALID)) {
		sapUrMapi_Label_setInvalid(sapUrMapi_Label_getInputLabel(sId),false);
		sapUrMapi_Label_setDisabled(sapUrMapi_Label_getInputLabel(sId));
	} else {
	sapUrMapi_Label_setDisabled(sapUrMapi_Label_getInputLabel(sId));
	}		
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_setEnabled
//* parameter   : sId - Id of the checkbox
//*	description	: sets an enabled checkbox to disabled and also the connected
//								label
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_setEnabled(sId) {
	var oIn=ur_get(sId),
		oRoot = ur_get(sId + "-r"),
		oLbl=ur_get(sId + "-lbl"),
		oImg=ur_get(sId + "-img");
	var newClass = "";
	oLbl.className=oLbl.className.replace("Dsbl","");
	oLbl.className=oLbl.className.replace("Ro","");
	oLbl.className=oLbl.className.replace("Inv","");
	oImg.className=oImg.className.replace("Dsbl","");
	oImg.className=oImg.className.replace("Ro","");
	oImg.className=oImg.className.replace("Inv","");
	
	// csn: 1635195 bug: radiobuttons don't work in IE9 Quirks Mode
	newClass=oImg.className;
	oImg.className="";
	oImg.className=newClass;
	
	oIn.disabled=false;
	ur_setSt(oRoot,ur_st.DISABLED,false);
	ur_setSt(oRoot,ur_st.READONLY,false);
	ur_setSt(oRoot,ur_st.INVALID,false);
	sapUrMapi_setTabIndex(oRoot,"0");
	sapUrMapi_Label_setInvalid(sapUrMapi_Label_getInputLabel(sId),false);
	sapUrMapi_Label_setEnabled(sapUrMapi_Label_getInputLabel(sId));
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_setReadonly
//* parameter   : sId - Id of the checkbox
//*								bSet - set/unset the checkbox readonly
//*	description	: sets/unsets a checkbox readonly and the connected
//								label enabled
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_setReadonly(sId,bSet){
	var oIn=ur_get(sId),
		oRoot = ur_get(sId + "-r"),
		oLbl=ur_get(sId+"-lbl"),
		oImg=ur_get(sId+"-img"),
		sClass="",
		newClass = "";
	if(bSet){
		if (ur_isSt(oRoot,ur_st.READONLY)) return;
		if (ur_isSt(oRoot,ur_st.DISABLED)){
			return;
		}
		if (ur_isSt(oRoot,ur_st.INVALID)){
			sClass = "Inv";
		}
		if (ur_isSt(oRoot,ur_st.SELECTED))
			oImg.className=oImg.className.replace("On" +sClass,"On" + sClass +"Ro");
		else if (ur_isSt(oRoot,ur_st.UNDEFINED))
			oImg.className=oImg.className.replace("Ind"+sClass,"Ind" + sClass +"Ro");			
		else
			oImg.className=oImg.className.replace("Off"+sClass,"Off" + sClass +"Ro");	
			
		// csn: 1635195 bug: radiobuttons don't work in IE9 Quirks Mode	
		newClass=oImg.className;
		oImg.className="";
		oImg.className=newClass;
			
		oIn.disabled=true;	
		ur_setSt(oRoot,ur_st.READONLY,true);
		if (ur_system.is508) {
			sapUrMapi_setTabIndex(oRoot,"0");
		} else {
			sapUrMapi_setTabIndex(oRoot,"-1");
		}
		
	} else {
		if (!ur_isSt(oRoot,ur_st.DISABLED)) {
			if (ur_isSt(oRoot,ur_st.INVALID)){
				sapUrMapi_CheckBox_setEnabled(sId);
				sapUrMapi_CheckBox_setInvalid(sId);
			} else {
				sapUrMapi_CheckBox_setEnabled(sId);
			}
	
	}
		ur_setSt(oRoot,ur_st.READONLY,false);
	}
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_setInvalid
//* parameter   : sId - Id of the checkbox
//*	description	: sets invalid state
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_setInvalid(sId) {
	var oIn=ur_get(sId),
		oRoot = ur_get(sId + "-r"),
		oLbl=ur_get(sId+"-lbl");
		oImg=ur_get(sId+"-img");
		var newClass = "";
	if (ur_isSt(oRoot,ur_st.INVALID) || ur_isSt(oRoot,ur_st.DISABLED)) return;
	oLbl.className=oLbl.className.replace("Lbl","LblInv");
	oImg.className=oImg.className.replace("Off","OffInv");
	oImg.className=oImg.className.replace("On","OnInv");
	oImg.className=oImg.className.replace("Ind","IndInv");
	
	// csn: 1635195 bug: radiobuttons don't work in IE9 Quirks Mode	
	newClass=oImg.className;
	oImg.className="";
	oImg.className=newClass;
	
	ur_setSt(oRoot,ur_st.INVALID,true);
	sapUrMapi_Label_setInvalid(sapUrMapi_Label_getInputLabel(sId),true);
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_focus
//* parameter   : sId - Id of the checkbox
//*								oEvt - event object
//*	description	: show data tip
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_focus(sId,oEvt) {
	sapUrMapi_DataTip_show(sId,"focus");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_blur
//* parameter   : sId - Id of the checkbox
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_blur(sId,oEvt) {
	sapUrMapi_DataTip_hide(sId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_CheckBox_keydown
//* parameter   : sId - Id of the checkbox
//* ------------------------------------------------------------------------
function sapUrMapi_CheckBox_keydown(sId,oEvt) {

	if(oEvt.keyCode==73 && oEvt.shiftKey && sapUrMapi_bCtrl(oEvt) ){
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
		return ur_EVT_cancel(oEvt);
	}
	
	else if(oEvt.keyCode==27){
		sapUrMapi_DataTip_hide(sId);
		return ur_EVT_cancel(oEvt);
	}
	
	else if(oEvt.keyCode==32 && !oEvt.altKey && !sapUrMapi_bCtrl(oEvt) ){
		var o=ur_EVT_src(oEvt);
		if(o) {
			o.click();
			ur_EVT_cancel(oEvt);
		}
	}
}
