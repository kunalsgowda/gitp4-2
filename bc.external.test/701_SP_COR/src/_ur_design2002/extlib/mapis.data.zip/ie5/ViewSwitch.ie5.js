//* ------------------------------------------------------------------------
//* function    : ur_VS_sel
//* parameter   : oEvt the event object of the original event
//* return      : none
//*	description	: fires the select event of the framework stored in osel
//* ------------------------------------------------------------------------
function ur_VS_sel(oEvt) {
  var o=ur_VS_getObj(oEvt).ref;
  oItm=ur_EVT_src(oEvt);
  while (oItm.getAttribute && (oItm.getAttribute("idx")==null || oItm.getAttribute("idx")=="")) {
    oItm=oItm.parentNode;
    if (oItm.tagName=="TR") return;
  }
  var iIdx=parseInt(oItm.getAttribute("idx"));
  var sSt=oItm.getAttribute("st");
  if (sSt.indexOf("d")==-1) { 
	  	ur_EVT_fire(oItm,"osel",oEvt);
	}
}

//* ------------------------------------------------------------------------
//* function    : ur_VS_getObj
//* parameter   : oEvt the event object
//* return      : object representation of the viewswitch control
//*	description	: builds a object representation of the viewswitch control 
//*               o.ref is the viewswitch outer object 
//*               o.items array carries the items in the viewwitch
//* ------------------------------------------------------------------------
function ur_VS_getObj(oEvt) {
  var o={ref:ur_getRootObj(ur_EVT_src(oEvt))};
  var items=new Array();
  for (var i=0;i<o.ref.firstChild.childNodes.length;i++)
    items.push(o.ref.firstChild.childNodes[i].firstChild);
  o["items"]=items;
  o["selected"]=o.ref.getAttribute("sidx");
  return o;
}
//* ------------------------------------------------------------------------
//* function    : ur_VS_cl
//* parameter   : oEvt the event object
//* return      : 
//*	description	: Handles the on click event on the viewswitch level
//*               and fires the select event
//* ------------------------------------------------------------------------
function ur_VS_cl(oEvt)
{
    if (!oEvt) oEvt=event; //if no event is given take the one from window
    ur_VS_sel(oEvt); //fire the select view event
}

//* ------------------------------------------------------------------------
//* function    : ur_VS_kd
//* parameter   : oEvt the event object
//* return      : 
//*	description	: Handles the on keydown event on the viewswitch level
//*               and fires the select event if space or return was pressed
//*               triggers the keyboard navigation for vertical 
//* ------------------------------------------------------------------------
function ur_VS_kd(oEvt) {

  if (!oEvt) oEvt=event;
  if (oEvt.keyCode==32 || oEvt.keyCode==13) {
    ur_VS_sel(oEvt);
    ur_EVT_cancel(oEvt);
  }
  else if(oEvt.keyCode==38 || oEvt.keyCode==40){
  	ur_VS_ac(oEvt);
  }
 var o=ur_VS_getObj(oEvt);
   ur_KY_nav(oEvt,o);

}

function ur_VS_ac(oEvt) 
{
   var o=ur_VS_getObj(oEvt);
   var aItms=o.ref.getElementsByTagName("TR");
   
   var oCur=ur_EVT_src(oEvt);
   var iIdx= parseInt(oCur.getAttribute("idx"));

   if(oEvt.keyCode==38) 
   	  iIdx=iIdx-1;
   	else if(oEvt.keyCode==40) 
   	  iIdx=iIdx+1;

   if(iIdx<0 || iIdx>aItms.length)return;
   if(aItms[iIdx]==null)return;
   
   ur_focus_Itm(aItms[iIdx].firstChild,oCur);
}
function ur_VS_mm(oEvt) {
  
}

