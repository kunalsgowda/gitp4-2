//* ************************************************************************
//* Tray
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_RegisterCreate
//* parameter   : sId - string - Id of the Tray
//*				: bScroll - boolean - indicates whether the tray is scrollable
//*				: bCollapsed - boolean - indicates whether the tray is collapsed
//* description : Registers the tray with the create item registry to be
//*				  initialized when the page loads
//* return      : none
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_RegisterCreate(sId, bScroll, bCollapsed) {
	//sapUrMapi_Create_AddItem(sId, "sapUrMapi_Tray_create('" + sId + "',"+bScroll+","+bCollapsed+")");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_create
//* parameter   : sId  - string - Id of the Tray
//* 			: bScroll - boolean - indicates weather the Tray is scrollable
//*  			: bCollapsed - boolean - indicates weather the Tray is collapsed
//* description : This is a dummy function to be implemented in the future.
//*               It is used in Netscape though
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_create(sId,bScroll,bCollapsed) {
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_showOptionMenu
//* parameter   : sTrayId    - string - Id of the Tray
//  							sTriggerId - string - The Id of the DOM Objects that
//                                      is the trigger for the menu
//  							sMenuContentId - string- The Id of the DOM Objects that
//                                         contains the menu
//  							enumPositionBehavior - string- Defines at which position the PopupMenu
//																			 will appear. Default is Right for ltr.
//							  e - EventObject - the events object
//* description : Opens the Menu that is applied as option menu to that tray.
//								There is an icon shown if a menu is connected to the tray
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_showOptionMenu2(sTrayId,sMenuContentId,oEvt) {
 	if (ur_system.direction=="rtl")
	  sapUrMapi_Tray_showOptionMenu(sTrayId,sTrayId+"-menu",sMenuContentId,sapPopupPositionBehavior.MENULEFT,oEvt) 
	else
	  sapUrMapi_Tray_showOptionMenu(sTrayId,sTrayId+"-menu",sMenuContentId,sapPopupPositionBehavior.MENURIGHT,oEvt) 
}

function sapUrMapi_Tray_showOptionMenu(sTrayId,sTriggerId,sMenuContentId,enumPositionBehavior,e) {
	if (e.type!="click") {
		if (!sapUrMapi_checkKey(e,"keydown",new Array("32","40"))) {
		  return false;
	  } else {
		  ur_EVT_cancel(e);
		}
	}
	sapUrMapi_PopupMenu_showMenu(sTriggerId,sMenuContentId,enumPositionBehavior,e);
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_toggle
//* parameter   : sTrayId    - string - Id of the Tray
//							  e - EventObject - the events object
//* description : Expand / Collapses the tray
//* return      : none
//*	sample			:
//* ------------------------------------------------------------------------

function sapUrMapi_Tray_toggle(sTrayId,e)
{
	ur_EVT_cancelBubble(e);
	var elBody = ur_get(sTrayId+"-bd"); 
	var elHeader = ur_get(sTrayId+"-hd");
	var oTray = ur_get(sTrayId);
	var elExp = ur_get(sTrayId+"-exp");

	if ( elBody != null && elExp != null )
	{
		var sScrollMode = elBody.getAttribute("scrlMode"),
			iHeight = elBody.getAttribute("cntHeight"),
			oTbar = ur_get(sTrayId+"-tbar"),
			oTbody = ur_get(sTrayId+"-height");
		if ( elBody.style.visibility == "hidden" )
		{
			if (oTbar != null) oTbar.style.display = "block";
			elBody.style.visibility = "inherit";
			elBody.style.overflow = sScrollMode;
			elBody.style.height = "100%";
			oTbody.parentNode.className = oTbody.parentNode.className.replace(" urTryCTransBody", "");
			oTbody.style.height = iHeight;
			
			ur_setSt(oTray,ur_st.COLLAPSED,false);
			ur_setSt(oTray,ur_st.EXPANDED,true);
			sapUrMapi_Focus_showFocusRect();
			if (elExp.className.indexOf("Closed") != -1)
			{
				var re = /Closed/gi;
				var clsNm = elExp.className;
				
				elExp.className = clsNm.replace(re, "Open");
			}
			if (elHeader.className == "urTrcHdBgClosedIco" )	elHeader.className = "urTrcHdBgOpenIco";
			elExp.title=getLanguageText("SAPUR_TY_BTNE");
			sapUrMapi_refocusElement(oTray);
		} 
		else
		{
			if (oTbar != null) oTbar.style.display = "none";
			elBody.style.overflow = "hidden";
			elBody.style.height = "1px";
			oTbody.style.height = "1px";
			oTbody.parentNode.className = oTbody.parentNode.className + " urTryCTransBody";
			elBody.style.visibility = "hidden";
			//elBody.style.width = "1px";
			
			ur_setSt(oTray,ur_st.COLLAPSED,true);
			ur_setSt(oTray,ur_st.EXPANDED,false);
			sapUrMapi_Focus_showFocusRect();
			if (elExp.className.indexOf("Open") != -1)
			{
				var re = /Open/gi;
				var clsNm = elExp.className;
				
				elExp.className = clsNm.replace(re, "Closed");
				
			}
			if (elHeader.className == "urTrcHdBgOpenIco" ) elHeader.className = "urTrcHdBgClosedIco";
			elExp.title=getLanguageText("SAPUR_TY_BTNC");
			sapUrMapi_refocusElement(oTray);
		}
	}
	return true;
}
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_Tray_keydown
//* parameter   : sTrayId - Id of the Tray using keydown
//*							e - event object
//* return      : true if keydown was successful
//*	description	: The keydown event is captured and checked for skipping and toggle events.
//* ------------------------------------------------------------------------
function sapUrMapi_Tray_keydown(sTrayId,e)
{
	var elBody = ur_get(sTrayId+"-tbd"); //tray body
	var elHeader = ur_get(sTrayId+"-hd");
	var oSkip=document.getElementById(sTrayId);
	var sCt=ur_EVT_src(e).ct;
	// numpad +: expand tray 
	if(e.keyCode==107 && !ur_isSt(oSkip,ur_st.DISABLED) && ur_isSt(oSkip,ur_st.COLLAPSED) && sCt=="TY")
		{
			sapUrMapi_Tray_toggle(sTrayId,e);
			sapUrMapi_DBTN_showDBtn();
		return true;
	 }
	 // numpad -: collapse tray
	 else  if(e.keyCode==109 && !ur_isSt(oSkip,ur_st.DISABLED) && ur_isSt(oSkip,ur_st.EXPANDED) && sCt=="TY")
		 {
			 sapUrMapi_Tray_toggle(sTrayId,e);
			 sapUrMapi_DBTN_hideDBtn(); 
		 return true;
	 }
	  else if(e.keyCode== 13)
	 {
		sapUrMapi_triggerDefaultButton(sTrayId,e);
	 }	 
	 else
		return sapUrMapi_skip(sTrayId,e);	
     
}
