//* ************************************************************************
//* RadioButton
//* ************************************************************************
//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_registerCreate
//* parameter   : sId - Id of the radiobutton 
//* return      : 
//*	description	: register the radiobutton cretae function
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_registerCreate(sId) {
	sapUrMapi_Create_AddItem(sId, "sapUrMapi_RadioButton_create('"+sId+"')");
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_create
//* parameter   : sId - Id of the radiobutton 
//* return      : 
//*	description	: Special handling for inerHtml exchange to enable
//*								correct keyboard navigation with arrow keys for
//*								the radiobuttons.
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_create(sId) {
	var o=ur_get(sId);
	if(o==null || !o.checked ) return;
	o.checked=false;
	o.checked=true;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_toggle
//* parameter   : sId - string Id of the radiobuttom to toggle
//* return      : true if the radiobutton was toggeled
//*	description	: checks the radiobutton specified by sId (and unchecks all others)
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_toggle(sId,e) {
	if(e.type=="keydown" && (e.ctrlLeft || e.ctrlRight)) return;
  var oIn=ur_get(sId);
  var oImg=ur_get(sId+"-img");
  if (ur_isSt(oIn,new Array(ur_st.DISABLED)) || ur_isSt(oIn,new Array(ur_st.READONLY))) return false;
  var oInGrp=new Array();
  var newClass = "";
  if(oIn.name!="") 
		oInGrp=document.getElementsByName(oIn.name);
	else
		oInGrp[0]=oIn;
  oIn.checked=true;
  ur_setSt(oIn,ur_st.SELECTED,true);
  ur_setSt(oIn,ur_st.NOTSELECTED,false);
  oImg.className=oImg.className.replace("Off","On");
  ur_focus(oIn);
  for(var i=0;i<oInGrp.length;i++){
	  oImg=ur_get(oInGrp[i].id+"-img");
	  if (oImg==null || oIn==oInGrp[i]) continue; 
	  if(ur_isSt(oInGrp[i],ur_st.SELECTED)){ 
			oImg.className=oImg.className.replace("On","Off");
			ur_setSt(oInGrp[i],ur_st.SELECTED,false);
			ur_setSt(oInGrp[i],ur_st.NOTSELECTED,true);			
		}
  }
  // csn: 1635195 bug: radiobuttons don't work in IE9 Quirks Mode	
  newClass=oImg.className;
  oImg.className="";
  oImg.className=newClass;
  if (ur_system.is508) oIn.fireEvent("onactivate");
  return true;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_setDisabled
//* parameter   : sId - string Id of the radiobutton
//* description	: sets an enabled radiobutton to disabled and also the connected
//								label
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_setDisabled(sId) {
	sapUrMapi_CheckBox_setDisabled(sId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_setEnabled
//* parameter   : sId - string Id of the radiobutton
//* description	: sets an disabled radiobutton to enabled and also the connected
//								label
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_setEnabled(sId) {
	sapUrMapi_CheckBox_setEnabled(sId); 	
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_setReadonly
//* parameter   : sId - Id of the checkbox
//*								bSet - set/unset the checkbox readonly
//*	description	: sets/unsets a radiobutton readonly and the connected
//								label enabled
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_setReadonly(sId,bSet){
	sapUrMapi_CheckBox_setReadonly(sId,bSet);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_setInvalid
//* parameter   : sId - Id of the radio button
//*	description	: sets the invalid state
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_setInvalid(sId){
	sapUrMapi_CheckBox_setInvalid(sId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_focus
//* parameter   : sId - string Id of the checkbox
//*								oEvt - event object
//*	description	: show data tip
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_focus(sId,oEvt) {
	sapUrMapi_DataTip_show(sId,"focus");
//	var sHlp=sapUrMapi_DataTip_getText(sId);
//	var sRt=ur_get(sId).title;
//	sRt = sRt + " "+sHlp;
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_blur
//* parameter   : sId - string Id of the checkbox
//*								oEvt - event object
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_blur(sId,oEvt) {
	sapUrMapi_DataTip_hide(sId);
}

//* ------------------------------------------------------------------------
//* function    : sapUrMapi_RadioButton_keydown
//* parameter   : sId - string Id of the checkbox
//*								oEvt - event object
//* ------------------------------------------------------------------------
function sapUrMapi_RadioButton_keydown(sId,oEvt) {
  var iKey=oEvt.keyCode;	
  if(iKey==37)
		iKey==ur_system.direction!="rtl"?37:39;
	else if(iKey==39)
		iKey==ur_system.direction!="rtl"?39:37;

	// show data tip when you press ctrl+shift+i (old key ctrl+q)
	if( oEvt.keyCode==73 && oEvt.shiftKey && sapUrMapi_bCtrl(oEvt) ){
		if (sapUrMapi_DataTip_isOpen(sId)) sapUrMapi_DataTip_hide(sId);
		else sapUrMapi_DataTip_show(sId,"keydown");
		return ur_EVT_cancel(oEvt);
	}
	
	// escape
	else if(oEvt.keyCode == "27"){
		sapUrMapi_DataTip_hide(sId);
		return ur_EVT_cancel(oEvt);		
	}
	
	// arrow left and up
	else if(iKey==37 || iKey==38){		 
		var oIn=ur_get(sId);
		if(!(oIn.disabled || oEvt.shiftKey)) return;
		var oInGrp=document.getElementsByName(oIn.name);
		for(var i=0; i<oInGrp.length;i++)
			if(oInGrp[i]==oIn) break;
		if(i>0) i-=1;
		if(oInGrp[i].disabled) oIn=ur_get(oInGrp[i].id+"-lbl");
		else oIn=oInGrp[i];
		ur_focus(oIn);
		sapUrMapi_Focus_showFocusRect(oIn.id);
		return ur_EVT_cancel(oEvt);
	}

	// arrow right and down
	else if(iKey==39 || iKey==40){
		var oIn=ur_get(sId);
		if(!(oIn.disabled || oEvt.shiftKey)) return;
		var oInGrp=document.getElementsByName(oIn.name);
		for(var i=0; i<oInGrp.length;i++)
			if(oInGrp[i]==oIn) break;
		if(i<oInGrp.length-1) i+=1;
		if(oInGrp[i].disabled) oIn=ur_get(oInGrp[i].id+"-lbl");
		else oIn=oInGrp[i];
		ur_focus(oIn);
		sapUrMapi_Focus_showFocusRect(oIn.id);
		return ur_EVT_cancel(oEvt);
	}
	// jump out of group
/*	else if(iKey==9){
		var oIn=ur_get(sId);
		var oInGrp=document.getElementsByName(oIn.name);
		for(var i=0; i<oInGrp.length;i++){
			if(oInGrp[i].st.indexOf("s")>-1){
				var oSel=oInGrp[i];
				if(oInGrp[i].st.indexOf("d")>-1)
					oSel=ur_get(oInGrp[oInGrp.length-1].id+"-lbl");
					
				ur_focus_Itm(oSel,oIn);
				break;
			}
		}
	}*/
}

