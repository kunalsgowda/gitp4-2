function sapUrMapi_TextView_menuActivate(sTextViewId,e) {
}
function sapUrMapi_TextView_focus(sId,oEvt) {

}