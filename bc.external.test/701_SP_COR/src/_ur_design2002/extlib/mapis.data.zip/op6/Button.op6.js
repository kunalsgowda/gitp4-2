//* Button
function sapUrMapi_Button_checkClick(sId,oEvt){
	if (oEvt.type=="click") return true;
	return sapUrMapi_checkKey(oEvt,"keypress",new Array("32"))
}
