function sapUrMapi_TabStrip_RegisterCreate(sId,iCount,iActive) {
}
function 	sapUrMapi_TabStrip_create(sId,iCount,iActive) {
}
function sapUrMapi_TabStrip_keySelect(strId, intSelectedIdx, intTabCount,e) {
}
function sapUrMapi_TabStrip_focusItem(sTabStripId,iFocusIdx,iTabCount,bNext,bPrev) {
}
function sapUrMapi_TabStrip_enter (sId,e) {
}
function sapUrMapi_TabStrip_setActiveItem(sId,iIdx) {
	return true	
}
function ur_TS_cl(sId,evt) {
}
function ur_TS_oadi(sId) {
}
function ur_TS_setPagiButtonState(iFirst,iLast,sId) {
}
function sapUrMapi_TabStripItem_keydown(sId,evt) {
}