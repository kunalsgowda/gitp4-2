function sapUrMapi_triggerFocus(sId) {}
function sapUrMapi_initLinkStatus() {}
var sapUrMapi_Create_Registry = new Array();
var sapUrMapi_Create_Apply = new Array();
var sapUrMapi_Resize_Registry = new Array();
function sapUrMapi_Create_CreateItems() {
	if (document.readyState != "complete") return;
	else {
		for (var ctl in sapUrMapi_Create_Registry) {
			if (ctl.indexOf("_") == 0) {continue;}
			if (sapUrMapi_Create_Registry[ctl] != null) {
				eval(sapUrMapi_Create_Registry[ctl].sHandler);
			}
		}
		sapUrMapi_Create_Registry = new Array();
		for (var ctl in sapUrMapi_Create_Apply) {
			if (ctl.indexOf("_") == 0) {continue;}
			if (sapUrMapi_Create_Apply[ctl] != null) {
				eval(sapUrMapi_Create_Apply[ctl].sHandler);
			}
		}
		sapUrMapi_Create_Apply = new Array();		
	}
}
function sapUrMapi_init() {
  oPopup=null;
  oDatePicker=null;
  sapUrMapi_Resize_Registry=new Array();
}
function ur_evtSrc(e){return e.srcElement;}
function ur_get(sId) {
  return document.getElementById(sId);
}
